@echo off
setlocal EnableExtensions EnableDelayedExpansion
rem ==========================================================================
rem  Nightfull - one-click Release x64 build (MSVC, /MT, /O2).
rem  Finds any Visual Studio with the C++ workload (incl. 2026 / Insiders /
rem  Preview) through vswhere, sets up the x64 toolchain and builds
rem  build\Nightfull.dll + copies fonts\ next to it.
rem ==========================================================================
cd /d "%~dp0"

set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
    echo [!] vswhere.exe not found. Install Visual Studio with "Desktop development with C++".
    goto :fail
)
set "VSDIR="
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -prerelease -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSDIR=%%i"
if not defined VSDIR (
    echo [!] No Visual Studio with the MSVC x64 toolset found.
    goto :fail
)
echo [*] Visual Studio: %VSDIR%
call "%VSDIR%\VC\Auxiliary\Build\vcvarsall.bat" x64 >nul
if errorlevel 1 ( echo [!] vcvarsall failed & goto :fail )

set "OUT=build"
set "OBJ=build\obj"
if not exist "%OBJ%" mkdir "%OBJ%"

set "SRC=src"
set "TP=src\third_party"
set INCLUDES=/I"%SRC%" /I"%TP%\imgui" /I"%TP%\minhook\include" /I"%TP%\entt"
set DEFINES=/DNDEBUG /D_WINDOWS /D_USRDLL /DUNICODE /D_UNICODE /DNOMINMAX /D_CRT_SECURE_NO_WARNINGS
set CFLAGS=/nologo /c /MP /O2 /Ob2 /MT /W3 /utf-8 /GS /Gy %DEFINES% %INCLUDES%
set CXXFLAGS=%CFLAGS% /std:c++20 /EHsc /Zc:__cplusplus /bigobj

set CPP=
for %%f in (
    "%SRC%\dllmain.cpp"
    "%SRC%\core\module_guard.cpp" "%SRC%\core\module_manager.cpp"
    "%SRC%\modules\client_modules.cpp" "%SRC%\modules\game_modules.cpp"
    "%SRC%\modules\hud_modules.cpp" "%SRC%\modules\registry.cpp" "%SRC%\modules\stub_modules.cpp"
    "%SRC%\overlay\overlay.cpp" "%SRC%\ui\menu.cpp"
    "%SRC%\utils\config.cpp" "%SRC%\utils\fonts.cpp" "%SRC%\utils\gui_render.cpp"
    "%SRC%\utils\gui_theme.cpp" "%SRC%\utils\keys.cpp" "%SRC%\utils\logger.cpp"
    "%TP%\imgui\imgui.cpp" "%TP%\imgui\imgui_draw.cpp" "%TP%\imgui\imgui_tables.cpp"
    "%TP%\imgui\imgui_widgets.cpp" "%TP%\imgui\imgui_impl_win32.cpp"
    "%TP%\imgui\imgui_impl_dx11.cpp" "%TP%\imgui\imgui_impl_dx12.cpp"
) do set CPP=!CPP! %%f
set C=
for %%f in (
    "%TP%\minhook\src\buffer.c" "%TP%\minhook\src\hook.c" "%TP%\minhook\src\trampoline.c"
    "%TP%\minhook\src\hde\hde64.c"
) do set C=!C! %%f

echo [*] Compiling C++ ...
cl %CXXFLAGS% /Fo"%OBJ%\\" %CPP%
if errorlevel 1 ( echo [!] C++ compile failed & goto :fail )
echo [*] Compiling MinHook ...
cl %CFLAGS% /Fo"%OBJ%\\" %C%
if errorlevel 1 ( echo [!] C compile failed & goto :fail )

echo [*] Linking ...
link /nologo /DLL /MACHINE:X64 /OPT:REF /OPT:ICF /INCREMENTAL:NO /OUT:"%OUT%\Nightfull.dll" ^
    "%OBJ%\*.obj" d3d11.lib d3d12.lib dxgi.lib d3dcompiler.lib dxguid.lib psapi.lib ^
    user32.lib gdi32.lib kernel32.lib ole32.lib shell32.lib advapi32.lib dwmapi.lib imm32.lib version.lib
if errorlevel 1 ( echo [!] link failed & goto :fail )

if exist "%SRC%\fonts" xcopy /y /i /q "%SRC%\fonts" "%OUT%\fonts" >nul
echo.
echo [+] Done: %OUT%\Nightfull.dll  (inject it; keep the fonts\ folder next to the dll)
endlocal & exit /b 0

:fail
echo.
echo [x] Build failed.
endlocal & pause & exit /b 1
