// menu.h - the Nightfull ClickGUI (single polished renderer).
//
// Layout: the attached Nightfull shell — brand/command/status topbar,
// profile/category sidebar, three-column module board and Settings/Themes/HUD
// inspector tabs. All existing module behavior and local configuration flows
// remain available.

#pragma once

namespace nf {

class Module;   // core/module.h

namespace ui {

// Register modules + load config + reset state (once, after ImGui context).
bool Init();
// Flush config (unload path).
void Shutdown();

// Full per-frame UI pass. Runs inside the ImGui frame: pushes the theme,
// dispatches keybinds, ticks+renders modules (HUD), autosaves the config
// and draws the menu while it is open or fading.
void Frame();

// Dismiss the topmost transient UI (text field, dropdown, popup, bind
// capture). Returns true when something was dismissed (ESC handling).
bool DismissTopmost();

// Bottom-left notification ("[Nightfull] ...").
void Toast(const char* fmt, ...);

// Open the ClickGUI on a module's settings page (HUD editor right-click
// parity): selects the module, shows the inspector and raises the menu.
void OpenModuleSettings(Module* m);

} // namespace ui
} // namespace nf
