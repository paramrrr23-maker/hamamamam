// dllmain.cpp - DLL entry point (thin layer over the overlay engine).
//
// Attach: spawn the worker thread and return immediately (no D3D/ImGui work
// on the loader lock). Detach: ask the engine for best-effort teardown.

#include <Windows.h>

#include "overlay/overlay.h"

namespace {

DWORD WINAPI AttachThread(LPVOID param) {
    nf::overlay::MainThread((HMODULE)param);
    return 0;
}

} // namespace

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hModule);
        HANDLE h = CreateThread(nullptr, 0, AttachThread, hModule, 0, nullptr);
        if (h) CloseHandle(h);
    } else if (reason == DLL_PROCESS_DETACH) {
        nf::overlay::NotifyDetach();
    }
    return TRUE;
}
