// gui_theme.cpp - the cycling accent engine + naming styles.

#include "utils/gui_theme.h"

#include <Windows.h>
#include <cctype>
#include <cmath>
#include <cstring>

#include "utils/gui_render.h"

namespace nf {
namespace gui {
namespace {

struct Preset { const char* name; ImColor a; ImColor b; };

const Preset kPresets[] = {
    { "Ember Dusk",   ImColor(0xD9, 0x77, 0x57), ImColor(0xF0, 0xB3, 0x6F) },
    { "Mint Glass",   ImColor(0x70, 0xB9, 0x9A), ImColor(0xB8, 0xD4, 0x8A) },
    { "Moon Rose",    ImColor(0xC7, 0x79, 0x8C), ImColor(0xF0, 0xB0, 0xA0) },
    { "Arctic Slate", ImColor(0x83, 0xA5, 0xB7), ImColor(0xC2, 0xD4, 0xD5) },
    { "Amethyst Fog", ImColor(0xA8, 0x83, 0xB7), ImColor(0xD2, 0xAF, 0xD0) },
    { "Mono Bone",    ImColor(0xB0, 0xAE, 0xA5), ImColor(0xFA, 0xF9, 0xF5) },
    { "Cyan",         ImColor(0xA4, 0xD8, 0xD0), ImColor(0x76, 0xB7, 0xAE) },
    { "Red",          ImColor(0xD9, 0xA0, 0xA0), ImColor(0xB9, 0x7F, 0x87) },
    { "Custom",       ImColor(0xD9, 0x77, 0x57), ImColor(0xD9, 0x77, 0x57) },
};
constexpr int kPresetCount = (int)(sizeof(kPresets) / sizeof(kPresets[0]));
constexpr int kCustomTheme = 8;

int g_theme = 0;
int g_naming = 3;
int g_customCount = 3;
ImColor g_custom[6] = {
    ImColor(0xD9, 0x77, 0x57), ImColor(0x77, 0xC5, 0x9A), ImColor(0xC7, 0x79, 0x8C),
    ImColor(0x83, 0xA5, 0xB7), ImColor(0xA8, 0x83, 0xB7), ImColor(0xE2, 0xB5, 0x7F),
};
float g_speed = 3.0f;
float g_saturation = 1.0f;

double NowSeconds() {
    static ULONGLONG s0 = GetTickCount64();
    return (GetTickCount64() - s0) / 1000.0;
}

ImColor ApplySaturation(const ImColor& c, float s) {
    if (s >= 0.999f) return c;
    float h, sat, v;
    ImGui::ColorConvertRGBtoHSV(c.Value.x, c.Value.y, c.Value.z, h, sat, v);
    ImGui::ColorConvertHSVtoRGB(h, sat * Clamp(s, 0.0f, 1.0f), v, h, sat, v);
    return ImColor(h, sat, v, c.Value.w);
}

} // namespace

void SetTheme(int index) { g_theme = (index >= 0 && index < kPresetCount) ? index : 0; }
void SetNamingStyle(int style) { g_naming = (style >= 0 && style <= 3) ? style : 3; }
void SetCustomColorCount(int n) { g_customCount = (n >= 1 && n <= 6) ? n : 3; }
void SetCustomColor(int i, const ImColor& c) { if (i >= 0 && i < 6) g_custom[i] = c; }
void SetColorSpeed(float speed) { g_speed = Clamp(speed, 0.0f, 60.0f); }
void SetSaturation(float s) { g_saturation = Clamp(s, 0.0f, 1.0f); }

ImColor Accent() { return GetThemedColor(0.0f); }

ImColor GetThemedColor(float phase) {
    const double t = NowSeconds() * (double)(g_speed * 0.12f) + (double)phase * 0.15;
    if (g_theme == kCustomTheme) {
        const int n = g_customCount > 0 ? g_customCount : 1;
        const double pos = t * (double)n;
        const int i0 = ((int)std::floor(pos) % n + n) % n;
        const int i1 = (i0 + 1) % n;
        const float f = (float)(pos - std::floor(pos));
        return ApplySaturation(LerpColor(g_custom[i0], g_custom[i1], f), g_saturation);
    }
    const Preset& p = kPresets[g_theme];
    const float f = 0.5f + 0.5f * std::sin((float)t * 6.2831853f);
    return LerpColor(p.a, p.b, f);
}

int ThemeCount() { return kPresetCount; }
const char* ThemeName(int index) {
    return (index >= 0 && index < kPresetCount) ? kPresets[index].name : "?";
}
ImColor ThemeSwatch(int index) {
    return (index >= 0 && index < kPresetCount) ? kPresets[index].a : ImColor(255, 255, 255);
}

const char* ApplyNaming(const char* name) {
    // Rotating static buffers: the menu may hold several results per frame.
    static char s_bufs[8][128];
    static int s_slot = 0;
    char* out = s_bufs[s_slot];
    s_slot = (s_slot + 1) & 7;
    if (!name) { out[0] = 0; return out; }

    char tmp[128];
    size_t len = std::strlen(name);
    if (len > sizeof(tmp) - 8) len = sizeof(tmp) - 8;
    std::memcpy(tmp, name, len);
    tmp[len] = 0;

    // "Spaced" variants insert a space before inner capitals ("MouseStrokes" -> "Mouse Strokes").
    char spaced[128];
    size_t w = 0;
    for (size_t r = 0; r < len && w + 2 < sizeof(spaced); r++) {
        const bool innerCap = r > 0 && tmp[r] >= 'A' && tmp[r] <= 'Z' &&
                              tmp[r - 1] != ' ' && !(tmp[r - 1] >= 'A' && tmp[r - 1] <= 'Z');
        if ((g_naming == 1 || g_naming == 3) && innerCap) spaced[w++] = ' ';
        spaced[w++] = tmp[r];
    }
    spaced[w] = 0;
    if (g_naming <= 1)
        for (size_t i = 0; i < w; i++) spaced[i] = (char)std::tolower((unsigned char)spaced[i]);
    std::strncpy(out, spaced, 128);
    out[127] = 0;
    return out;
}

} // namespace gui
} // namespace nf
