// fonts.cpp - font roles loaded from the fonts/ folder next to the DLL.

#include "utils/fonts.h"

#include <Windows.h>
#include <cstdio>

#include "imgui.h"
#include "utils/config.h"
#include "utils/logger.h"

namespace nf {
namespace fonts {
namespace {

ImFont* g_ui = nullptr;
ImFont* g_uiSemi = nullptr;
ImFont* g_bold = nullptr;
ImFont* g_title = nullptr;
ImFont* g_mono = nullptr;
ImFont* g_icon = nullptr;

// Lucide PUA codepoints used by the menu (see the icon table in menu.cpp).
// Stored statically: the atlas reads the ranges when it builds, after Init.
const ImWchar* IconRanges() {
    static const ImWchar r[] = {
        0x20, 0x7E,         // 'x' (close) lives at ASCII 0x78 in this font
        0xE038, 0xE038,     // activity
        0xE049, 0xE049,     // arrow-right
        0xE04D, 0xE04D,     // arrow-up-right
        0xE059, 0xE059,     // bell
        0xE05F, 0xE05F,     // book-open
        0xE061, 0xE061,     // box
        0xE06C, 0xE06C,     // check
        0xE06D, 0xE06D,     // chevron-down
        0xE06E, 0xE06E,     // chevron-up
        0xE06F, 0xE06F,     // chevron-right
        0xE082, 0xE082,     // circle-help
        0xE0AC, 0xE0AC,     // crosshair
        0xE0B6, 0xE0B6,     // ellipsis (more-horizontal)
        0xE0B9, 0xE0B9,     // external-link
        0xE0DF, 0xE0DF,     // gamepad-2
        0xE0FF, 0xE0FF,     // layout-grid (hotbar)
        0xE113, 0xE113,     // maximize-2
        0xE11D, 0xE11D,     // monitor
        0xE11E, 0xE11E,     // moon
        0xE13D, 0xE13D,     // plus
        0xE151, 0xE151,     // search
        0xE178, 0xE178,     // sun
        0xE180, 0xE180,     // target
        0xE18E, 0xE18E,     // trash-2
        0xE1B4, 0xE1B4,     // zap
        0xE1C1, 0xE1C1,     // layout-dashboard
        0xE1DD, 0xE1DD,     // palette
        0xE1FF, 0xE1FF,     // shield-check
        0xE245, 0xE245,     // settings-2
        0xE284, 0xE284,     // keyboard
        0xE28D, 0xE28D,     // git-fork (repo links)
        0xE29A, 0xE29A,     // sliders-horizontal
        0xE333, 0xE333,     // folder-heart
        0xE412, 0xE412,     // sparkles
        0xE455, 0xE455,     // arrow-down-to-line
        0xE529, 0xE529,     // layers-3
        0,
    };
    return r;
}

ImFont* LoadOne(const wchar_t* path, float px, const char* role,
                const ImWchar* ranges, ImFontConfig* cfg = nullptr) {
    DWORD attrs = GetFileAttributesW(path);
    if (attrs == INVALID_FILE_ATTRIBUTES) {
        LOG_ERROR("fonts: missing %ls (%s) - fallback engaged", path, role);
        return nullptr;
    }
    // ImGui takes UTF-8 narrow paths: convert.
    char narrow[MAX_PATH * 3] = {};
    WideCharToMultiByte(CP_UTF8, 0, path, -1, narrow, sizeof(narrow), nullptr, nullptr);
    ImFont* loaded = ImGui::GetIO().Fonts->AddFontFromFileTTF(narrow, px, cfg, ranges);
    if (!loaded) LOG_ERROR("fonts: failed to load %s (%s)", narrow, role);
    else LOG_INFO("fonts: role %s <- %s", role, narrow);
    return loaded;
}

void PathFor(const wchar_t* base, const wchar_t* file, wchar_t* out, size_t cap) {
    _snwprintf_s(out, cap, _TRUNCATE, L"%s\\%s", base, file);
}

ImFont* WithFallback(ImFont* f) {
    return f ? f : ImGui::GetFont();
}

} // namespace

bool Init(const wchar_t* dllDir) {
    // Candidate font roots, tried in order. A packaged (AppContainer) Bedrock
    // process cannot read files outside its own package storage, so the DLL's
    // own folder is NOT reliably readable even though the image was mapped from
    // there: fonts under <dllDir>\fonts come back "missing" while the very same
    // DLL reads and writes RoamingState without trouble. So try the DLL folder
    // first (unpackaged/dev runs), then the Nightfull RoamingState dir, which is
    // always readable from inside the package.
    std::wstring bases[2];
    {
        wchar_t primary[MAX_PATH] = {};
        _snwprintf_s(primary, _TRUNCATE, L"%s\\fonts", dllDir ? dllDir : L".");
        bases[0] = primary;
    }
    if (!config::baseDir().empty()) bases[1] = config::baseDir() + L"\\fonts";
    LOG_INFO("fonts: dir %ls", bases[0].c_str());
    if (!bases[1].empty() && bases[1] != bases[0])
        LOG_INFO("fonts: fallback dir %ls", bases[1].c_str());

    // Resolves the first existing copy of a face across the candidate roots. The
    // existence probe keeps the "missing" error to one line per role instead of
    // one per root.
    auto LoadFirst = [&](const wchar_t* file, float px, const char* role,
                         const ImWchar* ranges) -> ImFont* {
        wchar_t path[MAX_PATH] = {};
        for (const std::wstring& root : bases) {
            if (root.empty()) continue;
            PathFor(root.c_str(), file, path, MAX_PATH);
            if (GetFileAttributesW(path) == INVALID_FILE_ATTRIBUTES) continue;
            if (ImFont* font = LoadOne(path, px, role, ranges)) return font;
        }
        if (!bases[0].empty()) {
            PathFor(bases[0].c_str(), file, path, MAX_PATH);
            LoadOne(path, px, role, ranges);   // reports the miss
        }
        return nullptr;
    };

    // Last-resort source: the Windows system font always has Cyrillic, so
    // text stays readable when fonts/ did not travel with the DLL. (If the
    // sandbox blocks the read, roles fall through to the ImGui default.)
    wchar_t sysFont[MAX_PATH] = {};
    {
        wchar_t windir[MAX_PATH] = {};
        GetWindowsDirectoryW(windir, MAX_PATH);
        _snwprintf_s(sysFont, _TRUNCATE, L"%s\\Fonts\\arial.ttf", windir);
    }
    auto sysfix = [&](ImFont** slot, float px, const char* role, const ImWchar* ranges) {
        if (*slot) return;
        *slot = LoadOne(sysFont, px, role, ranges);
        if (*slot) LOG_INFO("fonts: %s via system fallback", role);
    };

    // ImGui's Cyrillic ranges already include Basic Latin + Latin-1.
    const ImWchar* textRanges = ImGui::GetIO().Fonts->GetGlyphRangesCyrillic();
    const ImWchar* iconRanges = IconRanges();

    struct Job { const wchar_t* file; float px; ImFont** out; const char* role;
                 const ImWchar* ranges; };
    // The Nightfull reference uses a compact mono shell. Use the bundled
    // JetBrains Mono face for every ClickGUI text role so the native overlay
    // follows that same typography instead of the older rounded Manrope look.
    // Atlas sizes are 1.5x the original (text roles 20->30, Mono 16->24): the
    // design space draws text in units mapped through kFontUnit, so bigger
    // glyphs at the same unit size read as larger text everywhere in the GUI
    // and the HUD (they share this atlas). Icons scale with it so a glyph
    // keeps matching its label.
    // HTML prototype font stack (Inter, system-ui, ...): Segoe UI is the
    // Windows system-ui face, so the ClickGUI + HUD text roles use it first.
    // JetBrains Mono stays for the Mono role and as the packaged fallback
    // when the sandbox hides system fonts; Lucide icons are unchanged.
    wchar_t segoeFont[MAX_PATH] = {};
    {
        wchar_t windir[MAX_PATH] = {};
        GetWindowsDirectoryW(windir, MAX_PATH);
        _snwprintf_s(segoeFont, _TRUNCATE, L"%s\\Fonts\\segoeui.ttf", windir);
    }
    auto segoefix = [&](ImFont** slot, float px, const char* role, const ImWchar* ranges) {
        if (*slot) return;
        *slot = LoadOne(segoeFont, px, role, ranges);
        if (*slot) LOG_INFO("fonts: %s via system sans", role);
    };

    Job jobs[] = {
        { L"JetBrainsMono-Regular.ttf", 24.0f, &g_mono,   "Mono",   textRanges },
        { L"lucide.ttf",                30.0f, &g_icon,   "Icon",   iconRanges },
    };
    bool allOk = true;
    for (const Job& j : jobs) {
        *j.out = LoadFirst(j.file, j.px, j.role, j.ranges);
        if (!*j.out) allOk = false;
    }

    // UI text roles: system sans primary, bundled JetBrains fallback.
    segoefix(&g_ui, 30.0f, "UI", textRanges);
    segoefix(&g_uiSemi, 30.0f, "UISemi", textRanges);
    segoefix(&g_bold, 30.0f, "Bold", textRanges);
    segoefix(&g_title, 33.0f, "Title", textRanges);
    if (!g_ui) { g_ui = LoadFirst(L"JetBrainsMono-Regular.ttf", 30.0f, "UI", textRanges); }
    if (!g_uiSemi) { g_uiSemi = LoadFirst(L"JetBrainsMono-Regular.ttf", 30.0f, "UISemi", textRanges); }
    if (!g_bold) { g_bold = LoadFirst(L"JetBrainsMono-Regular.ttf", 30.0f, "Bold", textRanges); }
    if (!g_title) { g_title = LoadFirst(L"JetBrainsMono-Regular.ttf", 33.0f, "Title", textRanges); }
    if (!g_ui || !g_uiSemi || !g_bold || !g_title) allOk = false;
    sysfix(&g_ui, 30.0f, "UI", textRanges);
    sysfix(&g_uiSemi, 30.0f, "UISemi", textRanges);
    sysfix(&g_bold, 30.0f, "Bold", textRanges);
    sysfix(&g_title, 33.0f, "Title", textRanges);
    sysfix(&g_mono, 24.0f, "Mono", textRanges);
    // NOTE: Icon (Lucide) has no system fallback: with fonts/ missing the
    // callers skip glyphs, so icons vanish instead of showing tofu.

    // Guarantee a default font exists even when every file is missing.
    ImGui::GetIO().Fonts->AddFontDefault();
    LOG_INFO("fonts: init %s", allOk ? "ok" : "with fallbacks");
    return allOk;
}

void Shutdown() {
    g_ui = g_uiSemi = g_bold = g_title = g_mono = g_icon = nullptr;
}

ImFont* UI() { return WithFallback(g_ui); }
ImFont* UISemi() { return WithFallback(g_uiSemi); }
ImFont* Bold() { return WithFallback(g_bold); }
ImFont* Title() { return WithFallback(g_title); }
ImFont* Mono() { return WithFallback(g_mono); }
ImFont* Icon() { return g_icon; }          // nullptr when missing: callers skip glyphs
ImFont* Current() { return UI(); }

} // namespace fonts
} // namespace nf
