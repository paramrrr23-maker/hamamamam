// gui_render.h - every drawing primitive the menu and HUD use.
//
// Two layers: (1) per-frame context (screen size, mouse, delta time) pushed
// by the overlay once per frame; (2) stateless helpers over ImGui draw
// lists. Rects are ImVec4(x0, y0, x1, y1). Text sizes are in "units":
// pixels = units * kFontUnit.

#pragma once

#include "imgui.h"

struct ImDrawList;
struct ImFont;

namespace nf {
namespace gui {

constexpr float kFontUnit = 18.0f;

// -- per-frame context (pushed by the overlay) -------------------------------
void BeginFrame(const ImVec2& screen, const ImVec2& mouse, float dt);
ImVec2 GetScreenSize();
ImVec2 GetMousePos();
float GetDeltaTime();
// Global text multiplier (General "Text Scale" setting, default 1.5).
// Applied inside DrawString/GetTextWidth/GetTextHeight, so layout measured
// through these helpers grows together with the glyphs.
void SetTextScale(float s);
float GetTextScale();

// -- math ---------------------------------------------------------------------
float Clamp(float v, float lo, float hi);
float Lerp(float a, float b, float t);
ImColor LerpColor(const ImColor& a, const ImColor& b, float t);
// Frame-rate independent approach: factor = dt * speed (0..1).
float Animate(float target, float current, float factor);
// Spring step toward target with overshoot control. stiffness ~170-320,
// damping ~12-20 (lower damping = more bounce). Used by the Dynamic Island
// plates and the gooey navigation blob.
void Spring(float& pos, float& vel, float target, float dt,
            float stiffness = 220.0f, float damping = 16.0f);

inline float RectW(const ImVec4& r) { return r.z - r.x; }
inline float RectH(const ImVec4& r) { return r.w - r.y; }
bool IsMouseOver(const ImVec4& r);   // against the stored mouse pos

// -- shapes --------------------------------------------------------------------
ImDrawList* Bg();  // background draw list shortcut
void FillRect(const ImVec4& r, const ImColor& c, float alpha, float radius = 0.0f,
              ImDrawList* d = nullptr, ImDrawFlags flags = 0);
void StrokeRect(const ImVec4& r, const ImColor& c, float radius, float thickness,
                float alpha = 1.0f, ImDrawList* d = nullptr);
void FillShadowRect(const ImVec4& r, const ImColor& c, float alpha, float radius,
                    ImDrawList* d = nullptr);
void FillGradientV(const ImVec4& r, const ImColor& top, const ImColor& bottom,
                   float alphaTop, float alphaBottom, float radius = 0.0f,
                   ImDrawList* d = nullptr);
void FillCircle(const ImVec2& center, float radius, const ImColor& c,
                float alpha, int segments = 16, ImDrawList* d = nullptr);

// -- text -----------------------------------------------------------------------
void DrawString(const ImVec2& pos, const char* text, const ImColor& c,
              float sizeUnits, float alpha, bool shadow = false,
              ImDrawList* d = nullptr, ImFont* font = nullptr);
float GetTextWidth(const char* text, float sizeUnits, ImFont* font = nullptr);
float GetTextHeight(float sizeUnits, ImFont* font = nullptr);

} // namespace gui
} // namespace nf
