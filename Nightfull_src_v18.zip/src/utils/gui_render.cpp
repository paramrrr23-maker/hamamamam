// gui_render.cpp - every drawing primitive the menu and HUD use.

#include "utils/gui_render.h"

#include <cfloat>
#include <cmath>

#include "utils/fonts.h"

namespace nf {
namespace gui {
namespace {

ImVec2 g_screen;
ImVec2 g_mouse;
float g_dt = 1.0f / 60.0f;
float g_textScale = 2.0f;

ImDrawList* Draw(ImDrawList* d) { return d ? d : ImGui::GetBackgroundDrawList(); }

ImU32 WithAlpha(const ImColor& c, float alpha) {
    return ImGui::ColorConvertFloat4ToU32(
        ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w * alpha));
}

// Soft-shadow falloff. The layer weights and their normalising sum depend only
// on the layer count, so they are computed once at compile time instead of
// being rebuilt on every FillShadowRect call.
constexpr int kShadowLayers = 6;
struct ShadowWeights {
    float w[kShadowLayers] = {};
    float sum = 0.0f;
};
constexpr ShadowWeights MakeShadowWeights() {
    ShadowWeights s{};
    for (int i = 0; i < kShadowLayers; i++) {
        const float t = (float)(i + 1) / (float)kShadowLayers;
        s.w[i] = (1.0f - t) * (1.0f - t);
        s.sum += s.w[i];
    }
    return s;
}
constexpr ShadowWeights kShadow = MakeShadowWeights();

} // namespace

void BeginFrame(const ImVec2& screen, const ImVec2& mouse, float dt) {
    g_screen = screen;
    g_mouse = mouse;
    g_dt = (dt > 0.0f && dt < 1.0f) ? dt : 1.0f / 60.0f;
}

ImVec2 GetScreenSize() { return g_screen; }
ImVec2 GetMousePos() { return g_mouse; }
float GetDeltaTime() { return g_dt; }

void SetTextScale(float s) {
    g_textScale = (s > 0.1f && s < 10.0f) ? s : 2.0f;
}
float GetTextScale() { return g_textScale; }

float Clamp(float v, float lo, float hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

void Spring(float& pos, float& vel, float target, float dt,
            float stiffness, float damping) {
    vel += (target - pos) * stiffness * dt;
    vel *= std::exp(-damping * dt);
    pos += vel * dt;
}

float Lerp(float a, float b, float t) { return a + (b - a) * t; }

ImColor LerpColor(const ImColor& a, const ImColor& b, float t) {
    t = Clamp(t, 0.0f, 1.0f);
    return ImColor(Lerp(a.Value.x, b.Value.x, t), Lerp(a.Value.y, b.Value.y, t),
                   Lerp(a.Value.z, b.Value.z, t), Lerp(a.Value.w, b.Value.w, t));
}

float Animate(float target, float current, float factor) {
    return current + (target - current) * Clamp(factor, 0.0f, 1.0f);
}

bool IsMouseOver(const ImVec4& r) {
    return g_mouse.x >= r.x && g_mouse.y >= r.y && g_mouse.x < r.z && g_mouse.y < r.w;
}

ImDrawList* Bg() { return ImGui::GetBackgroundDrawList(); }

void FillRect(const ImVec4& r, const ImColor& c, float alpha, float radius,
              ImDrawList* d, ImDrawFlags flags) {
    if (alpha <= 0.0f) return;
    Draw(d)->AddRectFilled(ImVec2(r.x, r.y), ImVec2(r.z, r.w), WithAlpha(c, alpha),
                           radius, flags);
}

void StrokeRect(const ImVec4& r, const ImColor& c, float radius, float thickness,
                float alpha, ImDrawList* d) {
    if (alpha <= 0.0f || thickness <= 0.0f) return;
    Draw(d)->AddRect(ImVec2(r.x, r.y), ImVec2(r.z, r.w), WithAlpha(c, alpha),
                     radius, 0, thickness);
}

void FillShadowRect(const ImVec4& r, const ImColor& c, float alpha, float radius,
                    ImDrawList* d) {
    if (alpha <= 0.0f) return;
    ImDrawList* dl = Draw(d);
    // Concentric expanding fills with quadratic falloff (cheap soft shadow).
    // Weights/sum come from the precomputed constexpr table above.
    for (int i = kShadowLayers - 1; i >= 0; i--) {
        const float t = (float)(i + 1) / (float)kShadowLayers;
        const float pad = 18.0f * t;
        const float a = alpha * kShadow.w[i] / kShadow.sum;
        dl->AddRectFilled(ImVec2(r.x - pad, r.y - pad), ImVec2(r.z + pad, r.w + pad),
                          WithAlpha(c, a), radius + pad);
    }
}

void FillGradientV(const ImVec4& r, const ImColor& top, const ImColor& bottom,
                   float alphaTop, float alphaBottom, float radius, ImDrawList* d) {
    ImDrawList* dl = Draw(d);
    if (radius > 0.0f) {
        // Approximate rounded gradient: clip to a rounded region is overkill;
        // ImGui has no rounded gradient primitive, so round only via an
        // outer clip when the caller needs it. Plain gradient here.
        (void)radius;
    }
    dl->AddRectFilledMultiColor(
        ImVec2(r.x, r.y), ImVec2(r.z, r.w),
        WithAlpha(top, alphaTop), WithAlpha(top, alphaTop),
        WithAlpha(bottom, alphaBottom), WithAlpha(bottom, alphaBottom));
}

void FillCircle(const ImVec2& center, float radius, const ImColor& c,
                float alpha, int segments, ImDrawList* d) {
    if (alpha <= 0.0f || radius <= 0.0f) return;
    Draw(d)->AddCircleFilled(center, radius, WithAlpha(c, alpha), segments);
}

void DrawString(const ImVec2& pos, const char* text, const ImColor& c,
              float sizeUnits, float alpha, bool shadow, ImDrawList* d, ImFont* font) {
    if (!text || !*text || alpha <= 0.0f) return;
    ImDrawList* dl = Draw(d);
    ImFont* f = font ? font : fonts::Current();
    if (!f) return;
    const float px = sizeUnits * kFontUnit * g_textScale;
    if (px < 1.0f) return;
    if (shadow) {
        dl->AddText(f, px, ImVec2(pos.x + 1.0f, pos.y + 1.0f),
                    ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 0.6f * alpha)), text);
    }
    dl->AddText(f, px, pos, WithAlpha(c, alpha), text);
}

float GetTextWidth(const char* text, float sizeUnits, ImFont* font) {
    ImFont* f = font ? font : fonts::Current();
    if (!f || !text) return 0.0f;
    return f->CalcTextSizeA(sizeUnits * kFontUnit * g_textScale, FLT_MAX, 0.0f, text).x;
}

float GetTextHeight(float sizeUnits, ImFont* font) {
    ImFont* f = font ? font : fonts::Current();
    if (!f) return 0.0f;
    return f->CalcTextSizeA(sizeUnits * kFontUnit * g_textScale, FLT_MAX, 0.0f, "Ag").y;
}

} // namespace gui
} // namespace nf
