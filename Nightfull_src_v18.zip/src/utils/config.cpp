// config.cpp - JSON persistence + named profiles (no third-party JSON).

#include "utils/config.h"

#include <Windows.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cwchar>
#include <string>

#include "core/module.h"
#include "core/module_manager.h"
#include "utils/logger.h"

namespace nf {
namespace config {
namespace {

std::wstring g_base;
std::wstring g_active;

// ============================ writer ============================
void WriteEscaped(std::string& out, const char* s) {
    out += '"';
    for (const char* p = s; *p; p++) {
        switch (*p) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if ((unsigned char)*p < 0x20) {
                    char b[8]; snprintf(b, sizeof(b), "\\u%04x", *p); out += b;
                } else out += *p;
        }
    }
    out += '"';
}

std::string Serialize() {
    std::string out = "{\"app\":\"Nightfull\",\"version\":1,\"modules\":[";
    bool firstMod = true;
    for (const auto& m : modules().modules()) {
        if (!firstMod) out += ',';
        firstMod = false;
        out += "{\"name\":";
        WriteEscaped(out, m->name());
        char head[64];
        snprintf(head, sizeof(head), ",\"enabled\":%s,\"key\":%d,\"settings\":[",
                 m->enabled() ? "true" : "false", m->key());
        out += head;
        bool firstSet = true;
        for (const auto& s : m->settings()) {
            if (!firstSet) out += ',';
            firstSet = false;
            out += "{\"name\":";
            WriteEscaped(out, s->mName.c_str());
            char b[128];
            switch (s->mType) {
                case SettingType::Bool:
                    snprintf(b, sizeof(b), ",\"type\":\"bool\",\"value\":%s}",
                             static_cast<BoolSetting*>(s.get())->mValue ? "true" : "false");
                    break;
                case SettingType::Number:
                    snprintf(b, sizeof(b), ",\"type\":\"number\",\"value\":%.6g}",
                             (double)static_cast<NumberSetting*>(s.get())->mValue);
                    break;
                case SettingType::Enum:
                    snprintf(b, sizeof(b), ",\"type\":\"enum\",\"value\":%d}",
                             static_cast<EnumSetting*>(s.get())->mValue);
                    break;
                case SettingType::Color: {
                    const float* v = static_cast<ColorSetting*>(s.get())->mValue;
                    snprintf(b, sizeof(b), ",\"type\":\"color\",\"value\":[%.5g,%.5g,%.5g,%.5g]}",
                             (double)v[0], (double)v[1], (double)v[2], (double)v[3]);
                    break;
                }
                case SettingType::String:
                    out += ",\"type\":\"string\",\"value\":";
                    WriteEscaped(out, static_cast<StringSetting*>(s.get())->mValue.c_str());
                    out += '}';
                    continue;
            }
            out += b;
        }
        out += "]}";
    }
    out += "]}";
    return out;
}

bool WriteFileAll(const std::wstring& path, const std::string& data) {
    HANDLE h = CreateFileW(path.c_str(), GENERIC_WRITE, 0, nullptr,
                           CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return false;
    DWORD written = 0;
    const BOOL ok = WriteFile(h, data.data(), (DWORD)data.size(), &written, nullptr);
    CloseHandle(h);
    return ok && written == data.size();
}

bool ReadFileAll(const std::wstring& path, std::string& data) {
    HANDLE h = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr,
                           OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return false;
    LARGE_INTEGER sz{};
    bool ok = false;
    if (GetFileSizeEx(h, &sz) && sz.QuadPart < 8 * 1024 * 1024) {
        data.resize((size_t)sz.QuadPart);
        DWORD read = 0;
        ok = ReadFile(h, data.data(), (DWORD)data.size(), &read, nullptr) &&
             read == data.size();
    }
    CloseHandle(h);
    return ok;
}

// ============================ reader ============================
// Minimal recursive-descent reader for exactly the subset Serialize emits
// (plus skipValue for forward compatibility with unknown fields).
struct Reader {
    const char* p;
    const char* end;
    bool failed = false;

    void ws() { while (p < end && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++; }
    bool expect(char c) { ws(); if (p < end && *p == c) { p++; return true; } failed = true; return false; }
    bool lit(const char* s) {
        ws(); size_t n = std::strlen(s);
        if ((size_t)(end - p) >= n && std::memcmp(p, s, n) == 0) { p += n; return true; }
        failed = true; return false;
    }
    bool str(std::string& out) {
        ws(); out.clear();
        if (p >= end || *p != '"') { failed = true; return false; }
        p++;
        while (p < end && *p != '"') {
            if (*p == '\\' && p + 1 < end) {
                p++;
                switch (*p) {
                    case '"': out += '"'; break;
                    case '\\': out += '\\'; break;
                    case 'n': out += '\n'; break;
                    case 'r': out += '\r'; break;
                    case 't': out += '\t'; break;
                    case 'u': {  // \uXXXX (BMP only, encoded as UTF-8)
                        if (p + 4 >= end) { failed = true; return false; }
                        char hex[5] = { p[1], p[2], p[3], p[4], 0 };
                        const unsigned cp = (unsigned)std::strtoul(hex, nullptr, 16);
                        if (cp < 0x80) out += (char)cp;
                        else if (cp < 0x800) {
                            out += (char)(0xC0 | (cp >> 6)); out += (char)(0x80 | (cp & 0x3F));
                        } else {
                            out += (char)(0xE0 | (cp >> 12));
                            out += (char)(0x80 | ((cp >> 6) & 0x3F));
                            out += (char)(0x80 | (cp & 0x3F));
                        }
                        p += 4;
                        break;
                    }
                    default: out += *p; break;
                }
                p++;
            } else out += *p++;
        }
        if (p >= end) { failed = true; return false; }
        p++;
        return true;
    }
    bool boolean(bool& out) {
        ws();
        if ((size_t)(end - p) >= 4 && std::memcmp(p, "true", 4) == 0) { p += 4; out = true; return true; }
        if ((size_t)(end - p) >= 5 && std::memcmp(p, "false", 5) == 0) { p += 5; out = false; return true; }
        failed = true; return false;
    }
    bool number(double& out) {
        ws();
        char* stop = nullptr;
        out = std::strtod(p, &stop);
        if (stop == p) { failed = true; return false; }
        p = stop; return true;
    }
    void skipValue() {  // skip one arbitrary value (object/array/literal)
        ws();
        if (p >= end) { failed = true; return; }
        if (*p == '{') {
            p++;
            ws(); if (p < end && *p == '}') { p++; return; }
            for (;;) {
                std::string k; str(k); expect(':'); skipValue();
                ws(); if (p < end && *p == ',') { p++; continue; }
                expect('}'); return;
            }
        }
        if (*p == '[') {
            p++;
            ws(); if (p < end && *p == ']') { p++; return; }
            for (;;) {
                skipValue();
                ws(); if (p < end && *p == ',') { p++; continue; }
                expect(']'); return;
            }
        }
        if (*p == '"') { std::string s; str(s); return; }
        // literal: consume until structural char
        while (p < end && *p != ',' && *p != ']' && *p != '}' &&
               *p != ' ' && *p != '\t' && *p != '\n' && *p != '\r') p++;
    }
};

void ApplyModule(Reader& r) {
    std::string name;
    bool enabled = false, haveEnabled = false;
    int key = 0; bool haveKey = false;
    // NOTE: settings are applied inline below (no DOM): we parse each
    // setting object and immediately apply it to the live module.
    if (!r.expect('{')) return;
    r.ws();
    if (r.p < r.end && *r.p == '}') { r.p++; return; }
    for (;;) {
        std::string k;
        if (!r.str(k) || !r.expect(':')) return;
        if (k == "name") r.str(name);
        else if (k == "enabled") haveEnabled = r.boolean(enabled);
        else if (k == "key") { double d = 0; if (r.number(d)) { key = (int)d; haveKey = true; } }
        else if (k == "settings") {
            Module* m = modules().find(name.c_str());
            if (m) {
                if (haveEnabled) m->setEnabled(enabled);
                if (haveKey) m->setKey(key);
            }
            // settings array: apply-or-skip each element
            if (!r.expect('[')) return;
            r.ws();
            if (r.p < r.end && *r.p == ']') { r.p++; }
            else for (;;) {
                // peek-apply: parse into temp, then apply by name+type
                const char* keep = r.p;
                (void)keep;
                // Inline parse (mirrors ApplySetting but applies directly).
                std::string sn, st; bool bv = false; double nv = 0; int ev = 0;
                float cv[4] = { 1, 1, 1, 1 }; std::string sv;
                bool hB = false, hN = false, hE = false, hC = false, hS = false;
                if (!r.expect('{')) return;
                r.ws();
                if (!(r.p < r.end && *r.p == '}')) {
                    for (;;) {
                        std::string sk;
                        if (!r.str(sk) || !r.expect(':')) return;
                        if (sk == "name") r.str(sn);
                        else if (sk == "type") r.str(st);
                        else if (sk == "value") {
                            if (st == "bool") hB = r.boolean(bv);
                            else if (st == "number") hN = r.number(nv);
                            else if (st == "enum") { double d = 0; hE = r.number(d); ev = (int)d; }
                            else if (st == "color") {
                                if (r.expect('[')) {
                                    double v[4] = { 1, 1, 1, 1 };
                                    for (int i = 0; i < 4; i++) {
                                        if (!r.number(v[i])) break;
                                        r.ws();
                                        if (i < 3) { if (r.p < r.end && *r.p == ',') r.p++; else break; }
                                    }
                                    r.expect(']');
                                    for (int i = 0; i < 4; i++) cv[i] = (float)v[i];
                                    hC = !r.failed;
                                }
                            }
                            else if (st == "string") hS = r.str(sv);
                            else r.skipValue();
                        } else r.skipValue();
                        if (r.failed) return;
                        r.ws();
                        if (r.p < r.end && *r.p == ',') { r.p++; continue; }
                        if (!r.expect('}')) return;
                        break;
                    }
                } else r.p++;
                if (m && !sn.empty()) {
                    if (Setting* s = m->findSetting(sn.c_str())) {
                        switch (s->mType) {
                            case SettingType::Bool:
                                if (hB && st == "bool") static_cast<BoolSetting*>(s)->mValue = bv;
                                break;
                            case SettingType::Number:
                                if (hN && st == "number") static_cast<NumberSetting*>(s)->setValue((float)nv);
                                break;
                            case SettingType::Enum:
                                if (hE && st == "enum") static_cast<EnumSetting*>(s)->setValue(ev);
                                break;
                            case SettingType::Color:
                                if (hC && st == "color")
                                    for (int i = 0; i < 4; i++)
                                        static_cast<ColorSetting*>(s)->mValue[i] = cv[i];
                                break;
                            case SettingType::String:
                                if (hS && st == "string") {
                                    StringSetting* ss = static_cast<StringSetting*>(s);
                                    ss->mValue = sv.substr(0, ss->mMaxLength);
                                }
                                break;
                        }
                    }
                }
                r.ws();
                if (r.p < r.end && *r.p == ',') { r.p++; continue; }
                if (!r.expect(']')) return;
                break;
            }
            // module-level fields may legally arrive AFTER settings; re-read
            // is unnecessary - JSON order is ours (name/enabled/key first).
            (void)haveEnabled; (void)haveKey;
        } else r.skipValue();
        if (r.failed) return;
        r.ws();
        if (r.p < r.end && *r.p == ',') { r.p++; continue; }
        r.expect('}'); return;
    }
}

bool ParseAndApply(const std::string& data) {
    Reader r{ data.data(), data.data() + data.size() };
    if (!r.expect('{')) return false;
    r.ws();
    if (r.p < r.end && *r.p == '}') return true;
    for (;;) {
        std::string k;
        if (!r.str(k) || !r.expect(':')) return false;
        if (k == "modules") {
            if (!r.expect('[')) return false;
            r.ws();
            if (r.p < r.end && *r.p == ']') { r.p++; }
            else for (;;) {
                ApplyModule(r);
                if (r.failed) return false;
                r.ws();
                if (r.p < r.end && *r.p == ',') { r.p++; continue; }
                if (!r.expect(']')) return false;
                break;
            }
        } else r.skipValue();
        if (r.failed) return false;
        r.ws();
        if (r.p < r.end && *r.p == ',') { r.p++; continue; }
        if (!r.expect('}')) return false;
        break;
    }
    return true;
}

std::wstring EnvW(const wchar_t* name) {
    if (!name || !*name) return {};
    wchar_t value[32768] = {};
    const DWORD length = GetEnvironmentVariableW(name, value,
                                                  static_cast<DWORD>(sizeof(value) / sizeof(value[0])));
    return length && length < sizeof(value) / sizeof(value[0])
        ? std::wstring(value, length) : std::wstring{};
}

std::wstring UserLocalAppData() {
    // In Bedrock's packaged process LOCALAPPDATA can point inside the
    // AppContainer AC tree. APPDATA still gives us the real user profile;
    // derive AppData\\Local from it first so this resolves to the same
    // package root as the previous Nightfull build.
    const std::wstring appData = EnvW(L"APPDATA");
    const std::wstring roaming = L"\\Roaming";
    if (appData.size() > roaming.size() &&
        _wcsicmp(appData.c_str() + appData.size() - roaming.size(), roaming.c_str()) == 0) {
        return appData.substr(0, appData.size() - roaming.size()) + L"\\Local";
    }

    const std::wstring local = EnvW(L"LOCALAPPDATA");
    if (!local.empty()) {
        // Reject the packaged AC-local path; it would create a second,
        // invisible config tree inside the sandbox instead of RoamingState.
        if (local.find(L"\\Microsoft.MinecraftUWP_8wekyb3d8bbwe\\AC\\") == std::wstring::npos)
            return local;
    }
    return {};
}

std::wstring MinecraftRoamingNightfullDir() {
    const std::wstring local = UserLocalAppData();
    if (local.empty()) return {};
    return local + L"\\Packages\\Microsoft.MinecraftUWP_8wekyb3d8bbwe"
                  L"\\RoamingState\\Nightfull";
}

bool EnsureDir(const std::wstring& dir) {
    if (dir.empty()) return false;
    const DWORD attributes = GetFileAttributesW(dir.c_str());
    if (attributes != INVALID_FILE_ATTRIBUTES)
        return (attributes & FILE_ATTRIBUTE_DIRECTORY) != 0;

    // CreateDirectoryW does not create parents. The packaged parent normally
    // already exists, but recursive creation keeps first-run behavior safe.
    const size_t slash = dir.find_last_of(L"\\/");
    if (slash != std::wstring::npos && slash > 2 && !EnsureDir(dir.substr(0, slash)))
        return false;

    if (CreateDirectoryW(dir.c_str(), nullptr)) return true;
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        const DWORD after = GetFileAttributesW(dir.c_str());
        return after != INVALID_FILE_ATTRIBUTES && (after & FILE_ATTRIBUTE_DIRECTORY) != 0;
    }
    return false;
}

} // namespace

bool Init(const wchar_t* dllDir) {
    // Primary location used by the previous version and visible to the user:
    // C:\\Users\\<user>\\AppData\\Local\\Packages\\Microsoft.MinecraftUWP_8wekyb3d8bbwe\\RoamingState\\Nightfull
    std::wstring cand = MinecraftRoamingNightfullDir();
    if (cand.empty() || !EnsureDir(cand)) {
        cand = std::wstring(dllDir ? dllDir : L".") + L"\\Nightfull";
        if (!EnsureDir(cand)) {
            wchar_t tmp[MAX_PATH] = {};
            GetTempPathW(MAX_PATH, tmp);
            cand = std::wstring(tmp) + L"Nightfull";
            if (!EnsureDir(cand)) return false;
        }
    }
    g_base = cand;
    g_active = g_base + L"\\config.json";
    EnsureDir(g_base + L"\\profiles");
    return true;
}

const std::wstring& baseDir() { return g_base; }
const std::wstring& activePath() { return g_active; }

bool Save() { return SaveTo(g_active); }

bool SaveTo(const std::wstring& path) {
    if (path.empty()) return false;
    const std::string data = Serialize();
    const bool ok = WriteFileAll(path, data);
    if (ok) LOG_INFO("config: saved %ls (%d bytes)", path.c_str(), (int)data.size());
    else LOG_ERROR("config: save failed %ls (err %lu)", path.c_str(), GetLastError());
    return ok;
}

bool Load() { return LoadFrom(g_active); }

bool LoadFrom(const std::wstring& path) {
    if (path.empty()) return false;
    std::string data;
    if (!ReadFileAll(path, data)) {
        LOG_INFO("config: no file at %ls - defaults kept", path.c_str());
        return false;
    }
    if (!ParseAndApply(data)) {
        LOG_ERROR("config: parse failed %ls - defaults kept", path.c_str());
        return false;
    }
    LOG_INFO("config: loaded %ls", path.c_str());
    return true;
}

bool validProfileName(const std::wstring& name) {
    if (name.empty() || name.size() > 48) return false;
    for (wchar_t c : name) {
        if (c == L'\\' || c == L'/' || c == L':' || c == L'*' || c == L'?' ||
            c == L'"' || c == L'<' || c == L'>' || c == L'|' || c < 32) return false;
    }
    if (name == L"." || name == L"..") return false;
    return true;
}

std::vector<std::wstring> listProfiles() {
    std::vector<std::wstring> out;
    if (g_base.empty()) return out;
    WIN32_FIND_DATAW fd{};
    HANDLE h = FindFirstFileW((g_base + L"\\profiles\\*.json").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return out;
    do {
        std::wstring n = fd.cFileName;
        if (n.size() > 5) out.push_back(n.substr(0, n.size() - 5));
    } while (FindNextFileW(h, &fd));
    FindClose(h);
    return out;
}

bool saveProfile(const std::wstring& name) {
    if (!validProfileName(name) || g_base.empty()) return false;
    return SaveTo(g_base + L"\\profiles\\" + name + L".json");
}

bool loadProfile(const std::wstring& name) {
    if (!validProfileName(name) || g_base.empty()) return false;
    return LoadFrom(g_base + L"\\profiles\\" + name + L".json");
}

bool deleteProfile(const std::wstring& name) {
    if (!validProfileName(name) || g_base.empty()) return false;
    return DeleteFileW((g_base + L"\\profiles\\" + name + L".json").c_str()) != 0;
}

} // namespace config
} // namespace nf
