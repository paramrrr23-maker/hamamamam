// logger.cpp - tiny thread-safe file + debugger logger.

#include "utils/logger.h"

#include <Windows.h>
#include <cstdio>
#include <cstring>

namespace nf {
namespace logger {
namespace {

CRITICAL_SECTION g_cs;
bool g_csInit = false;
HANDLE g_file = INVALID_HANDLE_VALUE;

void EnsureCs() {
    if (!g_csInit) { InitializeCriticalSection(&g_cs); g_csInit = true; }
}

} // namespace

void Init(const wchar_t* logPath) {
    EnsureCs();
    EnterCriticalSection(&g_cs);
    if (g_file == INVALID_HANDLE_VALUE && logPath) {
        // Always append, never truncate. CREATE_ALWAYS wiped the log of a
        // concurrently attached copy (and of the previous run) - a second
        // injection then looked like a fresh silent start. Opening with
        // OPEN_ALWAYS and seeking to the end keeps every copy's lines.
        g_file = CreateFileW(logPath, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr,
                             OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (g_file != INVALID_HANDLE_VALUE)
            SetFilePointer(g_file, 0, nullptr, FILE_END);
    }
    LeaveCriticalSection(&g_cs);
}

bool IsFileActive() {
    EnsureCs();
    EnterCriticalSection(&g_cs);
    const bool on = g_file != INVALID_HANDLE_VALUE;
    LeaveCriticalSection(&g_cs);
    return on;
}

void Shutdown() {
    if (!g_csInit) return;
    EnterCriticalSection(&g_cs);
    if (g_file != INVALID_HANDLE_VALUE) { CloseHandle(g_file); g_file = INVALID_HANDLE_VALUE; }
    LeaveCriticalSection(&g_cs);
}

void Write(const char* level, const char* fmt, va_list args) {
    EnsureCs();
    char msg[1024];
    vsnprintf(msg, sizeof(msg), fmt, args);
    msg[sizeof(msg) - 1] = 0;

    SYSTEMTIME st{};
    GetLocalTime(&st);
    char line[1152];
    snprintf(line, sizeof(line), "[%02u:%02u:%02u.%03u][%s][tid %lu] %s\r\n",
             st.wHour, st.wMinute, st.wSecond, st.wMilliseconds,
             level ? level : "?", GetCurrentThreadId(), msg);

    EnterCriticalSection(&g_cs);
    if (g_file != INVALID_HANDLE_VALUE) {
        DWORD written = 0;
        WriteFile(g_file, line, (DWORD)std::strlen(line), &written, nullptr);
    }
    LeaveCriticalSection(&g_cs);
    OutputDebugStringA(line);
}

} // namespace logger
} // namespace nf
