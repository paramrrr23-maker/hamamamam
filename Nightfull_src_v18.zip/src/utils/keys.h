// keys.h - fused per-frame keyboard snapshot.
//
// Producers: the overlay's WndProc subclass feeds legacy WM_KEYDOWN/WM_KEYUP
// plus WM_INPUT (raw keyboard) via FeedKey, and WM_CHAR (or raw-synthesized
// text) via FeedChar. FeedKey only stages into a pending set; BeginFrame()
// merges it (prev<-cur, then pending wins) and fuses an async key poll:
// while the poll has not proven alive it runs every frame and only ADDS downs
// (a dead all-zero sandbox poll can never erase WndProc-fed state); once alive
// it runs every 4th frame with the last sample carried between polls, since
// WndProc edges are the authoritative source and the poll is a fallback.
// Consumers ask Down()/
// PressedThisFrame()/Name()/TextInput(). One snapshot per rendered frame;
// Reset() drops all history (called on menu open/close transitions so held
// keys never misfire as fresh presses).

#pragma once

#include <cstddef>

namespace nf {
namespace keys {

// Optional raw sampler used by the overlay when it temporarily masks the
// process-wide Win32 async state from the game. The sampler must return the
// unmasked/original state for Nightfull's own input snapshot.
using AsyncStateSampler = short (*)(int vk);
void SetAsyncStateSampler(AsyncStateSampler sampler);

void BeginFrame();                 // call once per frame, before any query
void Reset();                      // drop all key history + char queue

void FeedKey(unsigned int vk, bool down);  // from WndProc (any thread)
void FeedChar(unsigned int ch);            // from WndProc WM_CHAR (UTF-16 unit)

bool Down(unsigned int vk);
bool PressedThisFrame(unsigned int vk);    // down now, up last frame
const char* Name(unsigned int vk);         // short display name ("INSERT", "K", ...)

// Appends drained WM_CHARs to a UTF-8 editor buffer (handles backspace).
// Returns true when the buffer changed. When active==false the queue is
// dropped and false is returned.
bool TextInput(char* buf, size_t cap, bool active);

} // namespace keys
} // namespace nf
