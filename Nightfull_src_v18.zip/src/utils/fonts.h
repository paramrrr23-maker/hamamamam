// fonts.h - font roles loaded from the fonts/ folder next to the DLL.
//
// Roles use the compact JetBrains Mono face from the Serpantinum-inspired
// web shell for UI, titles and values; Icon is the Lucide PUA font. Text roles
// rasterize Latin + Cyrillic. Every role falls back to the ImGui default font
// when its file is missing; text roles first try the Windows system font so a
// missing fonts/ folder degrades to readable text instead of ???.

#pragma once

struct ImFont;

namespace nf {
namespace fonts {

bool Init(const wchar_t* dllDir);  // loads fonts/<role>.ttf; true when all found
void Shutdown();                   // nothing cached outside the atlas; kept for symmetry

ImFont* UI();
ImFont* UISemi();
ImFont* Bold();
ImFont* Title();
ImFont* Mono();
ImFont* Icon();
ImFont* Current();                 // default HUD/menu font (= UI)

} // namespace fonts
} // namespace nf
