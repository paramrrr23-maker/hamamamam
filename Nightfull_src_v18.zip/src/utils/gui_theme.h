// gui_theme.h - the cycling accent engine + naming styles.
//
// The Themes module owns the preference data; the menu pushes it here every
// frame (SetTheme/SetCustomColor/...). Every colored draw pulls
// GetThemedColor(phase): presets breathe between two accent colors, Custom
// cycles through the user slots. Phase offsets the cycle so a column of
// widgets reads as a gradient.

#pragma once

#include "imgui.h"

namespace nf {
namespace gui {

void SetTheme(int index);            // 0..ThemeCount()-1
void SetNamingStyle(int style);      // 0..3 (see ApplyNaming)
void SetCustomColorCount(int n);     // 1..6
void SetCustomColor(int i, const ImColor& c);
void SetColorSpeed(float speed);     // cycle speed, ~0.25..20
void SetSaturation(float s);         // 0..1, custom colors only

ImColor GetThemedColor(float phase = 0.0f);
ImColor Accent();                    // GetThemedColor(0)

// Theme metadata for the Settings page swatches.
int ThemeCount();
const char* ThemeName(int index);
ImColor ThemeSwatch(int index);

// Naming styles: 0 lowercase, 1 lower spaced, 2 Normal, 3 Spaced.
const char* ApplyNaming(const char* name);

} // namespace gui
} // namespace nf
