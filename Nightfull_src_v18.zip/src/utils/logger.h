// logger.h - tiny thread-safe file + debugger logger.
//
// Usage: logger::Init(fullLogPath) once from the worker thread, then
// LOG_INFO("menu: ...", ...) / LOG_ERROR("...") anywhere. Never throws,
// never allocates on the calling thread beyond a 1 KB stack buffer.

#pragma once

#include <cstdarg>

namespace nf {
namespace logger {

void Init(const wchar_t* logPath);   // opens the log file (append; never truncates)
bool IsFileActive();                 // true once a file sink is open
void Shutdown();                     // flushes + closes; safe to call twice
void Write(const char* level, const char* fmt, va_list args);

inline void Info(const char* fmt, ...) {
    va_list a; va_start(a, fmt); Write("INFO", fmt, a); va_end(a);
}
inline void Error(const char* fmt, ...) {
    va_list a; va_start(a, fmt); Write("ERROR", fmt, a); va_end(a);
}

} // namespace logger
} // namespace nf

#define LOG_INFO(...)  ::nf::logger::Info(__VA_ARGS__)
#define LOG_ERROR(...) ::nf::logger::Error(__VA_ARGS__)
