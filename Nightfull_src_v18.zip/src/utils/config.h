// config.h - JSON persistence + named profiles (no third-party JSON).
//
// Layout on disk (base dir resolved by Init to
// "%LOCALAPPDATA%\Packages\Microsoft.MinecraftUWP_8wekyb3d8bbwe\RoamingState\Nightfull",
// with DLL-dir/TEMP fallbacks):
//   config.json            active configuration (autosaved)
//   profiles\<name>.json   named profiles (the Profiles page)
// The format only stores what the menu edits: per module {enabled, key,
// settings[{name, type, value}]}. Unknown modules/settings in the file are
// ignored, so old configs never break new builds.

#pragma once

#include <string>
#include <vector>

namespace nf {
namespace config {

bool Init(const wchar_t* dllDir);   // resolves base dir, creates folders
const std::wstring& baseDir();      // "...\Nightfull"
const std::wstring& activePath();   // "...\Nightfull\config.json"

bool Save();                        // writes the registry to config.json
bool SaveTo(const std::wstring& path);
bool Load();                        // reads config.json if present
bool LoadFrom(const std::wstring& path);

// Named profiles (bare names, no extension / no path separators allowed).
std::vector<std::wstring> listProfiles();
bool saveProfile(const std::wstring& name);    // snapshot active state
bool loadProfile(const std::wstring& name);    // load + make active
bool deleteProfile(const std::wstring& name);
bool validProfileName(const std::wstring& name);

} // namespace config
} // namespace nf
