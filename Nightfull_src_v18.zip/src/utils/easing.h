// easing.h - EasingUtil: a 0..1 percentage with shaped easing curves.
//
// The menu advances ONE percentage per transition (open/close) and then
// shapes copies of it per effect (fade vs zoom vs pop), so effects never
// fight over the underlying progress.

#pragma once

#include <cmath>

namespace nf {
namespace gui {

class EasingUtil {
public:
    void reset() { mPct = 0.0f; }
    void incrementPercentage(float v) { mPct += v; if (mPct > 1.0f) mPct = 1.0f; }
    void decrementPercentage(float v) { mPct -= v; if (mPct < 0.0f) mPct = 0.0f; }
    bool isPercentageMax() const { return mPct >= 1.0f; }
    bool isPercentageMin() const { return mPct <= 0.0f; }
    float getPercentage() const { return mPct; }

    // All shapers are pure: they read mPct and return 0..1 (overshooting
    // ones may exceed 1 by design - clamp at the call-site when needed).
    float easeOutExpo() const {
        return (mPct >= 1.0f) ? 1.0f : 1.0f - std::pow(2.0f, -10.0f * mPct);
    }
    float easeOutCubic() const {
        const float u = 1.0f - mPct;
        return 1.0f - u * u * u;
    }
    float easeOutBack() const {
        const float c1 = 1.70158f, c3 = c1 + 1.0f, u = mPct - 1.0f;
        return 1.0f + c3 * u * u * u + c1 * u * u;
    }
    float easeOutElastic() const {
        if (mPct <= 0.0f) return 0.0f;
        if (mPct >= 1.0f) return 1.0f;
        const float c = (2.0f * 3.14159265f) / 3.0f;
        return std::pow(2.0f, -10.0f * mPct) * std::sin((mPct * 10.0f - 0.75f) * c) + 1.0f;
    }
    explicit operator float() const { return mPct; }

private:
    float mPct = 0.0f;
};

} // namespace gui
} // namespace nf
