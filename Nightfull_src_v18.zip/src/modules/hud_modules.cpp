// hud_modules.cpp - the curated local-only HUD roster.

#include "modules/hud_modules.h"

#include <Windows.h>
#include <algorithm>
#include <cctype>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <map>
#include <string>
#include <vector>
#include <psapi.h>

#include "core/module_manager.h"
#include "overlay/overlay.h"
#include "ui/menu.h"
#include "utils/fonts.h"
#include "utils/gui_render.h"
#include "utils/gui_theme.h"
#include "utils/keys.h"

namespace nf {
namespace {

// Anchor indices (match HudPositionNames order).
enum Anchor { TopLeft = 0, TopRight, BottomLeft, BottomRight, TopCenter, BottomCenter };

constexpr float kPad = 10.0f;

// Accent-glass HUD palette (matches the Arraylist Glass row): surfaces are
// translucent theme-accent via GlassSurface(), text is white, muted text is
// dim white, accent colors keep.
const ImColor kGlassText(255, 255, 255);
const ImColor kGlassMuted(210, 214, 222);

// Accent glass surface (matches the Arraylist Glass row): translucent theme
// accent fill, white hairline border, soft shadow. `alpha` = element opacity.
inline void GlassSurface(const ImVec4& r, float alpha, float radius, ImDrawList* d = nullptr) {
    gui::FillShadowRect(r, ImColor(0, 0, 0), 0.25f * alpha, radius, d);
    gui::FillRect(r, gui::Accent(), 0.32f * alpha, radius, d);
    gui::StrokeRect(r, ImColor(255, 255, 255), radius, 1.0f, 0.28f * alpha, d);
}

ImVec2 Place(const ImVec2& screen, const ImVec2& size, int anchor, float pad = kPad) {
    switch (anchor) {
        case TopRight:    return ImVec2(screen.x - pad - size.x, pad);
        case BottomLeft:  return ImVec2(pad, screen.y - pad - size.y);
        case BottomRight: return ImVec2(screen.x - pad - size.x, screen.y - pad - size.y);
        case TopCenter:   return ImVec2((screen.x - size.x) * 0.5f, pad);
        case BottomCenter:return ImVec2((screen.x - size.x) * 0.5f, screen.y - pad - size.y);
        case TopLeft:
        default:          return ImVec2(pad, pad);
    }
}

// ---- free-form HUD editor (Flarial editmenu parity) --------------------------
//
// With the editor active every draggable element draws a translucent white
// box + its module name, can be dragged anywhere (the position is stored as a
// screen fraction, so it survives resolution changes), resized with the wheel
// while hovered, and right-clicked to open its ClickGUI settings page.

// Per-module drag state, touched only while the editor is active.
struct HudDrag {
    bool active = false;
    float grabX = 0.0f, grabY = 0.0f;   // mouse - box top-left at grab time
    // Right-button resize: press records the anchor, dragging horizontally
    // past a small threshold resizes instead of opening settings on release.
    bool rHeld = false;
    bool resizing = false;
    float rStartX = 0.0f, startScale = 1.0f;
    // Stillness watchdog: a missed button-release edge (focus loss mid-drag,
    // closed editor, eaten frame) used to latch drag/resize forever, after
    // which the element could never be moved again. A motionless hold
    // longer than this releases every latch; a real drag keeps moving.
    ImVec2 lastMouse{};
    bool hasLast = false;
    int stillFrames = 0;
};

// Returns the module's top-left for this frame: free percentages when enabled
// (Flarial percentageX/Y semantics: top-left = pct * screen), else the anchor.
ImVec2 HudResolvePos(bool freeOn, float fx, float fy, const ImVec2& screen,
                     const ImVec2& size, int anchorIdx) {
    if (freeOn) return ImVec2(fx * screen.x, fy * screen.y);
    return Place(screen, size, anchorIdx);
}

// Adds the shared free-position triplet to a HUD module. Registered AFTER the
// module's own settings; the X/Y values are hidden in the inspector (the
// editor owns them) but serialize to the config like every other setting.
void AddFreePositionSettings(Module* m, BoolSetting** freeOn,
                             NumberSetting** freeX, NumberSetting** freeY,
                             float defX, float defY) {
    *freeOn = m->addSetting<BoolSetting>(
        "Free position", "Двигай элементы HUD в любое место экрана (HUD editor).", false);
    *freeX = m->addSetting<NumberSetting>(
        "Free X", "Free position X (0..1 of screen).", defX, 0.0f, 1.0f, 0.001f);
    (*freeX)->mIsVisible = [] { return false; };
    *freeY = m->addSetting<NumberSetting>(
        "Free Y", "Free position Y (0..1 of screen).", defY, 0.0f, 1.0f, 0.001f);
    (*freeY)->mIsVisible = [] { return false; };
}

// Edit-mode chrome + interaction for one module box. No-op unless the HUD
// editor is active and the ClickGUI is closed. Draws the translucent fill +
// border + label, handles drag (writes fx/fy + freeOn), hover wheel-resize
// (±0.05 scale, clamped by the setting) and right-click -> module settings.
void HudEditChrome(Module* m, const char* label, const ImVec2& pos,
                   const ImVec2& size, BoolSetting* freeOn,
                   NumberSetting* fx, NumberSetting* fy, NumberSetting* scale) {
    if (!m || !overlay::HudEditActive() || overlay::g_showMenu) return;
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f || screen.y <= 0.0f) return;

    // Drag state, keyed by module pointer.
    //
    // This used to be a std::map<std::string, HudDrag>: every HUD module, every
    // frame, built a temporary std::string from the name and walked a
    // red-black tree comparing strings. Module pointers are stable for the
    // session, so a small linear array over at most a handful of live entries
    // is both faster and completely allocation-free.
    struct DragSlot { Module* mod = nullptr; HudDrag drag; };
    static DragSlot slots[64];
    DragSlot* slot = nullptr;
    for (DragSlot& s : slots) {
        if (s.mod == m) { slot = &s; break; }
    }
    if (!slot) {
        for (DragSlot& s : slots) {
            if (!s.mod) {
                s.mod = m;
                s.drag = HudDrag{};
                slot = &s;
                break;
            }
        }
    }
    if (!slot) return;   // more HUD modules than slots: draw no chrome
    HudDrag& drag = slot->drag;

    const ImVec2 mouse = gui::GetMousePos();
    // Latch hygiene first: an inactive editor (or bad screen) clears stale
    // drag/resize state so no latch survives across editor sessions.
    if (!m || !overlay::HudEditActive() || overlay::g_showMenu ||
        screen.x <= 0.0f || screen.y <= 0.0f) {
        drag.active = false;
        drag.rHeld = false;
        drag.resizing = false;
        drag.hasLast = false;
        drag.stillFrames = 0;
        return;
    }
    // Stillness watchdog (see struct): motionless 2 s releases everything.
    if (!drag.hasLast || mouse.x != drag.lastMouse.x || mouse.y != drag.lastMouse.y) {
        drag.lastMouse = mouse;
        drag.hasLast = true;
        drag.stillFrames = 0;
    } else if (++drag.stillFrames > 120) {
        drag.active = false;
        drag.rHeld = false;
        drag.resizing = false;
    }
    const bool hovered = mouse.x >= pos.x && mouse.x < pos.x + size.x &&
                         mouse.y >= pos.y && mouse.y < pos.y + size.y;
    // Menu-independent button edges, with the ImGui backend as fallback (the
    // same pattern the ClickGUI's Ctx::Clicked uses).
    const bool lPressed = overlay::g_guiMousePressed[0] || ImGui::IsMouseClicked(0);
    const bool lDown = overlay::g_guiMouseDown[0] || ImGui::IsMouseDown(0);
    const bool rPressed = overlay::g_guiMousePressed[1] || ImGui::IsMouseClicked(1);
    const bool rDown = overlay::g_guiMouseDown[1] || ImGui::IsMouseDown(1);

    // Right button: hold + horizontal drag resizes the module (scale follows
    // the mouse, snapped to the setting step); a quick tap without dragging
    // keeps the old behavior and opens the module settings page.
    if (hovered && rPressed && scale) {
        drag.rHeld = true;
        drag.resizing = false;
        drag.rStartX = mouse.x;
        drag.startScale = scale->mValue;
    }
    if (drag.rHeld && !rDown) {
        if (!drag.resizing && hovered) {
            // Quick right-click: the module's settings page opens in the
            // ClickGUI and the editor hands input ownership over to the menu.
            ui::OpenModuleSettings(m);
            overlay::HudEditSet(false);
            return;
        }
        drag.rHeld = false;
        drag.resizing = false;
    }
    if (drag.rHeld && rDown && scale) {
        if (!drag.resizing && std::fabs(mouse.x - drag.rStartX) > 6.0f)
            drag.resizing = true;
        if (drag.resizing)
            scale->setValue(drag.startScale + (mouse.x - drag.rStartX) * 0.003f);
    }

    // Wheel-resize: one scroll tick resizes at most one module per frame.
    static int wheelFrame = -1;
    static bool wheelConsumed = false;
    if (wheelFrame != ImGui::GetFrameCount()) {
        wheelFrame = ImGui::GetFrameCount();
        wheelConsumed = false;
    }
    const float wheel = overlay::g_guiMouseWheel;
    if (scale && hovered && !wheelConsumed && std::fabs(wheel) > 0.0001f) {
        wheelConsumed = true;
        scale->setValue(scale->mValue + (wheel > 0.0f ? 0.05f : -0.05f));
    }

    if (!drag.active && hovered && lPressed) {
        drag.active = true;
        drag.grabX = mouse.x - pos.x;
        drag.grabY = mouse.y - pos.y;
    }
    if (drag.active && !lDown) drag.active = false;
    if (drag.active) {
        // Flarial drag math: newPos = mouse - grab offset, clamped so the box
        // stays fully on screen; the result is stored as a screen fraction.
        const float maxX = std::max(0.0f, screen.x - size.x);
        const float maxY = std::max(0.0f, screen.y - size.y);
        const float nx = gui::Clamp(mouse.x - drag.grabX, 0.0f, maxX);
        const float ny = gui::Clamp(mouse.y - drag.grabY, 0.0f, maxY);
        if (fx) fx->mValue = gui::Clamp(nx / std::max(screen.x, 1.0f), 0.0f, 1.0f);
        if (fy) fy->mValue = gui::Clamp(ny / std::max(screen.y, 1.0f), 0.0f, 1.0f);
        if (freeOn) freeOn->mValue = true;
    }

    // Chrome on the foreground list so it stays above HUD elements that draw
    // there (Keystrokes cells, the crosshair).
    ImDrawList* d = ImGui::GetForegroundDrawList();
    const ImVec4 rect(pos.x, pos.y, pos.x + size.x, pos.y + size.y);
    gui::FillRect(rect, ImColor(255, 255, 255),
                  drag.active ? 0.38f : (hovered ? 0.34f : 0.28f), 2.0f, d);
    const ImColor frameCol = drag.resizing ? gui::Accent() : ImColor(255, 255, 255);
    gui::StrokeRect(rect, frameCol, 2.0f, drag.resizing ? 2.0f : 1.2f, 0.9f, d);
    // Label just above the box; flipped below it and clamped when the box
    // hugs a screen edge.
    const float labelUnits = 0.5f;
    const float labelH = gui::GetTextHeight(labelUnits);
    const float labelW = gui::GetTextWidth(label, labelUnits);
    float lx = gui::Clamp(pos.x, 2.0f, std::max(2.0f, screen.x - labelW - 2.0f));
    float ly = pos.y - labelH - 3.0f;
    if (ly < 2.0f) ly = pos.y + size.y + 3.0f;
    ly = gui::Clamp(ly, 2.0f, std::max(2.0f, screen.y - labelH - 2.0f));
    gui::DrawString(ImVec2(lx, ly), label, ImColor(255, 255, 255), labelUnits,
                    drag.active ? 1.0f : 0.95f, true, d);
}

ImColor AccentOf(BoolSetting* useTheme, ColorSetting* color) {
    if (useTheme && useTheme->mValue) return gui::Accent();
    if (color) return color->getAsImColor();
    return ImColor(255, 255, 255);
}

// One accent-glass chip with an accent outline (shared HUD look).
ImVec2 DrawChip(const ImVec2& pos, const char* text, float scale, const ImColor& accent) {
    const float units = 0.82f * scale;
    const float padX = 10.0f * scale, padY = 6.0f * scale;
    const float w = gui::GetTextWidth(text, units) + padX * 2.0f;
    const float h = gui::GetTextHeight(units) + padY * 2.0f;
    const ImVec4 r(pos.x, pos.y, pos.x + w, pos.y + h);
    GlassSurface(r, 0.88f, 6.0f * scale);
    gui::StrokeRect(r, accent, 6.0f * scale, 1.2f, 0.75f);   // outline replaces the left bar
    gui::DrawString(ImVec2(pos.x + padX, pos.y + padY), text,
                  kGlassText, units, 1.0f, true);
    return ImVec2(w, h);
}

ImVec2 ChipSize(const char* text, float scale) {
    const float units = 0.82f * scale;
    return ImVec2(gui::GetTextWidth(text, units) + 10.0f * scale * 2.0f,
                  gui::GetTextHeight(units) + 6.0f * scale * 2.0f);
}

// ---- Shared status pill (the Reach Display look) -----------------------------
//
// Dark Watermark-style glass pill: h/2 rounding, optional accent stroke,
// a small vectored glyph, then label and value. Reach Display and the CPS
// counter render through this one component so they read as two variants of
// the same HUD element.
enum class PillIcon { Target, Mouse };

void DrawTargetGlyph(ImDrawList* d, const ImVec2& c, float s, const ImColor& col) {
    const float r = 4.4f * s;
    d->AddCircle(c, r, col, 20, 1.3f * s);
    d->AddCircleFilled(c, 1.5f * s, col, 10);
    const float tickIn = r + 0.8f * s, tickOut = r + 3.4f * s;
    d->AddLine(ImVec2(c.x - tickOut, c.y), ImVec2(c.x - tickIn, c.y), col, 1.2f * s);
    d->AddLine(ImVec2(c.x + tickIn, c.y), ImVec2(c.x + tickOut, c.y), col, 1.2f * s);
    d->AddLine(ImVec2(c.x, c.y - tickOut), ImVec2(c.x, c.y - tickIn), col, 1.2f * s);
    d->AddLine(ImVec2(c.x, c.y + tickIn), ImVec2(c.x, c.y + tickOut), col, 1.2f * s);
}

void DrawMouseGlyph(ImDrawList* d, const ImVec2& c, float s, const ImColor& col) {
    // Computer mouse: capsule body, button split lines, scroll wheel.
    const float w = 8.4f * s, h = 12.6f * s;
    const float x0 = c.x - w * 0.5f, x1 = c.x + w * 0.5f;
    const float y0 = c.y - h * 0.5f, y1 = c.y + h * 0.5f;
    const float splitY = y0 + h * 0.42f;
    d->AddRect(ImVec2(x0, y0), ImVec2(x1, y1), col, w * 0.48f, 0, 1.3f * s);
    d->AddLine(ImVec2(c.x, y0 + 1.0f * s), ImVec2(c.x, splitY), col, 1.1f * s);
    d->AddLine(ImVec2(x0, splitY), ImVec2(x1, splitY), col, 1.1f * s);
    d->AddLine(ImVec2(c.x, y0 + 3.2f * s), ImVec2(c.x, y0 + 5.8f * s),
               ImColor(col.Value.x, col.Value.y, col.Value.z, col.Value.w * 0.55f),
               1.9f * s);
}

ImVec2 StatusPillSize(float scale, const char* label, const char* value) {
    const float units = 0.78f * scale;
    const float padX = 14.0f * scale, padY = 6.0f * scale;
    const float iconSize = 13.0f * scale;
    const float w = iconSize + 7.0f * scale +
                    gui::GetTextWidth(label, units) + 6.0f * scale +
                    gui::GetTextWidth(value, units) + padX * 2.0f;
    return ImVec2(w, gui::GetTextHeight(units) + padY * 2.0f);
}

void DrawStatusPill(const ImVec2& pos, float scale, float opacity, bool outline,
                    PillIcon icon, const char* label, const char* value) {
    const float s = scale;
    const float units = 0.78f * s;
    const float padX = 14.0f * s, padY = 6.0f * s;
    const float iconSize = 13.0f * s;
    const float iconGap = 7.0f * s;
    const float wordW = gui::GetTextWidth(label, units);
    const ImVec2 size = StatusPillSize(s, label, value);
    const float w = size.x, h = size.y;
    ImDrawList* d = gui::Bg();

    GlassSurface(ImVec4(pos.x, pos.y, pos.x + w, pos.y + h), opacity, h * 0.5f, d);
    if (outline)
        d->AddRect(ImVec2(pos.x + 0.7f, pos.y + 0.7f),
                   ImVec2(pos.x + w - 0.7f, pos.y + h - 0.7f),
                   gui::Accent(), h * 0.5f - 0.7f, 0, 1.4f);

    const ImColor accent = gui::Accent();
    const float cy = pos.y + h * 0.5f;
    const float cx = pos.x + padX + iconSize * 0.5f;
    if (icon == PillIcon::Target) DrawTargetGlyph(d, ImVec2(cx, cy), s, accent);
    else DrawMouseGlyph(d, ImVec2(cx, cy), s, accent);

    const float textY = pos.y + padY;
    const float tx = pos.x + padX + iconSize + iconGap;
    gui::DrawString(ImVec2(tx, textY), label, kGlassText, units, 1.0f, true);
    gui::DrawString(ImVec2(tx + wordW + 6.0f * s, textY), value,
                    kGlassText, units, 1.0f, true);
}

// Pulse/watermark plate with Arraylist neon details. The header gives both
// widgets a stable identity, while every data row keeps the Arraylist accent
// edge and the live status/effect colour. Rows carry Dynamic-Island presence
// (t/dy) fed by NeonPlateAnim; fully-present rows draw exactly as before.
void DrawNeonDot(ImDrawList* d, const ImVec2& center, float radius, const ImColor& color,
                 float alpha) {
    // A small translucent halo plus a sharp core is the same restrained neon
    // treatment used by Arraylist's accent bars.
    gui::FillCircle(center, radius * 2.3f, color, alpha * 0.16f, 16, d);
    gui::FillCircle(center, radius, color, alpha, 12, d);
}

// Minecraft empty glass bottle (the Potions header icon), drawn from
// primitives so it stays crisp at any HUD scale: narrow neck with a rim,
// flared shoulders, rounded body, pale-glass outline and a shine line.
void DrawBottleIcon(ImDrawList* d, const ImVec2& center, float h,
                    const ImColor& glass) {
    constexpr float kPi = 3.1415927f;
    const float w = h * 0.62f;
    const float x0 = center.x - w * 0.5f, x1 = center.x + w * 0.5f;
    const float y0 = center.y - h * 0.5f, y1 = center.y + h * 0.5f;
    const float neckW = w * 0.34f;
    const float shoulderY = y0 + h * 0.34f;
    const float rimW = w * 0.56f;
    const float lineW = h * 0.08f;
    const float r = w * 0.24f;

    d->PathLineTo(ImVec2(center.x - neckW * 0.5f, y0));
    d->PathLineTo(ImVec2(center.x - neckW * 0.5f, shoulderY));
    d->PathLineTo(ImVec2(x0, shoulderY + h * 0.10f));
    d->PathLineTo(ImVec2(x0, y1 - r));
    d->PathArcTo(ImVec2(x0 + r, y1 - r), r, kPi, kPi * 0.5f, 8);
    d->PathLineTo(ImVec2(x1 - r, y1));
    d->PathArcTo(ImVec2(x1 - r, y1 - r), r, kPi * 0.5f, 0.0f, 8);
    d->PathLineTo(ImVec2(x1, shoulderY + h * 0.10f));
    d->PathLineTo(ImVec2(x1, shoulderY));
    d->PathLineTo(ImVec2(center.x + neckW * 0.5f, shoulderY));
    d->PathLineTo(ImVec2(center.x + neckW * 0.5f, y0));
    d->PathStroke(glass, 0, lineW);

    // Rim across the bottle mouth.
    d->AddLine(ImVec2(center.x - rimW * 0.5f, y0 + lineW * 0.5f),
               ImVec2(center.x + rimW * 0.5f, y0 + lineW * 0.5f), glass, lineW);
    // Small vertical glass shine inside the body.
    d->AddLine(ImVec2(x0 + w * 0.24f, shoulderY + h * 0.28f),
               ImVec2(x0 + w * 0.24f, y1 - h * 0.18f),
               ImColor(255, 255, 255, (int)(glass.Value.w * 0.32f * 255.0f)),
               lineW * 0.7f);
}

ImVec2 NeonPlateSize(float scale, const char* title,
                     const std::vector<NeonPlateRow>& rows) {
    ImFont* font = fonts::Current();
    ImFont* icons = fonts::Icon();
    if (!font) return ImVec2(0.0f, 0.0f);
    const float pad = 9.0f * scale;
    const float headH = 24.0f * scale;
    const float rowH = 19.0f * scale;
    const float headUnits = 0.68f * scale;
    const float rowUnits = 0.60f * scale;
    const float iconPx = 14.0f * scale;
    const float titleW = gui::GetTextWidth(title, headUnits, font);
    float contentW = (icons ? iconPx + 6.0f * scale : 0.0f) + titleW;
    for (const NeonPlateRow& row : rows) {
        const float leftW = gui::GetTextWidth(row.left.c_str(), rowUnits, font);
        const float rightW = gui::GetTextWidth(row.right.c_str(), rowUnits, font);
        const float dotW = row.hasDot ? 12.0f * scale : 0.0f;
        contentW = std::max(contentW, dotW + leftW + rightW + 16.0f * scale);
    }
    return ImVec2(contentW + pad * 2.0f + 4.0f * scale,
                  headH + rowH * static_cast<float>(rows.size()) + pad * 0.65f);
}

} // namespace

// NeonPlateAnim::Update - the Dynamic Island core. Entering rows ease in
// (rise + fade), rows that disappeared stay until their fade completes, and
// the plate size springs toward the target with a slight bounce.
void NeonPlateAnim::Update(const std::vector<NeonPlateRow>& targetRows,
                           float targetW, float scale, float dt,
                           std::vector<NeonPlateRow>& outRows, float& outW,
                           float& outH) {
    constexpr float kEnter = 0.20f;   // seconds to fully appear
    constexpr float kExit = 0.16f;    // seconds to collapse
    const float headH = 24.0f * scale;
    const float rowH = 19.0f * scale;

    // Refresh/keep states for target rows; everything else is exiting.
    for (const NeonPlateRow& row : targetRows) {
        RowState* found = nullptr;
        for (RowState& st : rows) {
            if (st.key == row.left && !st.exiting) { found = &st; break; }
        }
        if (!found) {
            RowState st;
            st.key = row.left;
            st.last = row;
            st.t = 0.0f;
            rows.push_back(std::move(st));
        } else {
            found->last = row;
        }
    }
    for (RowState& st : rows) {
        bool kept = false;
        for (const NeonPlateRow& row : targetRows) {
            if (row.left == st.key) { kept = true; break; }
        }
        st.exiting = !kept;
    }
    // Advance presence; drop finished exits.
    for (RowState& st : rows) {
        if (st.exiting) st.t = std::max(0.0f, st.t - dt / kExit);
        else st.t = std::min(1.0f, st.t + dt / kEnter);
    }
    rows.erase(std::remove_if(rows.begin(), rows.end(),
                              [](const RowState& st) {
                                  return st.exiting && st.t <= 0.0f;
                              }),
               rows.end());

    // Drawable rows: targets in order, then the exiting tail.
    outRows.clear();
    float height = headH;
    for (const NeonPlateRow& row : targetRows) {
        for (const RowState& st : rows) {
            if (st.key != row.left || st.exiting) continue;
            NeonPlateRow out = st.last;
            const float e = 1.0f - (1.0f - st.t) * (1.0f - st.t) * (1.0f - st.t);
            out.t = e;
            out.dy = (1.0f - e) * rowH;
            outRows.push_back(std::move(out));
            height += rowH * e;
            break;
        }
    }
    for (const RowState& st : rows) {
        if (!st.exiting) continue;
        NeonPlateRow out = st.last;
        const float e = 1.0f - (1.0f - st.t) * (1.0f - st.t) * (1.0f - st.t);
        out.t = e;
        out.dy = (1.0f - e) * rowH;
        outRows.push_back(std::move(out));
        height += rowH * e;
    }

    // Spring the plate box toward its target with a soft island bounce.
    if (!started) {
        started = true;
        w = targetW;
        h = height;
        wVel = hVel = 0.0f;
    }
    gui::Spring(w, wVel, targetW, dt, 230.0f, 15.0f);
    gui::Spring(h, hVel, height, dt, 230.0f, 15.0f);
    outW = w;
    outH = h;
}

namespace {

void DrawNeonPlate(const ImVec2& pos, float scale, const ImColor& accent,
                  const char* icon, const char* title, bool outline,
                  const std::vector<NeonPlateRow>& rows, float opacity, bool edgeRight,
                  const ImVec2* sizeOverride = nullptr) {
    ImDrawList* d = gui::Bg();
    ImFont* font = fonts::Current();
    ImFont* icons = fonts::Icon();
    if (!font) return;

    const float pad = 9.0f * scale;
    const float headH = 24.0f * scale;
    const float rowH = 19.0f * scale;
    const float headUnits = 0.68f * scale;
    const float rowUnits = 0.60f * scale;
    const float iconPx = 14.0f * scale;
    const ImVec2 plateSize = sizeOverride ? *sizeOverride
                                          : NeonPlateSize(scale, title, rows);
    const float width = plateSize.x;
    const float height = plateSize.y;
    const ImVec4 rect(pos.x, pos.y, pos.x + width, pos.y + height);
    const float pulse = 0.70f + 0.30f * std::sin(static_cast<float>(GetTickCount64()) * 0.004f);

    // Watermark-like white glass with a very soft accent halo.
    gui::FillShadowRect(rect, accent, 0.045f * pulse, 8.0f * scale, d);
    gui::FillRect(rect, gui::Accent(), 0.32f * opacity, 8.0f * scale, d);
    gui::StrokeRect(rect, ImColor(255, 255, 255), 8.0f * scale, 1.0f, 0.28f * opacity, d);
    // Accent outline (replaces the old header / edge rails).
    (void)edgeRight;
    gui::StrokeRect(rect, accent, 8.0f * scale, outline ? 1.25f * scale : 1.0f,
                    (outline ? 0.92f : 0.55f) * opacity, d);

    float hx = pos.x + pad;
    const float hy = pos.y + (headH - iconPx) * 0.5f;
    if (icon && icon[0] == '\x01') {
        // Marker icon: the Minecraft empty bottle, drawn as vectors,
        // vertically centered next to the title text.
        DrawBottleIcon(d, ImVec2(hx + iconPx * 0.5f, hy + iconPx * 0.5f),
                       iconPx, ImColor(189, 206, 224, 235));
        hx += iconPx + 6.0f * scale;
    } else if (icons && icon && *icon) {
        gui::DrawString(ImVec2(hx, hy), icon, accent, iconPx / gui::kFontUnit,
                        1.0f, false, d, icons);
        hx += iconPx + 6.0f * scale;
    }
    gui::DrawString(ImVec2(hx, pos.y + (headH - gui::GetTextHeight(headUnits, font)) * 0.5f),
                    title, accent, headUnits, 1.0f, true, d, font);

    float y = pos.y + headH;
    for (const NeonPlateRow& row : rows) {
        // Dynamic-Island presence: t fades the row and slides it in from
        // below; exiting rows collapse the same way.
        if (row.t < 0.01f) continue;
        const float rowY = y + row.dy;
        const float textY = rowY + (rowH - gui::GetTextHeight(rowUnits, font)) * 0.5f;
        const float a = row.t;
        float leftX = pos.x + pad;
        if (row.hasDot) {
            DrawNeonDot(d, ImVec2(leftX + 2.0f * scale, rowY + rowH * 0.5f),
                        2.0f * scale, row.dot, a);
            leftX += 10.0f * scale;
        }
        gui::DrawString(ImVec2(leftX, textY), row.left.c_str(), row.color,
                        rowUnits, a, true, d, font);
        const float rightW = gui::GetTextWidth(row.right.c_str(), rowUnits, font);
        const ImColor rightColor = row.hasRightColor ? row.rightColor : row.color;
        gui::DrawString(ImVec2(pos.x + width - pad - rightW, textY), row.right.c_str(),
                        rightColor, rowUnits, 0.92f * a, true, d, font);
        y += rowH * row.t;
    }
}

// Wifi/ping glyph in the flat uiverse style: a dot with three expanding
// arcs. `sweep` (0..1) fills the arcs in so the icon can ride the text
// reveal, and the color reflects link quality (green / amber / red).
void DrawPingIcon(ImDrawList* d, const ImVec2& base, float size, const ImColor& col,
                  float sweep, float alpha) {
    constexpr float kPi = 3.1415927f;
    const float a0 = -kPi * 0.75f, a1 = -kPi * 0.25f;
    for (int i = 0; i < 3; ++i) {
        const float appear = gui::Clamp(sweep * 1.6f - i * 0.22f, 0.0f, 1.0f);
        if (appear <= 0.02f) continue;
        const float r = size * (0.24f + 0.24f * (float)i);
        const float half = (a1 - a0) * 0.5f;
        d->PathArcTo(base, r, a0 + (1.0f - appear) * half,
                     a1 - (1.0f - appear) * half, 14);
        d->PathStroke(ImColor(col.Value.x, col.Value.y, col.Value.z,
                              col.Value.w * alpha * appear),
                      0, size * 0.13f);
    }
    d->AddCircleFilled(base, size * 0.085f,
                       ImColor(col.Value.x, col.Value.y, col.Value.z,
                               col.Value.w * alpha),
                       10);
}

} // namespace

// ======================== Watermark ========================
WatermarkModule::WatermarkModule()
    : Module("HUD", "Watermark", "Top-left tag like PacketV2") {
    hiddenFromLists = true;
    m_text = addSetting<StringSetting>("Text", "Watermark tag.", "Nightfull", 24);
    m_background = addSetting<BoolSetting>("Background", "Dark plate behind the text.", true);
    m_outline = addSetting<BoolSetting>("Outline", "Accent stroke around the plate.", false);
    m_fps = addSetting<BoolSetting>("FPS", "FPS segment.", false);
    m_clock = addSetting<BoolSetting>("Clock", "Clock segment.", false);
    m_ping = addSetting<BoolSetting>("Ping", "Server ping segment.", false);
    m_opacity = addSetting<NumberSetting>("Opacity", "Plate opacity.", 0.88f, 0.0f, 1.0f, 0.05f);
    m_scale = addSetting<NumberSetting>("Scale", "Plate size.", 1.0f, 0.25f, 3.0f, 0.05f);
    AddFreePositionSettings(this, &m_freeOn, &m_freeX, &m_freeY, 0.01f, 0.01f);
    setEnabled(true);
}

void WatermarkModule::onRender() {
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    const float s = m_scale->mValue;
    ImFont* font = fonts::Current();
    if (!font) return;

    std::string text = m_text->mValue.empty() ? "Nightfull" : m_text->mValue;
    const ImGuiIO& io = ImGui::GetIO();
    if (m_fps->mValue) {
        char b[24];
        snprintf(b, sizeof(b), "  |  %d FPS", io.Framerate > 0.1f ? (int)(io.Framerate + 0.5f) : 0);
        text += b;
    }
    if (m_clock->mValue) {
        SYSTEMTIME st{}; GetLocalTime(&st);
        char b[24]; snprintf(b, sizeof(b), "  |  %02u:%02u", st.wHour, st.wMinute);
        text += b;
    }
    // Ping segment: hidden entirely in singleplayer (the game never polls
    // RakNet there, so the cached value goes stale).
    const int ping = m_ping->mValue ? overlay::GetPingMs() : -1;
    const bool hasPing = ping >= 0;
    char pingBuf[24] = {};
    if (hasPing) snprintf(pingBuf, sizeof(pingBuf), "%d ms", ping);

    const float units = 0.78f * s;
    const float pad = 6.0f * s;
    const float ox = 6.0f * s, oy = 3.0f * s;   // PacketV2 top-left margins
    const float iconW = 16.0f * s;
    const float pingW = hasPing ? iconW + 5.0f * s + gui::GetTextWidth(pingBuf, units)
                                : 0.0f;
    const float w = gui::GetTextWidth(text.c_str(), units) + (hasPing ? 10.0f * s : 0.0f) +
                    pingW + pad * 2.0f;
    const float textH = gui::GetTextHeight(units);
    const float h = textH + 8.0f * s;
    const ImVec2 size(w, h);
    // Free position keeps screen-fraction semantics; otherwise the plate sits
    // at the PacketV2 top-left margins.
    const ImVec2 pos = m_freeOn->mValue
        ? ImVec2(m_freeX->mValue * screen.x, m_freeY->mValue * screen.y)
        : ImVec2(ox, oy);
    ImDrawList* d = gui::Bg();
    const ImColor accent = gui::Accent();

    const ImVec4 wrect(pos.x, pos.y, pos.x + w, pos.y + h);
    if (m_background->mValue)
        GlassSurface(wrect, m_opacity->mValue, 8.0f * s, d);
    // Accent outline replaces the old top bar (rounded, always on).
    gui::StrokeRect(wrect, accent, 8.0f * s, m_outline->mValue ? 1.6f : 1.2f,
                    (m_outline->mValue ? 0.95f : 0.7f) * m_opacity->mValue, d);

    // Accent first letter (PacketV2 BOLD "P"), rest white, static text.
    const char* t0 = text.c_str();
    const char* t1 = t0 + 1;
    while (*t1 && ((*t1) & 0xC0) == 0x80) ++t1;
    const float firstW = gui::GetTextWidth(std::string(t0, t1).c_str(), units);
    const ImVec2 tp(pos.x + pad, pos.y + (h - textH) * 0.5f);
    gui::DrawString(tp, std::string(t0, t1).c_str(), accent, units, 1.0f, false);
    gui::DrawString(ImVec2(tp.x + firstW, tp.y), t1, ImColor(255, 255, 255), units, 1.0f, false);
    if (hasPing) {
        const ImColor pingColor = ping < 60 ? ImColor(86, 222, 130)
                                : ping < 140 ? ImColor(255, 196, 86)
                                             : ImColor(255, 92, 92);
        const float iconX = pos.x + pad + gui::GetTextWidth(text.c_str(), units) + 10.0f * s;
        const float iconCY = tp.y + textH - 2.0f * s;
        DrawPingIcon(d, ImVec2(iconX + iconW * 0.5f, iconCY), iconW, pingColor, 1.0f, 1.0f);
        gui::DrawString(ImVec2(iconX + iconW + 5.0f * s, tp.y),
                        pingBuf, pingColor, units, 1.0f, false);
    }

    HudEditChrome(this, name(), pos, size, m_freeOn, m_freeX, m_freeY, m_scale);
}

// ======================== Arraylist ========================
ArraylistModule::ArraylistModule()
    : Module("HUD", "Arraylist", "Right-edge list of enabled modules") {
    hiddenFromLists = false;
    m_style = addSetting<EnumSetting>("Style", "Row style.", 0,
                                     std::vector<std::string>{ "Glass", "Sans" });
    m_showMode = addSetting<BoolSetting>("Show Mode", "First enum value next to the name.", true);
    m_visibility = addSetting<EnumSetting>("Visibility", "Which modules are listed.", 0,
                                           std::vector<std::string>{ "All", "Bound" });
    m_fontSize = addSetting<NumberSetting>("Font Size", "Text size in pixels.", 15.0f, 10.0f, 30.0f, 0.5f);
    m_opacity = addSetting<NumberSetting>("Opacity", "Row opacity.", 0.6f, 0.0f, 1.0f, 0.05f);
    m_scale = addSetting<NumberSetting>("Scale", "Overall scale.", 1.0f, 0.25f, 3.0f, 0.05f);
    AddFreePositionSettings(this, &m_freeOn, &m_freeX, &m_freeY, 0.94f, 0.03f);
    setEnabled(true);
}

void ArraylistModule::onRender() {
    if (overlay::g_showMenu) return;   // the menu has its own right panels
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    const bool sans = m_style->mValue == 1;
    ImFont* font = sans ? fonts::Current() : fonts::UISemi();
    if (!font) return;

    const float s = m_scale->mValue;
    const float px = m_fontSize->mValue * s;
    const float units = px / gui::kFontUnit;
    // Measure pixels include the global text multiplier so e.w/rowH match
    // the scaled DrawString output (units already scale inside DrawString -
    // scaling px itself as well would count the multiplier twice).
    const float mpx = px * gui::GetTextScale();
    const bool boundOnly = m_visibility->mValue == 1;

    const auto& reg = modules().modules();
    if (m_anim.size() != reg.size()) m_anim.assign(reg.size(), 0.0f);

    struct Entry { size_t i; Module* m; std::string name, mode; float w; };
    std::vector<Entry> entries;
    for (size_t i = 0; i < reg.size(); i++) {
        Module* m = reg[i].get();
        if (!m || m->hiddenFromLists || m == this) continue;
        if (boundOnly && m->key() == 0) continue;
        Entry e{ i, m, gui::ApplyNaming(m->name()), "", 0.0f };
        if (m_showMode->mValue) {
            for (const auto& st : m->settings()) {
                if (st->mType == SettingType::Enum) {
                    e.mode = " " + static_cast<EnumSetting*>(st.get())->current();
                    break;
                }
            }
        }
        e.w = font->CalcTextSizeA(mpx, FLT_MAX, 0.0f, (e.name + e.mode).c_str()).x;
        entries.push_back(std::move(e));
    }
    std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {
        if (a.w != b.w) return a.w > b.w;
        return a.name < b.name;
    });

    const ImColor accent = gui::Accent();
    const float dt = gui::GetDeltaTime();
    // Two row styles:
    //  - Glass (default): a fully rounded pill with the theme-accent fill
    //    across the WHOLE row, white hairline border, soft shadow and a
    //    leading accent dot (matches the previous glass look, fixed so the
    //    accent covers the full row instead of a trailing half).
    //  - Sans: no background at all - right-aligned white text plus a thin
    //    accent bar on the trailing edge that darkens per row (HTML guide).
    const float padY = 3.0f * s, textPad = 12.0f * s;
    const float dotD = 6.0f * s, dotGap = 8.0f * s, rowR = 8.0f * s, rowGap = 4.0f * s;
    const float barW = 2.5f * s;
    // Free position anchors the whole block; otherwise the legacy top-right
    // anchor path renders from the right screen edge. With Free position the
    // block mirrors itself: left screen half -> accent tint on the left and
    // left-aligned text, right half -> right layout; bottom half -> rows
    // stack upward instead of downward.
    const bool freePos = m_freeOn->mValue;
    float blockW = 0.0f;
    if (freePos) {
        float maxW = 0.0f;
        for (const Entry& e : entries) maxW = std::max(maxW, e.w);
        blockW = sans ? (maxW + textPad * 2.0f)
                      : (maxW + textPad * 2.0f + dotD + dotGap);
    }
    const ImVec2 origin = freePos
        ? ImVec2(m_freeX->mValue * screen.x, m_freeY->mValue * screen.y)
        : ImVec2(0.0f, 0.0f);
    const bool rightSide = !freePos ||
        (origin.x + blockW * 0.5f >= screen.x * 0.5f);
    // Visible rows first (animation state), so the upward stack can measure
    // its total height before drawing.
    struct Row { const Entry* e; float a; float h; float nameW; };
    std::vector<Row> rows;
    rows.reserve(entries.size());
    float totalH = 0.0f;
    for (const Entry& e : entries) {
        float& a = m_anim[e.i];
        a = gui::Animate(e.m->enabled() ? 1.0f : 0.0f, a, dt * 12.0f);
        if (a < 0.01f) continue;
        const float h = font->CalcTextSizeA(mpx, FLT_MAX, 0.0f, e.name.c_str()).y + padY * 2.0f;
        const float nw = font->CalcTextSizeA(mpx, FLT_MAX, 0.0f, e.name.c_str()).x;
        rows.push_back({ &e, a, h, nw });
        totalH += (h + rowGap) * a;
    }
    const bool up = freePos && (origin.y + totalH * 0.5f >= screen.y * 0.5f);
    const float baseX = freePos ? origin.x : 0.0f;   // right edge (right) / left edge (left)
    const float baseRight = freePos ? origin.x + blockW : screen.x;
    float y = freePos ? (up ? origin.y - totalH : origin.y) : 6.0f * s;
    int visIdx = 0;
    for (const Row& r : rows) {
        const Entry& e = *r.e;
        const float a = r.a;
        const float rowH = r.h;
        const float slide = (1.0f - a) * (sans ? 8.0f : 18.0f) * s;
        const float modeW = e.w - r.nameW;   // mode suffix width (e.w = name+mode)
        if (sans) {
            // Sans: no fill; text + a thin trailing accent bar that darkens
            // down the list. The bar lives inside the trailing padding.
            const float barT = rows.size() <= 1 ? 0.0f
                : (float)visIdx / (float)(rows.size() - 1);
            const ImColor barCol = gui::LerpColor(accent, ImColor(0, 0, 0), barT * 0.72f);
            if (rightSide) {
                const float right = baseRight + slide;
                const float textRight = right - textPad;
                const float nameX = textRight - e.w;
                const float modeX = textRight - modeW;
                const float barX = right - barW;
                gui::FillRect(ImVec4(barX, y, right, y + rowH), barCol, a, 1.0f * s);
                if (!e.mode.empty())
                    gui::DrawString(ImVec2(modeX, y + padY), e.mode.c_str(),
                                    accent, units * 0.85f, 0.55f * a, false, nullptr, font);
                gui::DrawString(ImVec2(nameX, y + padY), e.name.c_str(),
                                ImColor(255, 255, 255), units, 0.88f * a, true, nullptr, font);
            } else {
                const float left = baseX - slide;
                const float textLeft = left + textPad;
                const float nameX = textLeft;
                const float modeX = textLeft + r.nameW;
                const float barX = left + blockW - barW;
                gui::FillRect(ImVec4(barX, y, barX + barW, y + rowH), barCol, a, 1.0f * s);
                gui::DrawString(ImVec2(nameX, y + padY), e.name.c_str(),
                                ImColor(255, 255, 255), units, 0.88f * a, true, nullptr, font);
                if (!e.mode.empty())
                    gui::DrawString(ImVec2(modeX, y + padY), e.mode.c_str(),
                                    accent, units * 0.85f, 0.55f * a, false, nullptr, font);
            }
        } else {
            // Glass: full-row accent pill + leading dot.
            if (rightSide) {
                const float right = baseRight + slide;
                const float textRight = right - textPad;
                const float nameX = textRight - e.w;
                const float modeX = textRight - modeW;
                const float dotLead = nameX - dotGap - dotD;
                const float left = dotLead - textPad;
                const ImVec4 rect(left, y, right, y + rowH);
                gui::FillShadowRect(rect, ImColor(0, 0, 0), 0.25f * a, rowR);
                gui::FillRect(rect, accent, 0.32f * m_opacity->mValue * a, rowR);
                gui::StrokeRect(rect, ImColor(255, 255, 255), rowR, 1.0f * s, 0.28f * a);
                const float dotCx = dotLead + dotD * 0.5f;
                const float dotCy = y + rowH * 0.5f;
                gui::FillCircle(ImVec2(dotCx, dotCy), dotD * 0.5f, accent, a);
                gui::FillCircle(ImVec2(dotCx - dotD * 0.12f, dotCy - dotD * 0.12f), dotD * 0.2f,
                                gui::LerpColor(accent, ImColor(255, 255, 255), 0.35f), a);
                if (!e.mode.empty())
                    gui::DrawString(ImVec2(modeX, y + padY), e.mode.c_str(),
                                    ImColor(255, 255, 255), units, 0.7f * a, false, nullptr, font);
                gui::DrawString(ImVec2(nameX, y + padY), e.name.c_str(),
                                ImColor(255, 255, 255), units, a, false, nullptr, font);
            } else {
                const float left = baseX - slide;
                const float textLeft = left + textPad;
                const float nameX = textLeft;
                const float modeX = textLeft + r.nameW;
                const float dotLead = textLeft + e.w + dotGap;
                const float right = dotLead + dotD + textPad;
                const ImVec4 rect(left, y, right, y + rowH);
                gui::FillShadowRect(rect, ImColor(0, 0, 0), 0.25f * a, rowR);
                gui::FillRect(rect, accent, 0.32f * m_opacity->mValue * a, rowR);
                gui::StrokeRect(rect, ImColor(255, 255, 255), rowR, 1.0f * s, 0.28f * a);
                const float dotCx = dotLead + dotD * 0.5f;
                const float dotCy = y + rowH * 0.5f;
                gui::FillCircle(ImVec2(dotCx, dotCy), dotD * 0.5f, accent, a);
                gui::FillCircle(ImVec2(dotCx - dotD * 0.12f, dotCy - dotD * 0.12f), dotD * 0.2f,
                                gui::LerpColor(accent, ImColor(255, 255, 255), 0.35f), a);
                gui::DrawString(ImVec2(nameX, y + padY), e.name.c_str(),
                                ImColor(255, 255, 255), units, a, false, nullptr, font);
                if (!e.mode.empty())
                    gui::DrawString(ImVec2(modeX, y + padY), e.mode.c_str(),
                                    ImColor(255, 255, 255), units, 0.7f * a, false, nullptr, font);
            }
        }
        y += (rowH + rowGap) * a;
        visIdx++;
    }
    if (overlay::HudEditActive() && !overlay::g_showMenu && rows.empty()) {
        // Editor ghost: an empty list draws nothing, so show a grabbable
        // placeholder that can be moved and resized like the live block.
        const ImVec2 gpos = freePos ? origin : ImVec2(screen.x - 220.0f * s, 6.0f * s);
        HudEditChrome(this, name(), gpos, ImVec2(220.0f * s, 30.0f * s),
                      m_freeOn, m_freeX, m_freeY, m_scale);
    } else if (freePos && !rows.empty()) {
        const ImVec2 boxPos = up ? ImVec2(origin.x, origin.y - totalH) : origin;
        HudEditChrome(this, name(), boxPos, ImVec2(blockW, totalH),
                      m_freeOn, m_freeX, m_freeY, m_scale);
    }
}

// ======================== Potions ========================
PotionsModule::PotionsModule()
    : Module("HUD", "Potions", "Active potion effects in the Keybinds plate style") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", TopLeft, HudPositionNames());
    m_fontSize = addSetting<NumberSetting>("Font Size", "Text size in pixels.", 15.0f, 10.0f, 30.0f, 0.5f);
    m_scale = addSetting<NumberSetting>("Scale", "Overall scale.", 1.0f, 0.25f, 3.0f, 0.05f);
    m_opacity = addSetting<NumberSetting>("Opacity", "Row opacity.", 0.6f, 0.0f, 1.0f, 0.05f);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Follow the theme accent.", true);
    m_color = addSetting<ColorSetting>("Color", "Accent when Theme Color is off.", 0xFF8E5CFF);
    m_outline = addSetting<BoolSetting>("Outline", "Neon outline around the plate.", true);
    AddFreePositionSettings(this, &m_freeOn, &m_freeX, &m_freeY, 0.5f, 0.1f);
    setEnabled(true);
}

void PotionsModule::onRender() {
    if (overlay::g_showMenu || !overlay::IsInWorld()) return;
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    ImFont* font = fonts::Current();
    if (!font) return;

    static const char* names[] = {
        "Speed", "Slowness", "Haste", "Mining Fatigue", "Strength",
        "Instant Health", "Instant Damage", "Jump Boost", "Nausea", "Regeneration",
        "Resistance", "Fire Resistance", "Water Breathing", "Invisibility", "Blindness",
        "Night Vision", "Hunger", "Weakness", "Poison", "Wither", "Health Boost",
        "Absorption", "Saturation", "Levitation", "Fatal Poison", "Conduit Power",
        "Slow Falling", "Bad Omen", "Hero of the Village", "Darkness", "Trial Omen",
        "Wind Charged", "Weaving", "Oozing", "Infested", "Raid Omen"
    };

    struct Row {
        std::string left;
        std::string right;
        ImColor nameColor = kGlassText;
        float width = 0.0f;
    };

    overlay::PotionEffect effects[24]{};
    const int count = overlay::GetPotionEffects(effects, 24);
    std::vector<Row> rows;
    rows.reserve(count);
    const float scale = m_scale->mValue;
    const float units = 0.60f * scale;
    const ImColor normalName = kGlassText;
    const ImColor dangerName(255, 48, 48);
    const ImColor timerColor = kGlassMuted;

    for (int i = 0; i < count; ++i) {
        const overlay::PotionEffect& effect = effects[i];
        if (effect.id < 1 || effect.id > sizeof(names) / sizeof(names[0])) continue;

        Row row;
        // Bedrock stores amplifier as zero-based; the HUD displays the
        // actual level, exactly as the previous working PotionsHud did.
        row.left = std::string(names[effect.id - 1]) + " " +
                   std::to_string(effect.amplifier + 1);
        if (effect.noCounter || effect.duration <= 0) {
            row.right = "\xE2\x88\x9E";
        } else {
            const int seconds = effect.duration / 20;
            char time[20]{};
            snprintf(time, sizeof(time), "%d:%02d", seconds / 60, seconds % 60);
            row.right = time;
        }

        // Start the warning ramp below 20 seconds and reach full red at zero.
        // Permanent effects with an infinity counter stay at the normal colour.
        const float remainingSeconds =
            effect.noCounter || effect.duration <= 0
                ? 100000.0f
                : static_cast<float>(effect.duration) / 20.0f;
        const float danger = gui::Clamp((20.0f - remainingSeconds) / 20.0f,
                                        0.0f, 1.0f);
        row.nameColor = gui::LerpColor(normalName, dangerName, danger);
        row.width = gui::GetTextWidth(row.left.c_str(), units, font) +
                    gui::GetTextWidth(row.right.c_str(), units, font) + 34.0f * scale;
        rows.push_back(std::move(row));
    }

    // Keep the plate/header visible like Keybinds, but never invent an
    // individual effect row when the reader returns no active effects.
    std::sort(rows.begin(), rows.end(), [](const Row& a, const Row& b) {
        if (a.width != b.width) return a.width > b.width;
        return a.left < b.left;
    });

    std::vector<NeonPlateRow> plateRows;
    plateRows.reserve(rows.size() + 1);
    for (const Row& row : rows) {
        NeonPlateRow plate;
        plate.left = row.left;
        plate.right = row.right;
        plate.color = row.nameColor;
        plate.rightColor = timerColor;
        plate.hasRightColor = true;
        // Keybinds uses one status dot per row; Potions uses the accent dot
        // while the live warning colour is reserved for the effect name.
        plate.dot = AccentOf(m_useTheme, m_color);
        plate.hasDot = true;
        plateRows.push_back(std::move(plate));
    }
    // Editor ghost: with no active effects the plate shrinks to a header,
    // so the editor shows a sample row that can be moved and resized. It
    // rides the same presence animator and slides out when real effects
    // arrive (stable key, never persisted).
    if (plateRows.empty() && overlay::HudEditActive() && !overlay::g_showMenu) {
        NeonPlateRow ghost;
        ghost.left = "No effects";
        ghost.right = "--";
        ghost.color = kGlassMuted;
        ghost.rightColor = timerColor;
        ghost.hasRightColor = true;
        plateRows.push_back(std::move(ghost));
    }

    const ImColor accent = AccentOf(m_useTheme, m_color);
    const ImVec2 targetSize = NeonPlateSize(scale, "Potions", plateRows);
    // Dynamic Island: rows morph in/out and the plate springs to its size.
    std::vector<NeonPlateRow> animRows;
    float plateW = targetSize.x, plateH = targetSize.y;
    m_anim.Update(plateRows, targetSize.x, scale, gui::GetDeltaTime(),
                  animRows, plateW, plateH);
    const ImVec2 plateSize(plateW, plateH);
    const bool edgeRight = m_position->mValue == TopRight || m_position->mValue == BottomRight;
    const ImVec2 pos = HudResolvePos(m_freeOn->mValue, m_freeX->mValue, m_freeY->mValue,
                                     screen, plateSize, m_position->mValue);
    DrawNeonPlate(pos, scale, accent, "\x01", "Potions",
                  m_outline->mValue, animRows, m_opacity->mValue, edgeRight,
                  &plateSize);
    HudEditChrome(this, name(), pos, plateSize, m_freeOn, m_freeX, m_freeY, m_scale);
}

// ======================== FPS ========================
FpsModule::FpsModule()
    : Module("HUD", "FPS Counter", "Плавность игры в реальном времени.") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", BottomLeft, HudPositionNames());
    m_scale = addSetting<NumberSetting>("Scale", "Chip size.", 1.0f, 0.25f, 3.0f, 0.05f);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Follow the theme accent.", true);
    m_color = addSetting<ColorSetting>("Color", "Bar color when Theme Color is off.", 0xFF8E5CFF);
    AddFreePositionSettings(this, &m_freeOn, &m_freeX, &m_freeY, 0.5f, 0.1f);
    setEnabled(true);
}

void FpsModule::onRender() {
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    const ImGuiIO& io = ImGui::GetIO();
    const float fps = io.Framerate > 0.1f ? io.Framerate
                                          : (io.DeltaTime > 0.0f ? 1.0f / io.DeltaTime : 0.0f);
    char b[32]; snprintf(b, sizeof(b), "FPS: %d", (int)(fps + 0.5f));
    const ImVec2 size = ChipSize(b, m_scale->mValue);
    const ImVec2 pos = HudResolvePos(m_freeOn->mValue, m_freeX->mValue, m_freeY->mValue,
                                     screen, size, m_position->mValue);
    DrawChip(pos, b, m_scale->mValue, AccentOf(m_useTheme, m_color));
    HudEditChrome(this, name(), pos, size, m_freeOn, m_freeX, m_freeY, m_scale);
}

// ======================== CPS ========================
CpsModule::CpsModule() : Module("HUD", "CPS", "Clicks-per-second chip") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", BottomRight, HudPositionNames());
    m_scale = addSetting<NumberSetting>("Scale", "Pill size.", 1.0f, 0.25f, 3.0f, 0.05f);
    m_buttons = addSetting<BoolSetting>("Buttons", "Separate LMB / RMB counters.", true);
    m_outline = addSetting<BoolSetting>("Outline", "Accent stroke around the pill.", false);
    m_opacity = addSetting<NumberSetting>("Opacity", "Pill opacity.", 0.88f, 0.0f, 1.0f, 0.05f);
    AddFreePositionSettings(this, &m_freeOn, &m_freeX, &m_freeY, 0.5f, 0.1f);
    setEnabled(true);
}

void CpsModule::onRender() {
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    // Counts are the clicks the game actually registered (post-CPS-limiter),
    // straight from the mouse feed gate - same source Flarial's CPSCounter
    // uses, so the chip matches the limiter instead of raw physical clicks.
    const int l = overlay::GetRegisteredCps(true);
    const int r = overlay::GetRegisteredCps(false);
    char val[32];
    if (m_buttons->mValue) snprintf(val, sizeof(val), "%d / %d", l, r);
    else snprintf(val, sizeof(val), "%d", l);
    // Same visual component as Reach Display, only the glyph/label/value
    // differ: [mouse icon] CPS 12.
    const ImVec2 size = StatusPillSize(m_scale->mValue, "CPS", val);
    const ImVec2 pos = HudResolvePos(m_freeOn->mValue, m_freeX->mValue, m_freeY->mValue,
                                     screen, size, m_position->mValue);
    DrawStatusPill(pos, m_scale->mValue, m_opacity->mValue, m_outline->mValue,
                   PillIcon::Mouse, "CPS", val);
    HudEditChrome(this, name(), pos, size, m_freeOn, m_freeX, m_freeY, m_scale);
}

// ======================== Keybinds ========================
KeybindsModule::KeybindsModule()
    : Module("HUD", "Keybinds", "Plate of bound modules with status dots") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", TopRight, HudPositionNames());
    m_scale = addSetting<NumberSetting>("Scale", "Plate size.", 1.0f, 0.25f, 3.0f, 0.05f);
    m_outline = addSetting<BoolSetting>("Outline", "Neon outline around the plate.", true);
    m_opacity = addSetting<NumberSetting>("Opacity", "Plate opacity.", 0.88f, 0.0f, 1.0f, 0.05f);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Follow the theme accent.", true);
    m_color = addSetting<ColorSetting>("Color", "Accent when Theme Color is off.", 0xFF8E5CFF);
    AddFreePositionSettings(this, &m_freeOn, &m_freeX, &m_freeY, 0.5f, 0.1f);
    setEnabled(true);
}

void KeybindsModule::onRender() {
    if (overlay::g_showMenu || !overlay::IsInWorld()) return;   // the menu has its own Keybinds panel
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    ImFont* font = fonts::Current();
    if (!font) return;

    struct Row { std::string name, key; bool on; float width = 0.0f; };
    std::vector<Row> rows;
    const float scale = m_scale->mValue;
    const float px = 15.0f * scale;
    // Widths here go through the scaled gui:: helpers, so no manual px is
    // needed (unlike Arraylist/Watermark, which measure raw pixels).
    const float units = px / gui::kFontUnit;
    for (const auto& m : modules().modules()) {
        if (!m || m->hiddenFromLists || m->key() <= 0) continue;
        const std::string raw = m->name();
        if (raw == "Watermark" || raw == "Arraylist" || raw == "Potions" || raw == "Keybinds") continue;
        Row row{ gui::ApplyNaming(raw.c_str()), keys::Name(m->key()), m->enabled() };
        row.width = gui::GetTextWidth(row.name.c_str(), units) +
                    gui::GetTextWidth(row.key.c_str(), units) + 42.0f * scale;
        rows.push_back(std::move(row));
    }
    if (rows.empty()) {
        Row empty;
        empty.name = "Keybinds";
        empty.key = "No binds";
        empty.on = false;
        empty.width = gui::GetTextWidth(empty.name.c_str(), units) +
                      gui::GetTextWidth(empty.key.c_str(), units) + 42.0f * scale;
        rows.push_back(std::move(empty));
    }
    std::sort(rows.begin(), rows.end(), [](const Row& a, const Row& b) {
        if (a.width != b.width) return a.width > b.width;
        return a.name < b.name;
    });

    std::vector<NeonPlateRow> plateRows;
    plateRows.reserve(rows.size());
    for (const Row& row : rows) {
        NeonPlateRow plate;
        plate.left = row.name;
        plate.right = row.key;
        plate.color = kGlassText;
        plate.dot = row.on ? ImColor(50, 235, 110) : ImColor(235, 70, 80);
        plate.hasDot = true;
        plateRows.push_back(std::move(plate));
    }
    const ImColor accent = AccentOf(m_useTheme, m_color);
    const ImVec2 targetSize = NeonPlateSize(scale, "Keybinds", plateRows);
    // Dynamic Island: rows morph in/out and the plate springs to its size.
    std::vector<NeonPlateRow> animRows;
    float plateW = targetSize.x, plateH = targetSize.y;
    m_anim.Update(plateRows, targetSize.x, scale, gui::GetDeltaTime(),
                  animRows, plateW, plateH);
    const ImVec2 plateSize(plateW, plateH);
    const bool edgeRight = m_position->mValue == TopRight || m_position->mValue == BottomRight;
    const ImVec2 pos = HudResolvePos(m_freeOn->mValue, m_freeX->mValue, m_freeY->mValue,
                                     screen, plateSize, m_position->mValue);
    DrawNeonPlate(pos, scale, accent, "\xEE\x8A\x84", "Keybinds",
                  m_outline->mValue, animRows, m_opacity->mValue, edgeRight,
                  &plateSize);
    HudEditChrome(this, name(), pos, plateSize, m_freeOn, m_freeX, m_freeY, m_scale);
}

// ======================== Reach Display ========================
ReachDisplayModule::ReachDisplayModule()
    : Module("Combat", "Reach Display", "Расстояние до цели при попадании") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", TopLeft, HudPositionNames());
    m_scale = addSetting<NumberSetting>("Scale", "Pill size.", 1.0f, 0.25f, 3.0f, 0.05f);
    m_outline = addSetting<BoolSetting>("Outline", "Accent stroke around the pill.", false);
    m_opacity = addSetting<NumberSetting>("Opacity", "Pill opacity.", 0.88f, 0.0f, 1.0f, 0.05f);
    AddFreePositionSettings(this, &m_freeOn, &m_freeX, &m_freeY, 0.5f, 0.1f);
    setEnabled(true);
}

void ReachDisplayModule::onRender() {
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;

    // Flarial ReachCounter format: two decimals, 0.00 before the first hit
    // and after the 15 s idle reset (handled by the overlay reader).
    const float value = overlay::GetReachValue();
    char val[16];
    snprintf(val, sizeof(val), "%.2f", value);

    // Shared status pill (the CPS counter renders through the same one):
    // [target glyph] Reach X.XX in the Watermark pill style.
    const ImVec2 size = StatusPillSize(m_scale->mValue, "Reach", val);
    const ImVec2 pos = HudResolvePos(m_freeOn->mValue, m_freeX->mValue, m_freeY->mValue,
                                     screen, size, m_position->mValue);
    DrawStatusPill(pos, m_scale->mValue, m_opacity->mValue, m_outline->mValue,
                   PillIcon::Target, "Reach", val);
    HudEditChrome(this, name(), pos, size, m_freeOn, m_freeX, m_freeY, m_scale);
}

// ======================== Target HUD ========================
// SystemDLC TargetHudElement geometry (175x54, radius 12, 54x54 head panel,
// 45x45 face at +4.5 with radius 6, HP bar radius 4, danger->caution->success
// HP colour, 4.5/s cubic appear animation, 0.1/frame HP smoothing) plus the
// damage feedback of the attached prototype (shake .34 s, red flash .42 s,
// floating damage number .62 s, cyan particles .55 s).
namespace {

ImColor ThLerp(const ImColor& a, const ImColor& b, float t) {
    t = t < 0.0f ? 0.0f : (t > 1.0f ? 1.0f : t);
    return ImColor(a.Value.x + (b.Value.x - a.Value.x) * t,
                   a.Value.y + (b.Value.y - a.Value.y) * t,
                   a.Value.z + (b.Value.z - a.Value.z) * t,
                   a.Value.w + (b.Value.w - a.Value.w) * t);
}

// SystemDLC TargetHudElement: danger -> caution below 50 %, caution ->
// success above (ThemePalette danger FCA5A5, caution FDBA74, success 86EFAC).
ImColor ThHpColor(float f) {
    const ImColor danger(0xFC, 0xA5, 0xA5), caution(0xFD, 0xBA, 0x74), success(0x86, 0xEF, 0xAC);
    if (f >= 0.5f) return ThLerp(caution, success, (f - 0.5f) / 0.5f);
    return ThLerp(danger, caution, f / 0.5f);
}

ImU32 ThCol(const ImColor& c, float a) {
    return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w * a));
}

// Piecewise-linear keyframe lookup (t in 0..1).
float ThKey(const float (*k)[2], int n, float t) {
    if (t <= k[0][0]) return k[0][1];
    for (int i = 0; i + 1 < n; ++i) {
        if (t <= k[i + 1][0]) {
            const float f = (t - k[i][0]) / (k[i + 1][0] - k[i][0]);
            return k[i][1] + (k[i + 1][1] - k[i][1]) * f;
        }
    }
    return k[n - 1][1];
}

} // namespace

TargetHudModule::TargetHudModule()
    : Module("Combat", "Target HUD", "Лицо, ник и HP игрока под прицелом") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", BottomRight, HudPositionNames());
    m_scale = addSetting<NumberSetting>("Scale", "Card size.", 1.25f, 0.25f, 3.0f, 0.05f);
    m_opacity = addSetting<NumberSetting>("Opacity", "Card opacity.", 0.96f, 0.05f, 1.0f, 0.05f);
    m_theme = addSetting<EnumSetting>("Theme", "Card palette (Light = SystemDLC default).", 0,
                                      std::vector<std::string>{ "Dark", "Light" });
    m_range = addSetting<NumberSetting>("Range", "Max distance to the looked-at player, blocks.",
                                        6.0f, 2.0f, 6.0f, 0.5f);
    m_hideDelay = addSetting<NumberSetting>("Hide Delay", "Hide after the crosshair leaves the player, ms.",
                                            300.0f, 0.0f, 2000.0f, 50.0f);
    m_shake = addSetting<BoolSetting>("Shake", "Shake the card when the target takes damage.", true);
    m_particles = addSetting<BoolSetting>("Particles", "Particle burst on target damage.", true);
    m_damageNumbers = addSetting<BoolSetting>("Damage Numbers", "Floating -HP number on damage.", true);
    m_hurtTint = addSetting<BoolSetting>("Hurt Tint", "Face turns red while the target is hurt.", true);
    AddFreePositionSettings(this, &m_freeOn, &m_freeX, &m_freeY, 0.53f, 0.56f);
    setEnabled(true);
}

void TargetHudModule::onRender() {
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f || screen.y <= 0.0f) return;
    const float dt = std::min(gui::GetDeltaTime(), 0.1f);
    ImDrawList* d = gui::Bg();

    if (!overlay::g_showMenu)
        overlay::UpdateTargetLook(m_range->mValue, (int)m_hideDelay->mValue);

    overlay::TargetHudInfo info{};
    const bool has = overlay::GetTargetHudInfo(&info);
    const bool ghost = !has && overlay::HudEditActive() && !overlay::g_showMenu;

    if (has) {
        if (std::strncmp(m_name, info.name, sizeof(m_name)) != 0) {
            // New target: snap the bars, no fake damage from the switch.
            std::snprintf(m_name, sizeof(m_name), "%s", info.name);
            m_lastHp = -1.0f;
            m_hpShown = m_hpTrail = info.healthValid && info.maxHealth > 0.0f
                                        ? gui::Clamp(info.health / info.maxHealth, 0.0f, 1.0f) : 1.0f;
            m_lastGen = info.damageGen;
            m_skinValid = false;
        }
        std::memcpy(m_pos, info.pos, sizeof(m_pos));
        m_hpValid = info.healthValid;
        if (info.healthValid) { m_hp = info.health; m_maxHp = info.maxHealth; }
        if (info.skinValid) { m_skinValid = true; std::memcpy(m_face, info.face, sizeof(m_face)); }
    } else if (ghost) {
        std::snprintf(m_name, sizeof(m_name), "%s", "Player");
        m_hpValid = true; m_hp = 15.0f; m_maxHp = 20.0f;
        m_skinValid = false;
    }

    // SystemDLC Animation(4.5) + cubic ease-out (1 - (1 - t)^3).
    const float want = (has || ghost) ? 1.0f : 0.0f;
    m_showP += (want > m_showP ? 1.0f : -1.0f) * dt * 4.5f;
    m_showP = gui::Clamp(m_showP, 0.0f, 1.0f);
    const float ease = 1.0f - (1.0f - m_showP) * (1.0f - m_showP) * (1.0f - m_showP);
    if (ease < 0.01f) {
        m_partCount = 0;
        m_wasVisible = false;
        for (auto& n : m_nums) n.t = -1.0f;
        m_name[0] = 0;
        return;
    }

    // ---- damage detection (target received damage) ----
    m_sinceEdge += dt;
    bool edge = false;
    if (has && m_wasVisible && info.damageGen != m_lastGen) edge = true;
    if (has) m_lastGen = info.damageGen;
    m_wasVisible = has;
    float hpDrop = 0.0f;
    if (has && m_hpValid) {
        if (m_lastHp >= 0.0f && m_hp < m_lastHp - 0.05f) hpDrop = m_lastHp - m_hp;
        m_lastHp = m_hp;
    }
    // An HP drop without a hurtTime edge (e.g. edge missed between polls)
    // still counts as damage, but never twice for one hit.
    if (hpDrop > 0.0f && !edge && m_sinceEdge > 0.35f) edge = true;
    if (edge) {
        m_sinceEdge = 0.0f;
        if (m_shake->mValue) m_shakeT = 0.0f;
        m_flashT = 0.0f;
    }
    if (hpDrop > 0.0f && m_damageNumbers->mValue) {
        DamageNum* slot = &m_nums[0];
        for (auto& n : m_nums) if (n.t < 0.0f) { slot = &n; break; }
        static int s_seed = 0;
        slot->value = hpDrop;
        slot->t = 0.0f;
        slot->dx = (float)((s_seed++ * 37) % 21 - 10);
    }

    // ---- geometry ----
    const float s = m_scale->mValue;
    const float W = 175.0f * s, H = 54.0f * s;
    ImVec2 pos;
    if (m_freeOn && m_freeOn->mValue) {
        pos = HudResolvePos(true, m_freeX->mValue, m_freeY->mValue, screen, ImVec2(W, H),
                            m_position->mValue);
    } else {
        // Default home: just below-right of the crosshair.
        pos = ImVec2(screen.x * 0.5f + 28.0f * s, screen.y * 0.5f + 28.0f * s);
    }
    const ImVec2 editPos = pos;

    // Appear scale (0.9 -> 1) around the card centre.
    const float sc = 0.9f + 0.1f * ease;
    const float cw = W * sc, ch = H * sc, u = s * sc;
    float x = pos.x + (W - cw) * 0.5f, y = pos.y + (H - ch) * 0.5f;

    // Prototype shake keyframes (.34 s).
    if (m_shakeT >= 0.0f) {
        m_shakeT += dt;
        const float t = m_shakeT / 0.34f;
        if (t >= 1.0f) m_shakeT = -1.0f;
        else {
            static const float kx[7][2] = { {0,0}, {.12f,-5}, {.25f,5}, {.40f,-4}, {.55f,3}, {.70f,-2}, {1,0} };
            static const float ky[7][2] = { {0,0}, {.12f,1}, {.25f,-1}, {.40f,1}, {.55f,0}, {.70f,0}, {1,0} };
            x += ThKey(kx, 7, t) * u;
            y += ThKey(ky, 7, t) * u;
        }
    }
    float flash = 0.0f;
    if (m_flashT >= 0.0f) {
        m_flashT += dt;
        const float t = m_flashT / 0.42f;
        if (t >= 1.0f) m_flashT = -1.0f;
        else {
            static const float kf[4][2] = { {0,0}, {.14f,1}, {.55f,.4f}, {1,0} };
            flash = ThKey(kf, 4, t);
        }
    }

    const float a = ease * m_opacity->mValue;
    const bool light = m_theme->mValue == 1;
    const ImColor bg = light ? ImColor(0xFF, 0xFF, 0xFF) : ImColor(0x14, 0x1B, 0x26);
    const ImColor bg2 = light ? ImColor(0xFA, 0xFA, 0xFA) : ImColor(0x09, 0x0E, 0x16);
    const ImColor elevated = light ? ImColor(0xF5, 0xF5, 0xF5) : ImColor(0x1C, 0x25, 0x33);
    const ImColor border = light ? ImColor(0xE5, 0xE5, 0xE5) : ImColor(255, 255, 255, 32);
    const ImColor fg = light ? ImColor(0x0A, 0x0A, 0x0A) : ImColor(0xF5, 0xF7, 0xFA);
    const ImColor muted = light ? ImColor(0x73, 0x73, 0x73) : ImColor(0x8A, 0x96, 0xA8);
    const ImColor track = light ? ImColor(0xE5, 0xE5, 0xE5) : ImColor(255, 255, 255, 26);
    const float R = 12.0f * u;

    // Card body: Arraylist Glass style (translucent theme accent, hairline border, shadow).
    const ImVec4 card(x, y, x + cw, y + ch);
    GlassSurface(card, a, R, d);
    if (flash > 0.001f) {
        const ImColor red(0xFF, 0x66, 0x66);
        gui::FillShadowRect(ImVec4(card.x - 4 * u, card.y - 4 * u, card.z + 4 * u, card.w + 4 * u),
                            ImColor(0xFF, 0x44, 0x44), 0.20f * flash * a, R + 4 * u, d);
        d->AddRect(ImVec2(card.x - 3 * u, card.y - 3 * u), ImVec2(card.z + 3 * u, card.w + 3 * u),
                   ThCol(red, flash * a), R + 3 * u, 0, 1.2f * u);
    }

    // Head panel: subtle tinted glass inset
    d->AddRectFilled(ImVec2(x, y), ImVec2(x + 54.0f * u, y + ch), ImGui::GetColorU32(ImVec4(0, 0, 0, 0.22f * a)), R,
                     ImDrawFlags_RoundCornersLeft);
    const float fx = x + 4.5f * u, fy = y + 4.5f * u, fs = 45.0f * u, px = fs / 8.0f;
    const float faceR = std::min(6.0f * u, px);
    // Red hurt tint (Flarial HurtColor idea): live hurtTime while known,
    // otherwise the damage flash envelope.
    float tint = 0.0f;
    if (m_hurtTint->mValue && has) {
        if (info.hurtTime > 0) tint = 0.55f * (float)info.hurtTime / 10.0f;
        else if (m_flashT >= 0.0f) tint = 0.55f * flash;
    }
    const ImColor hurt(1.0f, 0.24f, 0.24f);
    if (m_skinValid) {
        for (int py = 0; py < 8; ++py) {
            for (int pxi = 0; pxi < 8; ++pxi) {
                ImColor c(m_face[py * 8 + pxi]);
                if (tint > 0.0f) c = ThLerp(c, hurt, tint);
                ImDrawFlags fl = ImDrawFlags_RoundCornersNone;
                float rr = 0.0f;
                if (pxi == 0 && py == 0) { fl = ImDrawFlags_RoundCornersTopLeft; rr = faceR; }
                else if (pxi == 7 && py == 0) { fl = ImDrawFlags_RoundCornersTopRight; rr = faceR; }
                else if (pxi == 0 && py == 7) { fl = ImDrawFlags_RoundCornersBottomLeft; rr = faceR; }
                else if (pxi == 7 && py == 7) { fl = ImDrawFlags_RoundCornersBottomRight; rr = faceR; }
                // +0.5 px overlap hides seams between the pixel quads.
                d->AddRectFilled(ImVec2(fx + pxi * px, fy + py * px),
                                 ImVec2(fx + (pxi + 1) * px + 0.5f, fy + (py + 1) * px + 0.5f),
                                 ThCol(c, a), rr, fl);
            }
        }
    } else {
        // No skin proven on this build/server: initial-letter avatar.
        ImColor c0 = gui::Accent(), c1 = ThLerp(gui::Accent(), ImColor(0, 0, 0), 0.45f);
        if (tint > 0.0f) { c0 = ThLerp(c0, hurt, tint); c1 = ThLerp(c1, hurt, tint); }
        gui::FillGradientV(ImVec4(fx, fy, fx + fs, fy + fs), c0, c1, a, a, 6.0f * u, d);
        char ini[2] = { m_name[0] ? (char)std::toupper((unsigned char)m_name[0]) : 'P', 0 };
        const float iu = 22.0f * u / gui::kFontUnit / gui::GetTextScale();
        const float iw = gui::GetTextWidth(ini, iu, fonts::Bold());
        const float ih = gui::GetTextHeight(iu, fonts::Bold());
        gui::DrawString(ImVec2(fx + (fs - iw) * 0.5f, fy + (fs - ih) * 0.5f), ini,
                        ImColor(255, 255, 255), iu, a, false, d, fonts::Bold());
    }

    // Text column.
    const float ts = gui::GetTextScale();
    const float nameU = 13.0f * u / gui::kFontUnit / ts;
    const float hpU = 12.0f * u / gui::kFontUnit / ts;
    const float subU = 9.5f * u / gui::kFontUnit / ts;
    const float tx = x + 54.0f * u + 8.0f * u;
    const float right = x + cw - 8.0f * u;

    const float frac = m_hpValid && m_maxHp > 0.0f ? gui::Clamp(m_hp / m_maxHp, 0.0f, 1.0f) : 1.0f;
    // SystemDLC smoothing: 0.1 per 60 Hz frame, frame-rate independent.
    const float k = 1.0f - std::pow(0.9f, dt * 60.0f);
    m_hpShown += (frac - m_hpShown) * k;
    if (m_hpTrail < m_hpShown) { m_hpTrail = m_hpShown; m_trailHold = 0.0f; }
    else if (m_hpTrail > m_hpShown + 0.001f) {
        m_trailHold += dt;
        if (m_trailHold > 0.35f) m_hpTrail += (m_hpShown - m_hpTrail) * (1.0f - std::pow(0.92f, dt * 60.0f));
    }
    const ImColor hpc = m_hpValid ? ThHpColor(m_hpShown) : muted;

    char hpText[24];
    if (m_hpValid) std::snprintf(hpText, sizeof(hpText), "%.1f", m_hp);
    else std::snprintf(hpText, sizeof(hpText), "--");
    const float hpW = gui::GetTextWidth(hpText, hpU, fonts::Bold());
    gui::DrawString(ImVec2(right - hpW, y + 8.0f * u), hpText, hpc, hpU, a, false, d, fonts::Bold());

    // Name (clipped before the HP text).
    {
        char nick[24];
        std::snprintf(nick, sizeof(nick), "%s", m_name[0] ? m_name : "Player");
        const float maxW = right - hpW - 6.0f * u - tx;
        while (nick[0] && gui::GetTextWidth(nick, nameU, fonts::Bold()) > maxW) {
            const size_t n = std::strlen(nick);
            if (n <= 1) break;
            nick[n - 1] = 0;
        }
        gui::DrawString(ImVec2(tx, y + 7.0f * u), nick, fg, nameU, a, false, d, fonts::Bold());
    }
    // Distance sub line.
    {
        char sub[32] = "--";
        float cam[3] = {};
        if (!ghost && (m_pos[0] != 0.0f || m_pos[1] != 0.0f || m_pos[2] != 0.0f) && overlay::GetCameraWorldPosition(cam)) {
            const float dx = m_pos[0] - cam[0], dy = m_pos[1] - cam[1], dz = m_pos[2] - cam[2];
            const float dist = std::sqrt(dx * dx + dy * dy + dz * dz);
            if (dist < 1000.0f && std::isfinite(dist)) std::snprintf(sub, sizeof(sub), "%.1f m", dist);
        }
        gui::DrawString(ImVec2(tx, y + 24.0f * u), sub, muted, subU, a, false, d);
    }
    // HP bar: track, delayed trail, gradient fill, gloss.
    {
        const float bh = 6.0f * u, by = y + ch - 8.0f * u - bh;
        const float bw = right - tx;
        const float br = 4.0f * u;
        d->AddRectFilled(ImVec2(tx, by), ImVec2(right, by + bh), ThCol(track, a), br);
        if (m_hpTrail > m_hpShown + 0.002f)
            d->AddRectFilled(ImVec2(tx, by), ImVec2(tx + bw * m_hpTrail, by + bh),
                             ThCol(ImColor(255, 255, 255), (light ? 0.55f : 0.30f) * a), br);
        const float fw = std::max(bw * m_hpShown, bh);
        const ImColor c0 = ThLerp(hpc, ImColor(0, 0, 0), 0.12f);
        const ImColor c1 = ThLerp(hpc, ImColor(255, 255, 255), 0.18f);
        d->AddRectFilled(ImVec2(tx, by), ImVec2(tx + fw, by + bh), ThCol(c0, a), br);
        d->AddRectFilledMultiColor(ImVec2(tx + br, by), ImVec2(tx + std::max(fw - br, br), by + bh),
                                   ThCol(c0, a), ThCol(c1, a), ThCol(c1, a), ThCol(c0, a));
        d->AddRectFilled(ImVec2(tx + fw - br * 2.0f, by), ImVec2(tx + fw, by + bh), ThCol(c1, a), br,
                         ImDrawFlags_RoundCornersRight);
        d->AddLine(ImVec2(tx + br, by + 1.0f), ImVec2(tx + std::max(fw - br, br), by + 1.0f),
                   ThCol(ImColor(255, 255, 255), 0.30f * a), 1.0f);
    }

    // Particles (prototype: 4 px squares #D9F3FF with a #75DFFF glow, .55 s).
    if (edge && m_particles->mValue) {
        const float cx = fx + fs * 0.5f, cy = fy + fs * 0.5f;
        for (int i = 0; i < 12 && m_partCount < 32; ++i) {
            Particle& p = m_parts[m_partCount++];
            const float ang = 6.2831853f * (float)i / 12.0f + ((i * 29) % 10) * 0.05f;
            const float dist = (26.0f + (float)((i * 53) % 30)) * u;
            p.x = cx; p.y = cy;
            p.vx = std::cos(ang) * dist / 0.55f;
            p.vy = std::sin(ang) * dist / 0.55f;
            p.life = 1.0f;
            p.rot = 0.0f;
            p.rv = (float)(((i * 47) % 200) - 100) * 0.06f;
            p.sz = 4.0f * u;
        }
    }
    {
        int w = 0;
        for (int i = 0; i < m_partCount; ++i) {
            Particle& p = m_parts[i];
            p.life -= dt / 0.55f;
            if (p.life <= 0.0f) continue;
            const float t = 1.0f - p.life;
            const float e = 1.0f - (1.0f - t) * (1.0f - t) * (1.0f - t);   // fast-out like the CSS curve
            const float ox = p.vx * 0.55f * e, oy = p.vy * 0.55f * e;
            const float alpha = (t < 0.15f ? t / 0.15f : p.life) * ease;
            const float hs = p.sz * (0.6f - 0.45f * t) * 0.5f + 0.5f;
            const float rot = p.rot + p.rv * t;
            const float cs = std::cos(rot), sn = std::sin(rot);
            const ImVec2 c(p.x + ox, p.y + oy);
            gui::FillCircle(c, hs * 2.6f, ImColor(0x75, 0xDF, 0xFF), 0.25f * alpha, 12, d);
            const ImVec2 q[4] = {
                ImVec2(c.x + (-hs * cs + hs * sn), c.y + (-hs * sn - hs * cs)),
                ImVec2(c.x + (hs * cs + hs * sn), c.y + (hs * sn - hs * cs)),
                ImVec2(c.x + (hs * cs - hs * sn), c.y + (hs * sn + hs * cs)),
                ImVec2(c.x + (-hs * cs - hs * sn), c.y + (-hs * sn + hs * cs)),
            };
            d->AddQuadFilled(q[0], q[1], q[2], q[3], ThCol(ImColor(0xD9, 0xF3, 0xFF), alpha));
            m_parts[w++] = p;
        }
        m_partCount = w;
    }

    // Floating damage numbers (prototype .damage keyframes, .62 s).
    for (auto& n : m_nums) {
        if (n.t < 0.0f) continue;
        n.t += dt;
        const float t = n.t / 0.62f;
        if (t >= 1.0f) { n.t = -1.0f; continue; }
        static const float kyk[3][2] = { {0, 8}, {.15f, 0}, {1, -25} };
        static const float ksk[3][2] = { {0, .7f}, {.15f, 1.08f}, {1, .92f} };
        static const float kak[3][2] = { {0, 0}, {.15f, 1}, {1, 0} };
        char txt[16];
        std::snprintf(txt, sizeof(txt), "-%.1f", n.value);
        const float nu = 17.0f * u * ThKey(ksk, 3, t) / gui::kFontUnit / ts;
        const float nw = gui::GetTextWidth(txt, nu, fonts::Bold());
        const ImVec2 np(x + cw - 10.0f * u - nw + n.dx * u, y - 27.0f * u + ThKey(kyk, 3, t) * u);
        gui::DrawString(ImVec2(np.x, np.y + 2.0f * u), txt, ImColor(0x55, 0x1C, 0x1C), nu,
                        ThKey(kak, 3, t) * ease, false, d, fonts::Bold());
        gui::DrawString(np, txt, ImColor(0xFF, 0x66, 0x66), nu, ThKey(kak, 3, t) * ease, false, d,
                        fonts::Bold());
    }

    HudEditChrome(this, name(), editPos, ImVec2(W, H), m_freeOn, m_freeX, m_freeY, m_scale);
}

// ======================== Time ========================
TimeModule::TimeModule() : Module("HUD", "Time", "Local wall-clock chip") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", TopLeft, HudPositionNames());
    m_scale = addSetting<NumberSetting>("Scale", "Chip size.", 1.0f, 0.25f, 3.0f, 0.05f);
    m_seconds = addSetting<BoolSetting>("Seconds", "Include seconds.", false);
    m_24h = addSetting<BoolSetting>("24 Hour", "24-hour format.", true);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Follow the theme accent.", true);
    m_color = addSetting<ColorSetting>("Color", "Bar color when Theme Color is off.", 0xFF8E5CFF);
    AddFreePositionSettings(this, &m_freeOn, &m_freeX, &m_freeY, 0.5f, 0.1f);
}

void TimeModule::onRender() {
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    SYSTEMTIME st{}; GetLocalTime(&st);
    char b[32];
    if (m_24h->mValue)
        snprintf(b, sizeof(b), m_seconds->mValue ? "Time: %02u:%02u:%02u" : "Time: %02u:%02u",
                 st.wHour, st.wMinute, st.wSecond);
    else {
        const unsigned h = (st.wHour % 12) == 0 ? 12 : st.wHour % 12;
        snprintf(b, sizeof(b), m_seconds->mValue ? "Time: %02u:%02u:%02u %s" : "Time: %02u:%02u %s",
                 h, st.wMinute, st.wSecond, st.wHour < 12 ? "AM" : "PM");
    }
    const ImVec2 size = ChipSize(b, m_scale->mValue);
    const ImVec2 pos = HudResolvePos(m_freeOn->mValue, m_freeX->mValue, m_freeY->mValue,
                                     screen, size, m_position->mValue);
    DrawChip(pos, b, m_scale->mValue, AccentOf(m_useTheme, m_color));
    HudEditChrome(this, name(), pos, size, m_freeOn, m_freeX, m_freeY, m_scale);
}

// ======================== Memory ========================
MemoryModule::MemoryModule() : Module("HUD", "Memory", "Process working-set chip") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", TopRight, HudPositionNames());
    m_scale = addSetting<NumberSetting>("Scale", "Chip size.", 1.0f, 0.25f, 3.0f, 0.05f);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Follow the theme accent.", true);
    m_color = addSetting<ColorSetting>("Color", "Bar color when Theme Color is off.", 0xFF8E5CFF);
    AddFreePositionSettings(this, &m_freeOn, &m_freeX, &m_freeY, 0.5f, 0.1f);
}

void MemoryModule::onRender() {
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    static SIZE_T cached = 0;
    static unsigned long long nextSample = 0;
    const unsigned long long now = GetTickCount64();
    if (now >= nextSample) {
        PROCESS_MEMORY_COUNTERS_EX pmc{};
        pmc.cb = sizeof(pmc);
        if (GetProcessMemoryInfo(GetCurrentProcess(),
                                 reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&pmc), sizeof(pmc)))
            cached = pmc.WorkingSetSize;
        nextSample = now + 250;
    }
    char b[32]; snprintf(b, sizeof(b), "Memory: %.0f MB", (double)cached / (1024.0 * 1024.0));
    const ImVec2 size = ChipSize(b, m_scale->mValue);
    const ImVec2 pos = HudResolvePos(m_freeOn->mValue, m_freeX->mValue, m_freeY->mValue,
                                     screen, size, m_position->mValue);
    DrawChip(pos, b, m_scale->mValue, AccentOf(m_useTheme, m_color));
    HudEditChrome(this, name(), pos, size, m_freeOn, m_freeX, m_freeY, m_scale);
}

// ======================== Mouse Strokes ========================
MouseStrokesModule::MouseStrokesModule()
    : Module("HUD", "Mouse Strokes", "Cursor motion trail") {
    m_scale = addSetting<NumberSetting>("Scale", "Trail scale.", 1.0f, 0.25f, 3.0f, 0.05f);
    m_length = addSetting<NumberSetting>("Length", "Max trail points.", 28.0f, 4.0f, 64.0f, 1.0f);
    m_thickness = addSetting<NumberSetting>("Thickness", "Line width.", 2.0f, 1.0f, 6.0f, 0.5f);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Follow the theme accent.", true);
    m_color = addSetting<ColorSetting>("Color", "Trail color when Theme Color is off.", 0xFF8E5CFF);
}

void MouseStrokesModule::onEnable() { m_count = 0; }
void MouseStrokesModule::onDisable() { m_count = 0; }

void MouseStrokesModule::expire(unsigned long long now) {
    int live = 0;
    while (live < m_count && now - m_points[live].ms > kLifetimeMs) live++;
    if (live > 0) {
        for (int i = 0; i + live < m_count; i++) m_points[i] = m_points[i + live];
        m_count -= live;
    }
}

void MouseStrokesModule::onTick() {
    const unsigned long long now = GetTickCount64();
    expire(now);
}

void MouseStrokesModule::onRender() {
    const unsigned long long now = GetTickCount64();
    expire(now);
    const ImGuiIO& io = ImGui::GetIO();
    if (io.MousePos.x >= 0.0f && io.MousePos.y >= 0.0f &&
        (std::fabs(io.MouseDelta.x) >= 0.01f || std::fabs(io.MouseDelta.y) >= 0.01f)) {
        if (m_count < kMaxPoints) m_points[m_count++] = { io.MousePos, now };
        else {
            for (int i = 1; i < kMaxPoints; i++) m_points[i - 1] = m_points[i];
            m_points[kMaxPoints - 1] = { io.MousePos, now };
        }
    }
    // Editor resize handle: the trail follows the mouse and has no placed
    // box, so a naive live-bounds chrome jumps after the cursor (reported
    // as a flickering rectangle). Instead freeze the last bounds once the
    // mouse rests: the box stays put for wheel / right-drag resize, while
    // the live trail keeps drawing without any box on top of it.
    if (overlay::HudEditActive() && !overlay::g_showMenu) {
        const ImVec2 screen = gui::GetScreenSize();
        static ImVec2 fz0{}, fz1{};
        static ULONGLONG fzAt = 0;
        static bool fzInit = false;
        if (!fzInit && screen.x > 0.0f && screen.y > 0.0f) {
            fz0 = ImVec2(screen.x * 0.5f - 60.0f, screen.y * 0.5f - 30.0f);
            fz1 = ImVec2(screen.x * 0.5f + 60.0f, screen.y * 0.5f + 30.0f);
            fzInit = true;
        }
        if (m_count >= 2) {
            ImVec2 b0 = m_points[0].pos, b1 = b0;
            for (int i = 1; i < m_count; i++) {
                b0.x = std::min(b0.x, m_points[i].pos.x);
                b0.y = std::min(b0.y, m_points[i].pos.y);
                b1.x = std::max(b1.x, m_points[i].pos.x);
                b1.y = std::max(b1.y, m_points[i].pos.y);
            }
            b0.x -= 20.0f; b0.y -= 20.0f; b1.x += 20.0f; b1.y += 20.0f;
            if (b1.x - b0.x < 120.0f) { const float d = (120.0f - (b1.x - b0.x)) * 0.5f; b0.x -= d; b1.x += d; }
            if (b1.y - b0.y < 60.0f) { const float d = (60.0f - (b1.y - b0.y)) * 0.5f; b0.y -= d; b1.y += d; }
            // Freeze only while the trail is fresh; a stale box means the
            // mouse rested and the handle is safe to grab.
            if (now - m_points[m_count - 1].ms < 400) {
                fz0 = b0; fz1 = b1; fzAt = now;
            }
        }
        if (fzInit && now - fzAt > 400)
            HudEditChrome(this, name(), fz0, ImVec2(fz1.x - fz0.x, fz1.y - fz0.y),
                          nullptr, nullptr, nullptr, m_scale);
    }
    if (m_count < 2) return;
    const int visible = std::min(m_count, (int)m_length->mValue);
    const int first = m_count - visible;
    const float s = m_scale->mValue;
    const ImColor base = AccentOf(m_useTheme, m_color);
    ImDrawList* d = ImGui::GetForegroundDrawList();
    for (int i = first + 1; i < m_count; i++) {
        const float age = (float)(now - m_points[i].ms) / (float)kLifetimeMs;
        const float life = gui::Clamp(1.0f - age, 0.0f, 1.0f);
        if (life <= 0.0f) continue;
        const float t = (float)(i - first) / (float)std::max(1, visible - 1);
        d->AddLine(m_points[i - 1].pos, m_points[i].pos,
                   ImColor(base.Value.x, base.Value.y, base.Value.z, (0.08f + 0.82f * t) * life),
                   m_thickness->mValue * s);
    }
}

// ======================== Keystrokes ========================
KeystrokesModule::KeystrokesModule()
    : Module("HUD", "Keystrokes", "Наглядное отображение нажатий клавиш.") {
    m_position = addSetting<EnumSetting>("Position", "Corner anchor.", BottomLeft, HudPositionNames());
    m_scale = addSetting<NumberSetting>("Scale", "Widget size.", 1.0f, 0.25f, 3.0f, 0.05f);
    m_spacing = addSetting<NumberSetting>("Spacing", "Gap between cells.", 2.0f, 0.0f, 8.0f, 0.5f);
    m_rounding = addSetting<NumberSetting>("Rounding", "Cell corner radius.", 0.0f, 0.0f, 12.0f, 0.5f);
    m_showMouse = addSetting<BoolSetting>("Mouse Buttons", "LMB / RMB cells.", false);
    m_pressed = addSetting<ColorSetting>("Pressed", "Held-key color.", 0xFF8E5CFF);
    m_released = addSetting<ColorSetting>("Released", "Idle-key color.", 0xFF2A2438);
    AddFreePositionSettings(this, &m_freeOn, &m_freeX, &m_freeY, 0.01f, 0.90f);
    setEnabled(true);
}

void KeystrokesModule::onRender() {
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f || screen.y <= 0.0f) return;
    // PacketV2-exact grid: 20px cells at bottom-left (W above ASD, wide
    // Space below), flat black/white fills, no rounding, no borders.
    // Mouse cells stay behind the toggle (PacketV2 has none).
    const float s = m_scale->mValue;
    const float cell = 20.0f * s, pitch = 22.0f * s;
    const float ox = 10.0f * s;
    const int keyRows = 3;   // W / ASD / Space
    const int rows = m_showMouse->mValue ? keyRows + 1 : keyRows;
    const ImVec2 size(74.0f * s, (float)rows * pitch - 2.0f * s);
    const ImVec2 origin = HudResolvePos(m_freeOn->mValue, m_freeX->mValue, m_freeY->mValue,
                                        screen, size, m_position->mValue);
    ImDrawList* d = ImGui::GetForegroundDrawList();

    struct Cell { const char* label; int vk; float x, y, w; };
    const Cell cells[] = {
        { "W", 'W', ox + pitch, 0.0f, cell },
        { "A", 'A', ox, pitch, cell },
        { "S", 'S', ox + pitch, pitch, cell },
        { "D", 'D', ox + pitch * 2.0f, pitch, cell },
        { "-", VK_SPACE, ox, pitch * 2.0f, 64.0f * s },
        { "LMB", VK_LBUTTON, ox, pitch * 3.0f, cell },
        { "RMB", VK_RBUTTON, ox + pitch, pitch * 3.0f, cell },
    };
    const int n = m_showMouse->mValue ? 7 : 5;
    const float units = 0.64f * s;
    for (int i = 0; i < n; i++) {
        const Cell& c = cells[i];
        const ImVec2 p(origin.x + c.x, origin.y + c.y);
        const bool down = (c.vk == VK_LBUTTON) ? ImGui::IsMouseDown(0)
                        : (c.vk == VK_RBUTTON) ? ImGui::IsMouseDown(1)
                        : keys::Down(c.vk);
        const float rounding = m_rounding->mValue * s;
        const ImVec4 cellRect(p.x, p.y, p.x + c.w, p.y + cell);
        if (down)
            gui::FillRect(cellRect, gui::Accent(), 0.85f, rounding, d);
        else
            GlassSurface(cellRect, 0.5f, rounding, d);
        const float tw = gui::GetTextWidth(c.label, units);
        const float th = gui::GetTextHeight(units);
        gui::DrawString(ImVec2(p.x + (c.w - tw) * 0.5f, p.y + (cell - th) * 0.5f),
                      c.label, ImColor(255, 255, 255), units, 1.0f, false);
    }

    HudEditChrome(this, name(), origin, size, m_freeOn, m_freeX, m_freeY, m_scale);
}

// ======================== Crosshair ========================
CrosshairModule::CrosshairModule()
    : Module("Visual", "Crosshair", "Точность начинается с твоего прицела.") {
    m_scale = addSetting<NumberSetting>("Scale", "Very small 25% to very large 300%.", 1.0f, 0.25f, 3.0f, 0.05f);
    m_dynamic = addSetting<BoolSetting>("Dynamic", "Expand with mouse motion.", true);
    m_gap = addSetting<NumberSetting>("Gap", "Center gap.", 5.0f, 0.0f, 18.0f, 0.5f);
    m_length = addSetting<NumberSetting>("Length", "Arm length.", 7.0f, 2.0f, 20.0f, 0.5f);
    m_thickness = addSetting<NumberSetting>("Thickness", "Line thickness.", 2.0f, 1.0f, 5.0f, 0.5f);
    m_useTheme = addSetting<BoolSetting>("Theme Color", "Follow the theme accent.", true);
    m_color = addSetting<ColorSetting>("Color", "Color when Theme Color is off.", 0xFFFFFFFF);
    setEnabled(true);
}

void CrosshairModule::onRender() {
    if (overlay::g_showMenu) return;   // cursor is visible with the menu
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x <= 0.0f) return;
    const ImGuiIO& io = ImGui::GetIO();
    const float s = m_scale ? m_scale->mValue : 1.0f;
    const float motion = std::sqrt(io.MouseDelta.x * io.MouseDelta.x + io.MouseDelta.y * io.MouseDelta.y);
    const float gap = (m_gap->mValue + (m_dynamic->mValue ? gui::Clamp(motion * 0.7f, 0.0f, 7.0f) : 0.0f)) * s;
    const float len = m_length->mValue * s, th = m_thickness->mValue * s;
    const ImVec2 c(screen.x * 0.5f, screen.y * 0.5f);
    const ImU32 col = AccentOf(m_useTheme, m_color);
    ImDrawList* d = ImGui::GetForegroundDrawList();
    d->AddLine(ImVec2(c.x - gap - len, c.y), ImVec2(c.x - gap, c.y), col, th);
    d->AddLine(ImVec2(c.x + gap, c.y), ImVec2(c.x + gap + len, c.y), col, th);
    d->AddLine(ImVec2(c.x, c.y - gap - len), ImVec2(c.x, c.y - gap), col, th);
    d->AddLine(ImVec2(c.x, c.y + gap), ImVec2(c.x, c.y + gap + len), col, th);
}

} // namespace nf
