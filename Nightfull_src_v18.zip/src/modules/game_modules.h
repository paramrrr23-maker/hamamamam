// game_modules.h - target-compatible gameplay modules.
//
// These modules intentionally keep their UI/state in the normal Module
// system. Game-facing work is performed by the already-existing input and
// render hooks in overlay.cpp; the reference repositories are not included
// in the target build.

#pragma once

#include <vector>

#include "core/module.h"

namespace nf {

class AutoSprintModule final : public Module {
public:
    AutoSprintModule();

    void onEnable() override;
    void onDisable() override;

    BoolSetting* m_alwaysSprint = nullptr;
};

class FullBrightModule final : public Module {
public:
    FullBrightModule();

    void onEnable() override;
    void onDisable() override;
    void onRender() override;

    float currentGamma() const { return m_currentGamma; }

    NumberSetting* m_gamma = nullptr;

private:
    float m_currentGamma = 1.0f;
};

class NoHurtCamModule final : public Module {
public:
    NoHurtCamModule();

    void onEnable() override;
    void onDisable() override;
    void onTick() override;
};

// Flarial HueChanger parity (display name "Saturation"): the overlay applies
// a D2D-equivalent saturation filter to the game frame before the HUD draws.
class SaturationModule final : public Module {
public:
    SaturationModule();

    void onEnable() override;
    void onDisable() override;
    void onTick() override;

    NumberSetting* m_intensity = nullptr;
};

// Motion Blur: frame-accumulation blur on the GAME frame (before the ImGui
// overlay, so the Nightfull HUD/ClickGUI stays sharp). Blend = exponential
// trail (Flarial-style accumulation), Ghost = mix with the previous frame only.
class MotionBlurModule final : public Module {
public:
    MotionBlurModule();

    void onEnable() override;
    void onDisable() override;
    void onTick() override;

private:
    void push();

    EnumSetting* m_mode = nullptr;
    NumberSetting* m_intensity = nullptr;
    BoolSetting* m_fpsIndependent = nullptr;
    NumberSetting* m_refFps = nullptr;
    BoolSetting* m_onlyInWorld = nullptr;
    BoolSetting* m_pauseInMenu = nullptr;
};

class HitboxesModule final : public Module {
public:
    HitboxesModule();

    void onEnable() override;
    void onDisable() override;
    void onRender() override;

private:
    // Flarial-parity base controls (see Hitbox::defaultConfig/settingsRender).
    // Eye line / look line / show-self were removed per user request: the
    // module draws only the plain hitbox wireframe, never the local player.
    NumberSetting* m_maxDistance = nullptr;
    NumberSetting* m_thickness = nullptr;
    BoolSetting* m_staticThickness = nullptr;
    BoolSetting* m_2dMode = nullptr;
    ColorSetting* m_boxColor = nullptr;
    NumberSetting* m_boxOpacity = nullptr;
    BoolSetting* m_useTheme = nullptr;    // follow the GUI theme accent
    // SystemDLC PlayerESP parity: targets, shape, outline, fill, box glow
    // (soft blurred halo around the lines), gradient glow colors and the
    // silhouette "Glow" render mode with its wavy animated outline.
    EnumSetting* m_targets = nullptr;       // Players / Mobs / All
    BoolSetting* m_scaleDistance = nullptr; // thicken lines with distance
    BoolSetting* m_throughWalls = nullptr;  // false = occlusion (default)
    BoolSetting* m_outline = nullptr;       // dark stroke under the lines
    ColorSetting* m_outlineColor = nullptr;
    BoolSetting* m_fill = nullptr;          // fill the box faces/silhouette
    ColorSetting* m_fillColor = nullptr;
    BoolSetting* m_boxGlow = nullptr;       // soft halo around the lines
    NumberSetting* m_glowRadius = nullptr;
    NumberSetting* m_glowBrightness = nullptr;
    ColorSetting* m_glowColor = nullptr;
    BoolSetting* m_gradient = nullptr;      // glow color oscillation
    ColorSetting* m_secondColor = nullptr;
    NumberSetting* m_gradientSpeed = nullptr;
    EnumSetting* m_mode = nullptr;          // Box / Glow
    ColorSetting* m_silhouetteColor = nullptr;
    NumberSetting* m_auraRadius = nullptr;
    NumberSetting* m_auraBrightness = nullptr;
    BoolSetting* m_animation = nullptr;     // wavy aura outline
    NumberSetting* m_animStrength = nullptr;
    NumberSetting* m_animSize = nullptr;
    // Cull hysteresis: actors visible last frame survive until maxDistance +
    // the band below, so a mob pacing on the cull line does not blink.
    std::vector<void*> m_visible;
};

class JavaInventoryHotkeysModule final : public Module {
public:
    JavaInventoryHotkeysModule();

    void onEnable() override;
    void onDisable() override;
};

class VSyncDisablerModule final : public Module {
public:
    VSyncDisablerModule();

    void onEnable() override;
    void onDisable() override;
};

class NullMovementModule final : public Module {
public:
    NullMovementModule();

    void onEnable() override;
    void onDisable() override;
    void onTick() override;

private:
    BoolSetting* m_adPair = nullptr;
    BoolSetting* m_wsPair = nullptr;
};

class CpsLimiterModule final : public Module {
public:
    CpsLimiterModule();

    void onEnable() override;
    void onDisable() override;
    void onTick() override;

private:
    NumberSetting* m_left = nullptr;
    NumberSetting* m_right = nullptr;
};

class GuiScaleModule final : public Module {
public:
    GuiScaleModule();

    float targetScale() const;

    NumberSetting* m_scale = nullptr;
};

} // namespace nf
