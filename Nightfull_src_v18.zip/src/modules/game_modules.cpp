// game_modules.cpp - AutoSprint, FullBright and NoHurtCam.

#include "modules/game_modules.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
#include <tuple>
#include <vector>

#include "overlay/overlay.h"
#include "utils/gui_render.h"
#include "utils/gui_theme.h"
#include "utils/logger.h"

namespace nf {
namespace {

constexpr int kBoxEdges[12][2] = {
    {0, 1}, {1, 3}, {3, 2}, {2, 0},
    {4, 5}, {5, 7}, {7, 6}, {6, 4},
    {0, 4}, {1, 5}, {2, 6}, {3, 7}
};

void DrawWhiteBoxLine(ImDrawList* draw, const ImVec2& start,
                      const ImVec2& end, ImU32 color, float width,
                      const ImVec2& screen) {
    if (!draw) return;
    // Match DrawUtils::addLine: a projected endpoint outside GuiData's screen
    // is rejected instead of letting ImGui stretch an edge across the frame.
    if (start.x < 0.0f || start.x > screen.x || start.y < 0.0f || start.y > screen.y ||
        end.x < 0.0f || end.x > screen.x || end.y < 0.0f || end.y > screen.y)
        return;
    draw->AddLine(start, end, color, width);
}

// Convex hull polygon of the projected box corners (the walk behind Flarial's
// DrawUtils::addBox mode 2). Returned as unique vertices in wrap order; the
// polygon is treated as closed by every consumer.
struct HullPoly {
    ImVec2 pts[16] = {};
    int count = 0;
};

static HullPoly BuildHullPoly(const ImVec2 points[8], const bool valid[8]) {
    HullPoly hull;
    // Compact (original index, screen point) list of projected corners.
    //
    // Fixed-size stack storage. This runs once per actor per frame, and the
    // previous std::vector<std::tuple<int, ImVec2>> + std::vector<int> pair
    // cost two heap allocations per actor for at most 8 elements each - up to
    // ~3 000 allocations per second at 26 actors and 60 FPS.
    struct Cord { int idx; ImVec2 pt; };
    Cord cords[8];
    int cordCount = 0;
    for (int i = 0; i < 8; ++i) {
        if (valid[i]) cords[cordCount++] = Cord{ i, points[i] };
    }
    if (cordCount < 3) {
        // A degenerate (edge-on) box still has a usable line hull.
        for (int i = 0; i < cordCount; ++i)
            if (hull.count < 16) hull.pts[hull.count++] = cords[i].pt;
        return hull;
    }

    // Leftmost corner starts the wrap.
    Cord start = cords[0];
    for (int i = 1; i < cordCount; ++i) {
        if (cords[i].pt.x < start.pt.x) start = cords[i];
    }

    constexpr float kPi = 3.1415927f;
    int indices[8] = {};
    int indexCount = 0;
    Cord current = start;
    indices[indexCount++] = current.idx;
    ImVec2 lastDir(0.0f, -1.0f);
    do {
        float smallestAngle = kPi * 2.0f;
        ImVec2 smallestDir(0.0f, 0.0f);
        Cord smallestE = current;
        bool found = false;
        const float lastAtan = std::atan2(lastDir.y, lastDir.x);
        for (int i = 0; i < cordCount; ++i) {
            if (current.idx == cords[i].idx) continue;
            ImVec2 dir(cords[i].pt.x - current.pt.x,
                       cords[i].pt.y - current.pt.y);
            float angle = std::atan2(dir.y, dir.x) - lastAtan;
            if (angle > kPi) angle -= 2.0f * kPi;
            else if (angle <= -kPi) angle += 2.0f * kPi;
            if (angle >= 0.0f && angle < smallestAngle) {
                smallestAngle = angle;
                smallestDir = dir;
                smallestE = cords[i];
                found = true;
            }
        }
        if (!found) break;
        if (indexCount >= 8) break;   // same cap the walk used before
        indices[indexCount++] = smallestE.idx;
        lastDir = smallestDir;
        current = smallestE;
    } while (current.idx != start.idx && indexCount < 8);

    for (int k = 0; k < indexCount; ++k) {
        for (int i = 0; i < cordCount; ++i) {
            if (cords[i].idx != indices[k]) continue;
            if (hull.count < 16) hull.pts[hull.count++] = cords[i].pt;
            break;
        }
    }
    // Drop the duplicate closing vertex if the walk returned to the start.
    if (hull.count > 1 && hull.pts[0].x == hull.pts[hull.count - 1].x &&
        hull.pts[0].y == hull.pts[hull.count - 1].y)
        --hull.count;
    return hull;
}

// Closed-polygon segments. When screenBounds is given, endpoints outside the
// GuiData screen are rejected (Flarial's addLine behaviour for the sharp
// outline); glow and fill passes pass nullptr and rely on ImGui clipping.
static void DrawHullSegments(ImDrawList* draw, const HullPoly& hull,
                             ImU32 color, float width,
                             const ImVec2* screenBounds = nullptr) {
    if (!draw || hull.count < 2 || width <= 0.0f) return;
    const int segs = hull.count > 2 ? hull.count : 1;
    for (int i = 0; i < segs; ++i) {
        const ImVec2& a = hull.pts[i];
        const ImVec2& b = hull.pts[(i + 1) % hull.count];
        if (a.x == b.x && a.y == b.y) continue;
        if (screenBounds)
            DrawWhiteBoxLine(draw, a, b, color, width, *screenBounds);
        else
            draw->AddLine(a, b, color, width);
    }
}

// SystemDLC-style box glow ("Свечение бокса"): a soft multi-pass halo stroked
// around the box silhouette. Approximates their blur post-effect with layered
// strokes - widest and faintest first, brightest core last.
//
// The pass colors/widths only depend on the module settings (and ImGui style),
// which are frame-constant, so the plan is built once per frame and every
// hull in that frame reuses it: the ImGui color conversions and the pass
// arithmetic run once per frame instead of once per pass per actor.
struct HullGlowPlan {
    static constexpr int kMaxPasses = 6;
    ImU32 colors[kMaxPasses] = {};
    float widths[kMaxPasses] = {};
    int passCount = 0;
};

static HullGlowPlan BuildHullGlowPlan(const ImVec4& color, float radius,
                                      float brightness) {
    HullGlowPlan plan;
    if (radius < 1.0f || brightness <= 0.0f) return plan;
    constexpr int kPasses = 6;
    ImU32 prevColor = 0;
    float prevWidth = 0.0f;
    for (int p = kPasses; p >= 1; --p) {
        const float t = (float)p / (float)kPasses;
        const float falloff = (1.0f - t) * (1.0f - t);
        const float alpha = brightness * 0.20f * falloff;
        if (alpha < 0.004f) continue;
        const float w = std::max(1.0f, radius * t);
        const ImU32 c = ImGui::GetColorU32(ImVec4(
            color.x, color.y, color.z, std::min(1.0f, alpha)));
        // Two consecutive passes with identical width and color (possible
        // when the radius clamps to the 1 px width floor) stroke the same
        // polygon - skip the inner duplicate.
        if (plan.passCount > 0 && w == prevWidth && c == prevColor) continue;
        plan.colors[plan.passCount] = c;
        plan.widths[plan.passCount] = w;
        ++plan.passCount;
        prevColor = c;
        prevWidth = w;
    }
    return plan;
}

static void DrawHullGlow(ImDrawList* draw, const HullPoly& hull,
                         const HullGlowPlan& plan) {
    if (!draw || hull.count < 2 || plan.passCount == 0) return;
    const int segs = hull.count > 2 ? hull.count : 1;
    for (int p = 0; p < plan.passCount; ++p) {
        for (int i = 0; i < segs; ++i) {
            const ImVec2& a = hull.pts[i];
            const ImVec2& b = hull.pts[(i + 1) % hull.count];
            if (a.x == b.x && a.y == b.y) continue;
            draw->AddLine(a, b, plan.colors[p], plan.widths[p]);
        }
    }
}

// Wavy animated outline (SystemDLC "огненная волнистая обводка"): displace
// each hull vertex along its polygon normal with a time-phased sine.
static void DisplaceHullWavy(HullPoly& hull, float timeSec, float strengthPx) {
    const int n = hull.count;
    if (n < 3 || strengthPx <= 0.0f) return;
    ImVec2 src[16];
    for (int i = 0; i < n; ++i) src[i] = hull.pts[i];
    for (int i = 0; i < n; ++i) {
        const ImVec2& prev = src[(i + n - 1) % n];
        const ImVec2& next = src[(i + 1) % n];
        const float tx = next.x - prev.x;
        const float ty = next.y - prev.y;
        const float len = std::sqrt(tx * tx + ty * ty);
        if (len < 0.001f) continue;
        const float nx = -ty / len;
        const float ny = tx / len;
        const float wave =
            std::sin(timeSec * 3.1f + (float)i * 2.399963f);
        hull.pts[i].x = src[i].x + nx * strengthPx * wave;
        hull.pts[i].y = src[i].y + ny * strengthPx * wave;
    }
}

// Box fill (SystemDLC "Заливка"): fill the camera-facing sides of the cuboid.
// The visibility test runs in world space against each face's outward normal,
// so exactly the three front faces are drawn regardless of the projection
// convention, and alpha blending never stacks a back face under a front face.
static void DrawBoxFill3D(ImDrawList* draw, const float mins[3],
                          const float maxs[3], const ImVec2 points[8],
                          const bool valid[8], const float camera[3],
                          ImU32 color) {
    static constexpr int kFaces[6][4] = {
        {0, 1, 3, 2},  // -Z
        {4, 5, 7, 6},  // +Z
        {0, 2, 6, 4},  // -X
        {1, 3, 7, 5},  // +X
        {0, 1, 5, 4},  // -Y
        {2, 3, 7, 6},  // +Y
    };
    static constexpr float kNormals[6][3] = {
        {0.0f, 0.0f, -1.0f}, {0.0f, 0.0f, 1.0f},
        {-1.0f, 0.0f, 0.0f}, {1.0f, 0.0f, 0.0f},
        {0.0f, -1.0f, 0.0f}, {0.0f, 1.0f, 0.0f},
    };
    if (!draw) return;
    for (int f = 0; f < 6; ++f) {
        const int* quad = kFaces[f];
        ImVec2 screen[4];
        float cx = 0.0f, cy = 0.0f, cz = 0.0f;
        bool ok = true;
        for (int k = 0; k < 4; ++k) {
            const int c = quad[k];
            if (!valid[c]) { ok = false; break; }
            screen[k] = points[c];
            cx += ((c & 1) ? maxs[0] : mins[0]) * 0.25f;
            cy += ((c & 2) ? maxs[1] : mins[1]) * 0.25f;
            cz += ((c & 4) ? maxs[2] : mins[2]) * 0.25f;
        }
        if (!ok) continue;
        if (kNormals[f][0] * (cx - camera[0]) +
                kNormals[f][1] * (cy - camera[1]) +
                kNormals[f][2] * (cz - camera[2]) >=
            0.0f)
            continue;  // back face or edge-on
        draw->AddQuadFilled(screen[0], screen[1], screen[2], screen[3], color);
    }
}

// Project all 8 corners and report per-corner validity.
//
// Flarial's DrawUtils::addBox(mode 1) pushes each of the 12 edges through
// addLine3D independently, so an edge whose endpoint falls outside the frustum
// is skipped while the remaining edges still draw. Requiring all 8 corners to
// project - as the previous version did - dropped the entire box as soon as one
// corner crossed the near plane, which made close entities lose their hitbox.
int ProjectBox(const float mins[3], const float maxs[3], ImVec2 points[8],
               float depths[8], bool valid[8]) {
    if (!mins || !maxs || !points || !depths || !valid) return 0;
    int validCount = 0;
    for (int corner = 0; corner < 8; ++corner) {
        // Same corner ordering as Flarial's DrawUtils::addBox vertices[]:
        // bit0 = x max, bit1 = y max, bit2 = z max.
        const float world[3] = {
            (corner & 1) ? maxs[0] : mins[0],
            (corner & 2) ? maxs[1] : mins[1],
            (corner & 4) ? maxs[2] : mins[2]
        };
        float sx = 0.0f, sy = 0.0f, depth = 0.0f;
        valid[corner] =
            overlay::ProjectWorldToScreen(world, &sx, &sy, &depth) &&
            std::isfinite(sx) && std::isfinite(sy) &&
            std::isfinite(depth) && depth >= 0.3f;
        if (!valid[corner]) continue;
        points[corner] = ImVec2(sx, sy);
        depths[corner] = depth;
        ++validCount;
    }
    return validCount;
}

} // namespace

AutoSprintModule::AutoSprintModule()
    : Module("Movement", "AutoSprint", "Automatically sprints while moving") {
    // Mirrors the reference module's user-facing control. When disabled, the
    // module remains available in ClickGUI but does not synthesize sprint.
    m_alwaysSprint = addSetting<BoolSetting>(
        "Always Sprint", "Automatically hold sprint while moving", true);
}

void AutoSprintModule::onEnable() {
    // Flarial Sprint parity: the baseTick hook writes the MoveInputComponent
    // sprint flags for the local player on every game tick while enabled.
    overlay::SetAutoSprintEnabled(true);
}

void AutoSprintModule::onDisable() {
    // No restore writes: the game re-authors its input state every tick and
    // stops sprinting as soon as the flags stop being forced.
    overlay::SetAutoSprintEnabled(false);
}

FullBrightModule::FullBrightModule()
    : Module("Visual", "FullBright", "Raises the in-game gamma") {
    // Bedrock's normal gamma is approximately 1.0; Solstice/Flarial use a
    // high gamma value (13-25) for full brightness. Keep it user-adjustable.
    m_gamma = addSetting<NumberSetting>(
        "Brightness", "Target gamma returned by the Options hook", 13.0f,
        1.0f, 25.0f, 0.5f);
}

void FullBrightModule::onEnable() {
    m_currentGamma = 1.0f;
}

void FullBrightModule::onDisable() {
    // The hook returns vanilla gamma when disabled; animate our local value
    // back as well so a later enable starts from a predictable state.
    m_currentGamma = 1.0f;
}

void FullBrightModule::onRender() {
    const float target = m_gamma ? m_gamma->mValue : 13.0f;
    const float dt = std::max(0.0f, std::min(0.25f, ImGui::GetIO().DeltaTime));
    // Same smooth target behavior as the reference implementation, without
    // touching Options memory directly.
    const float amount = std::min(1.0f, 10.0f * dt);
    m_currentGamma += (target - m_currentGamma) * amount;
}

NoHurtCamModule::NoHurtCamModule()
    : Module("Visual", "NoHurtCam", "Solstice-style validated camera instruction patch") {}

void NoHurtCamModule::onEnable() {
    // The overlay resolves the Solstice CameraComponent candidate once and
    // refuses to patch when it is missing or ambiguous.
    overlay::SetNoHurtCamEnabled(true);
}

void NoHurtCamModule::onDisable() {
    overlay::SetNoHurtCamEnabled(false);
}

void NoHurtCamModule::onTick() {
    if (enabled())
        overlay::SetNoHurtCamEnabled(true);
}

// ======================== Saturation ========================
// Flarial HueChanger parity: one slider ("Saturation Intensity" there,
// "Intensity" here), range 0..3, default 0.5. The overlay applies the filter
// to the game frame before the HUD, exactly like Flarial's D2D pass.
SaturationModule::SaturationModule()
    : Module("Visual", "Saturation", "Фильтр насыщенности как во Flarial") {
    m_intensity = addSetting<NumberSetting>(
        "Intensity", "Saturation factor: 0 = grayscale, 1 = unchanged, up to 3 = oversaturated",
        0.5f, 0.0f, 3.0f, 0.05f);
}

void SaturationModule::onEnable() {
    overlay::SetSaturationEnabled(true);
    overlay::SetSaturationIntensity(m_intensity ? m_intensity->mValue : 0.5f);
}

void SaturationModule::onTick() {
    // Live slider updates while the module runs (like CpsLimiter).
    overlay::SetSaturationIntensity(m_intensity ? m_intensity->mValue : 0.5f);
}

void SaturationModule::onDisable() {
    overlay::SetSaturationEnabled(false);
}

// ======================== Motion Blur ========================
// All GPU work lives in the overlay (same pass discipline as Saturation):
// the module only publishes its settings every frame. "Only in world" and
// "Pause in ClickGUI" gate the pass itself; re-arming it resets the history
// so an old frame never bleeds into the first blurred one.
MotionBlurModule::MotionBlurModule()
    : Module("Visual", "Motion Blur", "Frame-accumulation motion blur on the game image") {
    m_mode = addSetting<EnumSetting>(
        "Mode", "Blend = smooth accumulated trail, Ghost = mix with the previous frame only.",
        0, std::vector<std::string>{ "Blend", "Ghost" });
    m_intensity = addSetting<NumberSetting>(
        "Intensity", "How much of the previous image stays on screen (0 = off, 0.95 = heavy).",
        0.55f, 0.0f, 0.95f, 0.01f);
    m_fpsIndependent = addSetting<BoolSetting>(
        "FPS Independent", "Same trail length at any frame rate (scaled to Reference FPS).", true);
    m_refFps = addSetting<NumberSetting>(
        "Reference FPS", "Frame rate at which Intensity is applied as-is.",
        60.0f, 30.0f, 360.0f, 1.0f);
    m_refFps->mIsVisible = [this] { return m_fpsIndependent && m_fpsIndependent->mValue; };
    m_onlyInWorld = addSetting<BoolSetting>(
        "Only In World", "Skip the blur on the main menu and loading screens.", true);
    m_pauseInMenu = addSetting<BoolSetting>(
        "Pause In ClickGUI", "No blur while the Nightfull menu or HUD editor is open.", false);
}

void MotionBlurModule::push() {
    bool active = true;
    if (m_onlyInWorld && m_onlyInWorld->mValue && !overlay::IsInWorld()) active = false;
    if (m_pauseInMenu && m_pauseInMenu->mValue &&
        (overlay::g_showMenu || overlay::HudEditActive()))
        active = false;
    overlay::SetMotionBlurParams(m_intensity ? m_intensity->mValue : 0.55f,
                                 m_mode ? m_mode->mValue : 0,
                                 m_fpsIndependent ? m_fpsIndependent->mValue : true,
                                 m_refFps ? m_refFps->mValue : 60.0f);
    overlay::SetMotionBlurEnabled(active);
}

void MotionBlurModule::onEnable() { push(); }

void MotionBlurModule::onTick() {
    // Live settings + gates while the module runs (like Saturation).
    push();
}

void MotionBlurModule::onDisable() {
    overlay::SetMotionBlurEnabled(false);
}

// ======================== Hitbox box smoothing ========================
// PacketV2 keeps its boxes glued to the entity by lerping posOld -> pos with
// the tick fraction (DrawUtils::drawEntityBox). The part that matters is not
// the lerp itself but where the data comes from: a box sampled once per tick
// steps at 20 Hz while the world runs at display rate, which reads as lag.
// Our AABB comes from a tick-updated component too, so it has exactly the
// same problem.
//
// Same idea, no extra game reads: ease the drawn box toward the freshly read
// one with a one-tick time constant. A jump larger than kBoxSmoothSnap blocks
// is a teleport (or a recycled actor pointer), so it snaps instead of gliding
// the box across the map.
struct BoxSmoothEntry {
    void* actor = nullptr;
    float mins[3] = {};
    float maxs[3] = {};
    ULONGLONG at = 0;
};

constexpr float kBoxSmoothTauMs = 40.0f;  // ~one game tick
constexpr float kBoxSmoothSnap = 3.0f;    // blocks; beyond this, snap

void SmoothHitboxAabb(void* actor, float mins[3], float maxs[3]) {
    static BoxSmoothEntry table[256];
    const ULONGLONG now = GetTickCount64();

    BoxSmoothEntry* slot = nullptr;
    BoxSmoothEntry* spare = nullptr;
    BoxSmoothEntry* oldest = &table[0];
    for (BoxSmoothEntry& e : table) {
        if (e.actor == actor) { slot = &e; break; }
        if (!e.actor && !spare) spare = &e;
        if (e.at < oldest->at) oldest = &e;
    }

    if (slot) {
        const float jump = std::max(
            std::max(std::fabs(mins[0] - slot->mins[0]),
                     std::fabs(mins[1] - slot->mins[1])),
            std::fabs(mins[2] - slot->mins[2]));
        if (jump <= kBoxSmoothSnap) {
            const float dt = static_cast<float>(now - slot->at);
            // Frame-rate independent ease; dt == 0 leaves the box untouched.
            const float k =
                dt > 0.0f ? 1.0f - std::exp(-dt / kBoxSmoothTauMs) : 0.0f;
            for (int c = 0; c < 3; ++c) {
                slot->mins[c] += (mins[c] - slot->mins[c]) * k;
                slot->maxs[c] += (maxs[c] - slot->maxs[c]) * k;
                mins[c] = slot->mins[c];
                maxs[c] = slot->maxs[c];
            }
            slot->at = now;
            return;
        }
    }

    // First sight, a teleport, or a recycled pointer: adopt the target box.
    BoxSmoothEntry& e = slot ? *slot : (spare ? *spare : *oldest);
    e.actor = actor;
    e.at = now;
    std::memcpy(e.mins, mins, sizeof(e.mins));
    std::memcpy(e.maxs, maxs, sizeof(e.maxs));
}

HitboxesModule::HitboxesModule()
    : Module("Visual", "Hitboxes", "Entity hitboxes: Normal / Wireframe / Glow") {
    // House style: bold readable boxes (growing lines, soft glow, filled
    // faces). PacketV2-exact is one click away: Thickness 1.0, Targets
    // Players, Scale with distance off, Fill off, Box glow off.
    m_maxDistance = addSetting<NumberSetting>(
        "Max distance", "Maximum entity render distance in blocks", 20.0f, 5.0f, 30.0f, 1.0f);
    m_thickness = addSetting<NumberSetting>(
        "Thickness", "Multiplier over the distance width.", 2.0f, 0.1f, 5.0f, 0.1f);
    m_staticThickness = addSetting<BoolSetting>(
        "Static thickness", "Keep line width constant regardless of distance.", false);
    m_2dMode = addSetting<BoolSetting>(
        "2D mode", "Flat rectangles instead of 3D cuboids.", false);
    // PacketV2 enemy white (0.9, 0.9, 0.9). Mobs always draw PacketV2 blue;
    // see onRender.
    m_boxColor = addSetting<ColorSetting>(
        "Box color", "Hitbox line color.", 0xFFE6E6E6u);
    m_boxOpacity = addSetting<NumberSetting>(
        "Box opacity", "Hitbox transparency.", 1.0f, 0.0f, 1.0f, 0.05f);
    m_useTheme = addSetting<BoolSetting>(
        "Use theme", "Paint lines and glow with the GUI theme accent.", true);

    // House style shows everything ("все все все"); Players-only is the
    // PacketV2-effective default.
    m_targets = addSetting<EnumSetting>(
        "Targets", "Which entities get a hitbox.", 2,
        std::vector<std::string>{"Players", "Mobs", "All"});
    m_scaleDistance = addSetting<BoolSetting>(
        "Scale with distance", "Thicken lines with distance (house style).", true);
    m_throughWalls = addSetting<BoolSetting>(
        "Show through walls", "Draw boxes behind walls (occlusion off).", false);
    m_outline = addSetting<BoolSetting>(
        "Outline", "Dark stroke under the lines for contrast.", false);
    m_outlineColor = addSetting<ColorSetting>(
        "Outline color", "Outline stroke color.", 0xFF000000u);
    m_fill = addSetting<BoolSetting>(
        "Fill", "Fill the surface, not just the perimeter (house style).", true);
    m_fillColor = addSetting<ColorSetting>(
        "Fill color", "Fill color (alpha = fill strength).", 0x4CFFFFFFu);
    m_boxGlow = addSetting<BoolSetting>(
        "Box glow", "Soft blurred glow around the box lines (house style).", true);
    m_glowRadius = addSetting<NumberSetting>(
        "Glow radius", "Glow halo radius in pixels.", 20.0f, 4.0f, 96.0f, 1.0f);
    m_glowBrightness = addSetting<NumberSetting>(
        "Glow brightness", "Glow brightness.", 1.0f, 0.1f, 4.0f, 0.05f);
    m_glowColor = addSetting<ColorSetting>(
        "Glow color", "Glow halo color.", 0xFF36D6FFu);
    m_gradient = addSetting<BoolSetting>(
        "Gradient", "Smooth transition between two glow colors.", false);
    m_secondColor = addSetting<ColorSetting>(
        "Second color", "Second glow gradient color.", 0xFFFF6B36u);
    m_gradientSpeed = addSetting<NumberSetting>(
        "Gradient speed", "Gradient movement speed (0 - static).", 0.0f, 0.0f, 5.0f, 0.05f);
    // Render style. Index is the stable API (configs store it): 0 Normal
    // (clean hull silhouette, PacketV2-like), 1 Glow (house aura
    // silhouette), 2 Wireframe (full 12-edge cuboid, no top lift).
    m_mode = addSetting<EnumSetting>(
        "Mode", "Box render style: Normal / Glow / Wireframe.", 2,
        std::vector<std::string>{"Normal", "Glow", "Wireframe"});
    m_silhouetteColor = addSetting<ColorSetting>(
        "Silhouette color", "Silhouette fill color in Glow mode.", 0x40FFFFFFu);
    m_auraRadius = addSetting<NumberSetting>(
        "Aura radius", "Silhouette aura radius in pixels.", 24.0f, 4.0f, 96.0f, 1.0f);
    m_auraBrightness = addSetting<NumberSetting>(
        "Aura brightness", "Silhouette aura brightness.", 1.5f, 0.3f, 4.0f, 0.05f);
    m_animation = addSetting<BoolSetting>(
        "Animation", "Wavy animated aura outline in Glow mode.", false);
    m_animStrength = addSetting<NumberSetting>(
        "Animation strength", "Wave distortion strength.", 1.0f, 0.0f, 3.0f, 0.05f);
    m_animSize = addSetting<NumberSetting>(
        "Animation size", "Aura expansion with animation.", 1.0f, 1.0f, 2.5f, 0.05f);
}

void HitboxesModule::onEnable() {
    // PacketV2 idea: ticking actors refresh their own AABB cache entry on the
    // game's tick thread while hitboxes are enabled.
    overlay::SetHitboxTickRefresh(true);
}

void HitboxesModule::onDisable() {
    overlay::SetHitboxTickRefresh(false);
}

void HitboxesModule::onRender() {
    // Flarial parity: the ClickGUI replaces the world view, so hitboxes are
    // not drawn while the menu is open (same as its onRender gate).
    if (overlay::g_showMenu) return;
    // World/menu validation is owned by the setup capture. Do not call
    // IsInWorld here: its guarded fallback can resolve a live local-player
    // vtable. The frame packet below naturally makes this callback a no-op
    // outside the active world.
    const float maxDistance = m_maxDistance
        ? gui::Clamp(m_maxDistance->mValue, 5.0f, 30.0f) : 20.0f;
    overlay::SetHitboxMaxDistance(maxDistance);
    overlay::SetHitboxThroughWalls(m_throughWalls ? m_throughWalls->mValue
                                                  : false);

    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x < 2.0f || screen.y < 2.0f) return;

    // The Present path has already selected the immutable camera/actor snapshot.
    // This module callback only copies that snapshot; it never resolves view,
    // EntityContext, components, RPM or native game objects here.

    ImDrawList* draw = ImGui::GetBackgroundDrawList();
    if (!draw) return;

    float camera[3] = {};
    if (!overlay::GetCameraWorldPosition(camera)) return;

    // ---- settings (PacketV2 ESP parity) ----
    const float thickness = m_thickness
        ? gui::Clamp(m_thickness->mValue, 0.1f, 5.0f) : 1.0f;
    const bool staticThickness = m_staticThickness && m_staticThickness->mValue;
    const bool mode2d = m_2dMode && m_2dMode->mValue;
    // Theme accent spreads to the whole client: lines (and glow below)
    // follow it unless the module opts out. Mob blue is kept so targets and
    // mobs never share a color.
    const bool useTheme = !m_useTheme || m_useTheme->mValue;
    ImColor boxColor = useTheme ? gui::Accent()
                                : (m_boxColor ? m_boxColor->getAsImColor() : ImColor(0.9f, 0.9f, 0.9f, 1.0f));
    const float opacity = m_boxOpacity
        ? gui::Clamp(m_boxOpacity->mValue, 0.0f, 1.0f) : 1.0f;
    boxColor.Value.w *= opacity;
    const ImU32 lineU32 = ImGui::GetColorU32(boxColor.Value);

    // PacketV2 enemy blue (0.2, 0.2, 0.9) for mobs; players draw Box color
    // (default 0.9 gray = PacketV2 enemy white). Opacity applies to both.
    const ImU32 mobU32 =
        ImGui::GetColorU32(ImVec4(0.2f, 0.2f, 0.9f, opacity));
    const bool scaleDistance = m_scaleDistance && m_scaleDistance->mValue;
    const bool outlineOn = m_outline && m_outline->mValue;
    const ImColor outlineColor = m_outlineColor
        ? m_outlineColor->getAsImColor() : ImColor(0.0f, 0.0f, 0.0f, 1.0f);
    const ImU32 outlineU32 = ImGui::GetColorU32(outlineColor.Value);
    const bool fillOn = m_fill && m_fill->mValue;
    const ImColor fillColor = m_fillColor
        ? m_fillColor->getAsImColor() : ImColor(1.0f, 1.0f, 1.0f, 0.30f);
    const ImU32 fillU32 = ImGui::GetColorU32(fillColor.Value);
    const bool glowOn = m_boxGlow && m_boxGlow->mValue;
    const float glowRadius = m_glowRadius
        ? gui::Clamp(m_glowRadius->mValue, 4.0f, 96.0f) : 20.0f;
    const float glowBrightness = m_glowBrightness
        ? gui::Clamp(m_glowBrightness->mValue, 0.1f, 4.0f) : 1.0f;
    ImVec4 glowColor = useTheme ? gui::Accent().Value
                                : (m_glowColor ? m_glowColor->getAsImColor().Value
                                               : ImVec4(0.21f, 0.84f, 1.0f, 1.0f));
    const bool gradientOn = m_gradient && m_gradient->mValue;
    const ImColor secondColor = m_secondColor
        ? m_secondColor->getAsImColor() : ImColor(1.0f, 0.42f, 0.21f, 1.0f);
    const float gradientSpeed = m_gradientSpeed
        ? gui::Clamp(m_gradientSpeed->mValue, 0.0f, 5.0f) : 0.0f;
    const int renderMode = m_mode ? m_mode->mValue : 2;  // 0 Normal, 1 Glow, 2 Wireframe
    const ImColor silhouetteColor = m_silhouetteColor
        ? m_silhouetteColor->getAsImColor() : ImColor(1.0f, 1.0f, 1.0f, 0.25f);
    const ImU32 silhouetteU32 = ImGui::GetColorU32(silhouetteColor.Value);
    float auraRadius = m_auraRadius
        ? gui::Clamp(m_auraRadius->mValue, 4.0f, 96.0f) : 24.0f;
    const float auraBrightness = m_auraBrightness
        ? gui::Clamp(m_auraBrightness->mValue, 0.3f, 4.0f) : 1.5f;
    const bool animOn = m_animation && m_animation->mValue;
    const float animStrength = m_animStrength
        ? gui::Clamp(m_animStrength->mValue, 0.0f, 3.0f) : 1.0f;
    const float animSize = m_animSize
        ? gui::Clamp(m_animSize->mValue, 1.0f, 2.5f) : 1.0f;
    const int targets = m_targets ? m_targets->mValue : 0;  // 0/1/2, PacketV2 = players

    // SystemDLC "Градиент": the glow color oscillates between the main glow
    // color and the second one; speed 0 keeps a static 50/50 blend.
    if (gradientOn) {
        const double nowSec = (double)ImGui::GetTime();
        const float phase = gradientSpeed > 0.0f
            ? 0.5f + 0.5f * std::sin((float)nowSec * gradientSpeed * 2.0f)
            : 0.5f;
        const float* src = &secondColor.Value.x;
        float* dst = &glowColor.x;  // ImVec4 is a plain 4-float aggregate
        for (int c = 0; c < 4; ++c) dst[c] += (src[c] - dst[c]) * phase;
    }

    // Frame-constant glow plans: pass colors/widths do not vary per actor,
    // so the conversions run once here instead of per pass per actor.
    const HullGlowPlan auraGlowPlan =
        BuildHullGlowPlan(glowColor, auraRadius * (animOn ? animSize : 1.0f),
                          auraBrightness);
    const HullGlowPlan boxGlowPlan =
        BuildHullGlowPlan(glowColor, glowRadius, glowBrightness);

    void* actors[256] = {};
    const int actorCount = overlay::GetActors(actors, 256);
    // Hysteresis band against cull-line blinking (see m_visible).
    constexpr float kCullHysteresis = 2.0f;
    // Static so its capacity survives across frames: the previous local vector
    // was reconstructed (and reallocated) every frame, and the swap at the end
    // of this function already hands its storage over to m_visible anyway.
    static std::vector<void*> stillVisible;
    stillVisible.clear();
    if (stillVisible.capacity() < static_cast<size_t>(actorCount))
        stillVisible.reserve(static_cast<size_t>(actorCount));
    // PacketV2 width, exactly: fmax(0.2, 1 / fmax(1, dist)), times the
    // Thickness multiplier (1.0 = 1:1 with PacketV2). Near boxes are ~1 px,
    // far ones bottom out at 0.2. The damage-time alpha
    // (fmax(0.1, fmin(1, 15 / (damageTime + 1)))) is identically 1.0 for every
    // real damageTime value (0..14), and the numeric field has no proven
    // offset on this build - so the box draws at full opacity, like PacketV2
    // does in practice. The growing "Scale with distance" branch stays as an
    // explicit opt-in extra (NOT PacketV2).
    int drawnCount = 0;
    int aabbOkCount = 0;
    int culledCount = 0;

    for (int i = 0; i < actorCount; ++i) {
        // The local player's own hitbox is never drawn - neither in first
        // person nor from the F5 third-person camera.
        if (overlay::IsHitboxLocalPlayer(actors[i])) continue;
        // SystemDLC "Цели": an unknown class (unreadable category word) still
        // draws - the categories offset is unproven on 1.21.11x.
        const int actorClass = overlay::GetActorClass(actors[i]);
        if (actorClass != 0) {
            if (targets == 0 && actorClass != 1) continue;  // Players
            if (targets == 1 && actorClass != 2) continue;  // Mobs
        }
        float mins[3] = {}, maxs[3] = {};
        if (!overlay::ActorReadAabb(actors[i], mins, maxs)) continue;
        ++aabbOkCount;

        // PacketV2's smoothing idea, applied to the box we just read: the
        // component only moves on the tick, so without this the box steps at
        // 20 Hz inside a display-rate world.
        SmoothHitboxAabb(actors[i], mins, maxs);

        const float dx = (mins[0] + maxs[0]) * 0.5f - camera[0];
        const float dy = (mins[1] + maxs[1]) * 0.5f - camera[1];
        const float dz = (mins[2] + maxs[2]) * 0.5f - camera[2];
        const float distanceSq = dx * dx + dy * dy + dz * dz;
        // Hard cull at maxDistance, but keep last frame's visible actors until
        // maxDistance + hysteresis: without this a mob walking the cull line
        // blinks every time its center crosses the boundary by centimeters.
        const bool wasVisible =
            std::find(m_visible.begin(), m_visible.end(), actors[i]) != m_visible.end();
        const float cullDist = wasVisible ? maxDistance + kCullHysteresis : maxDistance;
        if (distanceSq > cullDist * cullDist) {
            ++culledCount;
            continue;
        }
        stillVisible.push_back(actors[i]);

        // PacketV2 Normal lift: render.upper.y += 0.1 (drawEntityBox), also
        // used by its draw2D corners. Applied in Box mode for both the 3D box
        // and the flat projection; Glow mode keeps raw bounds.
        float pmaxs[3] = { maxs[0], maxs[1], maxs[2] };
        if (renderMode == 0) pmaxs[1] += 0.1f;
        ImVec2 points[8] = {};
        float depths[8] = {};
        bool valid[8] = {};
        // An edge that cannot be projected is skipped instead of discarding
        // the whole wireframe; fewer than 2 points kills the box, exactly
        // like PacketV2's drawBox early-out.
        if (ProjectBox(mins, pmaxs, points, depths, valid) < 2) continue;

        const float distance = std::sqrt(distanceSq);
        // PacketV2: 3D fmax(0.2, 1 / fmax(1, dist)), 2D corners
        // fmax(0.4, 1 / fmax(1, dist * 3)) - both times Thickness.
        const float packetWidth = mode2d
            ? std::max(0.4f, 1.0f / std::max(1.0f, distance * 3.0f))
            : std::max(0.2f, 1.0f / std::max(1.0f, distance));
        const float lineWidth =
            staticThickness
                ? thickness
                : scaleDistance
                    ? std::min(6.0f, thickness * std::max(1.0f, distance * 0.12f))
                    : thickness * packetWidth;
        // PacketV2 fixed colors: mobs blue, everyone else Box color.
        const ImU32 actorLineU32 = (actorClass == 2) ? mobU32 : lineU32;

        HullPoly hull = BuildHullPoly(points, valid);

        if (renderMode == 1) {
            // SystemDLC "Свечение" mode: a filled glowing silhouette instead
            // of sharp lines. Fill sits under the aura, the wavy animation
            // distorts the aura polygon and widens it.
            HullPoly aura = hull;
            if (animOn) {
                // The animSize widening is already baked into auraGlowPlan.
                DisplaceHullWavy(aura, (float)ImGui::GetTime(),
                                 animStrength * 8.0f);
            }
            if (aura.count >= 3)
                draw->AddConvexPolyFilled(aura.pts, aura.count, silhouetteU32);
            DrawHullGlow(draw, aura, auraGlowPlan);
            ++drawnCount;
            continue;
        }

        // House composite order: glow, fill, outline, lines.
        // Normal draws the gift-wrap silhouette (PacketV2-like clean box);
        // Wireframe draws the full 12-edge cuboid (classic house look).
        const bool wireframe = (renderMode == 2);
        if (glowOn)
            DrawHullGlow(draw, hull, boxGlowPlan);

        if (fillOn) {
            if (mode2d) {
                if (hull.count >= 3)
                    draw->AddConvexPolyFilled(hull.pts, hull.count, fillU32);
            } else {
                DrawBoxFill3D(draw, mins, pmaxs, points, valid, camera, fillU32);
            }
        }

        bool drewEdge = false;
        if (mode2d) {
            if (outlineOn)
                DrawHullSegments(draw, hull, outlineU32, lineWidth * 2.2f,
                                 &screen);
            DrawHullSegments(draw, hull, actorLineU32, lineWidth, &screen);
            drewEdge = hull.count >= 2;
        } else if (wireframe) {
            if (outlineOn) {
                // All outline strokes first so every line sits above them.
                for (const auto& edge : kBoxEdges) {
                    if (!valid[edge[0]] || !valid[edge[1]]) continue;
                    DrawWhiteBoxLine(draw, points[edge[0]], points[edge[1]],
                                     outlineU32, lineWidth * 2.2f, screen);
                }
            }
            for (const auto& edge : kBoxEdges) {
                if (!valid[edge[0]] || !valid[edge[1]]) continue;
                DrawWhiteBoxLine(draw, points[edge[0]], points[edge[1]],
                                 actorLineU32, lineWidth, screen);
                drewEdge = true;
            }
        } else {
            if (outlineOn)
                DrawHullSegments(draw, hull, outlineU32, lineWidth * 2.2f,
                                 &screen);
            DrawHullSegments(draw, hull, actorLineU32, lineWidth, &screen);
            drewEdge = hull.count >= 2;
        }
        if (drewEdge) ++drawnCount;
    }

    m_visible.swap(stillVisible);

    static ULONGLONG nextDiag = 0;
    const ULONGLONG now = GetTickCount64();
    if (now >= nextDiag) {
        nextDiag = now + 1000u;
        // aabbOk separates the two failure modes: actors>0 with aabbOk=0 means
        // the component read is still failing, while aabbOk>0 with drawn=0
        // means the projection is rejecting the boxes.
        LOG_INFO("hitboxes: boxes actors=%d aabbOk=%d culled=%d drawn=%d matrixMode=%d mode=%d",
                 actorCount, aabbOkCount, culledCount, drawnCount,
                 overlay::GetHitboxMatrixMode(), renderMode);
    }
}

JavaInventoryHotkeysModule::JavaInventoryHotkeysModule()
    : Module("Client", "Java Hotkeys",
              "Java-like hotbar swaps in the standard player inventory") {}

void JavaInventoryHotkeysModule::onEnable() {
    // The overlay owns the controller hook, bounded queue and options.txt
    // parser. Enabling the module only arms that already-installed path.
    overlay::SetJavaInventoryEnabled(true);
}

void JavaInventoryHotkeysModule::onDisable() {
    overlay::SetJavaInventoryEnabled(false);
}

// ======================== VSync Disabler ========================
VSyncDisablerModule::VSyncDisablerModule()
    : Module("Client", "VSync Disabler",
             "Present without the vertical sync wait (uncapped FPS)") {}

void VSyncDisablerModule::onEnable() {
    // The DXGI Present hook forces SyncInterval to 0 - the swapchain-level
    // equivalent of turning the game's VSync off.
    overlay::SetVSyncDisabled(true);
}

void VSyncDisablerModule::onDisable() {
    overlay::SetVSyncDisabled(false);
}

// ======================== Null Movement ========================
NullMovementModule::NullMovementModule()
    : Module("Movement", "Null Movement",
             "Last pressed of A/D and W/S wins - no standstill") {
    m_adPair = addSetting<BoolSetting>("A/D Pair", "Null the A/D pair.", true);
    m_wsPair = addSetting<BoolSetting>("W/S Pair", "Null the W/S pair.", true);
}

void NullMovementModule::onEnable() {
    overlay::SetNullMovementEnabled(true);
    overlay::SetNullMovementPairs(m_adPair ? m_adPair->mValue : true,
                                  m_wsPair ? m_wsPair->mValue : true);
}

void NullMovementModule::onTick() {
    // Live pair toggles while the module runs.
    overlay::SetNullMovementPairs(m_adPair ? m_adPair->mValue : true,
                                  m_wsPair ? m_wsPair->mValue : true);
}

void NullMovementModule::onDisable() {
    overlay::SetNullMovementEnabled(false);
}

// ======================== CPS Limiter ========================
CpsLimiterModule::CpsLimiterModule()
    : Module("Combat", "CPS Limiter",
             "Капает клики, которые игра регистрирует в секунду") {
    m_left = addSetting<NumberSetting>("Left limit", "LMB clicks per second.",
                                       16.0f, 1.0f, 50.0f, 1.0f);
    m_right = addSetting<NumberSetting>("Right limit", "RMB clicks per second.",
                                        24.0f, 1.0f, 50.0f, 1.0f);
}

void CpsLimiterModule::onEnable() {
    overlay::SetCpsLimiterEnabled(true);
    overlay::SetCpsLimits((int)m_left->mValue, (int)m_right->mValue);
}

void CpsLimiterModule::onTick() {
    // Live limit updates while the module runs.
    overlay::SetCpsLimits((int)m_left->mValue, (int)m_right->mValue);
}

void CpsLimiterModule::onDisable() {
    overlay::SetCpsLimiterEnabled(false);
}

GuiScaleModule::GuiScaleModule()
    : Module("Client", "GUI Scale", "Native Minecraft GUI size: inventory, chat and screens") {
    // Match Flarial's gradual control instead of a discrete enum. The value
    // is sampled every frame, so dragging this slider changes Bedrock's own
    // GUI continuously from the smallest to the largest supported scale.
    m_scale = addSetting<NumberSetting>(
        "Scale", "Native Minecraft GUI scale, 1.0 to 4.0.", 2.0f, 1.0f, 4.0f, 0.05f);
}

float GuiScaleModule::targetScale() const {
    const float value = m_scale ? m_scale->mValue : 2.0f;
    return value < 1.0f ? 1.0f : (value > 4.0f ? 4.0f : value);
}

} // namespace nf
