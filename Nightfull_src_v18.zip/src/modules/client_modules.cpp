// client_modules.cpp - menu + theme configuration holders.

#include "modules/client_modules.h"

#include <string>
#include <vector>

#include "modules/theme_presets.h"
#include "utils/gui_theme.h"

namespace nf {

GeneralModule* GeneralModule::s_instance = nullptr;
ThemesModule* ThemesModule::s_instance = nullptr;

GeneralModule::GeneralModule()
    : Module("Client", "General", "Menu behaviour and chrome") {
    s_instance = this;
    hiddenFromLists = true;
    setEnabled(true);

    m_animation = addSetting<EnumSetting>("Animation", "Menu open animation.", AnimRise,
        std::vector<std::string>{ "Fade", "Rise", "Zoom" });
    m_easeSpeed = addSetting<NumberSetting>("Ease Speed", "Transition speed.", 14.0f, 4.0f, 24.0f, 0.5f);
    m_scrim = addSetting<NumberSetting>("Scrim", "Backdrop darkness.", 0.15f, 0.0f, 0.8f, 0.05f);
    // The whole Nightfull interface scales with this (the reference's "GUI
    // size" slider). Default 0.80 = the old minimum, so the shell reads
    // smaller/tighter out of the box; 1.0 sits mid-range. Persisted like every
    // other setting, so it survives restarts and profiles.
    m_guiSize = addSetting<NumberSetting>("GUI Size", "Масштаб всего интерфейса Nightfull.",
                                          0.80f, 0.80f, 1.30f, 0.01f);
    m_textScale = addSetting<NumberSetting>("Text Scale", "Размер всего текста.",
                                            2.00f, 0.50f, 2.50f, 0.05f);
    m_rightPanels = addSetting<BoolSetting>("Secondary surfaces", "Additional page surfaces.", true);
    m_toasts = addSetting<BoolSetting>("Toasts", "Bottom-center notifications.", true);
    m_animations = addSetting<BoolSetting>("UI Animations", "Interface animation master switch.", true);
    m_blur = addSetting<BoolSetting>("UI Blur", "Translucent overlay panels.", true);
    m_hudEdit = addSetting<BoolSetting>("HUD Editor",
        "Двигай элементы HUD в любое место экрана (HUD editor). Забинди для быстрого доступа.",
        false);
}

ThemesModule::ThemesModule()
    : Module("Client", "Themes", "Accent color and name style") {
    s_instance = this;
    hiddenFromLists = true;
    setEnabled(true);

    m_naming = addSetting<EnumSetting>("Naming", "How module names are displayed.", NamingSpaced,
        std::vector<std::string>{ "lowercase", "lower spaced", "Normal", "Spaced" });

    std::vector<std::string> themes;
    for (int i = 0; i < gui::ThemeCount(); i++) themes.push_back(gui::ThemeName(i));
    m_theme = addSetting<EnumSetting>("Theme", "Accent preset.", ThemeDefault, themes);

    m_colorSlots = addSetting<NumberSetting>("Color Slots", "Custom accent colors in the cycle.",
                                             1.0f, 1.0f, 6.0f, 1.0f);
    m_color1 = addSetting<ColorSetting>("Color 1", "Custom accent 1.", 0xFFD97757);
    m_color2 = addSetting<ColorSetting>("Color 2", "Custom accent 2.", 0xFF77C59A);
    m_color3 = addSetting<ColorSetting>("Color 3", "Custom accent 3.", 0xFFC7798C);
    m_color4 = addSetting<ColorSetting>("Color 4", "Custom accent 4.", 0xFF83A5B7);
    m_color5 = addSetting<ColorSetting>("Color 5", "Custom accent 5.", 0xFFA883B7);
    m_color6 = addSetting<ColorSetting>("Color 6", "Custom accent 6.", 0xFFE2B57F);
    m_colorSpeed = addSetting<NumberSetting>("Accent Motion", "Accent cycle speed.",
                                             3.0f, 0.25f, 20.0f, 0.05f);
    m_saturation = addSetting<NumberSetting>("Saturation", "Custom color saturation.",
                                             1.0f, 0.0f, 1.0f, 0.01f);
    m_presetIdx = addSetting<NumberSetting>("Preset Index", "Gallery preset.", -1.0f,
                                            -1.0f, (float)(kThemePresetCount - 1), 1.0f);
    m_presetIdx->mIsVisible = [] { return false; };

    const auto custom = [this] { return m_theme->mValue == ThemeCustom; };
    m_colorSlots->mIsVisible = custom;
    m_color1->mIsVisible = [this] { return m_theme->mValue == ThemeCustom && m_colorSlots->mValue >= 1.0f; };
    m_color2->mIsVisible = [this] { return m_theme->mValue == ThemeCustom && m_colorSlots->mValue >= 2.0f; };
    m_color3->mIsVisible = [this] { return m_theme->mValue == ThemeCustom && m_colorSlots->mValue >= 3.0f; };
    m_color4->mIsVisible = [this] { return m_theme->mValue == ThemeCustom && m_colorSlots->mValue >= 4.0f; };
    m_color5->mIsVisible = [this] { return m_theme->mValue == ThemeCustom && m_colorSlots->mValue >= 5.0f; };
    m_color6->mIsVisible = [this] { return m_theme->mValue == ThemeCustom && m_colorSlots->mValue >= 6.0f; };
    m_saturation->mIsVisible = custom;
}

} // namespace nf
