// registry.cpp - builds the module roster (order = menu order).

#include "modules/registry.h"

#include <memory>
#include <utility>

#include "core/module_manager.h"
#include "modules/client_modules.h"
#include "modules/game_modules.h"
#include "modules/hud_modules.h"
#include "modules/stub_modules.h"
#include "utils/logger.h"

namespace nf {

void RegisterAllModules() {
    using std::make_unique;
    // Always-on HUD chrome (hidden from the menu, render regardless).
    modules().add(make_unique<WatermarkModule>());
    modules().add(make_unique<ArraylistModule>());
    // Gameplay modules are placed at the front of the visible roster so
    // they are immediately discoverable in ClickGUI without changing layout.
    modules().add(make_unique<AutoSprintModule>());
    modules().add(make_unique<FullBrightModule>());
    modules().add(make_unique<HitboxesModule>());
    modules().add(make_unique<GuiScaleModule>());
    modules().add(make_unique<JavaInventoryHotkeysModule>());
    modules().add(make_unique<NoHurtCamModule>());
    modules().add(make_unique<SaturationModule>());
    modules().add(make_unique<MotionBlurModule>());
    modules().add(make_unique<VSyncDisablerModule>());
    modules().add(make_unique<NullMovementModule>());
    modules().add(make_unique<CpsLimiterModule>());
    // ClickGUI roster (visible order follows the Nightfull reference).
    modules().add(make_unique<HudModule>());          // registered module
    modules().add(make_unique<CrosshairModule>());    // real
    modules().add(make_unique<SkyboxModule>());       // registered module
    modules().add(make_unique<KeystrokesModule>());   // real
    modules().add(make_unique<FpsModule>());          // real
    modules().add(make_unique<TargetHudModule>());    // registered module
    modules().add(make_unique<ZoomModule>());         // registered module
    modules().add(make_unique<HotbarModule>());       // registered module
    modules().add(make_unique<TimeChangerModule>());  // registered module
    // Working local-only HUD modules. Keep them in the normal roster so the
    // ClickGUI can actually enable/configure them instead of silently hiding
    // the implementations that already exist in target.
    modules().add(make_unique<CpsModule>());
    modules().add(make_unique<PotionsModule>());
    modules().add(make_unique<KeybindsModule>());
    modules().add(make_unique<ReachDisplayModule>());
    modules().add(make_unique<TimeModule>());
    modules().add(make_unique<MemoryModule>());
    modules().add(make_unique<MouseStrokesModule>());
    // Client category (menu/theme data holders).
    modules().add(make_unique<GeneralModule>());
    modules().add(make_unique<ThemesModule>());
    // Position anchors are HUD-editor-owned: the editor moves elements
    // freely, so the anchor dropdowns are hidden from every settings list.
    // Config files still apply them (unknown-field tolerant reader).
    for (const auto& holder : modules().modules())
        if (Setting* p = holder->findSetting("Position"))
            p->mIsVisible = [] { return false; };
    LOG_INFO("registry: %d modules", (int)modules().modules().size());
}

} // namespace nf
