// stub_modules.cpp - menu-driven module holders.
//
// Identity strings (names, categories, descriptions) and default on/off
// states mirror the Nightfull reference. See stub_modules.h for the
// replacement contract.

#include "modules/stub_modules.h"

namespace nf {

HudModule::HudModule()
    : Module("HUD", "HUD", "Всё важное — всегда перед глазами.") {
    m_scale = addSetting<NumberSetting>("Scale", "Very small 25% to very large 300%.", 1.0f, 0.25f, 3.0f, 0.05f);
    setEnabled(true);
}

SkyboxModule::SkyboxModule()
    : Module("World", "Skybox", "Новая атмосфера привычного мира.") {
    m_scale = addSetting<NumberSetting>("Scale", "Very small 25% to very large 300%.", 1.0f, 0.25f, 3.0f, 0.05f);
}

ZoomModule::ZoomModule()
    : Module("Visual", "Zoom", "Рассмотри свой мир в деталях.") {
    m_scale = addSetting<NumberSetting>("Scale", "Very small 25% to very large 300%.", 1.0f, 0.25f, 3.0f, 0.05f);
}

HotbarModule::HotbarModule()
    : Module("HUD", "Hotbar", "Плавные анимации панели предметов.") {
    m_scale = addSetting<NumberSetting>("Scale", "Very small 25% to very large 300%.", 1.0f, 0.25f, 3.0f, 0.05f);
    setEnabled(true);
}

TimeChangerModule::TimeChangerModule()
    : Module("World", "Time Changer", "Любимое время суток для мира.") {
    m_scale = addSetting<NumberSetting>("Scale", "Very small 25% to very large 300%.", 1.0f, 0.25f, 3.0f, 0.05f);
}

} // namespace nf
