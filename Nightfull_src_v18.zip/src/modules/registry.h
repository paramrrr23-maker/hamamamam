// registry.h - builds the module roster (order = menu order).

#pragma once

namespace nf {

void RegisterAllModules();

} // namespace nf
