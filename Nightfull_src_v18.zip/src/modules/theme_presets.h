// theme_presets.h - the built-in theme gallery (name + two accent colors).
//
// Emoji prefixes from the source list are dropped on purpose: the menu fonts
// have no emoji glyph coverage and would render tofu boxes. The two-tone
// swatch on each gallery card carries the colors instead.

#pragma once

namespace nf {

struct ThemePreset {
    const char* name;
    unsigned c1;   // 0xRRGGBB - primary accent
    unsigned c2;   // 0xRRGGBB - secondary accent
};

inline const ThemePreset kThemePresets[] = {
    { "Sakura",          0xFFB7C5, 0xFFF1F5 },
    { "Sunrise",         0xFF7A59, 0xFFD166 },
    { "Sunset",          0xFF4D6D, 0x7B2CBF },
    { "Midnight",        0x111827, 0x6366F1 },
    { "Ocean",           0x0077B6, 0x00B4D8 },
    { "Arctic",          0x8ECAE6, 0xEAF8FF },
    { "Forest",          0x14532D, 0x4ADE80 },
    { "Mint",            0x10B981, 0xD1FAE5 },
    { "Lavender",        0x8B5CF6, 0xE9D5FF },
    { "Strawberry",      0xE11D48, 0xFDA4AF },
    { "Blueberry",       0x3730A3, 0x818CF8 },
    { "Grape",           0x581C87, 0xC084FC },
    { "Citrus",          0xF97316, 0xFDE047 },
    { "Lemon",           0xFACC15, 0x84CC16 },
    { "Peach",           0xFB7185, 0xFDBA74 },
    { "Rose",            0xBE123C, 0xFB7185 },
    { "Tulip",           0xDB2777, 0xF9A8D4 },
    { "Sunflower",       0xEAB308, 0xFACC15 },
    { "Sage",            0x4D7C0F, 0xBEF264 },
    { "Tropical",        0x0F766E, 0x2DD4BF },
    { "Ember",           0xDC2626, 0xF97316 },
    { "Volcano",         0x7F1D1D, 0xF43F5E },
    { "Electric",        0x2563EB, 0x22D3EE },
    { "Neon",            0xA3E635, 0x22D3EE },
    { "Cyber Purple",    0x4C1D95, 0xD946EF },
    { "Cyber Blue",      0x172554, 0x00E5FF },
    { "Cyber Pink",      0x831843, 0xF472B6 },
    { "Cyber Green",     0x052E16, 0x39FF14 },
    { "Moonlight",       0x1E293B, 0xCBD5E1 },
    { "Starlight",       0x0F172A, 0xF8FAFC },
    { "Galaxy",          0x1E1B4B, 0xEC4899 },
    { "Cosmic",          0x312E81, 0xA855F7 },
    { "Nebula",          0x581C87, 0x06B6D4 },
    { "Rain",            0x334155, 0x38BDF8 },
    { "Fog",             0x475569, 0xCBD5E1 },
    { "Desert",          0xB45309, 0xFDE68A },
    { "Beach",           0x0EA5E9, 0xFDE68A },
    { "Earth",           0x78350F, 0xA3A3A3 },
    { "Autumn",          0xC2410C, 0xF59E0B },
    { "Winter",          0x1E3A8A, 0xBFDBFE },
    { "Spring",          0x22C55E, 0xF9A8D4 },
    { "Golden Hour",     0xD97706, 0xFDE68A },
    { "Diamond",         0x0EA5E9, 0xE0F2FE },
    { "Obsidian",        0x09090B, 0x71717A },
    { "Silver",          0x27272A, 0xD4D4D8 },
    { "Pearl",           0xE5E7EB, 0xFFFFFF },
    { "Crimson",         0x450A0A, 0xEF4444 },
    { "Amethyst Night",  0x090014, 0xA855F7 },
    { "Royal",           0x172554, 0x3B82F6 },
    { "Royal Violet",    0x2E1065, 0x8B5CF6 },
    { "Black Purple",    0x0A0710, 0x8B5CF6 },
    { "Deep Space",      0x050816, 0x4F46E5 },
    { "Night City",      0x080B12, 0x00B8D9 },
    { "Dark Violet",     0x10051A, 0xA855F7 },
    { "Dark Moon",       0x0B0F19, 0x64748B },
    { "Dark Amethyst",   0x120719, 0xC026D3 },
    { "Dark Ocean",      0x03141F, 0x0284C7 },
    { "Abyss",           0x020617, 0x06B6D4 },
    { "Dark Forest",     0x06130C, 0x16A34A },
    { "Pine Night",      0x07110D, 0x22C55E },
    { "Dark Crimson",    0x140507, 0xDC2626 },
    { "Blood Moon",      0x120305, 0xE11D48 },
    { "Dark Ember",      0x120A05, 0xF97316 },
    { "Dark Sunset",     0x140A08, 0xF43F5E },
    { "Dark Sakura",     0x12070D, 0xF472B6 },
    { "Midnight Rose",   0x120710, 0xEC4899 },
    { "Deep Blue",       0x030712, 0x2563EB },
    { "Dark Electric",   0x050B14, 0x22D3EE },
    { "Void Purple",     0x08030F, 0x7C3AED },
    { "Purple Night",    0x0D0717, 0x9333EA },
    { "Midnight Cyan",   0x041014, 0x06B6D4 },
    { "Emerald Night",   0x03100B, 0x10B981 },
    { "Dark Gold",       0x110D03, 0xEAB308 },
    { "Dark Magenta",    0x12050F, 0xD946EF },
    { "Dark Nebula",     0x090516, 0x6366F1 },
    { "Midnight Purple", 0x0A0612, 0x6D28D9 },
    { "Frozen Night",    0x061018, 0x38BDF8 },
    { "Dark Mist",       0x0B1016, 0x94A3B8 },
    { "Dark Void",       0x030305, 0x52525B },
    { "Dark Diamond",    0x080C12, 0x60A5FA },
};

inline constexpr int kThemePresetCount =
    (int)(sizeof(kThemePresets) / sizeof(kThemePresets[0]));

} // namespace nf
