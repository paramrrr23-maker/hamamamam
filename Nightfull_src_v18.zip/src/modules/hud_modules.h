// hud_modules.h - the curated local-only HUD roster.
//
// Every module here draws from process-local state (ImGui IO, Win32 clock,
// own working set, the module registry). None of them reads game memory.

#pragma once

#include <array>
#include <string>
#include <vector>

#include "core/module.h"

namespace nf {

// Shared 6-corner anchor (module settings store the int).
// NOTE: order is stable API (configs store the index).
inline std::vector<std::string> HudPositionNames() {
    return { "Top Left", "Top Right", "Bottom Left", "Bottom Right", "Top Center", "Bottom Center" };
}

// One row of the shared neon plate (Keybinds / Potions HUD).
struct NeonPlateRow {
    std::string left;
    std::string right;
    ImColor color = ImColor(242, 244, 246);
    ImColor rightColor = ImColor(0, 0, 0, 0);
    ImColor dot = ImColor(0, 0, 0, 0);
    bool hasRightColor = false;
    bool hasDot = false;
    // Dynamic-Island presence for this row (1 = fully in). t<1 fades the row
    // and slides it in from below; exiting rows keep their last content.
    float t = 1.0f;
    float dy = 0.0f;
};

// Free-form HUD editor state shared by every draggable element (Flarial
// percentageX/Y parity): "Free position" enables the free placement and the
// hidden Free X/Y settings store the top-left as a fraction of the screen
// (0..1), so positions survive resolution changes. Dragged by the editor;
// hidden from the inspector but persisted by the config like any setting.
// Each draggable class declares the triplet below as m_freeOn/m_freeX/m_freeY.

// Dynamic-Island style spring animator for the neon plates. Keybinds and
// Potions feed the target rows every frame; the animator keeps entering rows
// (fade+rise), keeps exiting rows visible while they collapse, and springs
// the plate width/height with a slight bounce so the block morphs like the
// iOS Dynamic Island when binds or effects appear/disappear.
struct NeonPlateAnim {
    struct RowState {
        std::string key;
        NeonPlateRow last;
        float t = 0.0f;       // 0..1 presence
        bool exiting = false;
    };
    std::vector<RowState> rows;
    float w = 0.0f, wVel = 0.0f;
    float h = 0.0f, hVel = 0.0f;
    bool started = false;

    // targetRows/targetW: the would-be plate this frame (full presence).
    // scale: plate scale (row metrics derive from it). Outputs the drawable
    // rows (targets + exiting tail, each with t/dy) and the sprung size.
    void Update(const std::vector<NeonPlateRow>& targetRows, float targetW,
                float scale, float dt,
                std::vector<NeonPlateRow>& outRows, float& outW, float& outH);
};

class WatermarkModule : public Module {
public:
    WatermarkModule();
    void onRender() override;
private:
    StringSetting* m_text = nullptr;
    BoolSetting* m_background = nullptr;
    BoolSetting* m_outline = nullptr;
    BoolSetting* m_fps = nullptr;
    BoolSetting* m_clock = nullptr;
    BoolSetting* m_ping = nullptr;
    NumberSetting* m_opacity = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_freeOn = nullptr;
    NumberSetting* m_freeX = nullptr;
    NumberSetting* m_freeY = nullptr;
    double m_animStart = -1000.0;   // last staggered text reveal start
};

class ArraylistModule : public Module {
public:
    ArraylistModule();
    void onRender() override;
private:
    EnumSetting* m_style = nullptr;      // Glass / Sans
    BoolSetting* m_showMode = nullptr;
    EnumSetting* m_visibility = nullptr;   // All / Bound
    NumberSetting* m_fontSize = nullptr;
    NumberSetting* m_opacity = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_freeOn = nullptr;
    NumberSetting* m_freeX = nullptr;
    NumberSetting* m_freeY = nullptr;
    std::vector<float> m_anim;             // per-registry-index slide 0..1
};

class PotionsModule : public Module {
public:
    PotionsModule();
    void onRender() override;
private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_fontSize = nullptr;
    NumberSetting* m_scale = nullptr;
    NumberSetting* m_opacity = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
    BoolSetting* m_outline = nullptr;
    BoolSetting* m_freeOn = nullptr;
    NumberSetting* m_freeX = nullptr;
    NumberSetting* m_freeY = nullptr;
    NeonPlateAnim m_anim;
};

class FpsModule : public Module {
public:
    FpsModule();
    void onRender() override;
private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
    BoolSetting* m_freeOn = nullptr;
    NumberSetting* m_freeX = nullptr;
    NumberSetting* m_freeY = nullptr;
};

class CpsModule : public Module {
public:
    CpsModule();
    void onRender() override;
private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_buttons = nullptr;
    BoolSetting* m_outline = nullptr;
    NumberSetting* m_opacity = nullptr;
    BoolSetting* m_freeOn = nullptr;
    NumberSetting* m_freeX = nullptr;
    NumberSetting* m_freeY = nullptr;
};

class KeybindsModule : public Module {
public:
    KeybindsModule();
    void onRender() override;
private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_outline = nullptr;
    NumberSetting* m_opacity = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
    BoolSetting* m_freeOn = nullptr;
    NumberSetting* m_freeX = nullptr;
    NumberSetting* m_freeY = nullptr;
    NeonPlateAnim m_anim;
};

// Reach Display: "[target icon] Reach X.XX" in the Watermark pill style.
// The value is the eye-to-target distance at each landed attack (Flarial
// ReachCounter behavior; 0.00 before the first hit and after 15 s idle).
class ReachDisplayModule : public Module {
public:
    ReachDisplayModule();
    void onRender() override;
private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_outline = nullptr;
    NumberSetting* m_opacity = nullptr;
    BoolSetting* m_freeOn = nullptr;
    NumberSetting* m_freeX = nullptr;
    NumberSetting* m_freeY = nullptr;
};

// Target HUD (SystemDLC TargetHudElement layout + damage feedback from the
// prototype): 175x54 card, radius 12, 54x54 head panel with the target's real
// skin face (8x8 face + hat layer), name, distance, HP text and a smoothed HP
// bar (danger -> caution -> success). Shows while the crosshair is on a
// player, hides "Hide Delay" ms (default 300) after it leaves. Shake, red
// flash, particles and a floating damage number fire when the TARGET takes
// damage (hurtTime edge / HP drop), never on my clicks.
class TargetHudModule : public Module {
public:
    TargetHudModule();
    void onRender() override;
private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    NumberSetting* m_opacity = nullptr;
    EnumSetting* m_theme = nullptr;
    NumberSetting* m_range = nullptr;
    NumberSetting* m_hideDelay = nullptr;
    BoolSetting* m_shake = nullptr;
    BoolSetting* m_particles = nullptr;
    BoolSetting* m_damageNumbers = nullptr;
    BoolSetting* m_hurtTint = nullptr;
    BoolSetting* m_freeOn = nullptr;
    NumberSetting* m_freeX = nullptr;
    NumberSetting* m_freeY = nullptr;

    // Last shown target (kept for the fade-out after the crosshair leaves).
    char m_name[24] = {};
    float m_pos[3] = {};
    bool m_hpValid = false;
    float m_hp = 20.0f, m_maxHp = 20.0f;
    bool m_skinValid = false;
    unsigned int m_face[64] = {};

    float m_showP = 0.0f;              // linear 0..1 (SystemDLC Animation 4.5/s)
    bool m_wasVisible = false;
    float m_hpShown = 1.0f;            // smoothed fraction
    float m_hpTrail = 1.0f;            // delayed damage trail fraction
    float m_trailHold = 0.0f;
    float m_lastHp = -1.0f;
    unsigned long long m_lastGen = 0;
    float m_shakeT = -1.0f;            // card shake timer (<0 idle)
    float m_flashT = -1.0f;            // red flash / hurt tint timer
    float m_sinceEdge = 99.0f;

    struct Particle {
        float x = 0, y = 0, vx = 0, vy = 0, life = 0, rot = 0, rv = 0, sz = 4;
    };
    Particle m_parts[32];
    int m_partCount = 0;
    struct DamageNum { float value = 0; float t = -1.0f; float dx = 0; };
    DamageNum m_nums[6];
};

class TimeModule : public Module {
public:
    TimeModule();
    void onRender() override;
private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_seconds = nullptr;
    BoolSetting* m_24h = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
    BoolSetting* m_freeOn = nullptr;
    NumberSetting* m_freeX = nullptr;
    NumberSetting* m_freeY = nullptr;
};

class MemoryModule : public Module {
public:
    MemoryModule();
    void onRender() override;
private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
    BoolSetting* m_freeOn = nullptr;
    NumberSetting* m_freeX = nullptr;
    NumberSetting* m_freeY = nullptr;
};

class MouseStrokesModule : public Module {
public:
    MouseStrokesModule();
    void onEnable() override;
    void onDisable() override;
    void onTick() override;
    void onRender() override;
private:
    struct TrailPoint { ImVec2 pos{}; unsigned long long ms = 0; };
    static constexpr int kMaxPoints = 64;
    static constexpr unsigned long long kLifetimeMs = 260;
    std::array<TrailPoint, kMaxPoints> m_points{};
    int m_count = 0;
    NumberSetting* m_scale = nullptr;
    NumberSetting* m_length = nullptr;
    NumberSetting* m_thickness = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
    void expire(unsigned long long now);
};

class KeystrokesModule : public Module {
public:
    KeystrokesModule();
    void onRender() override;
private:
    EnumSetting* m_position = nullptr;
    NumberSetting* m_scale = nullptr;
    NumberSetting* m_spacing = nullptr;
    NumberSetting* m_rounding = nullptr;
    BoolSetting* m_showMouse = nullptr;
    ColorSetting* m_pressed = nullptr;
    ColorSetting* m_released = nullptr;
    BoolSetting* m_freeOn = nullptr;
    NumberSetting* m_freeX = nullptr;
    NumberSetting* m_freeY = nullptr;
};

class CrosshairModule : public Module {
public:
    CrosshairModule();
    void onRender() override;
private:
    NumberSetting* m_scale = nullptr;
    BoolSetting* m_dynamic = nullptr;
    NumberSetting* m_gap = nullptr;
    NumberSetting* m_length = nullptr;
    NumberSetting* m_thickness = nullptr;
    BoolSetting* m_useTheme = nullptr;
    ColorSetting* m_color = nullptr;
};

} // namespace nf
