// overlay.cpp - Present interception, D3D11/D3D12 overlay rendering,
// WndProc input subclass, cursor arbitration and clean unload.
//
// Design notes:
//  * Patch surface: shared DXGI vtable slots for Present (8) /
//    ResizeBuffers (13) + the shared ID3D12CommandQueue slot for
//    ExecuteCommandLists (10), all obtained without touching game code -
//    PLUS one game-function detour, Keyboard::feed (MinHook + signature),
//    installed per explicit user order ("like in the repo") because no
//    in-sandbox Win32 key source exists. Feed use is read+mask only
//    (mirror every transition, swallow presses while the menu is open,
//    swallow the menu key). All patches are restored on unload.
//  * D3D11 path: render into the game's immediate context + our RTV.
//  * D3D12 path: single DIRECT queue of our own for ImGui-owned uploads, but
//    the per-frame UI list is submitted on the GAME's direct queue (learned
//    via an ExecuteCommandLists vtable hook, slot 10 - a system-interface
//    hook like Present, not a game detour). Same-queue FIFO ordering is what
//    keeps our PRESENT<->RT barriers after the game's own transitions; a
//    second racing queue wedged the GPU on frame 1 (dx12c). Our fence still
//    fully serializes each frame (Signal + wait with timeout).
//  * Input: WndProc subclass feeds nf::keys and the ImGui backend; while the
//    menu is open, input messages are swallowed so the game never sees them.
//    The game window gets no legacy key/mouse messages (raw/CoreWindow input
//    path), so we register our OWN raw-input sink (RIDEV_INPUTSINK): WM_INPUT
//    then arrives no matter what the game does, and the subclass parses it
//    (keyboard -> nf::keys, buttons/wheel -> ImGui IO). Mouse buttons are
//    additionally ORed from GetAsyncKeyState, which provably works for mouse
//    (not keys) inside AppContainer. A start-up message census proves which
//    path is alive (see "input census" in the log).
//  * Keyboard: the game's Keyboard::feed is detoured (see above) - the ONLY
//    key source that works inside AppContainer. The raw-input sink + async
//    poll stay fused underneath as fallback; every source merges into the
//    single keys:: edge, so one press is one toggle, never double.
//  * Cursor (in-world): relative input updates ImGui's virtual cursor.
//    While the GUI is open the OS arrow is hidden, ImGui draws the sole cursor,
//    and hit-testing/MouseStrokes share that exact MousePos. No desktop warp.
//    Cursor visibility counter changes are bounded and restored on close.

#include "overlay/overlay.h"

#include <d3d11.h>
#include <d3d12.h>
#include <d3dcompiler.h>
#include <winver.h>
#include <dxgi.h>
#include <dxgi1_4.h>
#include <cstdint>
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cwchar>
#include <setjmp.h>
#include <sstream>
#include <string>
#include <string_view>
#include <vector>

#include <MinHook.h>

#include "imgui.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_dx12.h"
#include "imgui_impl_win32.h"

// Forward declaration: imgui_impl_win32.h intentionally keeps it in `#if 0`
// and asks the caller to declare it (see the comment in that header).
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

#include "core/module_guard.h"
#include "core/module_manager.h"
// Exact Bedrock EnTT mirror from the previous working source. MSVC uses its
// native SEH path; MinGW uses the same layout behind a VEH guard and falls
// back to the ABI-neutral sparse/payload bridge when the STL ABI differs.
#include "overlay/bedrock_entt.hpp"
#include "modules/game_modules.h"
#include "ui/menu.h"
#include "utils/config.h"
#include "utils/fonts.h"
#include "utils/gui_render.h"
#include "utils/keys.h"
#include "utils/logger.h"

namespace nf {
namespace overlay {

constexpr int kHitboxFrameMaxActors = 256;

struct HitboxFrameTransformSnapshot {
    float matrix[16] = {};
    float origin[3] = {};
    float focalX = 1.428148f;
    float focalY = 1.428148f;
    void* registry = nullptr;
    int actorCount = 0;
    int eligibleCount = 0;
    int staleCount = 0; // eligible actors whose cached AABB exceeded keep-alive
    bool aabbComplete = false;
    void* actors[kHitboxFrameMaxActors] = {};
    void* eligibleActors[kHitboxFrameMaxActors] = {};
    ULONGLONG sampleAt[kHitboxFrameMaxActors] = {};
    float mins[kHitboxFrameMaxActors][3] = {};
    float maxs[kHitboxFrameMaxActors][3] = {};
    // Look direction captured in the same setup pass (Flarial's
    // Hitbox::onSetupAndRender reads ActorRotationComponent next to the AABB).
    float rotPitch[kHitboxFrameMaxActors] = {};
    float rotYaw[kHitboxFrameMaxActors] = {};
    bool rotValid[kHitboxFrameMaxActors] = {};
};

SRWLOCK g_hitboxFrameTransformLock = SRWLOCK_INIT;
HitboxFrameTransformSnapshot g_hitboxFrameTransforms[8] = {};
int g_hitboxFrameTransformHead = 0;
int g_hitboxFrameTransformCount = 0;
SRWLOCK g_hitboxActiveFrameLock = SRWLOCK_INIT;
HitboxFrameTransformSnapshot g_hitboxActiveFrame{};
bool g_hitboxActiveFrameValid = false;
SRWLOCK g_hitboxStableAabbLock = SRWLOCK_INIT;
HitboxFrameTransformSnapshot g_hitboxStableAabbFrame{};
bool g_hitboxStableAabbValid = false;
ULONGLONG g_hitboxStableAabbUpdatedAt = 0;
constexpr int kHitboxTransformDelay = 0;
// LevelRenderer::renderLevel is the closest stable game-side equivalent to
// Flarial's per-frame SetupAndRender capture. It only publishes a generation;
// the actual component/AABB reads remain on the background worker.
volatile LONG g_hitboxAabbUrgentGeneration = 0;
// Rotate a bounded worker batch so a large owner storage cannot make the
// first entries fresh forever while later players trail behind.
constexpr int kHitboxAabbBudgetPerPass = 24;
int g_hitboxAabbProbeStart = 0;

// Freshness stamp for g_hitboxActiveFrame.
//
// The packet is only rewritten on a frame whose camera proof passed
// (matrixOk && eyeOk). When that proof fails for a stretch - and on this build
// it does, because the LevelRenderer::renderLevel hook never fires and the
// ClientInstance+0xE0 level chain drifts - the packet stays "valid" while
// frozen. A frozen packet whose actor list happened to be empty then latches
// the whole module off: GetActors() keeps returning 0 for as long as the
// camera proof keeps failing, which is exactly "the hitboxes disappeared and
// never came back". Consumers therefore treat the packet as usable only inside
// this window and fall back to the worker's owner snapshot / AABB cache after.
constexpr ULONGLONG kHitboxPacketKeepAliveMs = 500u;
ULONGLONG g_hitboxActiveFrameAt = 0;

// Is the published packet still worth serving? Read under
// g_hitboxActiveFrameLock by the callers below.
inline bool HitboxActiveFrameFreshLocked(ULONGLONG now) {
    return g_hitboxActiveFrameValid && g_hitboxActiveFrameAt != 0 &&
           now - g_hitboxActiveFrameAt < kHitboxPacketKeepAliveMs;
}

// May this frame's packet be the ONLY actor source?
//
// "Fresh" is not the same as "right". A packet that is freshly stamped but
// carries zero actors is the one state that must never stand alone, because it
// is indistinguishable from a full world at the consumer:
//   - the per-actor AABB copy can drop every entry (a stalled/dead sampler
//     leaves the whole cache cold) -> kept=0,
//   - the owner walk can report a count without filling its buffer.
// In both cases the owner snapshot still holds the real actor list, and serving
// the empty packet instead is what produced "packet owners=46 complete=1 kept=0"
// next to "flarial-style boxes actors=0" on a world with dozens of live actors.
// An empty packet is only allowed to stand alone once the snapshot is empty too
// - and the snapshot is cleared on every world change, so that is exactly the
// genuinely-empty-world case.
inline bool HitboxPacketServesActorsLocked(ULONGLONG now) {
    return HitboxActiveFrameFreshLocked(now) &&
           g_hitboxActiveFrame.actorCount > 0;
}

// ---- Sampler liveness ------------------------------------------------------
//
// Every cached box in the render packet comes from exactly one background
// thread. If that thread dies, every cache entry silently expires, the packet
// keeps being published with kept=0, and the ESP vanishes with nothing in the
// log to say why - the observed symptom was the worker's last line at
// 22:33:23.029 and then 75 s of complete silence from that thread while the
// module reported actors=0. The heartbeat makes the death observable and lets
// the supervisor restart the sampler instead of losing the feature until the
// game is restarted.
volatile LONG g_hitboxWorkerAlive = 0;
volatile LONG g_hitboxWorkerRestarts = 0;
ULONGLONG g_hitboxWorkerBeatAt = 0;
ULONGLONG g_hitboxWorkerBeatPass = 0;

// ---- AABB pipeline diagnostics -------------------------------------------
//
// Every diagnostic in this path used to be a one-shot counter
// (InterlockedIncrement(&n) <= N). One world join burns all of them inside the
// first second - the 22:10 session consumed all 16 "AABB sample failed" lines
// in 6 ms, 0.7 s *before* the first successful owner walk - so the steady
// state, the only state a user can report from, was completely invisible and
// "no boxes" had to be diagnosed by elimination. These are rate limited to one
// line per second per stage instead, and the per-stage counters are drained by
// the worker's once-a-second aggregate, so a single log line answers "where
// did the boxes go".
enum HitboxAabbStage {
    kAabbStageCtxFail = 0,
    kAabbStageShapeMiss,
    kAabbStageShapeInvalid,
    kAabbStageShapeOk,
    kAabbStageNoPosition,
    kAabbStageOk,
    kAabbStageCount
};
const char* const kHitboxAabbStageNames[kAabbStageCount] = {
    "ctx-fail", "shape-miss", "shape-invalid", "shape-ok", "no-position", "ok"
};
volatile LONG g_hitboxAabbStageCount[kAabbStageCount] = {};
volatile LONG g_hitboxAabbRefreshOk = 0;
volatile LONG g_hitboxAabbRefreshFail = 0;
// Target-filter rejections. Now that HitboxCategoriesOffsetTrusted actually
// reports VALID, this gate can hide the world if +0x210 is not the category
// field for mobs after all - so the count and the last rejected word are part
// of the worker's once-a-second aggregate.
volatile LONG g_hitboxTargetRejectCount = 0;
volatile LONG g_hitboxTargetRejectWord = 0;
// Emergency release for the +0x210 target filter.
//
// Enabling the filter is only safe while +0x210 really is the category field.
// The local-player self-check proves the offset for the *player*; it cannot
// prove that a mob's word at the same offset carries the Mob bit. So if the
// filter ends up rejecting every single owner actor for several seconds in a
// row, it is not filtering junk - it is hiding the world - and it disables
// itself. A world with nothing but items is the accepted false positive: the
// filter is a convenience, an empty screen is a bug.
volatile LONG g_hitboxTargetFilterOff = 0;
volatile LONG g_hitboxTargetFilterStrikes = 0;
constexpr int kHitboxTargetFilterStrikeLimit = 3;

static void HitboxAabbDiag(HitboxAabbStage stage, void* actor, void* registry,
                           uint32_t entity, float a, float b) {
    if (stage < 0 || stage >= kAabbStageCount) return;
    InterlockedIncrement(&g_hitboxAabbStageCount[stage]);
    static ULONGLONG nextLogAt[kAabbStageCount] = {};
    static SRWLOCK diagLock = SRWLOCK_INIT;
    const ULONGLONG now = GetTickCount64();
    AcquireSRWLockExclusive(&diagLock);
    const bool emit = now >= nextLogAt[stage];
    if (emit) nextLogAt[stage] = now + 1000u;
    ReleaseSRWLockExclusive(&diagLock);
    if (!emit) return;
    LOG_INFO("hitboxes: aabb stage=%s actor=%p registry=%p entity=%08X a=%.3f b=%.3f",
             kHitboxAabbStageNames[stage], actor, registry, entity, a, b);
}

// Forward declaration for the worker-side AABB sampler defined after the
// private bridge helpers below.
static bool HitboxRefreshAabbEntry(void* actor);
static bool HitboxAabbRetryDue(void* actor);
// Occlusion + invisible gates used by the synchronous frame capture.
static void HitboxResolveCanSee();
static bool HitboxCallCanSee(void* local, void* actor);
static int HitboxActorInvisible(void* actor);
// Worker-side gate pass + render-side cached gate read (defined next to the
// AABB cache below). The occlusion/visibility gates are evaluated on the
// background sampler; the game render thread only consumes cached verdicts.
static void HitboxRefreshGates(void* const* actors, int count, ULONGLONG now);
static void HitboxCopyCachedGates(void* actor, bool& isTarget, bool& seen,
                                  bool& visibleOk);
static int HitboxActorArmorCount(void* actor);
// Target HUD hurt poll (worker thread; definition below).
static void ThPollTargetInfo();
// Target HUD selection globals (defined next to the attack hook below).
extern void* g_tiTarget;
extern bool g_tiLastHurt;
extern int g_tiStable;
// PacketV2 idea: per-actor AABB cache refresh on the game tick thread; armed
// by the Hitboxes module so disabled hitboxes cost nothing.
volatile LONG g_hitboxTickRefreshEnabled = 0;
void SetHitboxTickRefresh(bool enabled) {
    InterlockedExchange(&g_hitboxTickRefreshEnabled, enabled ? 1 : 0);
}

// VSync Disabler: 1 = force SyncInterval 0 on the hooked Present.
volatile LONG g_vsyncDisabled = 0;
// Set on the very first HkPresent call. The worker thread waits for it before
// arming the MinHook game hooks, so the log always shows whether the DXGI
// vtable patch actually took effect (injection half-failures become visible).
volatile LONG g_presentSeen = 0;
// Null Movement: press order for the A/D and W/S pairs, authored into the
// MoveInputComponent movement bits by the tick hook (see HitboxAutoSprintTick).
volatile LONG g_nullMovementEnabled = 0;
volatile LONG g_nmPairAd = 1, g_nmPairWs = 1;
volatile ULONGLONG g_nmPressAt[4] = {};
// CPS Limiter state.
volatile LONG g_cpsLimiterEnabled = 0;
volatile LONG g_cpsLimitL = 16, g_cpsLimitR = 24;

bool g_showMenu = false;
bool g_hudEdit = false;
int g_menuKey = VK_INSERT;
bool g_guiMouseDown[5] = {};
bool g_guiMousePressed[5] = {};
bool g_guiMouseReleased[5] = {};
float g_guiMouseWheel = 0.0f;
float g_guiMouseWheelH = 0.0f;

// Flarial editmenu parity: the free-form HUD editor owns the cursor and the
// game input mask exactly like an open menu. Every input/cursor gate below
// asks this instead of g_showMenu directly; gameplay-logic gates (hotbar
// queue, sprint tick, ...) keep reading g_showMenu alone.
static bool UiInputOwned() {
    return g_showMenu || g_hudEdit;
}

// Flarial-parity per-frame capture (Hitbox::onSetupAndRender): one immutable
// packet of actors + lerped AABBs + look rotations, collected synchronously on
// the game's render thread inside the SetupAndRender hook. The Hitboxes render
// callback consumes exactly this packet, so box availability no longer depends
// on the background cache/worker schedule - that dependency was the blink.
static void HitboxCaptureFrameSync(HitboxFrameTransformSnapshot& frame);
static bool HitboxReadActorCategories(void* actor, uint32_t* outCategories);
static bool HitboxActorIsTarget(void* actor);
static bool HitboxShouldRefreshAabb(void* actor, const float camera[3],
                                    bool cameraValid, ULONGLONG now,
                                    bool urgent = false);
static void* HitboxGetWorldRegistry();
static void HitboxAdoptWorldContext(void* registry, void* local);

namespace {

static void HitboxPublishLegacyView(const HitboxFrameTransformSnapshot& frame);
static void HitboxEnsureOwnerRefreshThread();
static void* HitboxLocalPlayer();
// Last published camera eye, if it is still inside kHitboxPacketKeepAliveMs.
// Lets the setup pass keep publishing a packet while only the eye proof is
// failing, instead of freezing the packet and latching the module off.
static bool HitboxReadRetainedEye(float out[3], float* focalX, float* focalY);
static bool HitboxReadActorContextDirect(void* actor, void** registry,
                                         void** enttRegistry, uint32_t* entity);

static bool HitboxReadLevelCameraOrigin(float out[3], float* focalX = nullptr,
                                        float* focalY = nullptr);
static bool HitboxEyeFromViewMatrix(const float matrix[16], float out[3]);
static bool HitboxEyeFromLocalPlayer(float out[3]);
static bool HitboxConsumeFrameTransform();
static bool HitboxMatPlausible(const float matrix[16]);
bool PotionReadBytes(const void* address, void* out, size_t bytes);

// ============================ state ============================
constexpr int kPresentIndex = 8;
constexpr int kResizeIndex = 13;
constexpr int kExecIndex = 10;  // ID3D12CommandQueue::ExecuteCommandLists
constexpr int kMaxBuffers = 8;

HMODULE g_hmod = nullptr;
wchar_t g_dllDir[MAX_PATH] = {};
bool g_abort = false;

void** g_vtable = nullptr;
void* g_oPresent = nullptr;
void* g_oResize = nullptr;
void** g_queueVtable = nullptr;
void* g_oExec = nullptr;

// Keyboard::feed detour state (game key source, explicit user order).
using KeyboardFeedFn = void(__cdecl*)(uint32_t, bool);
KeyboardFeedFn g_oFeed = nullptr;
bool g_feedHook = false;
bool g_autoSprintInjected = false;
// Flarial-parity AutoSprint: set by the module, consumed by the baseTick hook.
volatile LONG g_autoSprintFlagsEnabled = 0;
// Hitboxes occlusion: 0 = hide boxes behind walls (default), 1 = show.
volatile LONG g_hitboxThroughWalls = 0;

// Java Hotkeys uses the same game-input boundary plus two strictly resolved
// ContainerScreenController boundaries. The target is built with MinGW while
// Bedrock is an MSVC binary, so this module never passes libstdc++ strings to
// the game. JavaMsvcString below is the small-string-compatible MSVC layout
// used only for the verified short collection names.
struct JavaMsvcString {
    union {
        char local[16];
        char* heap;
    } storage;
    size_t size;
    size_t capacity;
};
static_assert(sizeof(JavaMsvcString) == 32, "unexpected MSVC string bridge size");

using JavaContainerHoverFn = int64_t(__fastcall*)(void*, const JavaMsvcString*, int64_t);
using JavaContainerTickFn = uint32_t(__fastcall*)(void*);
using JavaContainerTakeAllFn = void(__fastcall*)(void*, JavaMsvcString, int32_t);
using JavaContainerPlaceAllFn = void(__fastcall*)(void*, JavaMsvcString, int32_t);

JavaContainerHoverFn g_oJavaContainerHover = nullptr;
JavaContainerTickFn g_oJavaContainerTick = nullptr;
JavaContainerTakeAllFn g_javaTakeAll = nullptr;
uintptr_t g_javaHoverAddress = 0;
uintptr_t g_javaTickAddress = 0;
bool g_javaHooksTried = false;
bool g_javaHooksActive = false;
volatile LONG g_javaEnabled = 0;
volatile LONG g_javaTickSeen = 0;
volatile LONG g_javaHoverCallbacks = 0;
volatile LONG g_javaScreenProbeLogged = 0;

CRITICAL_SECTION g_javaCs;
bool g_javaCsInit = false;
int g_javaHotbarKeys[9] = {};
bool g_javaBindingsLoaded = false;
char g_javaServerHost[128] = {};
bool g_javaRestrictionLogged = false;

struct JavaMoveRequest {
    void* controller = nullptr;
    int destination = -1;
    int source = -1;
    char collection[32] = {};
    ULONGLONG created = 0;
};
JavaMoveRequest g_javaRequests[8] = {};
int g_javaRequestHead = 0;
int g_javaRequestCount = 0;
bool g_javaHeld[256] = {};
void* g_javaHoveredController = nullptr;
void* g_javaHoveredScreenView = nullptr;
int g_javaHoveredSlot = -1;
char g_javaHoveredCollection[32] = {};
ULONGLONG g_javaHoverTime = 0;
// Container tick watchdog: set by every controller tick, read by the input
// enqueue (no tick for 500 ms = no container screen = stale context).
ULONGLONG g_javaLastTickAt = 0;

bool JavaIsEnabled();
void JavaClearContext();
void JavaHandleKeyFeed(uint32_t key, bool isDown);
bool JavaIsGameCodeAddress(uintptr_t address);
void TryInstallJavaInventoryHooks();

// Options::getGamma detour state. The signature is resolved exactly once and
// only an unambiguous match is hooked; a missing/ambiguous match leaves the
// module visible but inert rather than guessing at executable code.
using GammaFn = float(__fastcall*)(uintptr_t*);
GammaFn g_oGamma = nullptr;
bool g_gammaHook = false;

// Native Minecraft GUI Scale state. Flarial uses the game's own
// ClientInstance::_updateScreenSizeVariables path so inventory, chat and
// screens are relaid out by Bedrock instead of only scaling our ImGui layer.
using UpdateScreenFn = void(__fastcall*)(void*, void*, void*, float);
UpdateScreenFn g_oUpdateScreen = nullptr;
void* g_clientInstance = nullptr;
void* g_guiData = nullptr;
using LevelRenderFn = void(__fastcall*)(void*, void*, void*);
LevelRenderFn g_oLevelRender = nullptr;
bool g_levelRenderHook = false;
SRWLOCK g_levelRenderLock = SRWLOCK_INIT;
void* g_levelRenderer = nullptr;
// The Hitboxes module installs this read-only actor registry hook lazily when
// it is first enabled. It is kept separate from the existing input/UI hooks so
// disabling Hitboxes never changes those paths.
bool g_actorBaseTickHook = false;
void* g_oActorBaseTick = nullptr;
bool g_screenSizeHook = false;
bool g_setupAndRenderHook = false;
bool g_screenSizeHookTried = false;
bool g_screenSizeSeen = false;
bool g_setupSeen = false;
bool g_screenSizeCallDisabled = false;
bool g_screenSizeCallProved = false;
uintptr_t g_clientMouseSig = 0;
int g_clientReleaseMouseVtable = -1;
bool g_clientMouseResolveTried = false;
bool g_clientMouseResolveLogged = false;
float g_lastRealScreen[2] = { 0.0f, 0.0f };
void* g_screenView = nullptr;
uintptr_t g_getPositionFn = 0;
bool g_guiScaleRelayoutPending = false;
int g_guiScaleRelayoutFails = 0;
float g_savedGuiScale = 0.0f;
void* g_savedGuiData = nullptr;
bool g_savedGuiScaleValid = false;

// Potions HUD reader. The 1.21.x path mirrors the previous working reader:
// resolve the game's own EnTT assure<MobEffectsComponent> call, locate the
// component pool for the live EntityContext, and copy only the vector header.
// The old try_get candidates are retained for reference but are never invoked
// when their signature could be an assurance marker.
using PotionAssureFn = void*(__fastcall*)(void*, uint32_t);
using PotionTryGetFn = void*(__fastcall*)(void*, const void*);
PotionAssureFn g_potionAssureCandidates[8] = {};
int g_potionAssureCandidateCount = 0;
PotionTryGetFn g_potionTryGet = nullptr;
PotionTryGetFn g_potionTryGetCandidates[8] = {};
int g_potionTryGetCandidateCount = 0;
PotionEffect g_potionSnapshot[24] = {};
int g_potionSnapshotCount = 0;
ULONGLONG g_potionSnapshotAt = 0;
bool g_potionWorldCached = false;
ULONGLONG g_potionWorldCheckAt = 0;
int g_potionLocalPlayerVfunc = -1;
int g_potionLocalPlayerCandidates[4] = {};
int g_potionLocalPlayerCandidateCount = 0;
bool g_potionReaderTried = false;
bool g_potionAssureScanTried = false;
bool g_potionLocalPlayerScanTried = false;
ULONGLONG g_potionNextReaderRetry = 0;
bool g_potionLogged = false;
bool g_potionEnTTFailureLogged = false;
bool g_potionContextProbeLogged = false;
bool g_potionFlarialProbeLogged = false;
uintptr_t g_potionFlarialAttemptedRegistry = 0;
bool g_potionRawRegistryProbeLogged = false;
int g_potionRawMapProbeCount = 0;
bool g_potionRegistryWordsLogged = false;
uintptr_t g_potionTypeProbeRegistry = 0;
ULONGLONG g_potionNextProbeAt = 0;
uintptr_t g_potionComponentAddress = 0;
void* g_potionComponentRegistry = nullptr;
uint32_t g_potionComponentEntity = 0;

// Hitbox ownership must follow the local player's current EntityContext. The
// potion reader can legitimately retain the previous registry for a short
// period while a server/world is being replaced, so Hitboxes keep a separate
// world context and reset all actor/component snapshots when it changes.
SRWLOCK g_hitboxWorldContextLock = SRWLOCK_INIT;
void* g_hitboxWorldRegistry = nullptr;
void* g_hitboxWorldLocal = nullptr;
volatile LONG g_hitboxMaxDistanceCm = 2000; // default 20 blocks
bool g_potionRawLayoutProbeTried = false;
// Direct component accessors are the safest MinGW bridge when the target emits
// the same try_get specialization as the previous working DLL. They are kept
// separate from the hash/assure storage walk because the two call ABIs differ.
PotionTryGetFn g_potionExactTryGetCandidates[4] = {};
int g_potionExactTryGetCandidateCount = 0;
using PotionActorComponentFn = void*(__fastcall*)(void*);
PotionActorComponentFn g_potionActorComponent = nullptr;
PotionTryGetFn g_potionFlarialTryGet = nullptr;
bool g_potionActorComponentScanTried = false;
constexpr uint32_t kPotionComponentHash = 0xF7D6B42Fu; // struct MobEffectsComponent

// NoHurtCam patch state. This follows Solstice's current approach: NOP one
// complete four-byte instruction only after the exact CameraComponent pattern
// has one executable-section match. Original bytes are restored on disable,
// detach and unload.
uintptr_t g_hurtCamAddress = 0;
std::vector<uint8_t> g_hurtCamOriginal;
bool g_hurtCamLocated = false;
bool g_hurtCamApplied = false;
bool g_hurtCamLocateTried = false;

// MouseDevice::feed detour state. Bedrock's CoreWindow path can bypass both
// Win32 messages and user32 raw-input APIs; this is the final game-side input
// boundary used only to cancel mouse movement/buttons/wheel while the GUI is
// open. It carries no gameplay logic and forwards every event unchanged when
// the GUI is closed.
using MouseFeedFn = void(__fastcall*)(void*, char, char, short, short,
                                      short, short, char);
MouseFeedFn g_oMouseFeed = nullptr;
bool g_mouseFeedHook = false;
volatile LONG g_mouseForwardedButtons = 0;

// user32 detour originals (cursor visibility + game input mask, menu-open only).
using GetRawInputDataFn = UINT(WINAPI*)(HRAWINPUT, UINT, LPVOID, PUINT, UINT);
using GetRawInputBufferFn = UINT(WINAPI*)(RAWINPUT*, PUINT, UINT);
using SetCursorPosFn = BOOL(WINAPI*)(int, int);
using ClipCursorFn = BOOL(WINAPI*)(const RECT*);
using SetCaptureFn = HWND(WINAPI*)(HWND);
using ShowCursorFn = int(WINAPI*)(BOOL);
using GetAsyncKeyStateFn = SHORT(WINAPI*)(int);
GetRawInputDataFn oGetRawInputData = nullptr;
GetRawInputBufferFn oGetRawInputBuffer = nullptr;
SetCursorPosFn oSetCursorPos = nullptr;
ClipCursorFn oClipCursor = nullptr;
SetCaptureFn oSetCapture = nullptr;
ShowCursorFn oShowCursor = nullptr;
GetAsyncKeyStateFn oGetAsyncKeyState = nullptr;
bool g_cursorHooks = false;
int g_hideBalance = 0;  // software-cursor mode: original ShowCursor(FALSE) calls to undo
HWND g_hwnd = nullptr;
WNDPROC g_origWnd = nullptr;
struct SubHook { HWND h; WNDPROC o; };
std::vector<SubHook> g_subs;  // non-primary process windows we subclassed
bool g_wndHooked = false;

IDXGISwapChain* g_sc = nullptr;
UINT g_w = 0, g_h = 0;

bool g_init = false;          // render objects ready
bool g_usingD3D12 = false;
bool g_imgui = false;         // ImGui context + modules + config ready
bool g_backend11 = false;
bool g_backend12 = false;
bool g_win32Init = false;
bool g_unloadRequested = false;
bool g_shuttingDown = false;
bool g_renderAborted = false;
// Defined with the Hitboxes bridge below; declared here because unload is
// implemented earlier in this translation unit.
extern HANDLE g_hitboxOwnerRefreshThread;
extern volatile LONG g_hitboxOwnerRefreshStarted;

// D3D11 objects
ID3D11Device* g_d11dev = nullptr;
ID3D11DeviceContext* g_d11ctx = nullptr;
ID3D11RenderTargetView* g_d11rtv = nullptr;

// D3D12 objects (our own queue on the game's device)
ID3D12Device* g_d12dev = nullptr;
ID3D12CommandQueue* g_d12queue = nullptr;
ID3D12CommandQueue* g_gameQueue = nullptr;  // captured, never owned: no Release
ID3D12CommandAllocator* g_d12alloc = nullptr;
ID3D12GraphicsCommandList* g_d12list = nullptr;
ID3D12DescriptorHeap* g_d12rtvHeap = nullptr;
ID3D12DescriptorHeap* g_d12srvHeap = nullptr;
ID3D12Resource* g_d12bufs[kMaxBuffers] = {};
D3D12_CPU_DESCRIPTOR_HANDLE g_d12rtvs[kMaxBuffers] = {};
int g_d12bufCount = 0;
ID3D12Fence* g_d12fence = nullptr;
HANDLE g_d12event = nullptr;
UINT64 g_d12fenceVal = 0;
bool g_d12waitLogged = false;

CRITICAL_SECTION g_renderCs;
bool g_csInit = false;
LONG g_inRender = 0;

bool g_menuWasOpen = false;
bool g_hudEditWas = false;   // HUD editor transition tracker (keys::Reset)
bool g_cursorForced = false;
bool g_menuKeyArmed = true;  // menu key re-arms only after a release (no hold-strobe)

// WndProc message census (dumped once at frame 600 - proves which input
// path the game actually delivers to our subclass).
int g_cKeyDown = 0, g_cKeyUp = 0, g_cInput = 0, g_cChar = 0, g_cMouse = 0, g_cBtn = 0;
int g_cRawBtn = 0;  // raw mouse packets carrying button transitions
bool g_legacyCharSeen = false;  // a real WM_CHAR arrived: stop synthesizing text
bool g_legacyWheelSeen = false;  // a real WM_MOUSEWHEEL arrived: stop raw wheel

// Raw-input mouse cache, written on the pump thread (HookWndProc) and
// consumed on the Present thread (ApplyRawMouse). Relative deltas are used
// while the game owns/parks the desktop cursor: the GUI must not depend on
// GetCursorPos moving in an in-world relative-mouse session.
bool g_rawBtn[5] = {};
// Wheel packets arrive on the window thread while ApplyRawMouse runs on the
// Present thread. Keep a dedicated atomic bridge for GUI wheel input; the
// cursor/keyboard ownership path remains unchanged.
volatile LONG g_guiWheelTicks = 0;
volatile LONG g_guiWheelHTicks = 0;
volatile LONG g_rawDx = 0, g_rawDy = 0;
volatile LONG g_feedDx = 0, g_feedDy = 0;
volatile LONG g_gameMouseX = 0, g_gameMouseY = 0;
volatile LONG g_gameMouseValid = 0;
// The game dispatcher is the reliable button/wheel source on CoreWindow
// builds. Keep it separate from the raw-input cache so GUI drag state can be
// mirrored into ImGui's event queue without depending on legacy WM_* events.
volatile LONG g_gameMouseButtons = 0;
volatile LONG g_gameMouseWheel = 0;
BYTE g_rawBuf[256] = {};  // scratch for GetRawInputData (keyboard/mouse only)
bool g_rawRegistered = false;

void EnsureCs() {
    if (!g_csInit) { InitializeCriticalSection(&g_renderCs); g_csInit = true; }
}

using PresentFn = HRESULT(__stdcall*)(IDXGISwapChain*, UINT, UINT);
using ResizeFn = HRESULT(__stdcall*)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);
using ExecFn = void(__stdcall*)(ID3D12CommandQueue*, UINT, ID3D12CommandList* const*);

void PatchVTable(void** vtable, int index, void* hook, void** original);  // defined below
void __stdcall HkExecuteCommandLists(ID3D12CommandQueue* q, UINT n,
                                    ID3D12CommandList* const* lists);  // defined below

void FinishUnload();  // defined below; called from the HkPresent tail
void TryInstallPotionReader(); // setup/Present path only; never from HUD render
void TryInstallGuiScaleHook();
void ApplyGameGuiScale();
void ReleaseGameMouseForGui();
void RestoreGameGuiScale();
void RestoreNoHurtCamPatch();
HWND FindGameWindow();  // defined below; used when the swapchain has no OutputWindow
void HandleRawInput(LPARAM l);  // defined below; WM_INPUT -> keys:: + raw mouse cache
void ApplyRawMouse();  // defined below; raw cache -> ImGui IO (post-backend, pre-ImGui)
short SampleAsyncKeyState(int vk);  // always bypasses our game-input mask

// ============================ input ============================
bool IsMouseInputMessage(UINT msg) {
    switch (msg) {
        case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_LBUTTONDBLCLK:
        case WM_RBUTTONDOWN: case WM_RBUTTONUP: case WM_RBUTTONDBLCLK:
        case WM_MBUTTONDOWN: case WM_MBUTTONUP: case WM_MBUTTONDBLCLK:
        case WM_XBUTTONDOWN: case WM_XBUTTONUP: case WM_XBUTTONDBLCLK:
        case WM_NCLBUTTONDOWN: case WM_NCLBUTTONUP: case WM_NCLBUTTONDBLCLK:
        case WM_NCRBUTTONDOWN: case WM_NCRBUTTONUP: case WM_NCRBUTTONDBLCLK:
        case WM_NCMBUTTONDOWN: case WM_NCMBUTTONUP: case WM_NCMBUTTONDBLCLK:
        case WM_NCXBUTTONDOWN: case WM_NCXBUTTONUP: case WM_NCXBUTTONDBLCLK:
        case WM_MOUSEWHEEL: case WM_MOUSEHWHEEL:
        case WM_MOUSEMOVE: case WM_NCMOUSEMOVE:
        case WM_MOUSELEAVE: case WM_NCMOUSELEAVE:
        case WM_MOUSEACTIVATE: case WM_SETCURSOR:
        case WM_INPUT:
            return true;
        default:
            return false;
    }
}

bool IsInputMessage(UINT msg) {
    switch (msg) {
        case WM_KEYDOWN: case WM_KEYUP: case WM_SYSKEYDOWN: case WM_SYSKEYUP:
        case WM_CHAR: case WM_SYSCHAR: case WM_DEADCHAR:
            return true;
        default:
            return IsMouseInputMessage(msg);
    }
}

LRESULT CALLBACK HookWndProc(HWND h, UINT msg, WPARAM w, LPARAM l) {
    // Always feed our snapshot first (toggle keys must work with menu closed).
    switch (msg) {
        case WM_KEYDOWN: case WM_SYSKEYDOWN:
            if (++g_cKeyDown == 1)
                LOG_INFO("wndproc: first WM_KEYDOWN vk=%02X", (unsigned)w);
            keys::FeedKey((unsigned)w, true);
            break;
        case WM_KEYUP: case WM_SYSKEYUP:
            if (++g_cKeyUp == 1) LOG_INFO("wndproc: first WM_KEYUP");
            keys::FeedKey((unsigned)w, false);
            break;
        case WM_INPUT:
            if (++g_cInput == 1) LOG_INFO("wndproc: first WM_INPUT");
            HandleRawInput(l);
            break;
        case WM_CHAR:
            if (++g_cChar == 1) LOG_INFO("wndproc: first WM_CHAR");
            g_legacyCharSeen = true;
            keys::FeedChar((unsigned)w);
            break;
        case WM_MOUSEMOVE:
            if (++g_cMouse == 1) LOG_INFO("wndproc: first WM_MOUSEMOVE");
            break;
        case WM_LBUTTONDOWN: case WM_LBUTTONDBLCLK:
            if (++g_cBtn == 1) LOG_INFO("wndproc: first WM_LBUTTONDOWN");
            g_rawBtn[0] = true;
            break;
        case WM_LBUTTONUP:
            g_rawBtn[0] = false;
            break;
        case WM_RBUTTONDOWN: case WM_RBUTTONDBLCLK:
            g_rawBtn[1] = true;
            break;
        case WM_RBUTTONUP:
            g_rawBtn[1] = false;
            break;
        case WM_MBUTTONDOWN: case WM_MBUTTONDBLCLK:
            g_rawBtn[2] = true;
            break;
        case WM_MBUTTONUP:
            g_rawBtn[2] = false;
            break;
        case WM_XBUTTONDOWN:
            g_rawBtn[GET_XBUTTON_WPARAM(w) == XBUTTON1 ? 3 : 4] = true;
            break;
        case WM_XBUTTONUP:
            g_rawBtn[GET_XBUTTON_WPARAM(w) == XBUTTON1 ? 3 : 4] = false;
            break;
        case WM_MOUSEWHEEL:
            g_legacyWheelSeen = true;
            if (UiInputOwned())
                InterlockedExchangeAdd(&g_guiWheelTicks,
                                       (LONG)GET_WHEEL_DELTA_WPARAM(w) / (LONG)WHEEL_DELTA);
            break;
        case WM_MOUSEHWHEEL:
            g_legacyWheelSeen = true;
            if (UiInputOwned())
                InterlockedExchangeAdd(&g_guiWheelHTicks,
                                       (LONG)GET_WHEEL_DELTA_WPARAM(w) / (LONG)WHEEL_DELTA);
            break;
        case WM_KILLFOCUS:
            keys::Reset();
            for (int i = 0; i < 5; i++) g_rawBtn[i] = false;
            InterlockedExchange(&g_guiWheelTicks, 0);
            InterlockedExchange(&g_guiWheelHTicks, 0);
            InterlockedExchange(&g_rawDx, 0);
            InterlockedExchange(&g_rawDy, 0);
            InterlockedExchange(&g_feedDx, 0);
            InterlockedExchange(&g_feedDy, 0);
            InterlockedExchange(&g_gameMouseValid, 0);
            InterlockedExchange(&g_gameMouseButtons, 0);
            InterlockedExchange(&g_gameMouseWheel, 0);
            break;
        default: break;
    }
    // While the GUI (menu or HUD editor) is open the custom relative-input
    // path owns mouse events. Do not also queue stale absolute WM_* events
    // through the Win32 backend: they can overwrite the driven position or
    // create a one-frame drag click.
    if (g_win32Init && !(UiInputOwned() && IsMouseInputMessage(msg)))
        ImGui_ImplWin32_WndProcHandler(h, msg, w, l);
    // Menu/HUD editor open: the game sees no input on ANY process window
    // (no camera, no click-through).
    if (UiInputOwned() && !g_shuttingDown && IsInputMessage(msg)) {
        // Do not let a click activate/focus the game behind the GUI.
        if (msg == WM_MOUSEACTIVATE) return MA_NOACTIVATE;
        return 0;
    }
    WNDPROC o = (h == g_hwnd) ? g_origWnd : nullptr;
    if (!o) for (auto& s : g_subs) if (s.h == h) { o = s.o; break; }
    if (o) return CallWindowProcW(o, h, msg, w, l);
    return DefWindowProcW(h, msg, w, l);  // unreachable: we only run where we hooked
}

UINT RawDataOrig(HRAWINPUT h, UINT cmd, LPVOID data, PUINT size, UINT hdr) {
    // Our own raw reads must bypass the detour installed below: while the
    // menu is open the detour neutralizes what the GAME reads, but the menu
    // itself needs the real packets.
    if (oGetRawInputData) return oGetRawInputData(h, cmd, data, size, hdr);
    return GetRawInputData(h, cmd, data, size, hdr);
}

short SampleAsyncKeyState(int vk) {
    // All Nightfull polling goes through the original user32 entry while the
    // public export is masked for the game. This keeps the GUI's key capture
    // and mouse state alive without leaking either into the game.
    if (oGetAsyncKeyState) return oGetAsyncKeyState(vk);
    return GetAsyncKeyState(vk);
}

void HandleRawInput(LPARAM l) {
    UINT sz = 0;
    if (RawDataOrig((HRAWINPUT)l, RID_INPUT, nullptr, &sz, sizeof(RAWINPUTHEADER)) != 0)
        return;
    if (sz == 0 || sz > sizeof(g_rawBuf)) return;  // HID blobs: ignore
    if (RawDataOrig((HRAWINPUT)l, RID_INPUT, g_rawBuf, &sz, sizeof(RAWINPUTHEADER)) != sz)
        return;
    const RAWINPUT* ri = (const RAWINPUT*)g_rawBuf;
    if (ri->header.dwType == RIM_TYPEKEYBOARD) {
        const RAWKEYBOARD& k = ri->data.keyboard;
        UINT vk = (UINT)k.VKey;
        // Disambiguate L/R modifiers (raw reports generic VK_SHIFT/CONTROL/MENU).
        if (vk == VK_SHIFT) vk = MapVirtualKeyW(k.MakeCode, MAPVK_VSC_TO_VK_EX);
        else if (vk == VK_CONTROL) vk = (k.Flags & RI_KEY_E0) ? VK_RCONTROL : VK_LCONTROL;
        else if (vk == VK_MENU) vk = (k.Flags & RI_KEY_E0) ? VK_RMENU : VK_LMENU;
        const bool down = (k.Flags & RI_KEY_BREAK) == 0;
        keys::FeedKey(vk, down);
        {
            static int n = 0;
            if (++n <= 20)
                LOG_INFO("rawkey: vk=%02X mapped=%02X %s sc=%02X e0=%d",
                         (unsigned)k.VKey, vk, down ? "down" : "up",
                         (unsigned)k.MakeCode, (k.Flags & RI_KEY_E0) ? 1 : 0);
        }
        // Text synthesis: RIDEV_NOLEGACY kills WM_CHAR, so translate through
        // the layout here. Skipped once a real WM_CHAR proves legacy alive.
        if (down && !g_legacyCharSeen) {
            if (vk == VK_BACK) {
                keys::FeedChar(8);
            } else {
                BYTE kb[256] = {};
                GetKeyboardState(kb);
                WCHAR out[8] = {};
                const int rc = ToUnicode(vk, k.MakeCode, kb, out, 8, 0);
                for (int i = 0; i < rc; i++) keys::FeedChar((unsigned)out[i]);
            }
        }
    } else if (ri->header.dwType == RIM_TYPEMOUSE) {
        const RAWMOUSE& m = ri->data.mouse;
        if (UiInputOwned() && !(m.usFlags & MOUSE_MOVE_ABSOLUTE)) {
            if (m.lLastX != 0) InterlockedExchangeAdd(&g_rawDx, (LONG)m.lLastX);
            if (m.lLastY != 0) InterlockedExchangeAdd(&g_rawDy, (LONG)m.lLastY);
        }
        if (m.usButtonFlags != 0) g_cRawBtn++;
        {
            static bool once = false;
            if (!once && m.usButtonFlags != 0) {
                once = true;
                LOG_INFO("rawmouse: first buttons=%04X", (unsigned)m.usButtonFlags);
            }
        }
        if (m.usButtonFlags & RI_MOUSE_LEFT_BUTTON_DOWN) g_rawBtn[0] = true;
        if (m.usButtonFlags & RI_MOUSE_LEFT_BUTTON_UP) g_rawBtn[0] = false;
        if (m.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_DOWN) g_rawBtn[1] = true;
        if (m.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_UP) g_rawBtn[1] = false;
        if (m.usButtonFlags & RI_MOUSE_MIDDLE_BUTTON_DOWN) g_rawBtn[2] = true;
        if (m.usButtonFlags & RI_MOUSE_MIDDLE_BUTTON_UP) g_rawBtn[2] = false;
        if (m.usButtonFlags & RI_MOUSE_BUTTON_4_DOWN) g_rawBtn[3] = true;
        if (m.usButtonFlags & RI_MOUSE_BUTTON_4_UP) g_rawBtn[3] = false;
        if (m.usButtonFlags & RI_MOUSE_BUTTON_5_DOWN) g_rawBtn[4] = true;
        if (m.usButtonFlags & RI_MOUSE_BUTTON_5_UP) g_rawBtn[4] = false;
        // Wheel: raw only while no legacy wheel was ever seen in the normal
        // game path. When the GUI owns input, the legacy message is swallowed
        // before ImGui sees it, so raw wheel remains the GUI fallback.
        if (m.usButtonFlags & RI_MOUSE_BUTTON_4_UP) g_rawBtn[3] = false;
        if (m.usButtonFlags & RI_MOUSE_BUTTON_5_DOWN) g_rawBtn[4] = true;
        if (m.usButtonFlags & RI_MOUSE_BUTTON_5_UP) g_rawBtn[4] = false;
        if (!g_legacyWheelSeen || UiInputOwned()) {
            if (m.usButtonFlags & RI_MOUSE_WHEEL)
                InterlockedExchangeAdd(&g_guiWheelTicks,
                                       (LONG)(short)m.usButtonData / (LONG)WHEEL_DELTA);
            if (m.usButtonFlags & RI_MOUSE_HWHEEL)
                InterlockedExchangeAdd(&g_guiWheelHTicks,
                                       (LONG)(short)m.usButtonData / (LONG)WHEEL_DELTA);
        }
    } else if (ri->header.dwType == RIM_TYPEHID) {
        static bool once = false;
        if (!once) {
            once = true;
            LOG_INFO("rawhid: first HID input (size=%u) - keyboard may be HID-only", sz);
        }
    }
}

void ApplyRawMouse() {
    // Full mouse ownership. In Bedrock's in-world relative-mouse mode the
    // desktop cursor is parked, so an absolute GetCursorPos poll cannot drive
    // the GUI. Prefer MouseDevice::feed deltas, then raw-input deltas, and use
    // the OS position only to seed a new GUI session.
    static const unsigned kBtnVk[5] = {
        VK_LBUTTON, VK_RBUTTON, VK_MBUTTON, VK_XBUTTON1, VK_XBUTTON2
    };
    ImGuiIO& io = ImGui::GetIO();
    // This is a per-frame bridge for the custom-drawn ClickGUI. ImGui still
    // receives the same event below, but the menu must not depend on whether
    // NewFrame/backend processing has already consumed MouseWheel.
    g_guiMouseWheel = 0.0f;
    g_guiMouseWheelH = 0.0f;
    static LONG localX = 0, localY = 0;
    static bool localInit = false;
    static bool previousOwned = false;   // UiInputOwned() state last frame
    static bool hadRelative = false;
    static bool previousButtons[5] = {};
    static LONG gameWheelSeen = 0;

    const bool owned = UiInputOwned();
    const bool menuChanged = owned != previousOwned;
    if (menuChanged) {
        InterlockedExchange(&g_feedDx, 0);
        InterlockedExchange(&g_feedDy, 0);
        InterlockedExchange(&g_rawDx, 0);
        InterlockedExchange(&g_rawDy, 0);
        InterlockedExchange(&g_guiWheelTicks, 0);
        InterlockedExchange(&g_guiWheelHTicks, 0);
        hadRelative = false;
        localInit = false;

        if (!owned) {
            // Release any GUI-side drag state before handing mouse ownership
            // back to the game. This prevents a slider/HUD drag from staying
            // logically held across an ESC/menu close (or HUD editor exit).
            for (int i = 0; i < 5; i++) {
                if (previousButtons[i]) io.AddMouseButtonEvent(i, false);
                previousButtons[i] = false;
            }
            InterlockedExchange(&g_gameMouseButtons, 0);
            InterlockedExchange(&g_gameMouseWheel, 0);
        }
        gameWheelSeen = InterlockedCompareExchange(&g_gameMouseWheel, 0, 0);
        previousOwned = owned;
    }

    if (owned) {
        if (!localInit) {
            POINT seed{};
            if (GetCursorPos(&seed)) {
                if (g_hwnd && IsWindow(g_hwnd)) ScreenToClient(g_hwnd, &seed);
                localX = seed.x;
                localY = seed.y;
            } else {
                localX = (LONG)(io.DisplaySize.x * 0.5f);
                localY = (LONG)(io.DisplaySize.y * 0.5f);
            }
            localInit = true;
        }

        const LONG feedDx = InterlockedExchange(&g_feedDx, 0);
        const LONG feedDy = InterlockedExchange(&g_feedDy, 0);
        const LONG rawDx = InterlockedExchange(&g_rawDx, 0);
        const LONG rawDy = InterlockedExchange(&g_rawDy, 0);
        // One physical motion can appear in both channels. The game's feed
        // is canonical when it provides a delta; raw input is the fallback.
        const bool haveFeedDelta = feedDx != 0 || feedDy != 0;
        const LONG dx = haveFeedDelta ? feedDx : rawDx;
        const LONG dy = haveFeedDelta ? feedDy : rawDy;
        if (dx != 0 || dy != 0) {
            localX += dx;
            localY += dy;
            hadRelative = true;
        } else if (!hadRelative && g_mouseFeedHook && g_gameMouseValid) {
            // Some builds send client-space positions but no relative delta
            // on the first packet. Use this only as the initial fallback.
            localX = g_gameMouseX;
            localY = g_gameMouseY;
        }
        if (io.DisplaySize.x > 1.0f) {
            if (localX < 0) localX = 0;
            if (localX >= (LONG)io.DisplaySize.x) localX = (LONG)io.DisplaySize.x - 1;
        }
        if (io.DisplaySize.y > 1.0f) {
            if (localY < 0) localY = 0;
            if (localY >= (LONG)io.DisplaySize.y) localY = (LONG)io.DisplaySize.y - 1;
        }
        io.AddMousePosEvent((float)localX, (float)localY);
        // Do not warp the desktop cursor. Relative in-world input is the
        // authoritative GUI position, and ImGui draws the sole visible cursor
        // there. Warping made Windows, Bedrock and ImGui each maintain a
        // different pointer, producing the phantom cursor/click mismatch.
    } else if (g_hwnd && IsWindow(g_hwnd)) {
        POINT pt{};
        if (GetCursorPos(&pt) && ScreenToClient(g_hwnd, &pt))
            io.AddMousePosEvent((float)pt.x, (float)pt.y);
    }

    // Feed button edges into ImGui's event queue. Writing only io.MouseDown
    // is not sufficient with ImGui 1.89+: NewFrame consumes queued events and
    // can overwrite the legacy fields, which breaks IsMouseClicked and long
    // drags. This transition mirror makes sliders and HUD dragging reliable.
    const LONG gameButtons = InterlockedCompareExchange(&g_gameMouseButtons, 0, 0);
    for (int i = 0; i < 5; i++) {
        g_guiMousePressed[i] = false;
        g_guiMouseReleased[i] = false;
        const LONG bit = (LONG)(1u << i);
        const bool down = ((gameButtons & bit) != 0) || g_rawBtn[i] ||
                          (SampleAsyncKeyState(kBtnVk[i]) & 0x8000) != 0;
        if (owned) {
            if (menuChanged) {
                // A button held while INSERT opens the menu is not a GUI
                // click. Establish the baseline silently; only a new press
                // after the menu is open creates an ImGui edge.
                previousButtons[i] = down;
                g_guiMouseDown[i] = false;
                io.MouseDown[i] = false;
            } else {
                g_guiMousePressed[i] = down && !previousButtons[i];
                g_guiMouseReleased[i] = !down && previousButtons[i];
                if (g_guiMousePressed[i] || g_guiMouseReleased[i])
                    io.AddMouseButtonEvent(i, down);
                previousButtons[i] = down;
                g_guiMouseDown[i] = down;
                // Keep the legacy field synchronized as an additional
                // fallback for local HUD modules that read io.MouseDown.
                io.MouseDown[i] = down;
            }
        } else {
            previousButtons[i] = false;
            g_guiMouseDown[i] = down;
            io.MouseDown[i] = down;
        }
    }

    const float rawWheel = static_cast<float>(InterlockedExchange(&g_guiWheelTicks, 0));
    const float rawWheelH = static_cast<float>(InterlockedExchange(&g_guiWheelHTicks, 0));
    if (owned) {
        // Legacy WM_MOUSEWHEEL is swallowed while the menu is open. Prefer
        // MouseDevice::feed when it produced a notch, otherwise consume the
        // raw fallback; one physical wheel event must not be counted twice.
        const LONG wheelNow = InterlockedCompareExchange(&g_gameMouseWheel, 0, 0);
        const LONG wheelDelta = wheelNow - gameWheelSeen;
        if (wheelDelta != 0) {
            g_guiMouseWheel = static_cast<float>(wheelDelta);
            io.AddMouseWheelEvent(0.0f, g_guiMouseWheel);
        } else if (rawWheel != 0.0f || rawWheelH != 0.0f) {
            g_guiMouseWheel = rawWheel;
            g_guiMouseWheelH = rawWheelH;
            io.AddMouseWheelEvent(rawWheelH, rawWheel);
        }
        gameWheelSeen = wheelNow;
    } else if (!g_legacyWheelSeen && (rawWheel != 0.0f || rawWheelH != 0.0f)) {
        io.AddMouseWheelEvent(rawWheelH, rawWheel);
    }
}

void RegisterRawInput() {
    // Our OWN raw-input sink (not piggybacking on the game's registration,
    // which may not exist at all on the CoreDispatcher path). RIDEV_INPUTSINK
    // delivers WM_INPUT to our window even unfocused; we deliberately do NOT
    // set RIDEV_NOLEGACY, so the game's own input path is untouched.
    if (!g_hwnd || g_rawRegistered) return;
    RAWINPUTDEVICE rid[2] = {};
    rid[0].usUsagePage = 1; rid[0].usUsage = 6;  // keyboard
    rid[0].dwFlags = RIDEV_INPUTSINK;
    rid[0].hwndTarget = g_hwnd;
    rid[1].usUsagePage = 1; rid[1].usUsage = 2;  // mouse
    rid[1].dwFlags = RIDEV_INPUTSINK;
    rid[1].hwndTarget = g_hwnd;
    if (RegisterRawInputDevices(rid, 2, sizeof(RAWINPUTDEVICE))) {
        g_rawRegistered = true;
        LOG_INFO("overlay: raw input sink registered on %p", g_hwnd);
    } else {
        LOG_ERROR("overlay: RegisterRawInputDevices failed (err %lu)", GetLastError());
    }
}

void HookOneWindow(HWND h) {
    if (!h || !IsWindow(h)) return;
    if (h == g_hwnd && g_wndHooked) return;
    for (auto& s : g_subs) if (s.h == h) return;  // already hooked: rescan-safe
    WNDPROC o = (WNDPROC)SetWindowLongPtrW(h, GWLP_WNDPROC, (LONG_PTR)HookWndProc);
    if (!o) {
        LOG_ERROR("overlay: subclass %p failed (err %lu)", h, GetLastError());
        return;
    }
    wchar_t cls[64] = L"?";
    GetClassNameW(h, cls, 64);
    if (!g_wndHooked) {
        // First window: keeps the legacy role (backend + raw sink anchor).
        g_hwnd = h; g_origWnd = o; g_wndHooked = true;
        LOG_INFO("overlay: WndProc subclass installed on %p [%ls] (primary)", h, cls);
        RegisterRawInput();
    } else {
        g_subs.push_back({h, o});
        LOG_INFO("overlay: WndProc subclass installed on %p [%ls] (extra)", h, cls);
    }
}

BOOL CALLBACK HookChildCb(HWND h, LPARAM pid) {
    DWORD wpid = 0; GetWindowThreadProcessId(h, &wpid);
    if (wpid == (DWORD)pid) HookOneWindow(h);
    return TRUE;
}
BOOL CALLBACK HookTopCb(HWND h, LPARAM pid) {
    DWORD wpid = 0; GetWindowThreadProcessId(h, &wpid);
    if (wpid == (DWORD)pid) {
        HookOneWindow(h);
        EnumChildWindows(h, HookChildCb, pid);
    }
    return TRUE;
}
void ScanAndHookProcessWindows() {
    EnumWindows(HookTopCb, (LPARAM)GetCurrentProcessId());
}

void InstallWndHook(HWND hwnd) {
    if (!hwnd || !IsWindow(hwnd)) return;
    if (!g_hwnd) g_hwnd = hwnd;  // usable for the Win32 backend even if the subclass fails
    HookOneWindow(hwnd);       // primary: backend + raw sink anchor
    ScanAndHookProcessWindows();  // siblings/children: same swallow rule
}

void RestoreWndHook() {
    if (g_rawRegistered) {
        RAWINPUTDEVICE rid[2] = {};
        rid[0].usUsagePage = 1; rid[0].usUsage = 6; rid[0].dwFlags = RIDEV_REMOVE;
        rid[1].usUsagePage = 1; rid[1].usUsage = 2; rid[1].dwFlags = RIDEV_REMOVE;
        RegisterRawInputDevices(rid, 2, sizeof(RAWINPUTDEVICE));
        g_rawRegistered = false;
    }
    if (g_wndHooked && g_hwnd && IsWindow(g_hwnd) && g_origWnd) {
        SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)g_origWnd);
        LOG_INFO("overlay: WndProc restored");
    }
    for (auto& s : g_subs)
        if (s.h && IsWindow(s.h) && s.o)
            SetWindowLongPtrW(s.h, GWLP_WNDPROC, (LONG_PTR)s.o);
    if (!g_subs.empty())
        LOG_INFO("overlay: %u extra WndProcs restored", (unsigned)g_subs.size());
    g_subs.clear();
    g_wndHooked = false;
    g_origWnd = nullptr;
}

void ReleaseMenuMouseCapture() {
    // Release the clip through the original trampoline, not through our own
    // HkClipCursor. This is important when Bedrock had already clipped the
    // cursor before the GUI was opened.
    if (oClipCursor) oClipCursor(nullptr);
    else ClipCursor(nullptr);
    ReleaseCapture();

    // Capture can belong to the game's input thread, while Present runs on
    // the render thread. WM_CANCELMODE is delivered on the window thread and
    // makes that thread release its existing capture as vanilla ESC does.
    static unsigned pulse = 0;
    if (g_hwnd && IsWindow(g_hwnd) && ((pulse++ % 30u) == 0u || !g_cursorForced)) {
        DWORD_PTR ignored = 0;
        SendMessageTimeoutW(g_hwnd, WM_CANCELMODE, 0, 0,
                            SMTO_ABORTIFHUNG, 20, &ignored);
    }
}

void UpdateCursor() {
    // One cursor, one coordinate source: software cursor at ImGui's relative
    // MousePos. This is also the position consumed by clicks and MouseStrokes.
    ImGui::GetIO().MouseDrawCursor = UiInputOwned();
    if (!UiInputOwned()) {
        if (g_cursorForced) {
            // Restore the OS cursor counter changes made while the GUI owned it.
            while (g_hideBalance > 0) {
                if (oShowCursor) oShowCursor(TRUE);
                else ShowCursor(TRUE);
                --g_hideBalance;
            }
            ReleaseCapture();
            ClipCursor(nullptr);
            g_cursorForced = false;
        }
        return;
    }
    ReleaseMenuMouseCapture();
    if (!g_cursorForced) {
        g_cursorForced = true;
    }
    // Hide the hardware arrow with bounded original calls. Never warp it or
    // draw it together with ImGui's cursor; reverse exactly our own decrements
    // when the menu closes.
    for (int i = 0; i < 8 && g_hideBalance < 32; i++) {
        CURSORINFO ci{};
        ci.cbSize = sizeof(ci);
        if (GetCursorInfo(&ci) && (ci.flags & CURSOR_SHOWING) == 0) break;
        if (oShowCursor) oShowCursor(FALSE);
        else ShowCursor(FALSE);
        ++g_hideBalance;
    }
}

// Manual mouse feed for ImGui when the Win32 backend is unavailable (no
// window handle / backend init failed). Keyboard keeps working through the
// keys:: poll in all cases.
void PollMouseFallback() {
    ImGuiIO& io = ImGui::GetIO();
    POINT pt{};
    if (GetCursorPos(&pt)) {
        if (g_hwnd) ScreenToClient(g_hwnd, &pt);
        io.MousePos = ImVec2((float)pt.x, (float)pt.y);
    }
    io.MouseDown[0] = (SampleAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
    io.MouseDown[1] = (SampleAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;
    io.MouseDown[2] = (SampleAsyncKeyState(VK_MBUTTON) & 0x8000) != 0;
    io.MouseDown[3] = (SampleAsyncKeyState(VK_XBUTTON1) & 0x8000) != 0;
    io.MouseDown[4] = (SampleAsyncKeyState(VK_XBUTTON2) & 0x8000) != 0;
}

// ============================ saturation ============================
// Flarial HueChanger parity (module display name "Saturation"): a full-screen
// saturation filter applied to the GAME frame in the backbuffer BEFORE the
// ImGui overlay draws, so the Nightfull HUD/ClickGUI is never filtered - the
// same ordering as Flarial, where the D2D DrawImage pass runs before the ImGui
// content of the frame.
//
// The pixel math reproduces the Direct2D Saturation effect
// (CLSID_D2D1Saturation / D2D1_SATURATION_PROP_SATURATION), which
// interpolates the identity matrix toward the gray matrix by the factor s:
//   lum     = 0.2126*r + 0.7152*g + 0.0722*b      (Rec.709)
//   out.rgb = lum + (rgb - lum) * s               (s clamped to >= 0)
//   out.a   = a
// 0.0 = grayscale, 1.0 = unchanged, >1.0 = oversaturated, <0.0 = 0.
//
// Shape of the implementation:
//  * Runtime-compiled HLSL (d3dcompiler, SM 5.0 on both backends - no SM6 /
//    DXC), full-screen triangle from SV_VertexID (no vertex buffer), an exact
//    1:1 backbuffer copy sampled point/clamp. The VS inverts V (uv.y ->
//    1 - uv.y): NDC is Y-up while render-target textures are top-down (row 0
//    at the top), so the raw NDC-derived V would draw the whole frame upside
//    down - the flip is what keeps the copy 1:1 upright on both backends.
//  * D3D11: own copy texture + SRV/RTV; copy, draw, restore the backbuffer
//    RTV, then the pre-existing ImGui path runs unchanged.
//  * D3D12: own per-backbuffer copies, own tiny SRV + RTV heaps and own PSO.
//    The copy + draw are recorded into the same g_d12list before Close(), so
//    they travel through the untouched game-queue submit + fence flow. The
//    pass owns the frame's PRESENT->RENDER_TARGET transition. Object creation
//    (heaps, copies, root signature, PSO) happens only with the command list
//    CLOSED: RenderD3D12Frame calls SaturationReadyD3D12 (Ensure) before the
//    allocator/list Reset - never on an open list.
//  * Disabled = zero cost: no barrier, no copy, no draw, no descriptor heap
//    switch. Objects stay cached, so toggling never thrashes creation.
//  * Fail-closed with a retry: a shader compile / root signature / PSO /
//    texture / heap failure logs ONCE for that failure kind, arms a 5 s
//    cooldown (the pass stays inert and cheap while the cooldown holds) and
//    is then RETRIED - a device that was not ready on the first enable (the
//    common case for a module enabled from config before the first Present)
//    recovers on its own, instead of latching dead for the whole session and
//    forcing an OFF->ON re-toggle. The 'logged' flags reset when a retry
//    finally succeeds so a later failure logs again. Two failures stay
//    permanently latched instead: a multisampled backbuffer (structurally
//    unsupported - no shader can fix that) and a GPU fault via
//    SaturationGpuFault() (device removed: the pass must never touch the GPU
//    again this session).
//  * TeardownRender() releases everything (unload, swapchain change, resize,
//    device removed) AFTER waiting for D3D12 GPU idle (WaitGpuIdle12), so no
//    copy/heap is freed while the GPU may still reference it; objects are
//    rebuilt lazily on the next enabled frame. The device-removed latch stays
//    sticky across those resets; the creation-failure cooldown does not (a
//    teardown/reinit is exactly the recovery path it waits for).

// Module-facing state: the module thread writes, the render thread reads.
// Intensity travels as centi-units (0..300) so a plain atomic is enough.
volatile LONG g_saturationEnabled = 0;
volatile LONG g_saturationIntensityCm = 50;  // 0.50 - Flarial's default
// Sticky, session-permanent fail-closed: MSAA backbuffer (structurally
// unsupported) or a GPU fault via SaturationGpuFault().
volatile LONG g_saturationFailed = 0;
// Creation-failure cooldown (GetTickCount64 ms): while now < this value the
// pass reports "not enabled" and stays free. Replacing the old sticky latch
// on compile/object-creation failures is what lets a device that was not yet
// ready on the first enable recover by itself - the module no longer needs
// an OFF->ON re-toggle to start working.
volatile LONG64 g_saturationFailUntil = 0;
// One log line per failure kind; reset on a successful retry so the next
// failure is reported again instead of vanishing.
static bool g_satLogged11Objects = false;
static bool g_satLogged11Copy = false;
static bool g_satLogged12Pipeline = false;
static bool g_satLogged12Heaps = false;
static bool g_satLogged12Copy = false;

static LONG SaturationFlag(volatile LONG* flag) {
    return InterlockedCompareExchange(flag, 0, 0);
}

// Arms the creation-failure cooldown (render thread only).
static void SaturationArmCooldown() {
    InterlockedExchange64(&g_saturationFailUntil,
                          (LONG64)(GetTickCount64() + 5000));
}

static bool SaturationCoolingDown() {
    return (ULONGLONG)InterlockedCompareExchange64(&g_saturationFailUntil, 0, 0) >
           GetTickCount64();
}

// Effective intensity (the setter clamps already; clamp again defensively).
static float SaturationIntensity() {
    float v = (float)SaturationFlag(&g_saturationIntensityCm) / 100.0f;
    if (!(v >= 0.0f)) v = 0.0f;
    if (v > 3.0f) v = 3.0f;
    return v;
}

// Swapchains may report a TYPELESS backbuffer format: our copy texture, its
// SRV and the PSO need a concrete member of the same format family.
static DXGI_FORMAT SaturationConcreteFormat(DXGI_FORMAT fmt) {
    switch (fmt) {
        case DXGI_FORMAT_R8G8B8A8_TYPELESS:     return DXGI_FORMAT_R8G8B8A8_UNORM;
        case DXGI_FORMAT_B8G8R8A8_TYPELESS:     return DXGI_FORMAT_B8G8R8A8_UNORM;
        case DXGI_FORMAT_R10G10B10A2_TYPELESS:  return DXGI_FORMAT_R10G10B10A2_UNORM;
        case DXGI_FORMAT_R16G16B16A16_TYPELESS: return DXGI_FORMAT_R16G16B16A16_UNORM;
        default: return fmt;
    }
}

// HLSL shared by both backends.
static const char kSaturationHlsl[] = R"HLSL(
// Nightfull Saturation - Flarial HueChanger parity.
// Reproduces the Direct2D Saturation effect pixel math: interpolate toward
// the Rec.709 luma by the saturation factor.
cbuffer SaturationCb : register(b0) {
    float g_saturation;   // clamped intensity (>= 0)
    float3 g_satPad;
};

Texture2D g_scene : register(t0);
SamplerState g_sampler : register(s0);

struct SatVsOut {
    float4 pos : SV_POSITION;
    float2 uv  : TEXCOORD0;
};

// Full-screen triangle from SV_VertexID: no vertex buffer, no IA bindings.
SatVsOut SaturationVS(uint id : SV_VertexID) {
    SatVsOut o;
    float2 uv = float2((float)((id << 1) & 2), (float)(id & 2));
    // NDC is Y-up (-1 = bottom of the screen) while render-target textures
    // are top-down (row 0 = top): sampling with the raw NDC-derived V draws
    // the frame upside down, so invert V for a 1:1 upright image.
    o.uv  = float2(uv.x, 1.0f - uv.y);
    o.pos = float4(uv * 2.0f - 1.0f, 0.0f, 1.0f);
    return o;
}

float4 SaturationPS(float4 pos : SV_POSITION, float2 uv : TEXCOORD0) : SV_Target {
    float4 c = g_scene.Sample(g_sampler, uv);
    const float s   = max(0.0f, g_saturation);   // D2D clamps s to >= 0
    const float lum = dot(c.rgb, float3(0.2126f, 0.7152f, 0.0722f));
    return float4(lum + (c.rgb - lum) * s, c.a);
}
)HLSL";

// One-shot shader compilation. The caller arms the retry cooldown on failure;
// the compiler may not be ready on the very first enable (module enabled from
// config before the first Present), so compile failures are retried every 5 s
// while the module stays on. Log at most once per cooldown window per kind so
// a permanently broken shader cannot spam the log once per frame.
static bool SaturationCompile(const char* entry, const char* target,
                              const char* what, ID3DBlob** out) {
    ID3DBlob* err = nullptr;
    const HRESULT hr = D3DCompile(kSaturationHlsl, sizeof(kSaturationHlsl) - 1,
                                  nullptr, nullptr, nullptr, entry, target, 0, 0,
                                  out, &err);
    if (FAILED(hr) || !*out) {
        static ULONGLONG nextCompileLog = 0;
        const ULONGLONG now = GetTickCount64();
        if (now >= nextCompileLog) {
            nextCompileLog = now + 5000;
            LOG_ERROR("saturation: %s shader compile failed (%08X) - retry in 5 s",
                      what, (unsigned)hr);
            if (err && err->GetBufferPointer())
                LOG_ERROR("saturation: compiler says: %.300s", (const char*)err->GetBufferPointer());
        }
    }
    if (err) err->Release();
    return SUCCEEDED(hr) && *out != nullptr;
}

// ---- D3D11 objects (cached; built lazily, released by teardown) ----
static ID3D11VertexShader*       g_sat11Vs = nullptr;
static ID3D11PixelShader*        g_sat11Ps = nullptr;
static ID3D11Buffer*             g_sat11Cb = nullptr;
static ID3D11SamplerState*       g_sat11Sampler = nullptr;
static ID3D11RasterizerState*    g_sat11Rs = nullptr;
static ID3D11BlendState*         g_sat11Bs = nullptr;
static ID3D11DepthStencilState*  g_sat11Dss = nullptr;
static ID3D11Texture2D*          g_sat11Copy = nullptr;
static ID3D11ShaderResourceView* g_sat11Srv = nullptr;
static ID3D11RenderTargetView*   g_sat11Rtv = nullptr;
static UINT g_sat11W = 0, g_sat11H = 0;
static DXGI_FORMAT g_sat11Fmt = DXGI_FORMAT_UNKNOWN;

static void SaturationReleaseD3D11() {
    if (g_sat11Rtv) { g_sat11Rtv->Release(); g_sat11Rtv = nullptr; }
    if (g_sat11Srv) { g_sat11Srv->Release(); g_sat11Srv = nullptr; }
    if (g_sat11Copy) { g_sat11Copy->Release(); g_sat11Copy = nullptr; }
    if (g_sat11Dss) { g_sat11Dss->Release(); g_sat11Dss = nullptr; }
    if (g_sat11Bs) { g_sat11Bs->Release(); g_sat11Bs = nullptr; }
    if (g_sat11Rs) { g_sat11Rs->Release(); g_sat11Rs = nullptr; }
    if (g_sat11Sampler) { g_sat11Sampler->Release(); g_sat11Sampler = nullptr; }
    if (g_sat11Cb) { g_sat11Cb->Release(); g_sat11Cb = nullptr; }
    if (g_sat11Ps) { g_sat11Ps->Release(); g_sat11Ps = nullptr; }
    if (g_sat11Vs) { g_sat11Vs->Release(); g_sat11Vs = nullptr; }
    g_sat11W = 0; g_sat11H = 0; g_sat11Fmt = DXGI_FORMAT_UNKNOWN;
}

// Shaders, constant buffer, sampler and fixed-function state: built once.
static bool SaturationBuildShaders11() {
    if (g_sat11Vs && g_sat11Ps && g_sat11Cb && g_sat11Sampler &&
        g_sat11Rs && g_sat11Bs && g_sat11Dss)
        return true;
    ID3DBlob* vsBlob = nullptr;
    ID3DBlob* psBlob = nullptr;
    if (!SaturationCompile("SaturationVS", "vs_5_0", "vertex", &vsBlob)) {
        SaturationArmCooldown();
        return false;
    }
    if (!SaturationCompile("SaturationPS", "ps_5_0", "pixel", &psBlob)) {
        vsBlob->Release();
        SaturationArmCooldown();
        return false;
    }
    HRESULT hr = g_d11dev->CreateVertexShader(vsBlob->GetBufferPointer(),
                                              vsBlob->GetBufferSize(), nullptr, &g_sat11Vs);
    if (SUCCEEDED(hr))
        hr = g_d11dev->CreatePixelShader(psBlob->GetBufferPointer(),
                                         psBlob->GetBufferSize(), nullptr, &g_sat11Ps);
    vsBlob->Release();
    psBlob->Release();

    // 16-byte constant buffer: the intensity is rewritten every enabled frame.
    D3D11_BUFFER_DESC cbd{};
    cbd.ByteWidth = 16;
    cbd.Usage = D3D11_USAGE_DEFAULT;
    cbd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateBuffer(&cbd, nullptr, &g_sat11Cb);

    // Point/clamp: the copy is 1:1 with the backbuffer, so texel centers land
    // exactly on pixel centers.
    D3D11_SAMPLER_DESC sd{};
    sd.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
    sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    sd.ComparisonFunc = D3D11_COMPARISON_NEVER;
    sd.MaxLOD = D3D11_FLOAT32_MAX;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateSamplerState(&sd, &g_sat11Sampler);

    // The game may have left scissor/cull state behind: bind our own.
    D3D11_RASTERIZER_DESC rd{};
    rd.FillMode = D3D11_FILL_SOLID;
    rd.CullMode = D3D11_CULL_NONE;
    rd.DepthClipEnable = TRUE;
    rd.ScissorEnable = FALSE;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateRasterizerState(&rd, &g_sat11Rs);

    // Opaque replace: the filtered frame overwrites the backbuffer.
    D3D11_BLEND_DESC bld{};
    bld.RenderTarget[0].BlendEnable = FALSE;
    bld.RenderTarget[0].SrcBlend = D3D11_BLEND_ONE;
    bld.RenderTarget[0].DestBlend = D3D11_BLEND_ZERO;
    bld.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    bld.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
    bld.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
    bld.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    bld.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateBlendState(&bld, &g_sat11Bs);

    D3D11_DEPTH_STENCIL_DESC dd{};
    dd.DepthEnable = FALSE;
    dd.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
    dd.DepthFunc = D3D11_COMPARISON_ALWAYS;
    dd.StencilEnable = FALSE;
    dd.StencilReadMask = 0xFF;
    dd.StencilWriteMask = 0xFF;
    dd.FrontFace.StencilFailOp = dd.FrontFace.StencilDepthFailOp =
        dd.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
    dd.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
    dd.BackFace = dd.FrontFace;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateDepthStencilState(&dd, &g_sat11Dss);

    if (FAILED(hr)) {
        if (!g_satLogged11Objects) {
            g_satLogged11Objects = true;
            LOG_ERROR("saturation: d3d11 object creation failed (%08X) - cooldown 5 s",
                      (unsigned)hr);
        }
        SaturationReleaseD3D11();
        SaturationArmCooldown();
        return false;
    }
    // A retry succeeded: let the next creation failure log again.
    g_satLogged11Objects = false;
    return true;
}

// Size-dependent D3D11 objects: rebuilt whenever the backbuffer size, format
// or sample count changes (a ResizeBuffers already tears everything down; this
// is the belt-and-braces check the pass does every enabled frame).
static bool SaturationEnsure11(const D3D11_TEXTURE2D_DESC& bd) {
    if (bd.SampleDesc.Count != 1) {
        // Structurally unsupported: no amount of retrying fixes a multisampled
        // backbuffer, so this one stays permanently latched (the cooldown path
        // is for recoverable failures only).
        static bool logged = false;
        if (!logged) {
            logged = true;
            LOG_ERROR("saturation: multisampled backbuffer (%ux) unsupported - pass disabled",
                      bd.SampleDesc.Count);
        }
        InterlockedExchange(&g_saturationFailed, 1);
        return false;
    }
    if (!SaturationBuildShaders11()) return false;
    const DXGI_FORMAT fmt = SaturationConcreteFormat(bd.Format);
    if (g_sat11Copy && g_sat11Srv && g_sat11Rtv &&
        g_sat11W == bd.Width && g_sat11H == bd.Height && g_sat11Fmt == fmt)
        return true;

    if (g_sat11Rtv) { g_sat11Rtv->Release(); g_sat11Rtv = nullptr; }
    if (g_sat11Srv) { g_sat11Srv->Release(); g_sat11Srv = nullptr; }
    if (g_sat11Copy) { g_sat11Copy->Release(); g_sat11Copy = nullptr; }
    g_sat11W = g_sat11H = 0;
    g_sat11Fmt = DXGI_FORMAT_UNKNOWN;

    D3D11_TEXTURE2D_DESC cd = bd;
    cd.Format = fmt;
    cd.MipLevels = 1;
    cd.ArraySize = 1;
    cd.Usage = D3D11_USAGE_DEFAULT;
    cd.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;
    cd.CPUAccessFlags = 0;
    cd.MiscFlags = 0;
    HRESULT hr = g_d11dev->CreateTexture2D(&cd, nullptr, &g_sat11Copy);
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateShaderResourceView(g_sat11Copy, nullptr, &g_sat11Srv);
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateRenderTargetView(g_sat11Copy, nullptr, &g_sat11Rtv);
    if (FAILED(hr)) {
        if (!g_satLogged11Copy) {
            g_satLogged11Copy = true;
            LOG_ERROR("saturation: d3d11 %ux%u fmt=%d copy creation failed (%08X) - cooldown 5 s",
                      bd.Width, bd.Height, (int)fmt, (unsigned)hr);
        }
        if (g_sat11Rtv) { g_sat11Rtv->Release(); g_sat11Rtv = nullptr; }
        if (g_sat11Srv) { g_sat11Srv->Release(); g_sat11Srv = nullptr; }
        if (g_sat11Copy) { g_sat11Copy->Release(); g_sat11Copy = nullptr; }
        SaturationArmCooldown();
        return false;
    }
    // A retry succeeded: let the next copy failure log again.
    g_satLogged11Copy = false;
    g_sat11W = bd.Width;
    g_sat11H = bd.Height;
    g_sat11Fmt = fmt;
    return true;
}

// Cheapest possible gate: evaluated on every frame, causes no GPU work while
// the module is off (Flarial likewise only runs its pass inside the listener
// while the module is enabled). A creation-failure cooldown suppresses the
// pass until its retry window opens; the sticky g_saturationFailed latch
// (MSAA backbuffer / GPU fault) suppresses it for the whole session.
static bool SaturationEnabled() {
    if (SaturationFlag(&g_saturationEnabled) == 0) return false;
    if (SaturationFlag(&g_saturationFailed) != 0) return false;
    return !SaturationCoolingDown();
}

static bool SaturationReadyD3D11() {
    if (!SaturationEnabled()) return false;
    return g_d11dev != nullptr && g_d11ctx != nullptr && g_d11rtv != nullptr;
}

// One enabled D3D11 frame: copy the game frame, filter it back over the
// backbuffer, restore the state the ImGui path expects. The backbuffer is
// resolved from g_d11rtv every frame (never retained), so a resize or device
// reset can never leave a dangling reference behind.
static void SaturationApplyD3D11() {
    ID3D11Resource* res = nullptr;
    g_d11rtv->GetResource(&res);   // AddRef'd; returns void
    if (!res) return;
    ID3D11Texture2D* back = nullptr;
    const HRESULT qi = res->QueryInterface(__uuidof(ID3D11Texture2D), (void**)&back);
    res->Release();
    if (FAILED(qi) || !back) return;
    D3D11_TEXTURE2D_DESC bd{};
    back->GetDesc(&bd);
    if (!SaturationEnsure11(bd)) {
        back->Release();
        return;
    }

    // Bind our own RTV first: this releases the backbuffer RTV, so the copy
    // below reads a resource that is no longer a pipeline output.
    g_d11ctx->OMSetRenderTargets(1, &g_sat11Rtv, nullptr);
    g_d11ctx->CopyResource(g_sat11Copy, back);
    back->Release();
    back = nullptr;

    const float intensity = SaturationIntensity();
    g_d11ctx->UpdateSubresource(g_sat11Cb, 0, nullptr, &intensity, 0, 0);

    D3D11_VIEWPORT vp{};
    vp.Width = (FLOAT)bd.Width;
    vp.Height = (FLOAT)bd.Height;
    vp.MaxDepth = 1.0f;
    g_d11ctx->RSSetViewports(1, &vp);
    g_d11ctx->OMSetBlendState(g_sat11Bs, nullptr, 0xFFFFFFFF);
    g_d11ctx->OMSetDepthStencilState(g_sat11Dss, 0);
    g_d11ctx->RSSetState(g_sat11Rs);
    g_d11ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    g_d11ctx->VSSetShader(g_sat11Vs, nullptr, 0);
    g_d11ctx->PSSetShader(g_sat11Ps, nullptr, 0);
    g_d11ctx->PSSetConstantBuffers(0, 1, &g_sat11Cb);
    g_d11ctx->PSSetSamplers(0, 1, &g_sat11Sampler);
    g_d11ctx->PSSetShaderResources(0, 1, &g_sat11Srv);
    g_d11ctx->Draw(3, 0);
    // Unbind the copy SRV so the next frame's CopyResource into it is clean.
    ID3D11ShaderResourceView* noSrv = nullptr;
    g_d11ctx->PSSetShaderResources(0, 1, &noSrv);
    // Hand the backbuffer back for the unchanged ImGui path.
    g_d11ctx->OMSetRenderTargets(1, &g_d11rtv, nullptr);

    static bool logged = false;
    if (!logged) {
        logged = true;
        LOG_INFO("saturation: pass active (dx11, %ux%u, intensity=%.2f)",
                 bd.Width, bd.Height, intensity);
    }
}

// ---- D3D12 objects (own SRV + RTV heaps; the ImGui heap is untouched) ----
static ID3D12RootSignature*        g_sat12Rs = nullptr;
static ID3D12PipelineState*        g_sat12Pso = nullptr;
static ID3D12DescriptorHeap*       g_sat12SrvHeap = nullptr;
static ID3D12DescriptorHeap*       g_sat12RtvHeap = nullptr;
static ID3D12Resource*             g_sat12Copies[kMaxBuffers] = {};
static D3D12_GPU_DESCRIPTOR_HANDLE g_sat12SrvGpu[kMaxBuffers] = {};
static D3D12_CPU_DESCRIPTOR_HANDLE g_sat12RtvCpu[kMaxBuffers] = {};
static UINT g_sat12W = 0, g_sat12H = 0;
static DXGI_FORMAT g_sat12Fmt = DXGI_FORMAT_UNKNOWN;

static void SaturationReleaseD3D12() {
    for (int i = 0; i < kMaxBuffers; i++) {
        if (g_sat12Copies[i]) { g_sat12Copies[i]->Release(); g_sat12Copies[i] = nullptr; }
    }
    if (g_sat12RtvHeap) { g_sat12RtvHeap->Release(); g_sat12RtvHeap = nullptr; }
    if (g_sat12SrvHeap) { g_sat12SrvHeap->Release(); g_sat12SrvHeap = nullptr; }
    if (g_sat12Pso) { g_sat12Pso->Release(); g_sat12Pso = nullptr; }
    if (g_sat12Rs) { g_sat12Rs->Release(); g_sat12Rs = nullptr; }
    g_sat12W = 0; g_sat12H = 0; g_sat12Fmt = DXGI_FORMAT_UNKNOWN;
}

// GPU idle wait, shared with ReleaseD3D12()/TeardownRender(): nothing that a
// command list may still reference (saturation copies, backbuffers, heaps)
// may be released while GPU work can still be in flight - e.g. after a fence
// timeout the frame continues "unsynchronized". Cheap when already idle: the
// Signal completes immediately. Defined here so the saturation rebuild branch
// below can use it; ReleaseD3D12/TeardownRender are defined later.
static void WaitGpuIdle12() {
    if (!g_d12dev || !g_d12fence || !g_d12event) return;
    // Signal - and therefore wait on - the queue our frame command lists were
    // actually submitted to.
    //
    // Frames go to the GAME queue when it has been captured (same-queue submit
    // keeps our barriers ordered behind the game's own transitions). A Signal on
    // our private queue would then only prove OUR queue idle and would NOT wait
    // for the most recent frame, which matters now that the per-frame fence wait
    // moved to the top of the next frame: teardown can run while that last
    // submission is still in flight.
    ID3D12CommandQueue* q = g_gameQueue ? g_gameQueue : g_d12queue;
    if (!q) return;
    q->Signal(g_d12fence, ++g_d12fenceVal);
    g_d12fence->SetEventOnCompletion(g_d12fenceVal, g_d12event);
    WaitForSingleObject(g_d12event, 1000);
}

// Root signature (one SRV table + a 4-word root-constant block backing the
// 16-byte cbuffer SaturationCb - only word 0 (the intensity) is written, the
// padding words stay zero - so no driver ever sees an out-of-range root
// constant, + a static point/clamp sampler) and the PSO (SM 5.0, empty input
// layout: SV_VertexID only).
static bool SaturationBuildPipeline12() {
    if (g_sat12Rs && g_sat12Pso) return true;
    ID3DBlob* vsBlob = nullptr;
    ID3DBlob* psBlob = nullptr;
    if (!SaturationCompile("SaturationVS", "vs_5_0", "vertex", &vsBlob)) {
        SaturationArmCooldown();
        return false;
    }
    if (!SaturationCompile("SaturationPS", "ps_5_0", "pixel", &psBlob)) {
        vsBlob->Release();
        SaturationArmCooldown();
        return false;
    }

    D3D12_DESCRIPTOR_RANGE range{};
    range.RangeType = D3D12_DESCRIPTOR_RANGE_TYPE_SRV;
    range.NumDescriptors = 1;
    range.BaseShaderRegister = 0;
    D3D12_ROOT_PARAMETER params[2]{};
    params[0].ParameterType = D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
    params[0].ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;
    params[0].DescriptorTable.NumDescriptorRanges = 1;
    params[0].DescriptorTable.pDescriptorRanges = &range;
    params[1].ParameterType = D3D12_ROOT_PARAMETER_TYPE_32BIT_CONSTANTS;
    params[1].ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;
    params[1].Constants.ShaderRegister = 0;   // b0
    // 4 words = the full 16-byte cbuffer SaturationCb (float + float3): the
    // declaration must cover everything the shader's cbuffer binds, or the
    // access is out of range (driver-specific behavior). Word 0 is the only
    // one written per frame; unwritten root constants read as zero.
    params[1].Constants.Num32BitValues = 4;

    D3D12_STATIC_SAMPLER_DESC sampler{};
    sampler.Filter = D3D12_FILTER_MIN_MAG_MIP_POINT;
    sampler.AddressU = sampler.AddressV = sampler.AddressW = D3D12_TEXTURE_ADDRESS_MODE_CLAMP;
    sampler.ComparisonFunc = D3D12_COMPARISON_FUNC_NEVER;
    sampler.MaxLOD = D3D12_FLOAT32_MAX;
    sampler.ShaderRegister = 0;
    sampler.ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;

    D3D12_ROOT_SIGNATURE_DESC rsd{};
    rsd.NumParameters = 2;
    rsd.pParameters = params;
    rsd.NumStaticSamplers = 1;
    rsd.pStaticSamplers = &sampler;
    rsd.Flags = D3D12_ROOT_SIGNATURE_FLAG_NONE;

    ID3DBlob* sigBlob = nullptr;
    ID3DBlob* sigErr = nullptr;
    HRESULT hr = D3D12SerializeRootSignature(&rsd, D3D_ROOT_SIGNATURE_VERSION_1_0,
                                             &sigBlob, &sigErr);
    if (SUCCEEDED(hr) && sigBlob) {
        hr = g_d12dev->CreateRootSignature(0, sigBlob->GetBufferPointer(),
                                           sigBlob->GetBufferSize(),
                                           __uuidof(ID3D12RootSignature), (void**)&g_sat12Rs);
    } else {
        hr = E_FAIL;
    }
    if (sigErr) sigErr->Release();
    if (sigBlob) sigBlob->Release();
    if (FAILED(hr) || !g_sat12Rs) {
        if (!g_satLogged12Pipeline) {
            g_satLogged12Pipeline = true;
            LOG_ERROR("saturation: d3d12 root signature failed (%08X) - cooldown 5 s",
                      (unsigned)hr);
        }
        vsBlob->Release();
        psBlob->Release();
        SaturationReleaseD3D12();
        SaturationArmCooldown();
        return false;
    }

    if (!g_sat12Pso) {
        const DXGI_FORMAT fmt = g_sat12Fmt != DXGI_FORMAT_UNKNOWN
                                    ? g_sat12Fmt : DXGI_FORMAT_B8G8R8A8_UNORM;
        D3D12_GRAPHICS_PIPELINE_STATE_DESC pd{};
        pd.pRootSignature = g_sat12Rs;
        pd.VS.pShaderBytecode = vsBlob->GetBufferPointer();
        pd.VS.BytecodeLength = vsBlob->GetBufferSize();
        pd.PS.pShaderBytecode = psBlob->GetBufferPointer();
        pd.PS.BytecodeLength = psBlob->GetBufferSize();
        // Opaque, no blending, no depth, no culling: one full-screen triangle.
        pd.BlendState.RenderTarget[0].BlendEnable = FALSE;
        pd.BlendState.RenderTarget[0].SrcBlend = D3D12_BLEND_ONE;
        pd.BlendState.RenderTarget[0].DestBlend = D3D12_BLEND_ZERO;
        pd.BlendState.RenderTarget[0].BlendOp = D3D12_BLEND_OP_ADD;
        pd.BlendState.RenderTarget[0].SrcBlendAlpha = D3D12_BLEND_ONE;
        pd.BlendState.RenderTarget[0].DestBlendAlpha = D3D12_BLEND_ZERO;
        pd.BlendState.RenderTarget[0].BlendOpAlpha = D3D12_BLEND_OP_ADD;
        pd.BlendState.RenderTarget[0].RenderTargetWriteMask = D3D12_COLOR_WRITE_ENABLE_ALL;
        pd.SampleMask = UINT_MAX;
        pd.RasterizerState.FillMode = D3D12_FILL_MODE_SOLID;
        pd.RasterizerState.CullMode = D3D12_CULL_MODE_NONE;
        pd.RasterizerState.DepthClipEnable = TRUE;
        pd.DepthStencilState.DepthEnable = FALSE;
        pd.DepthStencilState.DepthWriteMask = D3D12_DEPTH_WRITE_MASK_ALL;
        pd.DepthStencilState.DepthFunc = D3D12_COMPARISON_FUNC_ALWAYS;
        pd.DepthStencilState.StencilEnable = FALSE;
        pd.DepthStencilState.FrontFace.StencilFailOp = D3D12_STENCIL_OP_KEEP;
        pd.DepthStencilState.FrontFace.StencilDepthFailOp = D3D12_STENCIL_OP_KEEP;
        pd.DepthStencilState.FrontFace.StencilPassOp = D3D12_STENCIL_OP_KEEP;
        pd.DepthStencilState.FrontFace.StencilFunc = D3D12_COMPARISON_FUNC_ALWAYS;
        pd.DepthStencilState.BackFace = pd.DepthStencilState.FrontFace;
        pd.PrimitiveTopologyType = D3D12_PRIMITIVE_TOPOLOGY_TYPE_TRIANGLE;
        pd.NumRenderTargets = 1;
        pd.RTVFormats[0] = fmt;
        pd.SampleDesc.Count = 1;
        hr = g_d12dev->CreateGraphicsPipelineState(&pd, __uuidof(ID3D12PipelineState),
                                                   (void**)&g_sat12Pso);
        if (FAILED(hr) || !g_sat12Pso) {
            if (!g_satLogged12Pipeline) {
                g_satLogged12Pipeline = true;
                LOG_ERROR("saturation: d3d12 pso creation failed (%08X) fmt=%d - cooldown 5 s",
                          (unsigned)hr, (int)fmt);
            }
            vsBlob->Release();
            psBlob->Release();
            SaturationReleaseD3D12();
            SaturationArmCooldown();
            return false;
        }
    }
    vsBlob->Release();
    psBlob->Release();
    // A retry succeeded: let the next pipeline failure log again.
    g_satLogged12Pipeline = false;
    return true;
}

// Lazy (re)build for the current backbuffer index. Called from
// RenderD3D12Frame BEFORE the allocator/list Reset, i.e. with the command
// list closed: object creation never happens on an open command list. False
// means "not usable this frame" - the caller then takes the completely
// untouched original path, so a failure can never leave a half-transitioned
// backbuffer behind.
static bool SaturationEnsureD3D12(int idx) {
    if (!g_d12dev || !g_d12list) return false;
    if (idx < 0 || idx >= g_d12bufCount || idx >= kMaxBuffers || !g_d12bufs[idx])
        return false;
    const D3D12_RESOURCE_DESC bd = g_d12bufs[idx]->GetDesc();
    const UINT w = (UINT)bd.Width;
    const UINT h = (UINT)bd.Height;
    if (bd.SampleDesc.Count != 1) {
        // Structurally unsupported: stays permanently latched (the cooldown
        // path is for recoverable failures only).
        static bool logged = false;
        if (!logged) {
            logged = true;
            LOG_ERROR("saturation: multisampled backbuffer (%ux) unsupported - pass disabled",
                      bd.SampleDesc.Count);
        }
        InterlockedExchange(&g_saturationFailed, 1);
        return false;
    }
    const DXGI_FORMAT fmt = SaturationConcreteFormat(bd.Format);
    if (g_sat12Rs && g_sat12Pso && g_sat12SrvHeap && g_sat12RtvHeap &&
        g_sat12Copies[idx] && g_sat12W == w && g_sat12H == h && g_sat12Fmt == fmt)
        return true;

    // The PSO is format-bound: drop it when the backbuffer format changed
    // (size changes are handled by the copy rebuild below).
    if (g_sat12Pso && g_sat12Fmt != DXGI_FORMAT_UNKNOWN && g_sat12Fmt != fmt) {
        g_sat12Pso->Release();
        g_sat12Pso = nullptr;
    }
    g_sat12Fmt = fmt;   // published before the build so the PSO picks it up
    if (!SaturationBuildPipeline12()) return false;

    if (!g_sat12SrvHeap) {
        D3D12_DESCRIPTOR_HEAP_DESC hd{};
        hd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
        hd.NumDescriptors = kMaxBuffers;
        hd.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
        if (FAILED(g_d12dev->CreateDescriptorHeap(&hd, __uuidof(ID3D12DescriptorHeap),
                                                  (void**)&g_sat12SrvHeap)) ||
            !g_sat12SrvHeap) {
            if (!g_satLogged12Heaps) {
                g_satLogged12Heaps = true;
                LOG_ERROR("saturation: d3d12 srv heap creation failed - cooldown 5 s");
            }
            SaturationReleaseD3D12();
            SaturationArmCooldown();
            return false;
        }
    }
    if (!g_sat12RtvHeap) {
        D3D12_DESCRIPTOR_HEAP_DESC hd{};
        hd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV;
        hd.NumDescriptors = kMaxBuffers;
        if (FAILED(g_d12dev->CreateDescriptorHeap(&hd, __uuidof(ID3D12DescriptorHeap),
                                                  (void**)&g_sat12RtvHeap)) ||
            !g_sat12RtvHeap) {
            if (!g_satLogged12Heaps) {
                g_satLogged12Heaps = true;
                LOG_ERROR("saturation: d3d12 rtv heap creation failed - cooldown 5 s");
            }
            SaturationReleaseD3D12();
            SaturationArmCooldown();
            return false;
        }
        const UINT rtvInc =
            g_d12dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
        D3D12_CPU_DESCRIPTOR_HANDLE h = g_sat12RtvHeap->GetCPUDescriptorHandleForHeapStart();
        for (int i = 0; i < kMaxBuffers; i++) {
            g_sat12RtvCpu[i] = h;
            h.ptr += rtvInc;
        }
    }

    if (!g_sat12Copies[idx] || g_sat12W != w || g_sat12H != h) {
        // Rare (size change): idle the GPU before releasing the old copies -
        // they may still be referenced by work the fence wait missed.
        WaitGpuIdle12();
        for (int i = 0; i < kMaxBuffers; i++) {
            if (g_sat12Copies[i]) { g_sat12Copies[i]->Release(); g_sat12Copies[i] = nullptr; }
        }
        const UINT srvInc =
            g_d12dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
        D3D12_CPU_DESCRIPTOR_HANDLE srvCpu = g_sat12SrvHeap->GetCPUDescriptorHandleForHeapStart();
        D3D12_GPU_DESCRIPTOR_HANDLE srvGpu = g_sat12SrvHeap->GetGPUDescriptorHandleForHeapStart();
        HRESULT hr = S_OK;
        for (int i = 0; i < g_d12bufCount; i++) {
            D3D12_HEAP_PROPERTIES hp{};
            hp.Type = D3D12_HEAP_TYPE_DEFAULT;
            D3D12_RESOURCE_DESC cd{};
            cd.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
            cd.Width = w;
            cd.Height = h;
            cd.DepthOrArraySize = 1;
            cd.MipLevels = 1;
            cd.Format = fmt;
            cd.SampleDesc.Count = 1;
            cd.Layout = D3D12_TEXTURE_LAYOUT_UNKNOWN;
            // PIXEL_SHADER_RESOURCE is implicit for a non-DENY texture; the
            // render-target flag keeps the copy usable as a normal target too.
            cd.Flags = D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET;
            // Created in COPY_DEST, and the pass always leaves it in
            // COPY_DEST after drawing: the barrier sequence below is therefore
            // identical on the very first frame and on every later frame.
            hr = g_d12dev->CreateCommittedResource(
                &hp, D3D12_HEAP_FLAG_NONE, &cd,
                D3D12_RESOURCE_STATE_COPY_DEST, nullptr,
                __uuidof(ID3D12Resource), (void**)&g_sat12Copies[i]);
            if (FAILED(hr) || !g_sat12Copies[i]) break;
            g_d12dev->CreateShaderResourceView(g_sat12Copies[i], nullptr, srvCpu);
            g_sat12SrvGpu[i] = srvGpu;
            // Own RTV heap: g_d12rtvHeap (ImGui's backbuffer RTVs) is only
            // read by index here, never reallocated or reused.
            g_d12dev->CreateRenderTargetView(g_d12bufs[i], nullptr, g_sat12RtvCpu[i]);
            srvCpu.ptr += srvInc;
            srvGpu.ptr += srvInc;
        }
        if (FAILED(hr)) {
            if (!g_satLogged12Copy) {
                g_satLogged12Copy = true;
                LOG_ERROR("saturation: d3d12 %ux%u fmt=%d copy creation failed (%08X) - cooldown 5 s",
                          w, h, (int)fmt, (unsigned)hr);
            }
            SaturationReleaseD3D12();
            SaturationArmCooldown();
            return false;
        }
    }

    g_sat12W = w;
    g_sat12H = h;
    g_sat12Fmt = fmt;
    // A retry succeeded: let the next heap/copy failure log again.
    g_satLogged12Heaps = false;
    g_satLogged12Copy = false;
    return true;
}

static bool SaturationReadyD3D12(int idx) {
    if (!SaturationEnabled()) return false;
    return SaturationEnsureD3D12(idx);
}

// Records one enabled D3D12 frame. The pass owns this frame's
// PRESENT->RENDER_TARGET transition, so the state the ImGui path and the
// closing RT->PRESENT barrier expect is restored exactly. Every command goes
// into the same g_d12list -> same game-queue submit, same fence, unchanged.
static void SaturationRecordD3D12(int idx) {
    const UINT w = g_sat12W;
    const UINT h = g_sat12H;
    D3D12_RESOURCE_BARRIER b{};
    b.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    b.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;

    // 1) backbuffer PRESENT -> COPY_SOURCE (the game's frame is already there)
    b.Transition.pResource = g_d12bufs[idx];
    b.Transition.StateBefore = D3D12_RESOURCE_STATE_PRESENT;
    b.Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
    g_d12list->ResourceBarrier(1, &b);

    // 2) copy the game frame out (destination already sits in COPY_DEST)
    D3D12_TEXTURE_COPY_LOCATION dst{};
    dst.pResource = g_sat12Copies[idx];
    dst.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
    dst.SubresourceIndex = 0;
    D3D12_TEXTURE_COPY_LOCATION src{};
    src.pResource = g_d12bufs[idx];
    src.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
    src.SubresourceIndex = 0;
    g_d12list->CopyTextureRegion(&dst, 0, 0, 0, &src, nullptr);

    // 3) the copy becomes the shader resource for the draw below
    b.Transition.pResource = g_sat12Copies[idx];
    b.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;
    b.Transition.StateAfter = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
    g_d12list->ResourceBarrier(1, &b);

    // 4) backbuffer COPY_SOURCE -> RENDER_TARGET: the write target, and the
    //    state the pre-existing ImGui flow assumes when it starts drawing.
    b.Transition.pResource = g_d12bufs[idx];
    b.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;
    b.Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET;
    g_d12list->ResourceBarrier(1, &b);

    // 5) own heap + own pipeline. The ImGui code below rebinds g_d12srvHeap,
    //    so descriptor-heap ownership is unchanged.
    ID3D12DescriptorHeap* heaps[] = { g_sat12SrvHeap };
    g_d12list->SetDescriptorHeaps(1, heaps);
    g_d12list->SetGraphicsRootSignature(g_sat12Rs);
    g_d12list->SetPipelineState(g_sat12Pso);
    g_d12list->SetGraphicsRootDescriptorTable(0, g_sat12SrvGpu[idx]);
    const float intensity = SaturationIntensity();
    UINT bits = 0;
    memcpy(&bits, &intensity, sizeof(bits));
    g_d12list->SetGraphicsRoot32BitConstant(1, bits, 0);
    D3D12_CPU_DESCRIPTOR_HANDLE rtv = g_sat12RtvCpu[idx];
    g_d12list->OMSetRenderTargets(1, &rtv, FALSE, nullptr);
    D3D12_VIEWPORT vp{};
    vp.Width = (FLOAT)w;
    vp.Height = (FLOAT)h;
    vp.MaxDepth = 1.0f;
    g_d12list->RSSetViewports(1, &vp);
    // D3D12 keeps the scissor test permanently active and the initial
    // per-command-list scissor state is undefined/empty: bind our own or the
    // draw may legally be clipped to nothing (D3D11 gates this behind
    // ScissorEnable, D3D12 does not).
    D3D12_RECT sr{};
    sr.right = (LONG)w;
    sr.bottom = (LONG)h;
    g_d12list->RSSetScissorRects(1, &sr);
    g_d12list->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    g_d12list->DrawInstanced(3, 1, 0, 0);

    // 6) back to COPY_DEST so the next frame copies in without a barrier.
    b.Transition.pResource = g_sat12Copies[idx];
    b.Transition.StateBefore = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
    b.Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_DEST;
    g_d12list->ResourceBarrier(1, &b);

    static bool logged = false;
    if (!logged) {
        logged = true;
        LOG_INFO("saturation: pass active (dx12, %ux%u, intensity=%.2f)",
                 w, h, intensity);
    }
}

// Releases every saturation object. Called from TeardownRender(), so unload,
// swapchain replacement, resize and device-removal all stay leak free and no
// dangling pointer survives FreeLibrary.
static void SaturationReleaseAll() {
    SaturationReleaseD3D11();
    SaturationReleaseD3D12();
    // g_saturationFailed stays latched on purpose (device removal / MSAA):
    // see the section header. The creation-failure cooldown is left alone - a
    // teardown is exactly the recovery the cooldown waits out.
}

// SetSaturationEnabled/SetSaturationIntensity/SaturationGpuFault are defined
// next to the other module-facing setters (after the anonymous namespace
// closes): a definition inside an anonymous namespace does not attach to the
// overlay.h declaration, so the module side would link against a symbol this
// TU never emits.

// ============================ motion blur ============================
// Frame-accumulation motion blur on the GAME frame, recorded after the
// saturation pass and before the UI blur / ImGui, so the Nightfull overlay is
// never smeared. Same discipline as saturation: runtime-compiled SM 5.0 HLSL,
// full-screen triangle, own objects, zero cost while disabled, fail-closed
// with a 5 s retry cooldown, sticky latch on MSAA / device removal.
//
//   out  = lerp(current, history, k)
//   Blend: history = out      (exponential trail)
//   Ghost: history = current  (previous frame only)
//
// k is the Intensity setting; with "FPS Independent" it is rescaled to
// k^(refFps * dt) so the trail keeps the same length in seconds at any frame
// rate. The history is (re)seeded from the current frame on enable, resize
// and after long stalls, so stale images never bleed in.
//
// D3D11: own current/history textures (SRV only), copies via CopyResource.
// D3D12: one current + one history texture (steady state
// PIXEL_SHADER_RESOURCE), own 2-descriptor SRV heap, own root signature +
// PSO; everything recorded into g_d12list, so it rides the unchanged
// game-queue submit + fence flow. Object creation only with the list closed
// (MotionBlurReadyD3D12 runs before the allocator/list Reset).

volatile LONG g_mbEnabled = 0;
volatile LONG g_mbIntensityPm = 550;   // permille, 0..950
volatile LONG g_mbMode = 0;            // 0 Blend, 1 Ghost
volatile LONG g_mbFpsIndependent = 1;
volatile LONG g_mbRefFps = 60;
volatile LONG g_mbResetReq = 1;        // drop the history on the next frame
volatile LONG g_mbFailed = 0;          // sticky: MSAA / device removed
volatile LONG64 g_mbFailUntil = 0;     // creation-failure cooldown
static bool g_mbHistValid = false;     // render thread only
static LARGE_INTEGER g_mbLastQpc = {};
static bool g_mbLogged11 = false;
static bool g_mbLogged12 = false;

static void MotionBlurArmCooldown() {
    InterlockedExchange64(&g_mbFailUntil, (LONG64)(GetTickCount64() + 5000));
}

static bool MotionBlurEnabled() {
    if (InterlockedCompareExchange(&g_mbEnabled, 0, 0) == 0) return false;
    if (InterlockedCompareExchange(&g_mbFailed, 0, 0) != 0) return false;
    return (ULONGLONG)InterlockedCompareExchange64(&g_mbFailUntil, 0, 0) <= GetTickCount64();
}

// Per-frame blend factor. Also consumes the reset request and reseeds the
// history after a stall (> 250 ms between blurred frames).
static float MotionBlurFactor() {
    LARGE_INTEGER now{}, freq{};
    QueryPerformanceCounter(&now);
    QueryPerformanceFrequency(&freq);
    double dt = 0.0;
    if (g_mbLastQpc.QuadPart != 0 && freq.QuadPart != 0)
        dt = (double)(now.QuadPart - g_mbLastQpc.QuadPart) / (double)freq.QuadPart;
    g_mbLastQpc = now;
    if (InterlockedExchange(&g_mbResetReq, 0) != 0) g_mbHistValid = false;
    if (dt > 0.25) g_mbHistValid = false;

    float k = (float)InterlockedCompareExchange(&g_mbIntensityPm, 0, 0) / 1000.0f;
    if (!(k >= 0.0f)) k = 0.0f;
    if (k > 0.95f) k = 0.95f;
    if (InterlockedCompareExchange(&g_mbFpsIndependent, 0, 0) != 0 && dt > 0.0 && k > 0.0f) {
        LONG ref = InterlockedCompareExchange(&g_mbRefFps, 0, 0);
        if (ref < 1) ref = 60;
        k = (float)std::pow((double)k, dt * (double)ref);
    }
    if (!(k >= 0.0f)) k = 0.0f;
    if (k > 0.98f) k = 0.98f;
    return k;
}

static int MotionBlurMode() {
    return InterlockedCompareExchange(&g_mbMode, 0, 0) == 1 ? 1 : 0;
}

static const char kMotionBlurHlsl[] = R"HLSL(
// Nightfull Motion Blur - frame accumulation.
cbuffer MotionBlurCb : register(b0) {
    float g_blend;      // weight of the history image (0..0.98)
    float3 g_mbPad;
};

Texture2D g_cur  : register(t0);
Texture2D g_hist : register(t1);
SamplerState g_sampler : register(s0);

struct MbVsOut {
    float4 pos : SV_POSITION;
    float2 uv  : TEXCOORD0;
};

MbVsOut MotionBlurVS(uint id : SV_VertexID) {
    MbVsOut o;
    float2 uv = float2((float)((id << 1) & 2), (float)(id & 2));
    o.uv  = float2(uv.x, 1.0f - uv.y);   // NDC Y-up vs top-down textures
    o.pos = float4(uv * 2.0f - 1.0f, 0.0f, 1.0f);
    return o;
}

float4 MotionBlurPS(float4 pos : SV_POSITION, float2 uv : TEXCOORD0) : SV_Target {
    const float4 c = g_cur.Sample(g_sampler, uv);
    const float4 h = g_hist.Sample(g_sampler, uv);
    return float4(lerp(c.rgb, h.rgb, saturate(g_blend)), c.a);
}
)HLSL";

static bool MotionBlurCompile(const char* entry, const char* target, ID3DBlob** out) {
    ID3DBlob* err = nullptr;
    const HRESULT hr = D3DCompile(kMotionBlurHlsl, sizeof(kMotionBlurHlsl) - 1,
                                  nullptr, nullptr, nullptr, entry, target, 0, 0,
                                  out, &err);
    if (FAILED(hr) || !*out) {
        static ULONGLONG nextLog = 0;
        const ULONGLONG now = GetTickCount64();
        if (now >= nextLog) {
            nextLog = now + 5000;
            LOG_ERROR("motionblur: %s compile failed (%08X) - retry in 5 s", entry, (unsigned)hr);
            if (err && err->GetBufferPointer())
                LOG_ERROR("motionblur: compiler says: %.300s", (const char*)err->GetBufferPointer());
        }
        if (*out) { (*out)->Release(); *out = nullptr; }
    }
    if (err) err->Release();
    return SUCCEEDED(hr) && *out != nullptr;
}

// ---- D3D11 ----
static ID3D11VertexShader*       g_mb11Vs = nullptr;
static ID3D11PixelShader*        g_mb11Ps = nullptr;
static ID3D11Buffer*             g_mb11Cb = nullptr;
static ID3D11SamplerState*       g_mb11Sampler = nullptr;
static ID3D11RasterizerState*    g_mb11Rs = nullptr;
static ID3D11BlendState*         g_mb11Bs = nullptr;
static ID3D11DepthStencilState*  g_mb11Dss = nullptr;
static ID3D11Texture2D*          g_mb11Cur = nullptr;
static ID3D11Texture2D*          g_mb11Hist = nullptr;
static ID3D11ShaderResourceView* g_mb11CurSrv = nullptr;
static ID3D11ShaderResourceView* g_mb11HistSrv = nullptr;
static UINT g_mb11W = 0, g_mb11H = 0;
static DXGI_FORMAT g_mb11Fmt = DXGI_FORMAT_UNKNOWN;

template <typename T> static void MbRelease(T*& p) { if (p) { p->Release(); p = nullptr; } }

static void MotionBlurReleaseTextures11() {
    MbRelease(g_mb11HistSrv); MbRelease(g_mb11CurSrv);
    MbRelease(g_mb11Hist); MbRelease(g_mb11Cur);
    g_mb11W = g_mb11H = 0; g_mb11Fmt = DXGI_FORMAT_UNKNOWN;
}

static void MotionBlurReleaseD3D11() {
    MotionBlurReleaseTextures11();
    MbRelease(g_mb11Dss); MbRelease(g_mb11Bs); MbRelease(g_mb11Rs);
    MbRelease(g_mb11Sampler); MbRelease(g_mb11Cb);
    MbRelease(g_mb11Ps); MbRelease(g_mb11Vs);
}

static bool MotionBlurBuildShaders11() {
    if (g_mb11Vs && g_mb11Ps && g_mb11Cb && g_mb11Sampler && g_mb11Rs && g_mb11Bs && g_mb11Dss)
        return true;
    MotionBlurReleaseD3D11();
    ID3DBlob* vsBlob = nullptr;
    ID3DBlob* psBlob = nullptr;
    if (!MotionBlurCompile("MotionBlurVS", "vs_5_0", &vsBlob)) { MotionBlurArmCooldown(); return false; }
    if (!MotionBlurCompile("MotionBlurPS", "ps_5_0", &psBlob)) {
        vsBlob->Release(); MotionBlurArmCooldown(); return false;
    }
    HRESULT hr = g_d11dev->CreateVertexShader(vsBlob->GetBufferPointer(), vsBlob->GetBufferSize(),
                                              nullptr, &g_mb11Vs);
    if (SUCCEEDED(hr))
        hr = g_d11dev->CreatePixelShader(psBlob->GetBufferPointer(), psBlob->GetBufferSize(),
                                         nullptr, &g_mb11Ps);
    vsBlob->Release();
    psBlob->Release();

    D3D11_BUFFER_DESC cbd{};
    cbd.ByteWidth = 16;
    cbd.Usage = D3D11_USAGE_DEFAULT;
    cbd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateBuffer(&cbd, nullptr, &g_mb11Cb);

    D3D11_SAMPLER_DESC sd{};
    sd.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
    sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    sd.ComparisonFunc = D3D11_COMPARISON_NEVER;
    sd.MaxLOD = D3D11_FLOAT32_MAX;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateSamplerState(&sd, &g_mb11Sampler);

    D3D11_RASTERIZER_DESC rd{};
    rd.FillMode = D3D11_FILL_SOLID;
    rd.CullMode = D3D11_CULL_NONE;
    rd.DepthClipEnable = TRUE;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateRasterizerState(&rd, &g_mb11Rs);

    D3D11_BLEND_DESC bld{};
    bld.RenderTarget[0].BlendEnable = FALSE;
    bld.RenderTarget[0].SrcBlend = D3D11_BLEND_ONE;
    bld.RenderTarget[0].DestBlend = D3D11_BLEND_ZERO;
    bld.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    bld.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
    bld.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
    bld.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    bld.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateBlendState(&bld, &g_mb11Bs);

    D3D11_DEPTH_STENCIL_DESC dd{};
    dd.DepthEnable = FALSE;
    dd.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
    dd.DepthFunc = D3D11_COMPARISON_ALWAYS;
    dd.StencilEnable = FALSE;
    dd.StencilReadMask = 0xFF;
    dd.StencilWriteMask = 0xFF;
    dd.FrontFace.StencilFailOp = dd.FrontFace.StencilDepthFailOp =
        dd.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
    dd.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
    dd.BackFace = dd.FrontFace;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateDepthStencilState(&dd, &g_mb11Dss);

    if (FAILED(hr)) {
        if (!g_mbLogged11) {
            g_mbLogged11 = true;
            LOG_ERROR("motionblur: d3d11 object creation failed (%08X) - cooldown 5 s", (unsigned)hr);
        }
        MotionBlurReleaseD3D11();
        MotionBlurArmCooldown();
        return false;
    }
    g_mbLogged11 = false;
    return true;
}

static bool MotionBlurEnsure11(const D3D11_TEXTURE2D_DESC& bd) {
    if (bd.SampleDesc.Count != 1) {
        static bool logged = false;
        if (!logged) {
            logged = true;
            LOG_ERROR("motionblur: multisampled backbuffer (%ux) unsupported - pass disabled",
                      bd.SampleDesc.Count);
        }
        InterlockedExchange(&g_mbFailed, 1);
        return false;
    }
    if (!MotionBlurBuildShaders11()) return false;
    const DXGI_FORMAT fmt = SaturationConcreteFormat(bd.Format);
    if (g_mb11Cur && g_mb11Hist && g_mb11CurSrv && g_mb11HistSrv &&
        g_mb11W == bd.Width && g_mb11H == bd.Height && g_mb11Fmt == fmt)
        return true;

    MotionBlurReleaseTextures11();
    g_mbHistValid = false;
    D3D11_TEXTURE2D_DESC cd = bd;
    cd.Format = fmt;
    cd.MipLevels = 1;
    cd.ArraySize = 1;
    cd.Usage = D3D11_USAGE_DEFAULT;
    cd.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    cd.CPUAccessFlags = 0;
    cd.MiscFlags = 0;
    HRESULT hr = g_d11dev->CreateTexture2D(&cd, nullptr, &g_mb11Cur);
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateTexture2D(&cd, nullptr, &g_mb11Hist);
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateShaderResourceView(g_mb11Cur, nullptr, &g_mb11CurSrv);
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateShaderResourceView(g_mb11Hist, nullptr, &g_mb11HistSrv);
    if (FAILED(hr)) {
        if (!g_mbLogged11) {
            g_mbLogged11 = true;
            LOG_ERROR("motionblur: d3d11 %ux%u fmt=%d texture creation failed (%08X) - cooldown 5 s",
                      bd.Width, bd.Height, (int)fmt, (unsigned)hr);
        }
        MotionBlurReleaseTextures11();
        MotionBlurArmCooldown();
        return false;
    }
    g_mbLogged11 = false;
    g_mb11W = bd.Width;
    g_mb11H = bd.Height;
    g_mb11Fmt = fmt;
    return true;
}

static bool MotionBlurReadyD3D11() {
    if (!MotionBlurEnabled()) return false;
    return g_d11dev != nullptr && g_d11ctx != nullptr && g_d11rtv != nullptr;
}

static void MotionBlurApplyD3D11() {
    ID3D11Resource* res = nullptr;
    g_d11rtv->GetResource(&res);
    if (!res) return;
    ID3D11Texture2D* back = nullptr;
    const HRESULT qi = res->QueryInterface(__uuidof(ID3D11Texture2D), (void**)&back);
    res->Release();
    if (FAILED(qi) || !back) return;
    D3D11_TEXTURE2D_DESC bd{};
    back->GetDesc(&bd);
    if (!MotionBlurEnsure11(bd)) { back->Release(); return; }

    const float k = MotionBlurFactor();
    // Unbind the backbuffer before reading it as a copy source.
    g_d11ctx->OMSetRenderTargets(0, nullptr, nullptr);
    if (!g_mbHistValid) {
        // Seed: history = this frame, output unchanged.
        g_d11ctx->CopyResource(g_mb11Hist, back);
        g_mbHistValid = true;
        back->Release();
        g_d11ctx->OMSetRenderTargets(1, &g_d11rtv, nullptr);
        return;
    }
    g_d11ctx->CopyResource(g_mb11Cur, back);

    const float cb[4] = { k, 0.0f, 0.0f, 0.0f };
    g_d11ctx->UpdateSubresource(g_mb11Cb, 0, nullptr, cb, 0, 0);
    g_d11ctx->OMSetRenderTargets(1, &g_d11rtv, nullptr);
    D3D11_VIEWPORT vp{};
    vp.Width = (FLOAT)bd.Width;
    vp.Height = (FLOAT)bd.Height;
    vp.MaxDepth = 1.0f;
    g_d11ctx->RSSetViewports(1, &vp);
    g_d11ctx->OMSetBlendState(g_mb11Bs, nullptr, 0xFFFFFFFF);
    g_d11ctx->OMSetDepthStencilState(g_mb11Dss, 0);
    g_d11ctx->RSSetState(g_mb11Rs);
    g_d11ctx->IASetInputLayout(nullptr);
    g_d11ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    g_d11ctx->VSSetShader(g_mb11Vs, nullptr, 0);
    g_d11ctx->GSSetShader(nullptr, nullptr, 0);
    g_d11ctx->HSSetShader(nullptr, nullptr, 0);
    g_d11ctx->DSSetShader(nullptr, nullptr, 0);
    g_d11ctx->PSSetShader(g_mb11Ps, nullptr, 0);
    g_d11ctx->PSSetConstantBuffers(0, 1, &g_mb11Cb);
    g_d11ctx->PSSetSamplers(0, 1, &g_mb11Sampler);
    ID3D11ShaderResourceView* srvs[2] = { g_mb11CurSrv, g_mb11HistSrv };
    g_d11ctx->PSSetShaderResources(0, 2, srvs);
    g_d11ctx->Draw(3, 0);
    ID3D11ShaderResourceView* noSrv[2] = { nullptr, nullptr };
    g_d11ctx->PSSetShaderResources(0, 2, noSrv);

    // History update, then hand the backbuffer back to the ImGui path.
    g_d11ctx->OMSetRenderTargets(0, nullptr, nullptr);
    if (MotionBlurMode() == 0) g_d11ctx->CopyResource(g_mb11Hist, back);
    else                       g_d11ctx->CopyResource(g_mb11Hist, g_mb11Cur);
    back->Release();
    g_d11ctx->OMSetRenderTargets(1, &g_d11rtv, nullptr);

    static bool logged = false;
    if (!logged) {
        logged = true;
        LOG_INFO("motionblur: pass active (dx11, %ux%u)", bd.Width, bd.Height);
    }
}

// ---- D3D12 ----
static ID3D12RootSignature*  g_mb12Rs = nullptr;
static ID3D12PipelineState*  g_mb12Pso = nullptr;
static ID3D12DescriptorHeap* g_mb12SrvHeap = nullptr;
static ID3D12Resource*       g_mb12Cur = nullptr;
static ID3D12Resource*       g_mb12Hist = nullptr;
static UINT g_mb12W = 0, g_mb12H = 0;
static DXGI_FORMAT g_mb12Fmt = DXGI_FORMAT_UNKNOWN;

static void MotionBlurReleaseD3D12() {
    MbRelease(g_mb12Hist); MbRelease(g_mb12Cur);
    MbRelease(g_mb12SrvHeap); MbRelease(g_mb12Pso); MbRelease(g_mb12Rs);
    g_mb12W = g_mb12H = 0; g_mb12Fmt = DXGI_FORMAT_UNKNOWN;
}

static bool MotionBlurBuildPipeline12(DXGI_FORMAT fmt) {
    if (g_mb12Rs && g_mb12Pso) return true;
    ID3DBlob* vsBlob = nullptr;
    ID3DBlob* psBlob = nullptr;
    if (!MotionBlurCompile("MotionBlurVS", "vs_5_0", &vsBlob)) { MotionBlurArmCooldown(); return false; }
    if (!MotionBlurCompile("MotionBlurPS", "ps_5_0", &psBlob)) {
        vsBlob->Release(); MotionBlurArmCooldown(); return false;
    }

    HRESULT hr = S_OK;
    if (!g_mb12Rs) {
        D3D12_DESCRIPTOR_RANGE range{};
        range.RangeType = D3D12_DESCRIPTOR_RANGE_TYPE_SRV;
        range.NumDescriptors = 2;               // t0 current, t1 history
        range.BaseShaderRegister = 0;
        D3D12_ROOT_PARAMETER params[2]{};
        params[0].ParameterType = D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
        params[0].ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;
        params[0].DescriptorTable.NumDescriptorRanges = 1;
        params[0].DescriptorTable.pDescriptorRanges = &range;
        params[1].ParameterType = D3D12_ROOT_PARAMETER_TYPE_32BIT_CONSTANTS;
        params[1].ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;
        params[1].Constants.ShaderRegister = 0;
        params[1].Constants.Num32BitValues = 4;  // full 16-byte cbuffer
        D3D12_STATIC_SAMPLER_DESC sampler{};
        sampler.Filter = D3D12_FILTER_MIN_MAG_MIP_POINT;
        sampler.AddressU = sampler.AddressV = sampler.AddressW = D3D12_TEXTURE_ADDRESS_MODE_CLAMP;
        sampler.ComparisonFunc = D3D12_COMPARISON_FUNC_NEVER;
        sampler.MaxLOD = D3D12_FLOAT32_MAX;
        sampler.ShaderRegister = 0;
        sampler.ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;
        D3D12_ROOT_SIGNATURE_DESC rsd{};
        rsd.NumParameters = 2;
        rsd.pParameters = params;
        rsd.NumStaticSamplers = 1;
        rsd.pStaticSamplers = &sampler;
        ID3DBlob* sigBlob = nullptr;
        ID3DBlob* sigErr = nullptr;
        hr = D3D12SerializeRootSignature(&rsd, D3D_ROOT_SIGNATURE_VERSION_1_0, &sigBlob, &sigErr);
        if (SUCCEEDED(hr) && sigBlob)
            hr = g_d12dev->CreateRootSignature(0, sigBlob->GetBufferPointer(), sigBlob->GetBufferSize(),
                                               __uuidof(ID3D12RootSignature), (void**)&g_mb12Rs);
        else
            hr = E_FAIL;
        if (sigErr) sigErr->Release();
        if (sigBlob) sigBlob->Release();
    }
    if (SUCCEEDED(hr) && g_mb12Rs && !g_mb12Pso) {
        D3D12_GRAPHICS_PIPELINE_STATE_DESC pd{};
        pd.pRootSignature = g_mb12Rs;
        pd.VS.pShaderBytecode = vsBlob->GetBufferPointer();
        pd.VS.BytecodeLength = vsBlob->GetBufferSize();
        pd.PS.pShaderBytecode = psBlob->GetBufferPointer();
        pd.PS.BytecodeLength = psBlob->GetBufferSize();
        pd.BlendState.RenderTarget[0].BlendEnable = FALSE;
        pd.BlendState.RenderTarget[0].SrcBlend = D3D12_BLEND_ONE;
        pd.BlendState.RenderTarget[0].DestBlend = D3D12_BLEND_ZERO;
        pd.BlendState.RenderTarget[0].BlendOp = D3D12_BLEND_OP_ADD;
        pd.BlendState.RenderTarget[0].SrcBlendAlpha = D3D12_BLEND_ONE;
        pd.BlendState.RenderTarget[0].DestBlendAlpha = D3D12_BLEND_ZERO;
        pd.BlendState.RenderTarget[0].BlendOpAlpha = D3D12_BLEND_OP_ADD;
        pd.BlendState.RenderTarget[0].LogicOp = D3D12_LOGIC_OP_NOOP;
        pd.BlendState.RenderTarget[0].RenderTargetWriteMask = D3D12_COLOR_WRITE_ENABLE_ALL;
        pd.SampleMask = UINT_MAX;
        pd.RasterizerState.FillMode = D3D12_FILL_MODE_SOLID;
        pd.RasterizerState.CullMode = D3D12_CULL_MODE_NONE;
        pd.RasterizerState.DepthClipEnable = TRUE;
        pd.DepthStencilState.DepthEnable = FALSE;
        pd.DepthStencilState.DepthWriteMask = D3D12_DEPTH_WRITE_MASK_ALL;
        pd.DepthStencilState.DepthFunc = D3D12_COMPARISON_FUNC_ALWAYS;
        pd.DepthStencilState.StencilEnable = FALSE;
        pd.DepthStencilState.FrontFace.StencilFailOp = D3D12_STENCIL_OP_KEEP;
        pd.DepthStencilState.FrontFace.StencilDepthFailOp = D3D12_STENCIL_OP_KEEP;
        pd.DepthStencilState.FrontFace.StencilPassOp = D3D12_STENCIL_OP_KEEP;
        pd.DepthStencilState.FrontFace.StencilFunc = D3D12_COMPARISON_FUNC_ALWAYS;
        pd.DepthStencilState.BackFace = pd.DepthStencilState.FrontFace;
        pd.PrimitiveTopologyType = D3D12_PRIMITIVE_TOPOLOGY_TYPE_TRIANGLE;
        pd.NumRenderTargets = 1;
        pd.RTVFormats[0] = fmt;
        pd.SampleDesc.Count = 1;
        hr = g_d12dev->CreateGraphicsPipelineState(&pd, __uuidof(ID3D12PipelineState),
                                                   (void**)&g_mb12Pso);
    }
    vsBlob->Release();
    psBlob->Release();
    if (FAILED(hr) || !g_mb12Rs || !g_mb12Pso) {
        if (!g_mbLogged12) {
            g_mbLogged12 = true;
            LOG_ERROR("motionblur: d3d12 pipeline creation failed (%08X) fmt=%d - cooldown 5 s",
                      (unsigned)hr, (int)fmt);
        }
        MotionBlurReleaseD3D12();
        MotionBlurArmCooldown();
        return false;
    }
    return true;
}

// Called with the command list CLOSED (before the allocator/list Reset).
static bool MotionBlurEnsureD3D12(int idx) {
    if (!g_d12dev || !g_d12list) return false;
    if (idx < 0 || idx >= g_d12bufCount || idx >= kMaxBuffers || !g_d12bufs[idx]) return false;
    const D3D12_RESOURCE_DESC bd = g_d12bufs[idx]->GetDesc();
    const UINT w = (UINT)bd.Width;
    const UINT h = (UINT)bd.Height;
    if (bd.SampleDesc.Count != 1) {
        static bool logged = false;
        if (!logged) {
            logged = true;
            LOG_ERROR("motionblur: multisampled backbuffer (%ux) unsupported - pass disabled",
                      bd.SampleDesc.Count);
        }
        InterlockedExchange(&g_mbFailed, 1);
        return false;
    }
    const DXGI_FORMAT fmt = SaturationConcreteFormat(bd.Format);
    if (g_mb12Rs && g_mb12Pso && g_mb12SrvHeap && g_mb12Cur && g_mb12Hist &&
        g_mb12W == w && g_mb12H == h && g_mb12Fmt == fmt)
        return true;

    // Format change: the PSO is format-bound.
    if (g_mb12Pso && g_mb12Fmt != DXGI_FORMAT_UNKNOWN && g_mb12Fmt != fmt) MbRelease(g_mb12Pso);
    if (!MotionBlurBuildPipeline12(fmt)) return false;

    if (!g_mb12SrvHeap) {
        D3D12_DESCRIPTOR_HEAP_DESC hd{};
        hd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
        hd.NumDescriptors = 2;
        hd.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
        if (FAILED(g_d12dev->CreateDescriptorHeap(&hd, __uuidof(ID3D12DescriptorHeap),
                                                  (void**)&g_mb12SrvHeap)) || !g_mb12SrvHeap) {
            if (!g_mbLogged12) {
                g_mbLogged12 = true;
                LOG_ERROR("motionblur: d3d12 srv heap creation failed - cooldown 5 s");
            }
            MotionBlurReleaseD3D12();
            MotionBlurArmCooldown();
            return false;
        }
    }

    if (!g_mb12Cur || !g_mb12Hist || g_mb12W != w || g_mb12H != h || g_mb12Fmt != fmt) {
        // Rare (first use / resize): idle the GPU before dropping old textures.
        WaitGpuIdle12();
        MbRelease(g_mb12Hist);
        MbRelease(g_mb12Cur);
        g_mbHistValid = false;
        D3D12_HEAP_PROPERTIES hp{};
        hp.Type = D3D12_HEAP_TYPE_DEFAULT;
        D3D12_RESOURCE_DESC cd{};
        cd.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
        cd.Width = w;
        cd.Height = h;
        cd.DepthOrArraySize = 1;
        cd.MipLevels = 1;
        cd.Format = fmt;
        cd.SampleDesc.Count = 1;
        cd.Layout = D3D12_TEXTURE_LAYOUT_UNKNOWN;
        cd.Flags = D3D12_RESOURCE_FLAG_NONE;
        // Steady state between frames: PIXEL_SHADER_RESOURCE.
        HRESULT hr = g_d12dev->CreateCommittedResource(
            &hp, D3D12_HEAP_FLAG_NONE, &cd, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, nullptr,
            __uuidof(ID3D12Resource), (void**)&g_mb12Cur);
        if (SUCCEEDED(hr))
            hr = g_d12dev->CreateCommittedResource(
                &hp, D3D12_HEAP_FLAG_NONE, &cd, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, nullptr,
                __uuidof(ID3D12Resource), (void**)&g_mb12Hist);
        if (FAILED(hr) || !g_mb12Cur || !g_mb12Hist) {
            if (!g_mbLogged12) {
                g_mbLogged12 = true;
                LOG_ERROR("motionblur: d3d12 %ux%u fmt=%d texture creation failed (%08X) - cooldown 5 s",
                          w, h, (int)fmt, (unsigned)hr);
            }
            MotionBlurReleaseD3D12();
            MotionBlurArmCooldown();
            return false;
        }
        const UINT inc = g_d12dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
        D3D12_CPU_DESCRIPTOR_HANDLE cpu = g_mb12SrvHeap->GetCPUDescriptorHandleForHeapStart();
        g_d12dev->CreateShaderResourceView(g_mb12Cur, nullptr, cpu);
        cpu.ptr += inc;
        g_d12dev->CreateShaderResourceView(g_mb12Hist, nullptr, cpu);
    }
    g_mb12W = w;
    g_mb12H = h;
    g_mb12Fmt = fmt;
    g_mbLogged12 = false;
    return true;
}

static bool MotionBlurReadyD3D12(int idx) {
    if (!MotionBlurEnabled()) return false;
    return MotionBlurEnsureD3D12(idx);
}

static void MbBarrier12(ID3D12Resource* r, D3D12_RESOURCE_STATES before,
                        D3D12_RESOURCE_STATES after) {
    D3D12_RESOURCE_BARRIER b{};
    b.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    b.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    b.Transition.pResource = r;
    b.Transition.StateBefore = before;
    b.Transition.StateAfter = after;
    g_d12list->ResourceBarrier(1, &b);
}

static void MbCopy12(ID3D12Resource* dstRes, ID3D12Resource* srcRes) {
    D3D12_TEXTURE_COPY_LOCATION dst{};
    dst.pResource = dstRes;
    dst.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
    D3D12_TEXTURE_COPY_LOCATION src{};
    src.pResource = srcRes;
    src.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
    g_d12list->CopyTextureRegion(&dst, 0, 0, 0, &src, nullptr);
}

// fromPresent = the backbuffer is still in PRESENT (saturation did not run);
// otherwise it is in RENDER_TARGET. Always leaves it in RENDER_TARGET.
static void MotionBlurRecordD3D12(int idx, bool fromPresent) {
    ID3D12Resource* bb = g_d12bufs[idx];
    const float k = MotionBlurFactor();
    const auto kPsr = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
    MbBarrier12(bb, fromPresent ? D3D12_RESOURCE_STATE_PRESENT : D3D12_RESOURCE_STATE_RENDER_TARGET,
                D3D12_RESOURCE_STATE_COPY_SOURCE);
    if (!g_mbHistValid) {
        MbBarrier12(g_mb12Hist, kPsr, D3D12_RESOURCE_STATE_COPY_DEST);
        MbCopy12(g_mb12Hist, bb);
        MbBarrier12(g_mb12Hist, D3D12_RESOURCE_STATE_COPY_DEST, kPsr);
        MbBarrier12(bb, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_RENDER_TARGET);
        g_mbHistValid = true;
        return;
    }
    MbBarrier12(g_mb12Cur, kPsr, D3D12_RESOURCE_STATE_COPY_DEST);
    MbCopy12(g_mb12Cur, bb);
    MbBarrier12(g_mb12Cur, D3D12_RESOURCE_STATE_COPY_DEST, kPsr);
    MbBarrier12(bb, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_RENDER_TARGET);

    ID3D12DescriptorHeap* heaps[] = { g_mb12SrvHeap };
    g_d12list->SetDescriptorHeaps(1, heaps);
    g_d12list->SetGraphicsRootSignature(g_mb12Rs);
    g_d12list->SetPipelineState(g_mb12Pso);
    g_d12list->SetGraphicsRootDescriptorTable(0, g_mb12SrvHeap->GetGPUDescriptorHandleForHeapStart());
    UINT bits[4] = {};
    std::memcpy(&bits[0], &k, sizeof(UINT));
    g_d12list->SetGraphicsRoot32BitConstants(1, 4, bits, 0);
    g_d12list->OMSetRenderTargets(1, &g_d12rtvs[idx], FALSE, nullptr);
    D3D12_VIEWPORT vp{};
    vp.Width = (FLOAT)g_mb12W;
    vp.Height = (FLOAT)g_mb12H;
    vp.MaxDepth = 1.0f;
    g_d12list->RSSetViewports(1, &vp);
    D3D12_RECT sr{};
    sr.right = (LONG)g_mb12W;
    sr.bottom = (LONG)g_mb12H;
    g_d12list->RSSetScissorRects(1, &sr);
    g_d12list->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    g_d12list->DrawInstanced(3, 1, 0, 0);

    // History update.
    MbBarrier12(g_mb12Hist, kPsr, D3D12_RESOURCE_STATE_COPY_DEST);
    if (MotionBlurMode() == 0) {
        MbBarrier12(bb, D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_COPY_SOURCE);
        MbCopy12(g_mb12Hist, bb);
        MbBarrier12(bb, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_RENDER_TARGET);
    } else {
        MbBarrier12(g_mb12Cur, kPsr, D3D12_RESOURCE_STATE_COPY_SOURCE);
        MbCopy12(g_mb12Hist, g_mb12Cur);
        MbBarrier12(g_mb12Cur, D3D12_RESOURCE_STATE_COPY_SOURCE, kPsr);
    }
    MbBarrier12(g_mb12Hist, D3D12_RESOURCE_STATE_COPY_DEST, kPsr);

    static bool logged = false;
    if (!logged) {
        logged = true;
        LOG_INFO("motionblur: pass active (dx12, %ux%u)", g_mb12W, g_mb12H);
    }
}

static void MotionBlurReleaseAll() {
    MotionBlurReleaseD3D11();
    MotionBlurReleaseD3D12();
    g_mbHistValid = false;
    g_mbLastQpc.QuadPart = 0;
}

// ============================ UI blur (white glass) ============================
// A real frosted-glass backdrop for the ClickGUI: while the GUI owns input the
// game frame is copied out, blurred with a separable Gaussian (two passes -
// horizontal then vertical - into ping-pong copies) and composited back over
// the frame from the vertical pass itself, with a white-glass tint and alpha
// blending. The menu then draws its translucent white window on top of the
// frosted frame.
//
// Shape mirrors the saturation pass on purpose: own textures/heaps/PSOs, full
// res, SM 5.0, no vertex buffer, same teardown discipline. Differences:
//  * linear-clamp sampler (the blur needs filtered taps);
//  * two intermediate copies (A = copy source, B = blur target) instead of one;
//  * the vertical pass renders INTO the backbuffer with SrcAlpha/InvSrcAlpha
//    blending, so the blur and the white-glass tint are one draw;
//  * D3D12 may REUSE g_sat12Copies[idx] as the horizontal-pass source when
//    saturation already copied the frame this frame (same queue, same frame,
//    so the state machine is exact).
//
// Zero cost while closed: the gate below is evaluated before any object
// creation, copy, barrier or draw, and nothing else touches these objects.
// Gate = the General "UI Blur" setting (SetUiBlurEnabled, pushed per frame
// from ApplyClientModules) AND a non-zero strength (SetUiBlurStrength, pushed
// from ui::Frame with the menu open animation - 1.0 in the HUD editor). The
// strength therefore also fades the glass in/out with the menu animation.

// Module-facing state (module/UI thread writes, render thread reads).
volatile LONG g_uiBlurEnabled = 0;
volatile LONG64 g_uiBlurStrength = 0;   // thousandths, 0..1000
volatile LONG g_uiBlurTintR = 1000;    // theme accent rgb, thousandths 0..1000
volatile LONG g_uiBlurTintG = 1000;
volatile LONG g_uiBlurTintB = 1000;

static bool UiBlurGate() {
    if (InterlockedCompareExchange(&g_uiBlurEnabled, 0, 0) == 0) return false;
    return InterlockedCompareExchange64(&g_uiBlurStrength, 0, 0) > 0;
}

static float UiBlurStrength() {
    float v = (float)((double)InterlockedCompareExchange64(&g_uiBlurStrength, 0, 0) / 1000.0);
    if (!(v >= 0.0f)) v = 0.0f;
    if (v > 1.0f) v = 1.0f;
    return v;
}

static void UiBlurTint(float& r, float& g, float& b) {
    r = (float)InterlockedCompareExchange(&g_uiBlurTintR, 0, 0) / 1000.0f;
    g = (float)InterlockedCompareExchange(&g_uiBlurTintG, 0, 0) / 1000.0f;
    b = (float)InterlockedCompareExchange(&g_uiBlurTintB, 0, 0) / 1000.0f;
}

// Fixed glass radius (px). sigma = max(8*0.333, 0.5) ~ 2.66; 6 taps + centre
// per axis reach the full radius - a strong frosted look without the cost of
// a wide kernel.
static constexpr float kBlurRadius = 8.0f;

static const char kBlurHlsl[] = R"HLSL(
// Nightfull UI blur - separable Gaussian + white-glass composite.
cbuffer BlurCb : register(b0) {
    float4 g_texel;   // xy = 1/width, 1/height; z = radius px; w = strength 0..1
    float4 g_tint;    // rgb = theme accent tint (0..1), a unused
};

Texture2D  g_scene  : register(t0);
SamplerState g_sampler : register(s0);   // linear clamp

struct BlurVsOut {
    float4 pos : SV_POSITION;
    float2 uv  : TEXCOORD0;
};

// Full-screen triangle from SV_VertexID: no vertex buffer, no IA bindings.
// V is inverted (NDC is Y-up, render-target textures are top-down) so the
// copy stays 1:1 upright - same convention as the saturation pass.
BlurVsOut BlurVS(uint id : SV_VertexID) {
    BlurVsOut o;
    float2 uv = float2((float)((id << 1) & 2), (float)(id & 2));
    o.uv  = float2(uv.x, 1.0f - uv.y);
    o.pos = float4(uv * 2.0f - 1.0f, 0.0f, 1.0f);
    return o;
}

// SystemDLC blur.fsh math: sigma = max(Radius*0.333, 0.5),
// stepSize = Radius*0.16666667, 6 taps + centre per axis.
float3 BlurDir(float2 uv, float2 dir) {
    const float radius  = max(g_texel.z, 1.0);
    const float sigma   = max(radius * 0.333, 0.5);
    const float stepSz  = radius * 0.16666667;
    float3 sum = g_scene.Sample(g_sampler, uv).rgb;
    float wsum = 1.0;
    [unroll] for (int i = 1; i <= 6; i++) {
        const float off = i * stepSz;
        const float w   = exp(-(off * off) / (2.0 * sigma * sigma));
        const float2 d  = dir * off * g_texel.xy;
        sum  += g_scene.Sample(g_sampler, uv + d).rgb * w;
        sum  += g_scene.Sample(g_sampler, uv - d).rgb * w;
        wsum += 2.0 * w;
    }
    return sum / wsum;
}

// Horizontal pass: writes the intermediate blur target, opaque.
float4 BlurHPS(float4 pos : SV_POSITION, float2 uv : TEXCOORD0) : SV_Target {
    return float4(BlurDir(uv, float2(1.0, 0.0)), 1.0);
}

// Vertical pass + final composite: blends the blurred frame over the game
// frame (SrcAlpha/InvSrcAlpha on the render target) with a theme-accent tint, so the
// the translucent accent menu window on top reads as tinted frosted glass.
float4 BlurVPS(float4 pos : SV_POSITION, float2 uv : TEXCOORD0) : SV_Target {
    const float strength = g_texel.w;
    const float3 blur = BlurDir(uv, float2(0.0, 1.0));
    const float3 glass = lerp(blur, g_tint.rgb, 0.38 * strength);
    return float4(glass, 0.16 * strength);
}
)HLSL";

// One-shot shader compilation. Rate-limited to one line per 5 s: the pass is
// retried while the GUI stays open, so a permanently broken shader must not
// spam the log once per frame.
static bool UiBlurCompile(const char* entry, const char* target,
                          const char* what, ID3DBlob** out) {
    ID3DBlob* err = nullptr;
    const HRESULT hr = D3DCompile(kBlurHlsl, sizeof(kBlurHlsl) - 1,
                                  nullptr, nullptr, nullptr, entry, target, 0, 0,
                                  out, &err);
    if (FAILED(hr) || !*out) {
        static ULONGLONG nextLog = 0;
        const ULONGLONG now = GetTickCount64();
        if (now >= nextLog) {
            nextLog = now + 5000;
            LOG_ERROR("blur: %s shader compile failed (%08X) - retry in 5 s",
                      what, (unsigned)hr);
            if (err && err->GetBufferPointer())
                LOG_ERROR("blur: compiler says: %.300s", (const char*)err->GetBufferPointer());
        }
    }
    if (err) err->Release();
    return SUCCEEDED(hr) && *out != nullptr;
}

// ---- D3D11 objects (cached; built lazily, released by teardown) ----
static ID3D11VertexShader*       g_blur11Vs = nullptr;
static ID3D11PixelShader*        g_blur11PsH = nullptr;
static ID3D11PixelShader*        g_blur11PsV = nullptr;
static ID3D11Buffer*             g_blur11Cb = nullptr;
static ID3D11SamplerState*       g_blur11Sampler = nullptr;
static ID3D11RasterizerState*    g_blur11Rs = nullptr;
static ID3D11BlendState*         g_blur11BsCopy = nullptr;   // H pass: replace
static ID3D11BlendState*         g_blur11BsGlass = nullptr;  // V pass: blend
static ID3D11DepthStencilState*  g_blur11Dss = nullptr;
static ID3D11Texture2D*          g_blur11Tex[2] = {};        // A/B ping-pong
static ID3D11ShaderResourceView* g_blur11Srv[2] = {};
static ID3D11RenderTargetView*   g_blur11Rtv[2] = {};
static UINT g_blur11W = 0, g_blur11H = 0;
// Size of the half-resolution ping-pong target B. A has to stay at the
// backbuffer's resolution because it is the CopyResource destination; B is only
// ever sampled through a linear filter, so it can run at half size - which is
// what makes the horizontal pass shade a quarter of the pixels for the same
// on-screen blur radius.
static UINT g_blur11Bw = 0, g_blur11Bh = 0;
static DXGI_FORMAT g_blur11Fmt = DXGI_FORMAT_UNKNOWN;

static void UiBlurReleaseD3D11() {
    for (int i = 0; i < 2; i++) {
        if (g_blur11Rtv[i]) { g_blur11Rtv[i]->Release(); g_blur11Rtv[i] = nullptr; }
        if (g_blur11Srv[i]) { g_blur11Srv[i]->Release(); g_blur11Srv[i] = nullptr; }
        if (g_blur11Tex[i]) { g_blur11Tex[i]->Release(); g_blur11Tex[i] = nullptr; }
    }
    if (g_blur11Dss) { g_blur11Dss->Release(); g_blur11Dss = nullptr; }
    if (g_blur11BsGlass) { g_blur11BsGlass->Release(); g_blur11BsGlass = nullptr; }
    if (g_blur11BsCopy) { g_blur11BsCopy->Release(); g_blur11BsCopy = nullptr; }
    if (g_blur11Rs) { g_blur11Rs->Release(); g_blur11Rs = nullptr; }
    if (g_blur11Sampler) { g_blur11Sampler->Release(); g_blur11Sampler = nullptr; }
    if (g_blur11Cb) { g_blur11Cb->Release(); g_blur11Cb = nullptr; }
    if (g_blur11PsV) { g_blur11PsV->Release(); g_blur11PsV = nullptr; }
    if (g_blur11PsH) { g_blur11PsH->Release(); g_blur11PsH = nullptr; }
    if (g_blur11Vs) { g_blur11Vs->Release(); g_blur11Vs = nullptr; }
    g_blur11W = 0; g_blur11H = 0; g_blur11Bw = 0; g_blur11Bh = 0;
    g_blur11Fmt = DXGI_FORMAT_UNKNOWN;
}

// Shaders, cbuffer, sampler and fixed-function state: built once.
static bool UiBlurBuildShaders11() {
    if (g_blur11Vs && g_blur11PsH && g_blur11PsV && g_blur11Cb && g_blur11Sampler &&
        g_blur11Rs && g_blur11BsCopy && g_blur11BsGlass && g_blur11Dss)
        return true;
    ID3DBlob* vsBlob = nullptr;
    ID3DBlob* psH = nullptr;
    ID3DBlob* psV = nullptr;
    if (!UiBlurCompile("BlurVS", "vs_5_0", "vertex", &vsBlob)) return false;
    if (!UiBlurCompile("BlurHPS", "ps_5_0", "horizontal", &psH)) {
        vsBlob->Release();
        return false;
    }
    if (!UiBlurCompile("BlurVPS", "ps_5_0", "vertical", &psV)) {
        vsBlob->Release();
        psH->Release();
        return false;
    }
    HRESULT hr = g_d11dev->CreateVertexShader(vsBlob->GetBufferPointer(),
                                             vsBlob->GetBufferSize(), nullptr, &g_blur11Vs);
    if (SUCCEEDED(hr))
        hr = g_d11dev->CreatePixelShader(psH->GetBufferPointer(),
                                         psH->GetBufferSize(), nullptr, &g_blur11PsH);
    if (SUCCEEDED(hr))
        hr = g_d11dev->CreatePixelShader(psV->GetBufferPointer(),
                                         psV->GetBufferSize(), nullptr, &g_blur11PsV);
    vsBlob->Release();
    psH->Release();
    psV->Release();

    // 32-byte constant buffer: float4 texel + float4 tint, rewritten each frame.
    D3D11_BUFFER_DESC cbd{};
    cbd.ByteWidth = 32;
    cbd.Usage = D3D11_USAGE_DEFAULT;
    cbd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateBuffer(&cbd, nullptr, &g_blur11Cb);

    // Linear/clamp: the blur reads between texels by design.
    D3D11_SAMPLER_DESC sd{};
    sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
    sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    sd.ComparisonFunc = D3D11_COMPARISON_NEVER;
    sd.MaxLOD = D3D11_FLOAT32_MAX;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateSamplerState(&sd, &g_blur11Sampler);

    D3D11_RASTERIZER_DESC rd{};
    rd.FillMode = D3D11_FILL_SOLID;
    rd.CullMode = D3D11_CULL_NONE;
    rd.DepthClipEnable = TRUE;
    rd.ScissorEnable = FALSE;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateRasterizerState(&rd, &g_blur11Rs);

    // H pass: opaque replace into the intermediate target.
    D3D11_BLEND_DESC bldCopy{};
    bldCopy.RenderTarget[0].BlendEnable = FALSE;
    bldCopy.RenderTarget[0].SrcBlend = D3D11_BLEND_ONE;
    bldCopy.RenderTarget[0].DestBlend = D3D11_BLEND_ZERO;
    bldCopy.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    bldCopy.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
    bldCopy.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
    bldCopy.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    bldCopy.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateBlendState(&bldCopy, &g_blur11BsCopy);

    // V pass (the glass composite): blurred * alpha + dst * (1 - alpha).
    D3D11_BLEND_DESC bldGlass = bldCopy;
    bldGlass.RenderTarget[0].BlendEnable = TRUE;
    bldGlass.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
    bldGlass.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
    bldGlass.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    bldGlass.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
    bldGlass.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
    bldGlass.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateBlendState(&bldGlass, &g_blur11BsGlass);

    D3D11_DEPTH_STENCIL_DESC dd{};
    dd.DepthEnable = FALSE;
    dd.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
    dd.DepthFunc = D3D11_COMPARISON_ALWAYS;
    dd.StencilEnable = FALSE;
    dd.StencilReadMask = 0xFF;
    dd.StencilWriteMask = 0xFF;
    dd.FrontFace.StencilFailOp = dd.FrontFace.StencilDepthFailOp =
        dd.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
    dd.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
    dd.BackFace = dd.FrontFace;
    if (SUCCEEDED(hr)) hr = g_d11dev->CreateDepthStencilState(&dd, &g_blur11Dss);

    if (FAILED(hr)) {
        static bool logged = false;
        if (!logged) {
            logged = true;
            LOG_ERROR("blur: d3d11 object creation failed (%08X)", (unsigned)hr);
        }
        UiBlurReleaseD3D11();
        return false;
    }
    return true;
}

// Size-dependent D3D11 objects: rebuilt whenever the backbuffer size or
// format changes (a ResizeBuffers already tears everything down).
static bool UiBlurEnsure11(const D3D11_TEXTURE2D_DESC& bd) {
    if (bd.SampleDesc.Count != 1) {
        // Blurring an MSAA frame needs a resolve step this pass does not do;
        // silently skip (logged once) rather than latching - the user can
        // change the sample count and retry any session.
        static bool logged = false;
        if (!logged) {
            logged = true;
            LOG_INFO("blur: multisampled backbuffer (%ux) - glass disabled",
                     bd.SampleDesc.Count);
        }
        return false;
    }
    if (!UiBlurBuildShaders11()) return false;
    const DXGI_FORMAT fmt = SaturationConcreteFormat(bd.Format);
    // Half-resolution B: the horizontal pass shades a quarter of the pixels it
    // used to, and the vertical pass reads B back through the linear sampler,
    // so the on-screen blur radius is unchanged. A stays at the backbuffer's
    // resolution because it is the CopyResource destination and must match it.
    const UINT bw = bd.Width  > 1 ? bd.Width  / 2 : 1;
    const UINT bh = bd.Height > 1 ? bd.Height / 2 : 1;
    if (g_blur11Tex[0] && g_blur11Tex[1] && g_blur11Srv[0] && g_blur11Srv[1] &&
        g_blur11Rtv[0] && g_blur11Rtv[1] &&
        g_blur11W == bd.Width && g_blur11H == bd.Height &&
        g_blur11Bw == bw && g_blur11Bh == bh && g_blur11Fmt == fmt)
        return true;

    for (int i = 0; i < 2; i++) {
        if (g_blur11Rtv[i]) { g_blur11Rtv[i]->Release(); g_blur11Rtv[i] = nullptr; }
        if (g_blur11Srv[i]) { g_blur11Srv[i]->Release(); g_blur11Srv[i] = nullptr; }
        if (g_blur11Tex[i]) { g_blur11Tex[i]->Release(); g_blur11Tex[i] = nullptr; }
    }
    g_blur11W = g_blur11H = 0;
    g_blur11Bw = g_blur11Bh = 0;
    g_blur11Fmt = DXGI_FORMAT_UNKNOWN;

    D3D11_TEXTURE2D_DESC cd = bd;
    cd.Format = fmt;
    cd.MipLevels = 1;
    cd.ArraySize = 1;
    cd.Usage = D3D11_USAGE_DEFAULT;
    cd.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;
    cd.CPUAccessFlags = 0;
    cd.MiscFlags = 0;
    HRESULT hr = S_OK;
    for (int i = 0; i < 2 && SUCCEEDED(hr); i++) {
        if (i == 1) { cd.Width = bw; cd.Height = bh; }   // B: half-res intermediate
        hr = g_d11dev->CreateTexture2D(&cd, nullptr, &g_blur11Tex[i]);
        if (SUCCEEDED(hr)) hr = g_d11dev->CreateShaderResourceView(g_blur11Tex[i], nullptr, &g_blur11Srv[i]);
        if (SUCCEEDED(hr)) hr = g_d11dev->CreateRenderTargetView(g_blur11Tex[i], nullptr, &g_blur11Rtv[i]);
    }
    if (FAILED(hr)) {
        static bool logged = false;
        if (!logged) {
            logged = true;
            LOG_ERROR("blur: d3d11 %ux%u fmt=%d ping-pong creation failed (%08X)",
                      bd.Width, bd.Height, (int)fmt, (unsigned)hr);
        }
        UiBlurReleaseD3D11();
        return false;
    }
    g_blur11W = bd.Width;
    g_blur11H = bd.Height;
    g_blur11Bw = bw;
    g_blur11Bh = bh;
    g_blur11Fmt = fmt;
    return true;
}

static bool UiBlurReadyD3D11() {
    if (!UiBlurGate()) return false;
    return g_d11dev != nullptr && g_d11ctx != nullptr && g_d11rtv != nullptr;
}

// One active D3D11 frame: copy the game frame into A, blur A->B horizontally,
// then blur B vertically INTO the backbuffer with the glass blend. The game
// frame is copied through our own A: the blur needs a filtered source while
// the backbuffer may still be a resolved/MSAA surface.
static void UiBlurApplyD3D11() {
    ID3D11Resource* res = nullptr;
    g_d11rtv->GetResource(&res);   // AddRef'd; returns void
    if (!res) return;
    ID3D11Texture2D* back = nullptr;
    const HRESULT qi = res->QueryInterface(__uuidof(ID3D11Texture2D), (void**)&back);
    res->Release();
    if (FAILED(qi) || !back) return;
    D3D11_TEXTURE2D_DESC bd{};
    back->GetDesc(&bd);
    if (!UiBlurEnsure11(bd)) {
        back->Release();
        return;
    }

    float tr, tg, tb; UiBlurTint(tr, tg, tb);
    const float cb[8] = { 1.0f / (float)bd.Width, 1.0f / (float)bd.Height,
                          kBlurRadius, UiBlurStrength(), tr, tg, tb, 0.0f };
    g_d11ctx->UpdateSubresource(g_blur11Cb, 0, nullptr, cb, 0, 0);

    // Bind A's RTV first: this releases the backbuffer RTV, so the copy below
    // reads a resource that is no longer a pipeline output.
    g_d11ctx->OMSetRenderTargets(1, &g_blur11Rtv[0], nullptr);
    g_d11ctx->CopyResource(g_blur11Tex[0], back);
    back->Release();
    back = nullptr;

    D3D11_VIEWPORT vp{};
    vp.MaxDepth = 1.0f;
    g_d11ctx->OMSetDepthStencilState(g_blur11Dss, 0);
    g_d11ctx->RSSetState(g_blur11Rs);
    g_d11ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    g_d11ctx->VSSetShader(g_blur11Vs, nullptr, 0);
    g_d11ctx->PSSetConstantBuffers(0, 1, &g_blur11Cb);
    g_d11ctx->PSSetSamplers(0, 1, &g_blur11Sampler);

    // Horizontal: A -> B (opaque replace). B is half resolution, so the
    // viewport covers g_blur11Bw x g_blur11Bh. The constant buffer keeps the
    // *full-resolution* texel size: the shader turns the pixel radius into a
    // UV offset, so the on-screen blur stays 8 px wide regardless of which
    // resolution each pass runs at.
    vp.Width = (FLOAT)g_blur11Bw;
    vp.Height = (FLOAT)g_blur11Bh;
    g_d11ctx->RSSetViewports(1, &vp);
    g_d11ctx->OMSetRenderTargets(1, &g_blur11Rtv[1], nullptr);
    g_d11ctx->OMSetBlendState(g_blur11BsCopy, nullptr, 0xFFFFFFFF);
    g_d11ctx->PSSetShader(g_blur11PsH, nullptr, 0);
    g_d11ctx->PSSetShaderResources(0, 1, &g_blur11Srv[0]);
    g_d11ctx->Draw(3, 0);

    // Vertical + glass composite: B -> backbuffer, back at full resolution. B
    // stops being a target (the RTV switch below) before it becomes a shader
    // resource.
    vp.Width = (FLOAT)bd.Width;
    vp.Height = (FLOAT)bd.Height;
    g_d11ctx->RSSetViewports(1, &vp);
    g_d11ctx->OMSetRenderTargets(1, &g_d11rtv, nullptr);
    g_d11ctx->OMSetBlendState(g_blur11BsGlass, nullptr, 0xFFFFFFFF);
    g_d11ctx->PSSetShader(g_blur11PsV, nullptr, 0);
    g_d11ctx->PSSetShaderResources(0, 1, &g_blur11Srv[1]);
    g_d11ctx->Draw(3, 0);

    // Leave the pipeline as the ImGui path expects: backbuffer bound (already
    // set above), nothing left bound as a shader resource on slot 0 - the next
    // frame copies into A/B and reads them back as sources.
    ID3D11ShaderResourceView* noSrv = nullptr;
    g_d11ctx->PSSetShaderResources(0, 1, &noSrv);

    static bool logged = false;
    if (!logged) {
        logged = true;
        LOG_INFO("blur: pass active (dx11, %ux%u, half=%ux%u, strength=%.2f)",
                 bd.Width, bd.Height, g_blur11Bw, g_blur11Bh, UiBlurStrength());
    }
}

// ---- D3D12 objects (own SRV + RTV heaps; the ImGui heap is untouched) ----
static ID3D12RootSignature*        g_blur12Rs = nullptr;
static ID3D12PipelineState*        g_blur12PsoH = nullptr;
static ID3D12PipelineState*        g_blur12PsoV = nullptr;
static ID3D12DescriptorHeap*       g_blur12SrvHeap = nullptr;  // 2 SRVs: A, B
static ID3D12DescriptorHeap*       g_blur12RtvHeap = nullptr;  // 1 RTV: B
static ID3D12Resource*             g_blur12Tex[2] = {};        // A, B
static D3D12_GPU_DESCRIPTOR_HANDLE g_blur12SrvGpu[2] = {};
static D3D12_CPU_DESCRIPTOR_HANDLE g_blur12RtvCpu = {};
static UINT g_blur12W = 0, g_blur12H = 0;
// B's size when it runs at half resolution (see g_blur11Bw). A must stay at
// the backbuffer's resolution: it is the CopyTextureRegion destination.
static UINT g_blur12Bw = 0, g_blur12Bh = 0;
static DXGI_FORMAT g_blur12Fmt = DXGI_FORMAT_UNKNOWN;

static void UiBlurReleaseD3D12() {
    for (int i = 0; i < 2; i++) {
        if (g_blur12Tex[i]) { g_blur12Tex[i]->Release(); g_blur12Tex[i] = nullptr; }
    }
    if (g_blur12RtvHeap) { g_blur12RtvHeap->Release(); g_blur12RtvHeap = nullptr; }
    if (g_blur12SrvHeap) { g_blur12SrvHeap->Release(); g_blur12SrvHeap = nullptr; }
    if (g_blur12PsoV) { g_blur12PsoV->Release(); g_blur12PsoV = nullptr; }
    if (g_blur12PsoH) { g_blur12PsoH->Release(); g_blur12PsoH = nullptr; }
    if (g_blur12Rs) { g_blur12Rs->Release(); g_blur12Rs = nullptr; }
    g_blur12W = 0; g_blur12H = 0; g_blur12Bw = 0; g_blur12Bh = 0;
    g_blur12Fmt = DXGI_FORMAT_UNKNOWN;
}

// Root signature (one SRV table + a 4-word root-constant block backing the
// 16-byte cbuffer BlurCb) + the two PSOs (same VS, H vs V/blended PS) and the
// descriptor heaps.
static bool UiBlurBuildPipeline12() {
    if (g_blur12Rs && g_blur12PsoH && g_blur12PsoV) return true;
    ID3DBlob* vsBlob = nullptr;
    ID3DBlob* psH = nullptr;
    ID3DBlob* psV = nullptr;
    if (!UiBlurCompile("BlurVS", "vs_5_0", "vertex", &vsBlob)) return false;
    if (!UiBlurCompile("BlurHPS", "ps_5_0", "horizontal", &psH)) {
        vsBlob->Release();
        return false;
    }
    if (!UiBlurCompile("BlurVPS", "ps_5_0", "vertical", &psV)) {
        vsBlob->Release();
        psH->Release();
        return false;
    }

    D3D12_DESCRIPTOR_RANGE range{};
    range.RangeType = D3D12_DESCRIPTOR_RANGE_TYPE_SRV;
    range.NumDescriptors = 1;
    range.BaseShaderRegister = 0;
    D3D12_ROOT_PARAMETER params[2]{};
    params[0].ParameterType = D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
    params[0].ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;
    params[0].DescriptorTable.NumDescriptorRanges = 1;
    params[0].DescriptorTable.pDescriptorRanges = &range;
    params[1].ParameterType = D3D12_ROOT_PARAMETER_TYPE_32BIT_CONSTANTS;
    params[1].ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;
    params[1].Constants.ShaderRegister = 0;   // b0
    params[1].Constants.Num32BitValues = 8;   // float4 g_texel + float4 g_tint

    D3D12_STATIC_SAMPLER_DESC sampler{};
    sampler.Filter = D3D12_FILTER_MIN_MAG_MIP_LINEAR;
    sampler.AddressU = sampler.AddressV = sampler.AddressW = D3D12_TEXTURE_ADDRESS_MODE_CLAMP;
    sampler.ComparisonFunc = D3D12_COMPARISON_FUNC_NEVER;
    sampler.MaxLOD = D3D12_FLOAT32_MAX;
    sampler.ShaderRegister = 0;
    sampler.ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;

    D3D12_ROOT_SIGNATURE_DESC rsd{};
    rsd.NumParameters = 2;
    rsd.pParameters = params;
    rsd.NumStaticSamplers = 1;
    rsd.pStaticSamplers = &sampler;
    rsd.Flags = D3D12_ROOT_SIGNATURE_FLAG_NONE;

    ID3DBlob* sigBlob = nullptr;
    ID3DBlob* sigErr = nullptr;
    HRESULT hr = D3D12SerializeRootSignature(&rsd, D3D_ROOT_SIGNATURE_VERSION_1_0,
                                             &sigBlob, &sigErr);
    if (SUCCEEDED(hr) && sigBlob) {
        hr = g_d12dev->CreateRootSignature(0, sigBlob->GetBufferPointer(),
                                           sigBlob->GetBufferSize(),
                                           __uuidof(ID3D12RootSignature), (void**)&g_blur12Rs);
    } else {
        hr = E_FAIL;
    }
    if (sigErr) sigErr->Release();
    if (sigBlob) sigBlob->Release();
    if (FAILED(hr) || !g_blur12Rs) {
        LOG_ERROR("blur: d3d12 root signature failed (%08X)", (unsigned)hr);
        vsBlob->Release();
        psH->Release();
        psV->Release();
        UiBlurReleaseD3D12();
        return false;
    }

    const DXGI_FORMAT fmt = g_blur12Fmt != DXGI_FORMAT_UNKNOWN
                                ? g_blur12Fmt : DXGI_FORMAT_B8G8R8A8_UNORM;
    auto fillDesc = [&](D3D12_GRAPHICS_PIPELINE_STATE_DESC& pd) {
        pd.pRootSignature = g_blur12Rs;
        pd.VS.pShaderBytecode = vsBlob->GetBufferPointer();
        pd.VS.BytecodeLength = vsBlob->GetBufferSize();
        pd.SampleMask = UINT_MAX;
        pd.RasterizerState.FillMode = D3D12_FILL_MODE_SOLID;
        pd.RasterizerState.CullMode = D3D12_CULL_MODE_NONE;
        pd.RasterizerState.DepthClipEnable = TRUE;
        pd.DepthStencilState.DepthEnable = FALSE;
        pd.DepthStencilState.DepthWriteMask = D3D12_DEPTH_WRITE_MASK_ALL;
        pd.DepthStencilState.DepthFunc = D3D12_COMPARISON_FUNC_ALWAYS;
        pd.DepthStencilState.StencilEnable = FALSE;
        pd.DepthStencilState.FrontFace.StencilFailOp = D3D12_STENCIL_OP_KEEP;
        pd.DepthStencilState.FrontFace.StencilDepthFailOp = D3D12_STENCIL_OP_KEEP;
        pd.DepthStencilState.FrontFace.StencilPassOp = D3D12_STENCIL_OP_KEEP;
        pd.DepthStencilState.FrontFace.StencilFunc = D3D12_COMPARISON_FUNC_ALWAYS;
        pd.DepthStencilState.BackFace = pd.DepthStencilState.FrontFace;
        pd.PrimitiveTopologyType = D3D12_PRIMITIVE_TOPOLOGY_TYPE_TRIANGLE;
        pd.NumRenderTargets = 1;
        pd.RTVFormats[0] = fmt;
        pd.SampleDesc.Count = 1;
    };

    if (!g_blur12PsoH) {
        D3D12_GRAPHICS_PIPELINE_STATE_DESC pd{};
        fillDesc(pd);
        pd.PS.pShaderBytecode = psH->GetBufferPointer();
        pd.PS.BytecodeLength = psH->GetBufferSize();
        // Opaque replace into the intermediate target.
        pd.BlendState.RenderTarget[0].BlendEnable = FALSE;
        pd.BlendState.RenderTarget[0].SrcBlend = D3D12_BLEND_ONE;
        pd.BlendState.RenderTarget[0].DestBlend = D3D12_BLEND_ZERO;
        pd.BlendState.RenderTarget[0].BlendOp = D3D12_BLEND_OP_ADD;
        pd.BlendState.RenderTarget[0].SrcBlendAlpha = D3D12_BLEND_ONE;
        pd.BlendState.RenderTarget[0].DestBlendAlpha = D3D12_BLEND_ZERO;
        pd.BlendState.RenderTarget[0].BlendOpAlpha = D3D12_BLEND_OP_ADD;
        pd.BlendState.RenderTarget[0].RenderTargetWriteMask = D3D12_COLOR_WRITE_ENABLE_ALL;
        hr = g_d12dev->CreateGraphicsPipelineState(&pd, __uuidof(ID3D12PipelineState),
                                                   (void**)&g_blur12PsoH);
        if (FAILED(hr) || !g_blur12PsoH) {
            LOG_ERROR("blur: d3d12 h-pso creation failed (%08X) fmt=%d",
                      (unsigned)hr, (int)fmt);
            vsBlob->Release();
            psH->Release();
            psV->Release();
            UiBlurReleaseD3D12();
            return false;
        }
    }
    if (!g_blur12PsoV) {
        D3D12_GRAPHICS_PIPELINE_STATE_DESC pd{};
        fillDesc(pd);
        pd.PS.pShaderBytecode = psV->GetBufferPointer();
        pd.PS.BytecodeLength = psV->GetBufferSize();
        // Glass composite into the backbuffer: blurred * a + dst * (1 - a).
        pd.BlendState.RenderTarget[0].BlendEnable = TRUE;
        pd.BlendState.RenderTarget[0].SrcBlend = D3D12_BLEND_SRC_ALPHA;
        pd.BlendState.RenderTarget[0].DestBlend = D3D12_BLEND_INV_SRC_ALPHA;
        pd.BlendState.RenderTarget[0].BlendOp = D3D12_BLEND_OP_ADD;
        pd.BlendState.RenderTarget[0].SrcBlendAlpha = D3D12_BLEND_ONE;
        pd.BlendState.RenderTarget[0].DestBlendAlpha = D3D12_BLEND_ZERO;
        pd.BlendState.RenderTarget[0].BlendOpAlpha = D3D12_BLEND_OP_ADD;
        pd.BlendState.RenderTarget[0].RenderTargetWriteMask = D3D12_COLOR_WRITE_ENABLE_ALL;
        hr = g_d12dev->CreateGraphicsPipelineState(&pd, __uuidof(ID3D12PipelineState),
                                                   (void**)&g_blur12PsoV);
        if (FAILED(hr) || !g_blur12PsoV) {
            LOG_ERROR("blur: d3d12 v-pso creation failed (%08X) fmt=%d",
                      (unsigned)hr, (int)fmt);
            vsBlob->Release();
            psH->Release();
            psV->Release();
            UiBlurReleaseD3D12();
            return false;
        }
    }
    vsBlob->Release();
    psH->Release();
    psV->Release();
    return true;
}

// Lazy (re)build for the current backbuffer size. Called from
// RenderD3D12Frame BEFORE the allocator/list Reset (command list closed), so
// object creation never runs on an open list. Steady states: A lives in
// COPY_DEST (it is always the copy destination), B lives in RENDER_TARGET
// (it is always the horizontal-pass target) - both are created in those
// states, so the barrier sequence in UiBlurRecordD3D12 is identical on the
// first frame and on every later frame.
static bool UiBlurEnsureD3D12(int idx) {
    if (!g_d12dev || !g_d12list) return false;
    if (idx < 0 || idx >= g_d12bufCount || idx >= kMaxBuffers || !g_d12bufs[idx])
        return false;
    const D3D12_RESOURCE_DESC bd = g_d12bufs[idx]->GetDesc();
    const UINT w = (UINT)bd.Width;
    const UINT h = (UINT)bd.Height;
    if (bd.SampleDesc.Count != 1) {
        static bool logged = false;
        if (!logged) {
            logged = true;
            LOG_INFO("blur: multisampled backbuffer (%ux) - glass disabled",
                     bd.SampleDesc.Count);
        }
        return false;
    }
    const DXGI_FORMAT fmt = SaturationConcreteFormat(bd.Format);
    // Half-resolution B (see UiBlurEnsure11 for the rationale). A keeps the
    // backbuffer size - it is the copy destination.
    const UINT bw = w > 1 ? w / 2 : 1;
    const UINT bh = h > 1 ? h / 2 : 1;
    if (g_blur12Rs && g_blur12PsoH && g_blur12PsoV && g_blur12SrvHeap &&
        g_blur12RtvHeap && g_blur12Tex[0] && g_blur12Tex[1] &&
        g_blur12W == w && g_blur12H == h &&
        g_blur12Bw == bw && g_blur12Bh == bh && g_blur12Fmt == fmt)
        return true;

    // The PSOs are format-bound: drop them when the backbuffer format changed.
    if ((g_blur12PsoH || g_blur12PsoV) && g_blur12Fmt != DXGI_FORMAT_UNKNOWN &&
        g_blur12Fmt != fmt) {
        if (g_blur12PsoH) { g_blur12PsoH->Release(); g_blur12PsoH = nullptr; }
        if (g_blur12PsoV) { g_blur12PsoV->Release(); g_blur12PsoV = nullptr; }
    }
    g_blur12Fmt = fmt;   // published before the build so the PSOs pick it up
    if (!UiBlurBuildPipeline12()) return false;

    if (!g_blur12SrvHeap) {
        D3D12_DESCRIPTOR_HEAP_DESC hd{};
        hd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
        hd.NumDescriptors = 2;                     // A and B
        hd.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
        if (FAILED(g_d12dev->CreateDescriptorHeap(&hd, __uuidof(ID3D12DescriptorHeap),
                                                  (void**)&g_blur12SrvHeap)) ||
            !g_blur12SrvHeap) {
            LOG_ERROR("blur: d3d12 srv heap creation failed");
            UiBlurReleaseD3D12();
            return false;
        }
    }
    if (!g_blur12RtvHeap) {
        D3D12_DESCRIPTOR_HEAP_DESC hd{};
        hd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV;
        hd.NumDescriptors = 1;                     // B only
        if (FAILED(g_d12dev->CreateDescriptorHeap(&hd, __uuidof(ID3D12DescriptorHeap),
                                                  (void**)&g_blur12RtvHeap)) ||
            !g_blur12RtvHeap) {
            LOG_ERROR("blur: d3d12 rtv heap creation failed");
            UiBlurReleaseD3D12();
            return false;
        }
        g_blur12RtvCpu = g_blur12RtvHeap->GetCPUDescriptorHandleForHeapStart();
    }

    if (!g_blur12Tex[0] || !g_blur12Tex[1] || g_blur12W != w || g_blur12H != h ||
        g_blur12Bw != bw || g_blur12Bh != bh) {
        // Rare (size change / first build): idle the GPU before releasing the
        // old textures - they may still be referenced by work the fence wait
        // missed. ONLY the ping-pong textures are released here: the heaps,
        // root signature and PSOs above stay alive (a full release would null
        // the descriptor handles this block still uses).
        WaitGpuIdle12();
        for (int i = 0; i < 2; i++) {
            if (g_blur12Tex[i]) { g_blur12Tex[i]->Release(); g_blur12Tex[i] = nullptr; }
        }
        const UINT srvInc =
            g_d12dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
        D3D12_CPU_DESCRIPTOR_HANDLE srvCpu = g_blur12SrvHeap->GetCPUDescriptorHandleForHeapStart();
        D3D12_GPU_DESCRIPTOR_HANDLE srvGpu = g_blur12SrvHeap->GetGPUDescriptorHandleForHeapStart();
        HRESULT hr = S_OK;
        for (int i = 0; i < 2 && SUCCEEDED(hr); i++) {
            D3D12_HEAP_PROPERTIES hp{};
            hp.Type = D3D12_HEAP_TYPE_DEFAULT;
            D3D12_RESOURCE_DESC cd{};
            cd.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
            // A (i == 0) mirrors the backbuffer; B (i == 1) is the half-res
            // intermediate the horizontal pass writes and the vertical pass
            // samples back through a linear filter.
            cd.Width = (i == 0) ? w : bw;
            cd.Height = (i == 0) ? h : bh;
            cd.DepthOrArraySize = 1;
            cd.MipLevels = 1;
            cd.Format = fmt;
            cd.SampleDesc.Count = 1;
            cd.Layout = D3D12_TEXTURE_LAYOUT_UNKNOWN;
            cd.Flags = D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET;
            // A starts (and always returns to) COPY_DEST; B starts (and always
            // returns to) RENDER_TARGET - the record sequence below relies on
            // both, so the first frame's barriers are identical to later ones.
            const D3D12_RESOURCE_STATES initial =
                (i == 0) ? D3D12_RESOURCE_STATE_COPY_DEST
                         : D3D12_RESOURCE_STATE_RENDER_TARGET;
            hr = g_d12dev->CreateCommittedResource(
                &hp, D3D12_HEAP_FLAG_NONE, &cd, initial, nullptr,
                __uuidof(ID3D12Resource), (void**)&g_blur12Tex[i]);
            if (FAILED(hr) || !g_blur12Tex[i]) break;
            g_d12dev->CreateShaderResourceView(g_blur12Tex[i], nullptr, srvCpu);
            g_blur12SrvGpu[i] = srvGpu;
            srvCpu.ptr += srvInc;
            srvGpu.ptr += srvInc;
        }
        if (FAILED(hr)) {
            LOG_ERROR("blur: d3d12 %ux%u fmt=%d ping-pong creation failed (%08X)",
                      w, h, (int)fmt, (unsigned)hr);
            UiBlurReleaseD3D12();
            return false;
        }
        // B's RTV (A is never a target).
        g_d12dev->CreateRenderTargetView(g_blur12Tex[1], nullptr, g_blur12RtvCpu);
    }

    g_blur12W = w;
    g_blur12H = h;
    g_blur12Bw = bw;
    g_blur12Bh = bh;
    g_blur12Fmt = fmt;
    return true;
}

static bool UiBlurReadyD3D12(int idx) {
    if (!UiBlurGate()) return false;
    return UiBlurEnsureD3D12(idx);
}

// Records one active D3D12 frame into the same g_d12list, after the saturation
// pass when it ran. reuseSatCopy = saturation copied the frame this frame
// (g_sat12Copies[idx] then holds it in COPY_DEST): the horizontal pass reads
// that copy instead of making its own, and it is handed back in COPY_DEST at
// the end. Otherwise the blur owns the copy: backbuffer RENDER_TARGET ->
// COPY_SOURCE -> copy into A -> RENDER_TARGET, exactly the transition pair the
// plain frame path expects. The backbuffer always ends this function in
// RENDER_TARGET, which is what the ImGui path and the closing RT->PRESENT
// barrier assume.
static void UiBlurRecordD3D12(int idx, bool reuseSatCopy) {
    const UINT w = g_blur12W;
    const UINT h = g_blur12H;
    const UINT bw = g_blur12Bw;
    const UINT bh = g_blur12Bh;
    D3D12_RESOURCE_BARRIER b{};
    b.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    b.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;

    ID3D12Resource* src = nullptr;
    D3D12_GPU_DESCRIPTOR_HANDLE srcGpu{};
    ID3D12DescriptorHeap* srcHeap = nullptr;
    if (reuseSatCopy && g_sat12Copies[idx] && g_sat12SrvHeap) {
        b.Transition.pResource = g_sat12Copies[idx];
        b.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;
        b.Transition.StateAfter = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
        g_d12list->ResourceBarrier(1, &b);
        src = g_sat12Copies[idx];
        srcGpu = g_sat12SrvGpu[idx];
        srcHeap = g_sat12SrvHeap;
    } else {
        // 1) backbuffer RENDER_TARGET -> COPY_SOURCE
        b.Transition.pResource = g_d12bufs[idx];
        b.Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET;
        b.Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
        g_d12list->ResourceBarrier(1, &b);
        // 2) copy the game frame out (A already sits in COPY_DEST)
        D3D12_TEXTURE_COPY_LOCATION dst{};
        dst.pResource = g_blur12Tex[0];
        dst.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
        dst.SubresourceIndex = 0;
        D3D12_TEXTURE_COPY_LOCATION srcLoc{};
        srcLoc.pResource = g_d12bufs[idx];
        srcLoc.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
        srcLoc.SubresourceIndex = 0;
        g_d12list->CopyTextureRegion(&dst, 0, 0, 0, &srcLoc, nullptr);
        // 3) backbuffer COPY_SOURCE -> RENDER_TARGET again
        b.Transition.pResource = g_d12bufs[idx];
        b.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;
        b.Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET;
        g_d12list->ResourceBarrier(1, &b);
        // 4) A becomes the shader resource for the horizontal pass
        b.Transition.pResource = g_blur12Tex[0];
        b.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;
        b.Transition.StateAfter = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
        g_d12list->ResourceBarrier(1, &b);
        src = g_blur12Tex[0];
        srcGpu = g_blur12SrvGpu[0];
        srcHeap = g_blur12SrvHeap;
    }

    // 5) horizontal: src -> B (B's steady state is RENDER_TARGET)
    ID3D12DescriptorHeap* heaps[] = { srcHeap };
    g_d12list->SetDescriptorHeaps(1, heaps);
    g_d12list->SetGraphicsRootSignature(g_blur12Rs);
    g_d12list->SetPipelineState(g_blur12PsoH);
    g_d12list->SetGraphicsRootDescriptorTable(0, srcGpu);
    float tr, tg, tb; UiBlurTint(tr, tg, tb);
    float cb[8] = { 1.0f / (float)w, 1.0f / (float)h, kBlurRadius, UiBlurStrength(), tr, tg, tb, 0.0f };
    UINT bits[8] = {};
    std::memcpy(bits, cb, sizeof(bits));
    g_d12list->SetGraphicsRoot32BitConstants(1, 8, bits, 0);
    g_d12list->OMSetRenderTargets(1, &g_blur12RtvCpu, FALSE, nullptr);
    // B is half resolution, so this pass shades a quarter of the pixels the
    // full-res version did. The constant buffer still carries the full-res
    // texel size - the shader converts the pixel radius into a UV offset, so
    // the on-screen blur width is unchanged.
    D3D12_VIEWPORT vp{};
    vp.Width = (FLOAT)bw;
    vp.Height = (FLOAT)bh;
    vp.MaxDepth = 1.0f;
    g_d12list->RSSetViewports(1, &vp);
    // D3D12 keeps the scissor test permanently active with an undefined
    // initial rect: bind our own or the draw may be clipped to nothing.
    D3D12_RECT sr{};
    sr.right = (LONG)bw;
    sr.bottom = (LONG)bh;
    g_d12list->RSSetScissorRects(1, &sr);
    g_d12list->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    g_d12list->DrawInstanced(3, 1, 0, 0);

    // 6) B -> PIXEL_SHADER_RESOURCE for the vertical pass
    b.Transition.pResource = g_blur12Tex[1];
    b.Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET;
    b.Transition.StateAfter = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
    g_d12list->ResourceBarrier(1, &b);

    // 7) vertical + glass composite: B -> backbuffer (blended)
    heaps[0] = g_blur12SrvHeap;
    g_d12list->SetDescriptorHeaps(1, heaps);
    g_d12list->SetPipelineState(g_blur12PsoV);
    g_d12list->SetGraphicsRootDescriptorTable(0, g_blur12SrvGpu[1]);
    g_d12list->OMSetRenderTargets(1, &g_d12rtvs[idx], FALSE, nullptr);
    // Back to the full backbuffer resolution for the composite.
    vp.Width = (FLOAT)w;
    vp.Height = (FLOAT)h;
    g_d12list->RSSetViewports(1, &vp);
    sr.right = (LONG)w;
    sr.bottom = (LONG)h;
    g_d12list->RSSetScissorRects(1, &sr);
    g_d12list->DrawInstanced(3, 1, 0, 0);

    // 8) restore the steady states the next frame's sequence starts from: B
    // back to RENDER_TARGET, and the source back to COPY_DEST (A in the
    // own-copy case, the saturation copy when it was reused).
    b.Transition.pResource = g_blur12Tex[1];
    b.Transition.StateBefore = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
    b.Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET;
    g_d12list->ResourceBarrier(1, &b);
    b.Transition.pResource = src;
    b.Transition.StateBefore = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
    b.Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_DEST;
    g_d12list->ResourceBarrier(1, &b);

    static bool logged = false;
    if (!logged) {
        logged = true;
        LOG_INFO("blur: pass active (dx12, %ux%u, half=%ux%u, strength=%.2f, src=%s)",
                 w, h, bw, bh, UiBlurStrength(), reuseSatCopy ? "saturation-copy" : "own-copy");
    }
}

static void UiBlurReleaseAll() {
    UiBlurReleaseD3D11();
    UiBlurReleaseD3D12();
}

// ============================ D3D teardown ============================
void ReleaseD3D11() {
    if (g_backend11) { ImGui_ImplDX11_Shutdown(); g_backend11 = false; }
    if (g_d11rtv) { g_d11rtv->Release(); g_d11rtv = nullptr; }
    if (g_d11ctx) { g_d11ctx->Release(); g_d11ctx = nullptr; }
    if (g_d11dev) { g_d11dev->Release(); g_d11dev = nullptr; }
}

void ReleaseD3D12() {
    if (!g_d12dev && !g_backend12) return;
    if (g_backend12) { ImGui_ImplDX12_Shutdown(); g_backend12 = false; }
    // Idle the GPU before releasing anything (no-op when the D3D12 state is
    // incomplete; completes immediately when already idle). TeardownRender
    // waits before calling in; this still covers direct callers (init-failure
    // paths).
    WaitGpuIdle12();
    for (int i = 0; i < kMaxBuffers; i++) {
        if (g_d12bufs[i]) { g_d12bufs[i]->Release(); g_d12bufs[i] = nullptr; }
    }
    g_d12bufCount = 0;
    if (g_d12list) { g_d12list->Release(); g_d12list = nullptr; }
    if (g_d12alloc) { g_d12alloc->Release(); g_d12alloc = nullptr; }
    if (g_d12rtvHeap) { g_d12rtvHeap->Release(); g_d12rtvHeap = nullptr; }
    if (g_d12srvHeap) { g_d12srvHeap->Release(); g_d12srvHeap = nullptr; }
    if (g_d12fence) { g_d12fence->Release(); g_d12fence = nullptr; }
    if (g_d12event) { CloseHandle(g_d12event); g_d12event = nullptr; }
    if (g_d12queue) { g_d12queue->Release(); g_d12queue = nullptr; }
    if (g_d12dev) { g_d12dev->Release(); g_d12dev = nullptr; }
}

void TeardownRender() {
    // Idle the D3D12 GPU FIRST: saturation copies (and everything released
    // below) must not be freed while GPU work may still reference them -
    // a fence timeout upstream leaves frames unsynchronized. On a removed
    // device this just runs out its 1 s timeout once (the old ReleaseD3D12
    // wait cost the same), then the releases proceed.
    WaitGpuIdle12();
    // Saturation + UI blur objects first: they reference the D3D devices
    // below (and WaitGpuIdle12 has already run above).
    SaturationReleaseAll();
    MotionBlurReleaseAll();
    UiBlurReleaseAll();
    ReleaseD3D11();
    ReleaseD3D12();
    g_sc = nullptr;
    g_init = false;
    g_usingD3D12 = false;
}

// ============================ D3D init ============================
bool EnsureImGui() {
    if (g_imgui) return true;
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;      // never write imgui.ini into the game folder
    io.LogFilename = nullptr;
    ImGui::StyleColorsDark();
    if (!fonts::Init(g_dllDir)) LOG_ERROR("overlay: fonts degraded (see log)");
    if (!ui::Init()) { LOG_ERROR("overlay: menu init failed"); return false; }
    g_imgui = true;
    LOG_INFO("overlay: ImGui + menu ready");
    return true;
}

bool InitD3D11(IDXGISwapChain* sc) {
    HRESULT hr = sc->GetDevice(__uuidof(ID3D11Device), (void**)&g_d11dev);
    if (FAILED(hr) || !g_d11dev) return false;
    g_d11dev->GetImmediateContext(&g_d11ctx);
    ID3D11Texture2D* back = nullptr;
    hr = sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&back);
    if (FAILED(hr) || !back) { ReleaseD3D11(); return false; }
    hr = g_d11dev->CreateRenderTargetView(back, nullptr, &g_d11rtv);
    back->Release();
    if (FAILED(hr) || !g_d11rtv) { ReleaseD3D11(); return false; }
    if (!EnsureImGui()) { ReleaseD3D11(); return false; }
    if (!g_backend11) {
        ImGui_ImplDX11_Init(g_d11dev, g_d11ctx);
        g_backend11 = true;
    }
    g_usingD3D12 = false;
    LOG_INFO("overlay: D3D11 path engaged");
    return true;
}

bool InitD3D12(IDXGISwapChain* sc) {
    HRESULT hr = sc->GetDevice(__uuidof(ID3D12Device), (void**)&g_d12dev);
    if (FAILED(hr) || !g_d12dev) return false;

    DXGI_SWAP_CHAIN_DESC sd{};
    if (FAILED(sc->GetDesc(&sd)) || sd.BufferCount < 1) { ReleaseD3D12(); return false; }
    const int count = sd.BufferCount > kMaxBuffers ? kMaxBuffers : (int)sd.BufferCount;

    D3D12_COMMAND_QUEUE_DESC qd{};
    qd.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
    if (FAILED(g_d12dev->CreateCommandQueue(&qd, __uuidof(ID3D12CommandQueue), (void**)&g_d12queue))) {
        ReleaseD3D12(); return false;
    }
    // Hook the shared ID3D12CommandQueue vtable to learn the game's direct
    // queue (all queues of one device share the vtable, so ours reveals it).
    if (!g_oExec && g_d12queue) {
        g_queueVtable = *(void***)g_d12queue;
        PatchVTable(g_queueVtable, kExecIndex, (void*)HkExecuteCommandLists, &g_oExec);
        LOG_INFO("overlay: queue hook live (exec=%p)", g_oExec);
    }
    if (FAILED(g_d12dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT,
                                               __uuidof(ID3D12CommandAllocator), (void**)&g_d12alloc))) {
        ReleaseD3D12(); return false;
    }
    if (FAILED(g_d12dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, g_d12alloc,
                                           nullptr, __uuidof(ID3D12GraphicsCommandList), (void**)&g_d12list))) {
        ReleaseD3D12(); return false;
    }
    g_d12list->Close();

    D3D12_DESCRIPTOR_HEAP_DESC hd{};
    hd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV;
    hd.NumDescriptors = count;
    if (FAILED(g_d12dev->CreateDescriptorHeap(&hd, __uuidof(ID3D12DescriptorHeap), (void**)&g_d12rtvHeap))) {
        ReleaseD3D12(); return false;
    }
    const UINT inc = g_d12dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
    D3D12_CPU_DESCRIPTOR_HANDLE h = g_d12rtvHeap->GetCPUDescriptorHandleForHeapStart();
    for (int i = 0; i < count; i++) {
        if (FAILED(sc->GetBuffer(i, __uuidof(ID3D12Resource), (void**)&g_d12bufs[i]))) {
            ReleaseD3D12(); return false;
        }
        g_d12dev->CreateRenderTargetView(g_d12bufs[i], nullptr, h);
        g_d12rtvs[i] = h;
        h.ptr += inc;
    }
    g_d12bufCount = count;

    D3D12_DESCRIPTOR_HEAP_DESC shd{};
    shd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
    shd.NumDescriptors = 1;
    shd.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
    if (FAILED(g_d12dev->CreateDescriptorHeap(&shd, __uuidof(ID3D12DescriptorHeap), (void**)&g_d12srvHeap))) {
        ReleaseD3D12(); return false;
    }
    if (FAILED(g_d12dev->CreateFence(0, D3D12_FENCE_FLAG_NONE,
                                    __uuidof(ID3D12Fence), (void**)&g_d12fence))) {
        ReleaseD3D12(); return false;
    }
    g_d12event = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    if (!g_d12event) { ReleaseD3D12(); return false; }

    if (!EnsureImGui()) { ReleaseD3D12(); return false; }
    if (!g_backend12) {
        // NOTE: do NOT use the legacy ImGui_ImplDX12_Init() overload here: it
        // leaves InitInfo::CommandQueue null, and the backend unconditionally
        // dereferences it on the first NewFrame (font texture upload) -> AV.
        ImGui_ImplDX12_InitInfo init_info{};
        init_info.Device = g_d12dev;
        init_info.CommandQueue = g_d12queue;
        init_info.NumFramesInFlight = 2;
        init_info.RTVFormat = sd.BufferDesc.Format;
        init_info.SrvDescriptorHeap = g_d12srvHeap;
        init_info.LegacySingleSrvCpuDescriptor = g_d12srvHeap->GetCPUDescriptorHandleForHeapStart();
        init_info.LegacySingleSrvGpuDescriptor = g_d12srvHeap->GetGPUDescriptorHandleForHeapStart();
        if (!ImGui_ImplDX12_Init(&init_info)) {
            ReleaseD3D12(); return false;
        }
        g_backend12 = true;
        // Create PSO/root-signature/font-texture NOW (not lazily on the first
        // NewFrame) so a failure is visible here instead of mid-frame.
        if (!ImGui_ImplDX12_CreateDeviceObjects()) {
            LOG_ERROR("overlay: DX12 CreateDeviceObjects failed - aborting D3D12 path");
            ReleaseD3D12(); return false;
        }
        LOG_INFO("overlay: DX12 device objects ready");
    }
    g_usingD3D12 = true;
    LOG_INFO("overlay: D3D12 path engaged (%d buffers, fmt=%d %ux%u sample=%u effect=%d)",
             count, (int)sd.BufferDesc.Format, sd.BufferDesc.Width, sd.BufferDesc.Height,
             sd.SampleDesc.Count, (int)sd.SwapEffect);
    return true;
}

// ============================ frame ============================
// Render self-check: ImGui::Render must produce at least one draw list once
// the overlay objects are up. 60 consecutive empty results mean the frame is
// swallowed somewhere upstream (no UI work, broken backend) - log once so it
// is diagnosable. Diagnostic only; the render call itself is unchanged.
static void DiagDrawData(ImDrawData* data) {
    static int emptyFrames = 0;
    if (data && data->CmdListsCount > 0) { emptyFrames = 0; return; }
    if (++emptyFrames == 60) LOG_ERROR("render: drawdata empty for 60 frames");
}

void RenderD3D12Frame() {
    int idx = 0;
    IDXGISwapChain3* sc3 = nullptr;
    if (SUCCEEDED(g_sc->QueryInterface(__uuidof(IDXGISwapChain3), (void**)&sc3)) && sc3) {
        idx = (int)sc3->GetCurrentBackBufferIndex();
        sc3->Release();
    }
    if (idx < 0 || idx >= g_d12bufCount) idx = 0;

    // Saturation setup FIRST, while the command list is still closed: Ensure
    // may create device objects (heaps, copies, root signature, PSO) and must
    // never run on an open command list. False = pass disabled or Ensure
    // failed; the frame then takes the untouched plain path below. The UI
    // blur ensures the same way (own objects, own steady states).
    const bool satReady = SaturationReadyD3D12(idx);
    const bool mbReady = MotionBlurReadyD3D12(idx);
    const bool blurReady = UiBlurReadyD3D12(idx);

    static int d12fno = 0;
    const bool dtrace = ++d12fno <= 3;
    static bool resetErrLogged = false;

    // Wait for the PREVIOUS frame's submission before reusing the allocator and
    // the command list.
    //
    // The wait used to sit immediately AFTER this frame's ExecuteCommandLists,
    // so the render thread blocked until the work it had just queued finished -
    // zero CPU/GPU overlap, and a hard frame-rate ceiling of 1/(GPU frame time)
    // regardless of how fast the CPU was. Moving the same wait to the top of the
    // next frame gives the GPU an entire frame to complete, so it normally
    // returns instantly while providing exactly the same reuse guarantee: the
    // allocator/list are only reset once their last submission is done.
    if (g_d12fenceVal != 0 && g_d12fence && g_d12event) {
        g_d12fence->SetEventOnCompletion(g_d12fenceVal, g_d12event);
        if (WaitForSingleObject(g_d12event, 1000) != WAIT_OBJECT_0 && !g_d12waitLogged) {
            g_d12waitLogged = true;
            LOG_ERROR("overlay: D3D12 fence wait timed out - continuing unsynchronized");
        }
    }

    const HRESULT hrAlloc = g_d12alloc->Reset();
    const HRESULT hrList = g_d12list->Reset(g_d12alloc, nullptr);
    if ((FAILED(hrAlloc) || FAILED(hrList)) && !resetErrLogged) {
        resetErrLogged = true;
        LOG_ERROR("overlay: D3D12 allocator/list reset failed (%08X/%08X)", hrAlloc, hrList);
    }
    if (dtrace) LOG_INFO("trace: d3d12 list reset");

    D3D12_RESOURCE_BARRIER b{};
    b.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    b.Transition.pResource = g_d12bufs[idx];
    b.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    // Saturation (Flarial parity): while enabled, the pass copies the game's
    // frame out of the backbuffer and redraws it through the saturation shader
    // BEFORE any ImGui work. It owns this frame's PRESENT->RENDER_TARGET
    // transition (PRESENT->COPY_SOURCE, copy, COPY_SOURCE->RENDER_TARGET,
    // draw), so the backbuffer ends in RENDER_TARGET exactly as the code below
    // and the closing RT->PRESENT barrier expect. The draw binds its own
    // shader-visible heap; the ImGui path rebinds g_d12srvHeap afterwards, so
    // heap ownership and the submit/fence flow are untouched. Setup already
    // ran with the list closed (satReady above); when the pass is disabled or
    // failed it contributes nothing at all.
    if (satReady) SaturationRecordD3D12(idx);
    // Motion blur runs on the (already saturated) game frame and also leaves
    // the backbuffer in RENDER_TARGET; from PRESENT when saturation is off.
    if (mbReady) MotionBlurRecordD3D12(idx, !satReady);
    if (!satReady && !mbReady) {
        b.Transition.StateBefore = D3D12_RESOURCE_STATE_PRESENT;
        b.Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET;
        g_d12list->ResourceBarrier(1, &b);
    }
    // White-glass backdrop blur, recorded after saturation so the frame is
    // already out of the backbuffer: with saturation active the blur reuses
    // g_sat12Copies[idx] as its horizontal-pass source instead of copying the
    // frame twice. Either way the backbuffer is left in RENDER_TARGET for the
    // ImGui path below.
    if (blurReady) UiBlurRecordD3D12(idx, satReady && !mbReady);
    g_d12list->OMSetRenderTargets(1, &g_d12rtvs[idx], FALSE, nullptr);
    if (dtrace) LOG_INFO("trace: d3d12 target set");

    ImGui_ImplDX12_NewFrame();
    if (g_win32Init) ImGui_ImplWin32_NewFrame();
    else PollMouseFallback();
    ApplyRawMouse();
    ImGui::NewFrame();
    if (dtrace) LOG_INFO("trace: d3d12 newframe done");
    gui::BeginFrame(ImVec2((float)g_w, (float)g_h), ImGui::GetIO().MousePos,
                    ImGui::GetIO().DeltaTime);
    if (dtrace) LOG_INFO("trace: d3d12 ui::Frame enter");
    ui::Frame();
    if (dtrace) LOG_INFO("trace: d3d12 ui::Frame exit");
    ImGui::Render();
    if (dtrace) LOG_INFO("trace: d3d12 imgui render done");
    ID3D12DescriptorHeap* heaps[] = { g_d12srvHeap };
    g_d12list->SetDescriptorHeaps(1, heaps);
    ImDrawData* d12Data = ImGui::GetDrawData();
    DiagDrawData(d12Data);
    ImGui_ImplDX12_RenderDrawData(d12Data, g_d12list);
    if (dtrace) LOG_INFO("trace: d3d12 drawdata done");

    b.Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET;
    b.Transition.StateAfter = D3D12_RESOURCE_STATE_PRESENT;
    g_d12list->ResourceBarrier(1, &b);
    g_d12list->Close();
    ID3D12CommandList* lists[] = { g_d12list };
    // Same-queue submit: per-queue FIFO guarantees our barriers run after the
    // game's own transitions. Fallback to our queue only if the game queue
    // was never captured (should not happen: the game always Executes before
    // it Presents).
    ID3D12CommandQueue* submitQ = g_gameQueue ? g_gameQueue : g_d12queue;
    if (dtrace)
        LOG_INFO("trace: d3d12 submit queue %p (%s)", submitQ,
                 submitQ == g_gameQueue ? "game" : "own");
    submitQ->ExecuteCommandLists(1, lists);
    submitQ->Signal(g_d12fence, ++g_d12fenceVal);
    // Deliberately NO wait here. The matching wait now lives at the top of the
    // next frame, right before the allocator/list reset - see the comment there.
    // Waiting here is what destroyed CPU/GPU overlap and capped the frame rate.
    if (dtrace) LOG_INFO("trace: d3d12 submit done");
}

void RenderD3D11Frame() {
    // Saturation (Flarial parity): filter the game's frame in the backbuffer
    // before any ImGui work; the pass restores the backbuffer RTV itself and
    // does absolutely nothing while the module is disabled.
    if (SaturationReadyD3D11()) SaturationApplyD3D11();
    // Motion blur on the (saturated) game frame, before the UI blur + ImGui.
    if (MotionBlurReadyD3D11()) MotionBlurApplyD3D11();
    // White-glass backdrop blur for the ClickGUI: same spot, same discipline -
    // runs only while the GUI owns input and the General "UI Blur" gate is
    // on, and hands the backbuffer RTV back for the ImGui path below.
    if (UiBlurReadyD3D11()) UiBlurApplyD3D11();
    ImGui_ImplDX11_NewFrame();
    if (g_win32Init) ImGui_ImplWin32_NewFrame();
    else PollMouseFallback();
    ApplyRawMouse();
    ImGui::NewFrame();
    gui::BeginFrame(ImVec2((float)g_w, (float)g_h), ImGui::GetIO().MousePos,
                    ImGui::GetIO().DeltaTime);
    ui::Frame();
    ImGui::Render();
    g_d11ctx->OMSetRenderTargets(1, &g_d11rtv, nullptr);
    ImDrawData* d11Data = ImGui::GetDrawData();
    DiagDrawData(d11Data);
    ImGui_ImplDX11_RenderDrawData(d11Data);
}

// ============================ queue hook ============================
void __stdcall HkExecuteCommandLists(ID3D12CommandQueue* q, UINT n,
                                    ID3D12CommandList* const* lists) {
    (void)n; (void)lists;
#ifdef _MSC_VER
    __try {
#endif
        // Capture the game's direct queue for same-queue UI submit. Our own
        // queue (ImGui font upload) must never be captured.
        if (q && q != g_d12queue && q->GetDesc().Type == D3D12_COMMAND_LIST_TYPE_DIRECT) {
            if (g_gameQueue != q) {
                g_gameQueue = q;
                LOG_INFO("overlay: game direct queue captured (%p)", q);
            }
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        LOG_ERROR("overlay: exception in Execute hook - capture skipped");
    }
#endif
    ExecFn o = (ExecFn)g_oExec;
    if (o) o(q, n, lists);
}

// ============================ signature scan ============================
// Minimal executable-section scanner for Solstice-style "E8 ? ? ? ? ..."
// signatures. Used ONLY for Keyboard::feed; a hook is installed on
// exactly-one-match, never on ambiguity (a lookalike hook would crash).
bool BuildSigPattern(const char* sig, std::vector<uint8_t>& bytes, std::string& mask) {
    bytes.clear();
    mask.clear();
    if (!sig) return false;
    std::istringstream in(sig);
    std::string tok;
    while (in >> tok) {
        if (tok == "?" || tok == "??") {
            bytes.push_back(0);
            mask.push_back('?');
            continue;
        }
        char* end = nullptr;
        const unsigned long v = std::strtoul(tok.c_str(), &end, 16);
        if (!end || *end != '\0' || v > 0xFFul) return false;
        bytes.push_back((uint8_t)v);
        mask.push_back('x');
    }
    return !bytes.empty();
}

// Counts matches (stops at 2); first receives the first hit, or 0.
int ScanSigMatches(HMODULE mod, const char* sig, uintptr_t& first) {
    first = 0;
    std::vector<uint8_t> bytes;
    std::string mask;
    if (!mod || !BuildSigPattern(sig, bytes, mask)) return 0;
    const uint8_t* base = (const uint8_t*)mod;
    const IMAGE_DOS_HEADER* dos = (const IMAGE_DOS_HEADER*)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return 0;
    const IMAGE_NT_HEADERS* nt = (const IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return 0;
    const IMAGE_SECTION_HEADER* sec = IMAGE_FIRST_SECTION(nt);
    int found = 0;
    const size_t len = bytes.size();
    for (WORD s = 0; s < nt->FileHeader.NumberOfSections && found < 2; s++, sec++) {
        if (!(sec->Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        const uint8_t* begin = base + sec->VirtualAddress;
        const uint8_t* end = begin + sec->Misc.VirtualSize;
        for (const uint8_t* p = begin; p + len <= end; p++) {
            bool ok = true;
            for (size_t i = 0; i < len; i++) {
                if (mask[i] == 'x' && p[i] != bytes[i]) { ok = false; break; }
            }
            if (ok) {
                if (found == 0) first = (uintptr_t)p;
                if (++found >= 2) break;
            }
        }
    }
    return found;
}

// ============================ Options::getGamma detour ============================
float __fastcall HkGamma(uintptr_t* options) {
    // This is a GAME detour: Bedrock calls getGamma many times per frame.
    // Resolving the module by name was a strcmp scan over the whole roster on
    // every one of those calls. Module pointers are stable for the session
    // (RegisterAllModules adds the roster once; nothing is ever removed), so
    // resolve it once and cache it.
    static Module* s_fullBright = nullptr;
    if (!s_fullBright) s_fullBright = modules().find("FullBright");
    Module* base = s_fullBright;
    if (base && base->enabled()) {
        const FullBrightModule* bright = static_cast<const FullBrightModule*>(base);
        return bright->currentGamma();
    }
    GammaFn o = g_oGamma;
    return o ? o(options) : 1.0f;
}

void TryInstallGammaHook() {
    static bool tried = false;
    if (tried) return;
    tried = true;

    // Solstice and Flarial both identify Options::getGamma with this exact
    // prologue. Unlike a loose byte patch, the detour is installed only on a
    // single match for the current Bedrock executable.
    static const char kSig[] =
        "48 83 EC 28 48 8B 01 48 8D 54 24 30 41 B8 34 00 00 00";
    uintptr_t first = 0;
    const int matches = ScanSigMatches(GetModuleHandleW(nullptr), kSig, first);
    if (matches != 1 || !first) {
        LOG_INFO("overlay: Options::getGamma sig matches=%d - FullBright hook off", matches);
        return;
    }

    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) {
        LOG_ERROR("overlay: MH_Initialize for gamma failed (%d)", (int)st);
        return;
    }
    st = MH_CreateHook((LPVOID)first, (LPVOID)&HkGamma, (LPVOID*)&g_oGamma);
    if (st != MH_OK || !g_oGamma) {
        LOG_ERROR("overlay: MH_CreateHook(gamma) failed (%d)", (int)st);
        return;
    }
    st = MH_EnableHook((LPVOID)first);
    g_gammaHook = (st == MH_OK);
    LOG_INFO("overlay: Options::getGamma hook active=%d (%d, %p)",
             g_gammaHook ? 1 : 0, (int)st, (void*)first);
}

// ============================ Native GUI Scale ============================
#ifdef _MSC_VER
#define NF_GUI_TRY __try
#define NF_GUI_EXCEPT(x) __except(x)
#else
#define NF_GUI_TRY if (true)
#define NF_GUI_EXCEPT(x) else if (false)
#endif
uintptr_t g_gameImageBase = 0;
size_t g_gameImageSize = 0;

// ---- Per-walk page memo ----------------------------------------------------
//
// VirtualQuery is a kernel transition, and the actor walks below ask about the
// same handful of 4 KB pages over and over: every actor of one class shares a
// vtable page and a first-vtable-entry page, and heap allocations arrive in
// bursts. Memoising the page's state/protection turns the three probes each
// candidate used to pay into (usually) zero. The memo is armed only while a
// walk is running - per thread, cleared when the walk starts - so an answer can
// never outlive the pass that produced it. A stale answer would be harmless
// anyway: every read that follows is SEH-guarded and degrades into exactly the
// bad-slot path a failed probe would have taken.
constexpr int kPageMemoSlots = 64;   // power of two
struct PageMemoSlot { uintptr_t page; DWORD state; DWORD protect; };
thread_local PageMemoSlot g_pageMemo[kPageMemoSlots];
thread_local int g_pageMemoDepth = 0;

// Clears the table and arms it. Paired with PageMemoDisarm by PageMemoScope;
// called directly only where a scope guard would be illegal (an SEH frame).
static void PageMemoArm() {
    std::memset(g_pageMemo, 0, sizeof(g_pageMemo));
    ++g_pageMemoDepth;
}
static void PageMemoDisarm() {
    if (g_pageMemoDepth > 0) --g_pageMemoDepth;
}

// Armed on entry, disarmed on every exit including the early returns. Only used
// from functions that contain no __try of their own, so a destructor is legal.
struct PageMemoScope {
    PageMemoScope() { PageMemoArm(); }
    ~PageMemoScope() { PageMemoDisarm(); }
    PageMemoScope(const PageMemoScope&) = delete;
    PageMemoScope& operator=(const PageMemoScope&) = delete;
};

// Committed-and-readable test, with the page's protection mask handed back so
// callers that need more (executable, writable) do not probe a second time.
// Page 0 is never a valid object page, so a zero slot reads as empty.
static bool PageQueryMemo(const void* p, DWORD* protectOut) {
    if (!p) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if (g_pageMemoDepth > 0) {
        const uintptr_t page = reinterpret_cast<uintptr_t>(p) >> 12;
        if (page) {
            PageMemoSlot& slot = g_pageMemo[(page ^ (page >> 7)) & (kPageMemoSlots - 1)];
            if (slot.page != page) {
                if (!VirtualQuery(p, &mbi, sizeof(mbi))) {
                    slot.page = page;
                    slot.state = 0;
                    slot.protect = 0;
                } else {
                    slot.page = page;
                    slot.state = mbi.State;
                    slot.protect = mbi.Protect;
                }
            }
            if (protectOut) *protectOut = slot.protect;
            return slot.state == MEM_COMMIT && !(slot.protect & (PAGE_NOACCESS | PAGE_GUARD));
        }
    }
    if (!VirtualQuery(p, &mbi, sizeof(mbi))) return false;
    if (protectOut) *protectOut = mbi.Protect;
    return mbi.State == MEM_COMMIT && !(mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD));
}

bool GuiPageReadable(const void* p) {
    return PageQueryMemo(p, nullptr);
}

bool GuiRangeReadable(const void* p, size_t bytes) {
    if (!p || bytes == 0) return false;
    const uintptr_t begin = reinterpret_cast<uintptr_t>(p);
    const uintptr_t end = begin + bytes - 1;
    if (end < begin) return false;
    // VirtualQuery is a kernel transition. The overwhelming majority of calls
    // here probe an 8-16 byte field, which lies inside a single 4 KB page - so
    // probing the start and the end separately doubled the syscall count for
    // no added information. Same page => same protection => one probe.
    if ((begin >> 12) == (end >> 12))
        return GuiPageReadable(reinterpret_cast<const void*>(begin));
    return GuiPageReadable(reinterpret_cast<const void*>(begin)) &&
           GuiPageReadable(reinterpret_cast<const void*>(end));
}

bool GuiPageWritable(const void* p) {
    // One probe, not two: the old readable pre-check queried the very same page
    // and then threw the result away.
    DWORD protect = 0;
    if (!PageQueryMemo(p, &protect)) return false;
    const DWORD writable = PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
    return (protect & writable) != 0;
}

bool GuiRangeWritable(const void* p, size_t bytes) {
    if (!p || bytes == 0) return false;
    const uintptr_t begin = reinterpret_cast<uintptr_t>(p);
    const uintptr_t end = begin + bytes - 1;
    if (end < begin) return false;
    // GuiPageWritable already rejects uncommitted/guard/no-access pages, so the
    // separate GuiRangeReadable pass (1-2 more VirtualQuery calls) was pure
    // duplication. Same single-page shortcut as GuiRangeReadable.
    if ((begin >> 12) == (end >> 12))
        return GuiPageWritable(reinterpret_cast<const void*>(begin));
    return GuiPageWritable(reinterpret_cast<const void*>(begin)) &&
           GuiPageWritable(reinterpret_cast<const void*>(end));
}

void CacheGuiGameImage() {
    if (g_gameImageBase) return;
    const uint8_t* base = reinterpret_cast<const uint8_t*>(GetModuleHandleW(nullptr));
    if (!base) return;
    const IMAGE_DOS_HEADER* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return;
    const IMAGE_NT_HEADERS* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return;
    g_gameImageBase = reinterpret_cast<uintptr_t>(base);
    g_gameImageSize = nt->OptionalHeader.SizeOfImage;
}

bool LooksLikeGuiObject(const void* object) {
    if (!object) return false;
    CacheGuiGameImage();
    if (!g_gameImageBase || !GuiPageReadable(object)) return false;
    NF_GUI_TRY {
        const uintptr_t vft = *reinterpret_cast<const uintptr_t*>(object);
        return vft >= g_gameImageBase &&
               vft < g_gameImageBase + g_gameImageSize &&
               GuiPageReadable(reinterpret_cast<const void*>(vft));
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

// ============================ Java Hotkeys ============================
//
// This is deliberately a small target-side adapter rather than a copy of the
// Flarial SDK. The only game calls below are the 1.21.11X signatures already
// identified for this target family and the 1.21.11X _handlePlaceAll vtable
// slot. Any missing, ambiguous or non-game address disables the whole path.
//
// Bedrock's collection arguments are MSVC std::string objects. A MinGW-built
// DLL must not pass its libstdc++ std::string across that boundary. All names
// used here fit the MSVC small-string representation and are built in the
// bridge type above; no ItemStack is read or written directly.
void JavaEnsureCs() {
    if (!g_javaCsInit) {
        InitializeCriticalSection(&g_javaCs);
        g_javaCsInit = true;
    }
}

bool JavaIsEnabled() {
    return InterlockedCompareExchange(&g_javaEnabled, 0, 0) != 0;
}

void JavaClearContextLocked() {
    for (auto& request : g_javaRequests) request = JavaMoveRequest{};
    std::memset(g_javaHeld, 0, sizeof(g_javaHeld));
    g_javaRequestHead = 0;
    g_javaRequestCount = 0;
    g_javaHoveredController = nullptr;
    g_javaHoveredScreenView = nullptr;
    g_javaHoveredSlot = -1;
    g_javaHoveredCollection[0] = 0;
    g_javaHoverTime = 0;
}

void JavaClearContext() {
    JavaEnsureCs();
    EnterCriticalSection(&g_javaCs);
    JavaClearContextLocked();
    LeaveCriticalSection(&g_javaCs);
}

bool JavaReadMsvcString(const void* address, char* out, size_t outCap) {
    if (!address || !out || outCap < 2 ||
        !GuiRangeReadable(address, sizeof(JavaMsvcString))) return false;

    JavaMsvcString value{};
    NF_GUI_TRY {
        std::memcpy(&value, address, sizeof(value));
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }

    // Release MSVC std::string uses capacity 15 for its inline buffer. Be
    // conservative: an unknown layout is a reason to turn the feature off,
    // not a reason to follow an arbitrary heap pointer.
    if (value.size > 255 || value.capacity < value.size || value.capacity > (1u << 20))
        return false;
    const char* data = value.capacity <= 15 ? value.storage.local : value.storage.heap;
    if (!data || !GuiRangeReadable(data, value.size + 1)) return false;

    NF_GUI_TRY {
        for (size_t i = 0; i < value.size; ++i) {
            if (data[i] == 0) return false;
            if (i + 1 >= outCap) return false;
            out[i] = data[i];
        }
        out[value.size] = 0;
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
    return true;
}

bool JavaMakeMsvcString(const char* text, JavaMsvcString& out) {
    if (!text) return false;
    const size_t length = std::strlen(text);
    // inventory_items is exactly 15 bytes; keep the bridge SSO-only so the
    // game never tries to destroy memory owned by the DLL's CRT.
    if (length > 15) return false;
    std::memset(&out, 0, sizeof(out));
    std::memcpy(out.storage.local, text, length);
    out.storage.local[length] = 0;
    out.size = length;
    out.capacity = 15;
    return true;
}

bool JavaValidSource(const char* collection, int slot) {
    if (!collection || slot < 0) return false;
    if (std::strcmp(collection, "hotbar_items") == 0)
        return slot < 9;
    if (std::strcmp(collection, "inventory_items") == 0)
        return slot < 27;

    // Flarial's controller path also supports ordinary item containers
    // (chests, furnaces, etc.) and recipe output collections. Keep search and
    // creative/browser collections out of the operation; their slots do not
    // represent the server-backed standard inventory path.
    const std::string_view name(collection);
    if (name.find("search") != std::string_view::npos ||
        name.find("creative") != std::string_view::npos)
        return false;
    if (name.find("_output") != std::string_view::npos)
        return slot < 64;
    if (name.find("_items") != std::string_view::npos)
        return slot < 256;
    if (name.find("recipe_") != std::string_view::npos)
        return slot < 64;
    return false;
}

// Flarial parity: their container tick listener does not probe UI screens -
// the tick firing at all means a container controller exists. Here the same
// fact comes from the tick watchdog in JavaEnqueueSlotMove; this probe only
// logs the UI layer once per session for diagnostics.
static void JavaLogScreenLayerOnce() {
    if (InterlockedCompareExchange(&g_javaScreenProbeLogged, 1, 0) != 0) return;
    if (!g_screenView || !LooksLikeGuiObject(g_screenView)) {
        LOG_INFO("java-hotkeys: diagnostics: no ScreenView captured on this build");
        return;
    }
    const uintptr_t screen = reinterpret_cast<uintptr_t>(g_screenView);
    if (!GuiRangeReadable(reinterpret_cast<const void*>(screen + 0x48), sizeof(void*)))
        return;
    void* visualTree = nullptr;
    NF_GUI_TRY {
        visualTree = *reinterpret_cast<void**>(screen + 0x48);
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) { return; }
    if (!visualTree || !GuiRangeReadable(reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(visualTree) + 0x8), sizeof(void*)))
        return;
    void* root = nullptr;
    NF_GUI_TRY {
        root = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(visualTree) + 0x8);
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) { return; }
    if (!root || !GuiRangeReadable(root, sizeof(void*))) return;
    const uintptr_t rootBase = reinterpret_cast<uintptr_t>(root);
    const size_t layerOffsets[] = { 0x20, 0x18 };
    for (const size_t offset : layerOffsets) {
        char candidate[64] = {};
        if (!JavaReadMsvcString(reinterpret_cast<const void*>(rootBase + offset),
                                candidate, sizeof(candidate)))
            continue;
        LOG_INFO("java-hotkeys: diagnostics: UI layer '%s'", candidate);
        return;
    }
    LOG_INFO("java-hotkeys: diagnostics: UI layer unreadable");
}

std::string JavaTrimOption(std::string value) {
    const size_t first = value.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    const size_t last = value.find_last_not_of(" \t\r\n");
    value = value.substr(first, last - first + 1);
    if (value.size() >= 2 && value.front() == '"' && value.back() == '"')
        value = value.substr(1, value.size() - 2);
    return value;
}

bool JavaReadOptionsFile(const std::wstring& path, std::string& output) {
    HANDLE file = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                              nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) return false;

    LARGE_INTEGER length{};
    bool ok = GetFileSizeEx(file, &length) && length.QuadPart >= 0 && length.QuadPart <= (1ll << 20);
    if (ok) {
        output.assign(static_cast<size_t>(length.QuadPart), '\0');
        DWORD read = 0;
        if (!output.empty()) ok = ReadFile(file, output.data(), static_cast<DWORD>(output.size()), &read, nullptr) != FALSE &&
                                     read == output.size();
    }
    CloseHandle(file);
    if (!ok) output.clear();
    return ok;
}

std::wstring JavaLocalAppData() {
    wchar_t buffer[32768] = {};
    const DWORD capacity = static_cast<DWORD>(sizeof(buffer) / sizeof(buffer[0]));

    // Match config::Init: inside the packaged Bedrock process LOCALAPPDATA
    // may be redirected into AC. Derive the real profile-local root from
    // APPDATA first so options.txt is read from the package LocalState tree.
    DWORD length = GetEnvironmentVariableW(L"APPDATA", buffer, capacity);
    if (length && length < capacity) {
        std::wstring appData(buffer, length);
        const std::wstring roaming = L"\\Roaming";
        if (appData.size() > roaming.size() &&
            _wcsicmp(appData.c_str() + appData.size() - roaming.size(), roaming.c_str()) == 0)
            return appData.substr(0, appData.size() - roaming.size()) + L"\\Local";
    }

    length = GetEnvironmentVariableW(L"LOCALAPPDATA", buffer, capacity);
    if (length && length < capacity) {
        std::wstring local(buffer, length);
        if (local.find(L"\\Microsoft.MinecraftUWP_8wekyb3d8bbwe\\AC\\") == std::wstring::npos)
            return local;
    }
    return {};
}

void JavaLoadOptions() {
    int type0[9];
    int type1[9];
    for (int i = 0; i < 9; ++i) { type0[i] = -1; type1[i] = -1; }
    int fullKeyboard = -1;
    std::string contents;
    bool read = false;

    std::vector<std::wstring> optionPaths;
    const std::wstring local = JavaLocalAppData();
    if (!local.empty()) {
        const wchar_t* suffixes[] = {
            L"\\Packages\\Microsoft.MinecraftUWP_8wekyb3d8bbwe\\LocalState\\games\\com.mojang\\minecraftpe\\options.txt",
            L"\\Packages\\Microsoft.MinecraftWindowsBeta_8wekyb3d8bbwe\\LocalState\\games\\com.mojang\\minecraftpe\\options.txt",
            L"\\Packages\\Microsoft.MinecraftPreview_8wekyb3d8bbwe\\LocalState\\games\\com.mojang\\minecraftpe\\options.txt",
            L"\\Minecraft Bedrock\\Users\\Shared\\games\\com.mojang\\minecraftpe\\options.txt"
        };
        for (const wchar_t* suffix : suffixes) optionPaths.push_back(local + suffix);
    }

    // The config resolver now targets ...\\RoamingState\\Nightfull. Derive
    // the sibling package LocalState from that already-proven path as a
    // second candidate; this works even when AppContainer environment
    // variables are redirected.
    const std::wstring configBase = config::baseDir();
    const std::wstring roamingMarker = L"\\RoamingState\\Nightfull";
    const size_t marker = configBase.rfind(roamingMarker);
    if (marker != std::wstring::npos) {
        const std::wstring packageRoot = configBase.substr(0, marker);
        optionPaths.push_back(packageRoot + L"\\LocalState\\games\\com.mojang\\minecraftpe\\options.txt");
    }

    for (const std::wstring& path : optionPaths) {
        if (JavaReadOptionsFile(path, contents)) { read = true; break; }
    }

    if (read) {
        std::istringstream lines(contents);
        std::string line;
        while (std::getline(lines, line)) {
            const size_t colon = line.find(':');
            if (colon == std::string::npos) continue;
            const std::string key = JavaTrimOption(line.substr(0, colon));
            const std::string value = JavaTrimOption(line.substr(colon + 1));
            if (key == "ctrl_fullkeyboardgameplay") {
                fullKeyboard = std::strcmp(value.c_str(), "1") == 0 ? 1 : 0;
                continue;
            }
            int kind = -1;
            const char* prefix0 = "keyboard_type_0_key.hotbar.";
            const char* prefix1 = "keyboard_type_1_key.hotbar.";
            if (key.rfind(prefix0, 0) == 0) kind = 0;
            else if (key.rfind(prefix1, 0) == 0) kind = 1;
            if (kind < 0) continue;
            const size_t prefixLength = kind == 0 ? std::strlen(prefix0) : std::strlen(prefix1);
            const char* suffix = key.c_str() + prefixLength;
            char* end = nullptr;
            const long oneBased = std::strtol(suffix, &end, 10);
            if (!end || *end != 0 || oneBased < 1 || oneBased > 9) continue;
            char* valueEnd = nullptr;
            const long code = std::strtol(value.c_str(), &valueEnd, 10);
            // Mouse binds are stored as negative codes (Flarial maps mouse
            // button b to -100 + b), so the accepted range spans both.
            if (!valueEnd || *valueEnd != 0 || code < -128 || code > 255) continue;
            (kind == 0 ? type0 : type1)[oneBased - 1] = static_cast<int>(code);
        }
    }

    const bool useType1 = fullKeyboard == 1;
    int found = 0;
    JavaEnsureCs();
    EnterCriticalSection(&g_javaCs);
    for (int i = 0; i < 9; ++i) {
        g_javaHotbarKeys[i] = useType1 ? type1[i] : type0[i];
        if (g_javaHotbarKeys[i] != -1) ++found;   // -1 = unbound; mouse codes are negative
    }
    g_javaBindingsLoaded = read && found > 0;
    LeaveCriticalSection(&g_javaCs);

    LOG_INFO("java-hotkeys: options read=%d type=%d bindings=%d", read ? 1 : 0,
             useType1 ? 1 : 0, found);
}

void JavaLoadServerHint() {
    // The target source has no verified 1.21.111 server-string accessor. Do
    // not guess one from Flarial's private offsets. A deployment-specific,
    // verified adapter may populate NIGHTFULL_SERVER_HOST; when present we
    // retain the upstream NetherGames deny rule, never a new allow-list.
    char host[sizeof(g_javaServerHost)] = {};
    const DWORD length = GetEnvironmentVariableA("NIGHTFULL_SERVER_HOST", host,
                                                 static_cast<DWORD>(sizeof(host)));
    JavaEnsureCs();
    EnterCriticalSection(&g_javaCs);
    std::memset(g_javaServerHost, 0, sizeof(g_javaServerHost));
    if (length && length < sizeof(g_javaServerHost))
        std::memcpy(g_javaServerHost, host, length);
    g_javaRestrictionLogged = false;
    LeaveCriticalSection(&g_javaCs);
}

bool JavaServerRestricted() {
    char host[sizeof(g_javaServerHost)] = {};
    JavaEnsureCs();
    EnterCriticalSection(&g_javaCs);
    std::memcpy(host, g_javaServerHost, sizeof(host));
    LeaveCriticalSection(&g_javaCs);
    if (!host[0]) return false;

    for (char& ch : host) {
        if (ch >= 'A' && ch <= 'Z') ch = static_cast<char>(ch - 'A' + 'a');
    }
    const bool restricted = std::strstr(host, "nethergames") != nullptr;
    if (restricted) {
        JavaEnsureCs();
        EnterCriticalSection(&g_javaCs);
        if (!g_javaRestrictionLogged) {
            LOG_INFO("java-hotkeys: upstream NetherGames restriction active");
            g_javaRestrictionLogged = true;
        }
        LeaveCriticalSection(&g_javaCs);
    }
    return restricted;
}

int JavaFindDestination(int key) {
    JavaEnsureCs();
    EnterCriticalSection(&g_javaCs);
    int destination = -1;
    if (g_javaBindingsLoaded) {
        for (int slot = 0; slot < 9; ++slot) {
            if (g_javaHotbarKeys[slot] == static_cast<int>(key)) {
                destination = slot;
                break;
            }
        }
    }
    LeaveCriticalSection(&g_javaCs);
    return destination;
}

void JavaRecordHover(void* controller, const JavaMsvcString* collectionName, int64_t slot) {
    if (!JavaIsEnabled()) return;
    // The hover callback is the authoritative live-controller boundary. Keep
    // the slot context here even during a render-tree transition; the screen
    // and focus gates are revalidated immediately before execution.
    if (!controller || !LooksLikeGuiObject(controller) || slot < 0 || slot > 255) {
        JavaClearContext();
        return;
    }

    char collection[32] = {};
    if (!JavaReadMsvcString(collectionName, collection, sizeof(collection)) ||
        !collection[0]) {
        JavaClearContext();
        return;
    }

    JavaEnsureCs();
    EnterCriticalSection(&g_javaCs);
    if (g_javaHoveredController != controller) JavaClearContextLocked();
    g_javaHoveredController = controller;
    g_javaHoveredScreenView = g_screenView;
    g_javaHoveredSlot = static_cast<int>(slot);
    std::strncpy(g_javaHoveredCollection, collection, sizeof(g_javaHoveredCollection) - 1);
    g_javaHoveredCollection[sizeof(g_javaHoveredCollection) - 1] = 0;
    g_javaHoverTime = GetTickCount64();
    LeaveCriticalSection(&g_javaCs);
}

// Shared enqueue for hotbar-slot hotkeys (Flarial's MoveRequest queue).
// heldIndex >= 0 enables the auto-repeat guard for keyboard keys; mouse
// buttons never auto-repeat and pass -1.
static void JavaEnqueueSlotMove(int code, int heldIndex) {
    if (!JavaIsEnabled()) return;

    JavaEnsureCs();
    if (g_showMenu) {
        JavaClearContext();
        return;
    }
    // Flarial has no hover freshness window: the last hovered slot stays
    // valid until another hover event or a controller change. The only
    // staleness guard is the container tick watchdog - the controller tick
    // fires every frame while a container is open, so a stale timestamp
    // means no container screen exists (their hud_screen clear equivalent).
    const ULONGLONG now = GetTickCount64();
    // Container watchdog: live ticks (mid-container) or a fresh hover (the
    // first instants after opening, before the first tick) allow queueing;
    // the request is still only consumed by a live matching controller tick.
    const bool containerAlive =
        g_javaLastTickAt != 0 && now - g_javaLastTickAt <= 500;
    const bool hoverFresh = g_javaHoverTime != 0 && now - g_javaHoverTime <= 750;
    if (!containerAlive && !hoverFresh)
        return;

    const int destination = JavaFindDestination(code);
    JavaMoveRequest request{};
    bool accepted = false;
    const char* reject = nullptr;
    EnterCriticalSection(&g_javaCs);
    bool fresh = true;
    if (heldIndex >= 0) {
        fresh = !g_javaHeld[heldIndex];
        g_javaHeld[heldIndex] = true;
    }
    if (!fresh) {
        reject = "repeat";
    } else if (destination < 0) {
        reject = "no-bind";
    } else if (!g_javaHoveredController) {
        reject = "no-hover";
    } else if (!JavaValidSource(g_javaHoveredCollection, g_javaHoveredSlot)) {
        reject = "source";
    } else if (std::strcmp(g_javaHoveredCollection, "hotbar_items") == 0 &&
               g_javaHoveredSlot == destination) {
        reject = "same-slot";
    } else if (g_javaRequestCount >= 8) {
        reject = "queue-full";
    } else {
        request.controller = g_javaHoveredController;
        request.destination = destination;
        request.source = g_javaHoveredSlot;
        std::strncpy(request.collection, g_javaHoveredCollection, sizeof(request.collection) - 1);
        request.collection[sizeof(request.collection) - 1] = 0;
        request.created = now;
        const int index = (g_javaRequestHead + g_javaRequestCount) % 8;
        g_javaRequests[index] = request;
        ++g_javaRequestCount;
        accepted = true;
    }
    LeaveCriticalSection(&g_javaCs);

    if (accepted) {
        LOG_INFO("java-hotkeys: queued source=%s:%d destination=hotbar_items:%d",
                 request.collection, request.source, request.destination);
    } else if (destination >= 0 && reject) {
        // Rate-limited rejection diagnostics so a dead path is visible.
        static ULONGLONG nextRejectLog = 0;
        if (now >= nextRejectLog) {
            nextRejectLog = now + 2000;
            LOG_INFO("java-hotkeys: press code=%d rejected (%s) hover='%s':%d",
                     code, reject, g_javaHoveredCollection, g_javaHoveredSlot);
        }
    }
}

void JavaHandleKeyFeed(uint32_t key, bool isDown) {
    if (!JavaIsEnabled() || key >= 256) return;

    JavaEnsureCs();
    if (!isDown) {
        EnterCriticalSection(&g_javaCs);
        g_javaHeld[key] = false;
        LeaveCriticalSection(&g_javaCs);
        return;
    }
    JavaEnqueueSlotMove(static_cast<int>(key), static_cast<int>(key));
}

// Flarial parity: hotbar binds may point at mouse buttons. Their code is
// -100 + the MouseDevice::feed button value (Left=-99, Right=-98, Middle=-97,
// X1=-95, X2=-94). Wheel (4) and motion (0) are not buttons.
void JavaHandleMouseFeed(int mouseButton) {
    if (!JavaIsEnabled()) return;
    if (mouseButton <= 0 || mouseButton == 4) return;
    const int code = -100 + mouseButton;
    if (code < -128) return;
    JavaEnqueueSlotMove(code, -1);
}

// Minecraft build as "1.21.<patch>" (Minecraft.Windows.exe FileVersion is
// 1.21.PPPRR.0, e.g. 1.21.11401 = 1.21.114). 0 = unknown.
static int JavaGamePatch() {
    static int s_patch = -1;
    if (s_patch >= 0) return s_patch;
    s_patch = 0;
    wchar_t path[MAX_PATH] = {};
    if (!GetModuleFileNameW(nullptr, path, MAX_PATH)) return s_patch;
    DWORD handle = 0;
    const DWORD size = GetFileVersionInfoSizeW(path, &handle);
    if (!size || size > (1u << 20)) return s_patch;
    std::vector<unsigned char> buf(size);
    VS_FIXEDFILEINFO* info = nullptr;
    UINT len = 0;
    if (GetFileVersionInfoW(path, 0, size, buf.data()) &&
        VerQueryValueW(buf.data(), L"\\", reinterpret_cast<void**>(&info), &len) &&
        info && len >= sizeof(VS_FIXEDFILEINFO)) {
        const unsigned major = HIWORD(info->dwFileVersionMS);
        const unsigned minor = LOWORD(info->dwFileVersionMS);
        const unsigned build = HIWORD(info->dwFileVersionLS);
        if (major == 1 && minor == 21) s_patch = (int)(build >= 1000 ? build / 100 : build);
        LOG_INFO("java-hotkeys: game version %u.%u.%u -> patch %d", major, minor, build, s_patch);
    }
    return s_patch;
}

// Flarial OffsetInit: ContainerScreenController::_handlePlaceAll vtable slot
// init2130 = 56, init21110 = 57, init21130 = 54 (_handlePlaceOne = +1).
// Calling the PlaceOne slot by mistake is exactly the "only one item of the
// stack reaches the hotbar" bug, so the slot follows the running build.
static size_t JavaPlaceAllSlot() {
    const int patch = JavaGamePatch();
    if (patch >= 130) return 54;
    if (patch >= 110 || patch == 0) return 57;
    if (patch >= 30) return 56;
    return 57;
}

bool JavaContainerSwap(void* controller, const char* collection, int source, int destination) {
    if (!controller || !JavaValidSource(collection, source) || destination < 0 || destination > 8 ||
        !LooksLikeGuiObject(controller)) return false;

    const uintptr_t object = reinterpret_cast<uintptr_t>(controller);
    uintptr_t vft = 0;
    if (!GuiRangeReadable(reinterpret_cast<const void*>(object), sizeof(void*))) return false;
    NF_GUI_TRY {
        vft = *reinterpret_cast<const uintptr_t*>(object);
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }

    // Flarial's ContainerScreenController on 1.21.11X:
    //   _handlePlaceAll = vtable slot 57 (their OffsetInit::init21110),
    //   _handleTakeAll  = resolved from the 1.21.11X call-site signature,
    // NOT vtable slot 56 - calling slot 56 silently did nothing, which is
    // exactly the "hook fires, items never move" symptom.
    const size_t kPlaceAllSlot = JavaPlaceAllSlot();
    if (!vft ||
        !GuiRangeReadable(reinterpret_cast<const void*>(vft + kPlaceAllSlot * sizeof(void*)), sizeof(void*)))
        return false;

    static uintptr_t s_takeAddress = 0;
    static bool s_takeResolved = false;
    if (!s_takeResolved) {
        s_takeResolved = true;
        uintptr_t site = 0;
        const int matches = ScanSigMatches(
            GetModuleHandleW(nullptr),
            "E8 ? ? ? ? 48 8B 46 ? C6 80 ? ? ? ? ? 48 8B 7E", site);
        if (matches == 1 && site) {
            const uintptr_t target =
                site + 5 + (uintptr_t)(int32_t)*(const int32_t*)(site + 1);
            if (JavaIsGameCodeAddress(target)) s_takeAddress = target;
        }
        LOG_INFO("java-hotkeys: _handleTakeAll resolved=%p matches=%d",
                 (void*)s_takeAddress, matches);
    }

    uintptr_t placeAddress = 0;
    NF_GUI_TRY {
        placeAddress = *reinterpret_cast<const uintptr_t*>(vft + kPlaceAllSlot * sizeof(void*));
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
    if (!s_takeAddress || !JavaIsGameCodeAddress(placeAddress)) return false;

    const JavaContainerTakeAllFn takeAll = reinterpret_cast<JavaContainerTakeAllFn>(s_takeAddress);
    const JavaContainerPlaceAllFn placeAll = reinterpret_cast<JavaContainerPlaceAllFn>(placeAddress);
    JavaMsvcString sourceName{};
    JavaMsvcString hotbarName{};
    if (!JavaMakeMsvcString(collection, sourceName) ||
        !JavaMakeMsvcString("hotbar_items", hotbarName)) return false;

    // Flarial ContainerScreenController::swap, verbatim sequence:
    //   take(src) -> placeAll(hotbar, dst) -> placeAll(src)
    // The previous build branched on _isCursorSelectedActive() to detect an
    // empty source. That function reports the GAMEPAD cursor selection mode,
    // not "the mouse holds an item", so on keyboard+mouse it stays false and
    // the "empty source" branch ran for every stack: take(src) lifted the
    // whole stack, take(hotbar) then dropped ONE item into the hotbar slot and
    // the rest went back into the source slot. That was the one-item bug.
    // The plain sequence below is correct for full and partial stacks and
    // for an occupied hotbar slot (the two stacks swap).
    const bool output = std::strstr(collection, "_output") != nullptr;
    JavaMsvcString sourceNameAgain{};
    if (!output && !JavaMakeMsvcString(collection, sourceNameAgain)) return false;
    NF_GUI_TRY {
        takeAll(controller, sourceName, source);
        placeAll(controller, hotbarName, destination);
        // Output slots are consumed into the hotbar and have no source stack
        // to exchange back into.
        if (!output) placeAll(controller, sourceNameAgain, source);
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
    return true;
}

void JavaProcessContainerTick(void* controller) {
    if (!JavaIsEnabled()) return;
    if (!controller) return;
    // Flarial's onContainerTick has no UI-screen probe: the container tick
    // firing means a ContainerScreenController is alive. The timestamp feeds
    // the enqueue watchdog (no tick for 500 ms = no container = stale).
    g_javaLastTickAt = GetTickCount64();
    JavaLogScreenLayerOnce();
    if (JavaServerRestricted()) {
        JavaClearContext();
        return;
    }

    JavaMoveRequest request{};
    bool haveRequest = false;
    JavaEnsureCs();
    EnterCriticalSection(&g_javaCs);
    if (controller != g_javaHoveredController) {
        JavaClearContextLocked();
        LeaveCriticalSection(&g_javaCs);
        return;
    }
    if (g_javaRequestCount > 0) {
        request = g_javaRequests[g_javaRequestHead];
        g_javaRequests[g_javaRequestHead] = JavaMoveRequest{};
        g_javaRequestHead = (g_javaRequestHead + 1) % 8;
        --g_javaRequestCount;
        haveRequest = true;
    }
    LeaveCriticalSection(&g_javaCs);
    if (!haveRequest || request.controller != controller) return;

    const ULONGLONG now = GetTickCount64();
    if (now < request.created || now - request.created > 750 ||
        !JavaValidSource(request.collection, request.source)) return;

    if (JavaContainerSwap(controller, request.collection, request.source, request.destination)) {
        LOG_INFO("java-hotkeys: swap source=%s:%d destination=hotbar_items:%d",
                 request.collection, request.source, request.destination);
    } else {
        LOG_INFO("java-hotkeys: swap refused by validated controller ABI");
    }
}

bool JavaIsGameCodeAddress(uintptr_t address) {
    if (!address || !g_gameImageBase || address < g_gameImageBase ||
        address >= g_gameImageBase + g_gameImageSize || !GuiPageReadable(reinterpret_cast<const void*>(address)))
        return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if (!VirtualQuery(reinterpret_cast<const void*>(address), &mbi, sizeof(mbi))) return false;
    const DWORD executable = PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
    return (mbi.Protect & executable) != 0;
}

bool JavaResolveCallTarget(uintptr_t callSite, uintptr_t& target) {
    target = 0;
    if (!callSite || !GuiRangeReadable(reinterpret_cast<const void*>(callSite), 5)) return false;
    int32_t relative = 0;
    NF_GUI_TRY {
        std::memcpy(&relative, reinterpret_cast<const void*>(callSite + 1), sizeof(relative));
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
    const intptr_t resolved = static_cast<intptr_t>(callSite) + 5 + relative;
    if (resolved <= 0 || !JavaIsGameCodeAddress(static_cast<uintptr_t>(resolved)))
        return false;
    target = static_cast<uintptr_t>(resolved);
    return true;
}

int64_t __fastcall HkJavaContainerHover(void* controller, const JavaMsvcString* collectionName,
                                        int64_t slot) {
    if (JavaIsEnabled()) {
        const LONG callbacks = InterlockedIncrement(&g_javaHoverCallbacks);
        if (callbacks == 1) {
            char collection[32] = {};
            const bool readable = JavaReadMsvcString(collectionName, collection, sizeof(collection));
            LOG_INFO("java-hotkeys: first hover callback controller=%p slot=%lld collection='%s' readable=%d",
                     controller, (long long)slot, readable ? collection : "<unreadable>",
                     readable ? 1 : 0);
        }
    }
    JavaRecordHover(controller, collectionName, slot);
    if (JavaIsEnabled()) {
        // Drain from the live hover/controller path on every callback. The
        // normal tick hook may also consume the request first; the queue is
        // single-consumer, so this fallback is harmless and covers binaries
        // where the matched tick call-site is not dispatched for this UI.
        JavaProcessContainerTick(controller);
    }
    JavaContainerHoverFn original = g_oJavaContainerHover;
    return original ? original(controller, collectionName, slot) : 0;
}

uint32_t __fastcall HkJavaContainerTick(void* controller) {
    if (JavaIsEnabled()) InterlockedExchange(&g_javaTickSeen, 1);
    JavaProcessContainerTick(controller);
    JavaContainerTickFn original = g_oJavaContainerTick;
    return original ? original(controller) : 0;
}

void TryInstallJavaInventoryHooks() {
    if (g_javaHooksTried) return;
    g_javaHooksTried = true;

    HMODULE game = GetModuleHandleW(nullptr);
    CacheGuiGameImage();
    // The hover boundary is the reliable live-controller boundary on this
    // build. It is the required hook. The old take-all call-site target is not
    // used: the callable handlers are read from the validated controller
    // vtable at the moment of the queued swap.
    static const char kHoverSig[] =
        "48 89 5C 24 10 48 89 6C 24 18 48 89 7C 24 20 41 56 48 83 EC 20 45 33 F6 41 8B E8";
    static const char kTickSig[] =
        "E8 ? ? ? ? 48 8B 8B ? ? ? ? 48 8D 93 ? ? ? ? 41 B0";

    uintptr_t hover = 0;
    const int hoverMatches = ScanSigMatches(game, kHoverSig, hover);
    if (hoverMatches != 1 || !hover) {
        LOG_INFO("java-hotkeys: hooks off hover=%d", hoverMatches);
        return;
    }

    // Tick is optional. Some 1.21.111 binaries contain a unique call-site
    // match that is never dispatched for the active controller; the hover
    // callback below remains the safe execution fallback in that case.
    uintptr_t tickSite = 0;
    uintptr_t tick = 0;
    const int tickMatches = ScanSigMatches(game, kTickSig, tickSite);
    const bool tickReady = tickMatches == 1 && JavaResolveCallTarget(tickSite, tick) && tick && tick != hover;

    MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) {
        LOG_INFO("java-hotkeys: MinHook init failed status=%d", (int)init);
        return;
    }

    MH_STATUS status = MH_CreateHook(reinterpret_cast<LPVOID>(hover),
                                     reinterpret_cast<LPVOID>(&HkJavaContainerHover),
                                     reinterpret_cast<LPVOID*>(&g_oJavaContainerHover));
    if (status != MH_OK || !g_oJavaContainerHover) {
        LOG_INFO("java-hotkeys: hover hook create failed status=%d", (int)status);
        return;
    }

    bool tickCreated = false;
    if (tickReady) {
        status = MH_CreateHook(reinterpret_cast<LPVOID>(tick),
                               reinterpret_cast<LPVOID>(&HkJavaContainerTick),
                               reinterpret_cast<LPVOID*>(&g_oJavaContainerTick));
        tickCreated = status == MH_OK && g_oJavaContainerTick;
        if (!tickCreated)
            LOG_INFO("java-hotkeys: optional tick hook unavailable status=%d", (int)status);
    }

    const MH_STATUS hoverEnable = MH_EnableHook(reinterpret_cast<LPVOID>(hover));
    if (hoverEnable != MH_OK) {
        MH_RemoveHook(reinterpret_cast<LPVOID>(hover));
        if (tickCreated) MH_RemoveHook(reinterpret_cast<LPVOID>(tick));
        g_oJavaContainerHover = nullptr;
        g_oJavaContainerTick = nullptr;
        LOG_INFO("java-hotkeys: hover hook enable failed status=%d", (int)hoverEnable);
        return;
    }

    MH_STATUS tickEnable = MH_OK;
    if (tickCreated) {
        tickEnable = MH_EnableHook(reinterpret_cast<LPVOID>(tick));
        if (tickEnable != MH_OK) {
            MH_RemoveHook(reinterpret_cast<LPVOID>(tick));
            g_oJavaContainerTick = nullptr;
            tickCreated = false;
            LOG_INFO("java-hotkeys: optional tick hook enable failed status=%d; hover fallback retained",
                     (int)tickEnable);
        }
    }

    g_javaTakeAll = nullptr;
    g_javaHoverAddress = hover;
    g_javaTickAddress = tickCreated ? tick : 0;
    g_javaHooksActive = true;
    LOG_INFO("java-hotkeys: controller hooks active hover=%p tick=%p takeAll=sig placeAllVft=%d",
             reinterpret_cast<void*>(hover),
             reinterpret_cast<void*>(g_javaTickAddress), (int)JavaPlaceAllSlot());
}

bool LooksLikeGuiData(const void* data) {
    const uintptr_t base = reinterpret_cast<uintptr_t>(data);
    if (!data || !GuiRangeReadable(reinterpret_cast<const void*>(base + 0x40), 8) ||
        !GuiRangeReadable(reinterpret_cast<const void*>(base + 0x5C), 8))
        return false;
    NF_GUI_TRY {
        const float scale = *reinterpret_cast<const float*>(reinterpret_cast<uintptr_t>(data) + 0x5C);
        const float rx = *reinterpret_cast<const float*>(reinterpret_cast<uintptr_t>(data) + 0x40);
        const float ry = *reinterpret_cast<const float*>(reinterpret_cast<uintptr_t>(data) + 0x44);
        return std::isfinite(scale) && scale > 0.05f && scale < 20.0f &&
               std::isfinite(rx) && std::isfinite(ry) && rx > 1.0f && ry > 1.0f &&
               rx < 100000.0f && ry < 100000.0f;
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

bool RawApplyGameGuiScale(float target) {
    const uintptr_t base = reinterpret_cast<uintptr_t>(g_guiData);
    if (!g_guiData || target < 1.0f || target > 4.0f || !LooksLikeGuiData(g_guiData) ||
        !GuiRangeReadable(reinterpret_cast<const void*>(base + 0x40), 8) ||
        !GuiRangeWritable(reinterpret_cast<const void*>(base + 0x48), 28)) return false;
    NF_GUI_TRY {
        float* scale = reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x5C);
        const float current = *scale;
        if (!(current > 0.05f && current < 20.0f)) return false;
        *scale = target;                                      // GuiData::mGuiScale
        *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x60) = 1.0f / target;
        float rx = *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x40);
        float ry = *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x44);
        if (rx <= 1.0f || ry <= 1.0f) {
            const ImVec2 screen = gui::GetScreenSize();
            rx = screen.x; ry = screen.y;
        }
        // Keep GuiData::mResolutionRounded coherent with mResolution. A
        // stale rounded pair is what makes Bedrock anchor scaled controls at
        // the upper-left when the target scale is below the vanilla value.
        *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x48) = std::round(rx);
        *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x4C) = std::round(ry);
        *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x50) = rx / target;
        *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x54) = ry / target;
        LOG_INFO("guiscale: raw GuiData %.2f -> %.2f", current, target);
        return true;
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        LOG_ERROR("guiscale: guarded GuiData write failed");
        return false;
    }
}

using SetupAndRenderFn = void(__fastcall*)(void*, void*);
SetupAndRenderFn g_oSetupAndRender = nullptr;
using GetPositionFn = void*(__fastcall*)(void*);

bool WalkGuiControl(void* control, int depth, int& visited) {
    const uintptr_t base = reinterpret_cast<uintptr_t>(control);
    if (!control || depth > 128 || visited >= 262144 || !LooksLikeGuiObject(control) ||
        !GuiRangeWritable(reinterpret_cast<const void*>(base + 0x18), sizeof(int)) ||
        !GuiRangeReadable(reinterpret_cast<const void*>(base + 0x90), 16)) return false;
    ++visited;
    NF_GUI_TRY {
        // 1.21.11X UIControl layout: cached-position dirty flag at +0x18.
        *reinterpret_cast<int*>(base + 0x18) |= 1;
#if defined(_MSC_VER)
        // The MSVC build calls the validated Flarial getPosition target.
        if (g_getPositionFn)
            reinterpret_cast<GetPositionFn>(g_getPositionFn)(control);
#else
        // MinGW waits until the updateScreen call has passed its live
        // GuiData proof; only then does it use the exact unique Flarial
        // getPosition candidate instead of relying on dirty flags alone.
        if (g_screenSizeCallProved && g_getPositionFn)
            reinterpret_cast<GetPositionFn>(g_getPositionFn)(control);
#endif
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
    NF_GUI_TRY {
        // UIControl::children is std::vector<shared_ptr<UIControl>> at +0x90.
        void** begin = *reinterpret_cast<void***>(reinterpret_cast<uintptr_t>(control) + 0x90);
        void** end = *reinterpret_cast<void***>(reinterpret_cast<uintptr_t>(control) + 0x98);
        if (!begin) return true;
        if (end < begin || (end - begin) > 8192 ||
            !GuiPageReadable(begin) || (end > begin && !GuiPageReadable(end - 1)))
            return false;
        for (void** it = begin; it != end; ++it) {
            void* child = *it;
            if (child && !WalkGuiControl(child, depth + 1, visited)) return false;
        }
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
    return true;
}

bool RelayoutGuiTree() {
    if (!g_screenView || !LooksLikeGuiObject(g_screenView) ||
        !GuiRangeReadable(reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(g_screenView) + 0x48), sizeof(void*)))
        return false;
    NF_GUI_TRY {
        // 1.21.11X ScreenView::visualTree and VisualTree::root.
        void* visualTree = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(g_screenView) + 0x48);
        if (!visualTree || !GuiRangeReadable(reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(visualTree) + 0x8), sizeof(void*)))
            return false;
        void* root = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(visualTree) + 0x8);
        if (!root) return false;
        int visited = 0;
        return WalkGuiControl(root, 0, visited);
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

void TrackGuiRelayout(bool ok) {
    if (ok) {
        g_guiScaleRelayoutPending = false;
        g_guiScaleRelayoutFails = 0;
        return;
    }
    g_guiScaleRelayoutPending = true;
    if (++g_guiScaleRelayoutFails == 1 || g_guiScaleRelayoutFails % 300 == 0)
        LOG_INFO("guiscale: UI tree relayout deferred (%d tries)", g_guiScaleRelayoutFails);
    if (g_guiScaleRelayoutFails >= 600) {
        g_guiScaleRelayoutPending = false;
        g_guiScaleRelayoutFails = 0;
    }
}

void RelayoutAfterScale() {
    // Rate limit: when the relayout keeps failing, this used to be reached
    // every frame and each RelayoutGuiTree could walk up to 262144 controls -
    // the "GUI scale changed and everything froze" spike. One attempt per
    // 250 ms keeps the same retry semantics (TrackGuiRelayout still owns the
    // pending/fail tracking) without the per-frame tree walk.
    static ULONGLONG lastAttemptAt = 0;
    const ULONGLONG now = GetTickCount64();
    if (!g_setupAndRenderHook || !g_screenView) {
        g_guiScaleRelayoutPending = false;
        return;
    }
    if (lastAttemptAt != 0 && now - lastAttemptAt < 250u) return;
    lastAttemptAt = now;
    TrackGuiRelayout(RelayoutGuiTree());
}

void __fastcall HkSetupAndRender(void* screenView, void* muirc) {
    NF_GUI_TRY {
        if (screenView && LooksLikeGuiObject(screenView)) {
            const bool screenChanged = g_screenView && g_screenView != screenView;
            g_screenView = screenView;
            g_setupSeen = true;
            if (screenChanged && JavaIsEnabled()) JavaClearContext();
        }
        if (muirc && GuiPageReadable(muirc)) {
            void* client = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(muirc) + 0x8);
            if (client && LooksLikeGuiObject(client)) {
                g_clientInstance = client;
                void* guiData = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(client) + 0x578);
                if (LooksLikeGuiData(guiData)) {
                    if (g_guiData != guiData && g_savedGuiScaleValid)
                        g_savedGuiScaleValid = false;
                    g_guiData = guiData;
                }
            }
        }
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {}

    // Capture one immutable camera snapshot before the original setup call.
    // When the camera proof passes, the same pass also collects the actor
    // list and their AABBs (HitboxCaptureFrameSync) so the whole render packet
    // describes one instant of one frame - Flarial's SetupAndRenderEvent flow.
    HitboxFrameTransformSnapshot frame{};
    bool transformReady = false;
    if (g_clientInstance) {
        float origin[3] = {};
        float focalX = frame.focalX;
        float focalY = frame.focalY;
        const bool matrixOk =
            PotionReadBytes(reinterpret_cast<const void*>(
                                reinterpret_cast<uintptr_t>(g_clientInstance) + 0x348u),
                            frame.matrix, sizeof(frame.matrix)) &&
            HitboxMatPlausible(frame.matrix);
        const bool originOk = HitboxReadLevelCameraOrigin(origin, &focalX, &focalY);
        // Two fallbacks, cheapest and most trustworthy first. The local player's
        // own RenderPositionComponent needs no offsets and is the actor whose
        // reads are proven to work, so it is preferred over a matrix-derived eye
        // - that one is only valid when the matrix really is a view matrix, and
        // it silently produced a degenerate (0,0,0) camera when it was not.
        bool eyeOk = originOk;
        if (!eyeOk && HitboxEyeFromLocalPlayer(origin)) {
            eyeOk = true;
            static volatile LONG eyeLocalLogged = 0;
            if (InterlockedIncrement(&eyeLocalLogged) <= 3)
                LOG_INFO("hitboxes: camera eye from local player (%.2f,%.2f,%.2f)",
                         origin[0], origin[1], origin[2]);
        }
        if (!eyeOk && matrixOk && HitboxEyeFromViewMatrix(frame.matrix, origin)) {
            eyeOk = true;
            static volatile LONG eyeFallbackLogged = 0;
            if (InterlockedIncrement(&eyeFallbackLogged) <= 3)
                LOG_INFO("hitboxes: camera eye from view matrix (%.2f,%.2f,%.2f)",
                         origin[0], origin[1], origin[2]);
        }
        // Last resort: the eye we published a moment ago.
        //
        // The whole packet is only rebuilt when this function says the camera
        // is ready, so requiring a *fresh* eye proof every frame means a run of
        // failures freezes the packet - and because a frozen packet keeps its
        // "valid" flag, an empty one latched the module off until the eye
        // happened to resolve again. The matrix is what the projection needs and
        // it is re-proven above on every call; the eye only feeds distance
        // culling and the distance-scaled line width, so a slightly old one is
        // harmless. Observed: "frame transform skipped ... matrix=1 origin=0
        // eye=0" held for minutes while the boxes were gone.
        const bool retainedEye =
            !eyeOk && HitboxReadRetainedEye(origin, &focalX, &focalY);
        if (retainedEye) eyeOk = true;
        if (matrixOk && eyeOk) {
            std::memcpy(frame.origin, origin, sizeof(frame.origin));
            frame.focalX = focalX;
            frame.focalY = focalY;
            transformReady = true;
        } else {
            static ULONGLONG nextFrameTransformDiag = 0;
            const ULONGLONG now = GetTickCount64();
            if (now >= nextFrameTransformDiag) {
                nextFrameTransformDiag = now + 2000u;
                LOG_INFO("hitboxes: frame transform skipped client=%p levelRenderer=%p matrix=%d origin=%d eye=%d retainedEye=%d",
                         g_clientInstance, g_levelRenderer, matrixOk ? 1 : 0,
                         originOk ? 1 : 0, eyeOk ? 1 : 0, retainedEye ? 1 : 0);
            }
        }
    }

    if (transformReady) {
        // Flarial parity: the same setup pass that captures the camera also
        // collects the actor list and their lerped AABBs, so the box data and
        // the projection always come from one instant of one frame. The
        // Hitboxes render callback only draws this packet.
        HitboxCaptureFrameSync(frame);
        HitboxPublishLegacyView(frame);
        AcquireSRWLockExclusive(&g_hitboxActiveFrameLock);
        g_hitboxActiveFrame = frame;
        g_hitboxActiveFrameValid = true;
        g_hitboxActiveFrameAt = GetTickCount64();
        ReleaseSRWLockExclusive(&g_hitboxActiveFrameLock);
    } else {
        // No camera proof this frame: keep the previous packet visible with
        // the retained view (the legacy publish path holds the last good
        // matrix/eye), but refresh nothing. A cleared packet here would blink
        // every box whenever a single camera field read hiccups.
    }
    if (g_oSetupAndRender) g_oSetupAndRender(screenView, muirc);

    // This is only a worker wake/scheduling signal. No game/component/AABB
    // read is performed on the SetupAndRender or ImGui thread.
    InterlockedIncrement(&g_hitboxAabbUrgentGeneration);

    // setupAndRender runs on Bedrock's UI/render path. MSVC follows the
    // original Flarial timing and applies here; MinGW applies immediately
    // before Present to avoid re-entering this hook from the screen-size
    // relayout call, then the tree dirty flags are flushed here.
#ifdef _MSC_VER
    ApplyGameGuiScale();
#else
    if (g_guiScaleRelayoutPending) RelayoutAfterScale();
#endif
}

void TryInstallGuiTreeHooks(HMODULE game) {
    static const char* setupCandidates[] = {
        "48 8B C4 48 89 58 ? 55 56 57 41 54 41 55 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 0F 29 70 ? 0F 29 78 ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 85 ? ? ? ? 4C 8B FA 48 89 55",
        "48 89 5C 24 ? 55 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 0F 29 BC 24 ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 85 ? ? ? ? 4C 8B FA"
    };
    uintptr_t setup = 0;
    for (const char* sig : setupCandidates) {
        uintptr_t first = 0;
        // This hook receives live object pointers and is therefore strict:
        // ambiguity is a hard refusal, never a first-match fallback.
        if (ScanSigMatches(game, sig, first) == 1) { setup = first; break; }
    }
    if (setup) {
        MH_STATUS st = MH_CreateHook((LPVOID)setup, (LPVOID)&HkSetupAndRender,
                                     (LPVOID*)&g_oSetupAndRender);
        if (st == MH_OK && g_oSetupAndRender) {
            st = MH_EnableHook((LPVOID)setup);
            g_setupAndRenderHook = (st == MH_OK);
        }
        LOG_INFO("guiscale: ScreenView::setupAndRender active=%d status=%d",
                 g_setupAndRenderHook ? 1 : 0, (int)st);
    } else {
        LOG_INFO("guiscale: setupAndRender signature not found or ambiguous");
    }

    static const char* positionCandidates[] = {
        "48 89 5C 24 10 48 89 74 24 18 57 48 83 EC 60 0F 29 74 24 50 0F 29 7C 24 40 48 8B 05 ? ? ? ? 48 33 C4 48 89 44 24 30",
        "48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 0F 29 74 24 ? 0F 29 7C 24 ? 48 8B F9 F6 41"
    };
    for (const char* sig : positionCandidates) {
        uintptr_t first = 0;
        if (ScanSigMatches(game, sig, first) == 1) {
            g_getPositionFn = first;
            break;
        }
    }
    LOG_INFO("guiscale: UIControl::getPosition found=%d", g_getPositionFn ? 1 : 0);
}

void __fastcall HkUpdateScreenSize(void* client, void* screenSize,
                                   void* safeZone, float forcedScale) {
    if (client && LooksLikeGuiObject(client) &&
        GuiRangeReadable(reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(client) + 0x578), sizeof(void*))) {
        g_clientInstance = client;
        NF_GUI_TRY {
            void* guiData = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(client) + 0x578);
            if (guiData && LooksLikeGuiData(guiData)) {
                if (g_guiData != guiData) {
                    if (g_savedGuiScaleValid) g_savedGuiScaleValid = false; // new screen/session object
                    g_screenSizeCallDisabled = false;
                    g_screenSizeCallProved = false;
                }
                g_guiData = guiData;
            }
        } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {}
    }
    if (screenSize && GuiRangeReadable(screenSize, sizeof(float) * 2)) {
        const float* live = reinterpret_cast<const float*>(screenSize);
        if (std::isfinite(live[0]) && std::isfinite(live[1]) &&
            live[0] > 1.0f && live[1] > 1.0f && live[0] < 100000.0f && live[1] < 100000.0f) {
            g_lastRealScreen[0] = live[0];
            g_lastRealScreen[1] = live[1];
            g_screenSizeSeen = true;
        }
    }
    if (g_oUpdateScreen) g_oUpdateScreen(client, screenSize, safeZone, forcedScale);
}

void TryInstallGuiScaleHook() {
    if (g_screenSizeHookTried) return;
    g_screenSizeHookTried = true;
    HMODULE game = GetModuleHandleW(nullptr);
    // Flarial's 1.21.11X ClientInstance::_updateScreenSizeVariables
    // signature, with nearby layout fallbacks. Never accept ambiguity.
    static const char* candidates[] = {
        "48 8B C4 48 89 58 ? 55 56 57 41 54 41 55 41 56 41 57 48 8D 68 ? 48 81 EC ? ? ? ? 0F 29 70 ? 0F 29 78 ? 44 0F 29 40 ? 44 0F 29 48 ? 44 0F 29 90 ? ? ? ? 44 0F 29 98 ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 ? 0F 28 FB",
        "48 8B C4 48 89 58 ? 48 89 70 ? 55 57 41 54 41 56 41 57 48 8D 68 ? 48 81 EC ? ? ? ? 0F 29 70 ? 0F 29 78 ? 44 0F 29 40 ? 44 0F 29 48 ? 44 0F 29 50 ? 44 0F 29 98 ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 ? 0F 28 FB",
        "48 8B C4 48 89 58 ? 48 89 70 ? 55 57 41 54 41 56 41 57 48 8D 68 ? 48 81 EC ? ? ? ? 0F 29 70 ? 0F 29 78 ? 44 0F 29 40 ? 44 0F 29 48 ? 44 0F 29 50 ? 44 0F 29 98 ? ? ? ? 44 0F 29 A0 ? ? ? ? 44 0F 29 A8 ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 ? 0F 28 F3"
    };
    uintptr_t fn = 0;
    for (const char* sig : candidates) {
        uintptr_t first = 0;
        if (ScanSigMatches(game, sig, first) == 1) {
            fn = first;
            break;
        }
    }
    MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) return;
    // Flarial's render-thread capture is still useful in MinGW: the target
    // performs only prevalidated pointer/dirty-flag work there. The optional
    // getPosition call remains MSVC-only because MinGW has no native SEH.
    TryInstallGuiTreeHooks(game);
#ifndef _MSC_VER
    LOG_INFO("guiscale: MinGW build - getPosition waits for live updateScreen proof");
#endif
    if (!fn) {
        LOG_INFO("guiscale: ClientInstance screen-size signature not found or ambiguous");
        return;
    }
    MH_STATUS st = MH_CreateHook((LPVOID)fn, (LPVOID)&HkUpdateScreenSize,
                                 (LPVOID*)&g_oUpdateScreen);
    if (st == MH_OK || st == MH_ERROR_ALREADY_CREATED) {
        st = MH_EnableHook((LPVOID)fn);
        g_screenSizeHook = (st == MH_OK);
        LOG_INFO("guiscale: screen-size hook active=%d status=%d", g_screenSizeHook ? 1 : 0, (int)st);
    } else {
        LOG_INFO("guiscale: screen-size hook unavailable status=%d", (int)st);
    }
}

bool GuiExecutableAddress(uintptr_t address) {
    if (!address || !GuiPageReadable(reinterpret_cast<const void*>(address))) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if (!VirtualQuery(reinterpret_cast<const void*>(address), &mbi, sizeof(mbi))) return false;
    const DWORD executable = PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
    return (mbi.Protect & executable) != 0;
}

void ResolveClientMouseRelease() {
    if (g_clientMouseResolveTried) return;
    g_clientMouseResolveTried = true;
    static const char kSig[] =
        "48 8B 80 ? ? ? ? FF 15 ? ? ? ? 48 8B 8F ? ? ? ? E8 ? ? ? ? 33 D2";
    uintptr_t first = 0;
    const int matches = ScanSigMatches(GetModuleHandleW(nullptr), kSig, first);
    if (matches != 1 || !first || !GuiRangeReadable(reinterpret_cast<const void*>(first + 3), sizeof(int32_t))) {
        LOG_INFO("overlay: ClientInstance::grabMouse sig matches=%d - game mouse release off", matches);
        return;
    }
    int32_t byteOffset = 0;
    std::memcpy(&byteOffset, reinterpret_cast<const void*>(first + 3), sizeof(byteOffset));
    if (byteOffset < 0 || byteOffset > 0x1000 || (byteOffset % (int)sizeof(void*)) != 0) {
        LOG_INFO("overlay: ClientInstance::grabMouse vtable offset invalid (%d)", (int)byteOffset);
        return;
    }
    const int grabIndex = byteOffset / (int)sizeof(void*);
    const int releaseIndex = grabIndex + 1;
    if (releaseIndex < 1 || releaseIndex > 512) {
        LOG_INFO("overlay: ClientInstance::releaseMouse vtable index invalid (%d)", releaseIndex);
        return;
    }
    g_clientMouseSig = first;
    g_clientReleaseMouseVtable = releaseIndex;
    LOG_INFO("overlay: ClientInstance::releaseMouse vtable=%d (grab=%d)", releaseIndex, grabIndex);
}

void ReleaseGameMouseForGui() {
    if (!UiInputOwned() || g_shuttingDown || !g_clientInstance) return;
    ResolveClientMouseRelease();
    const int index = g_clientReleaseMouseVtable;
    if (index < 0 || !LooksLikeGuiObject(g_clientInstance) ||
        !GuiRangeReadable(g_clientInstance, sizeof(void*))) return;
    NF_GUI_TRY {
        void** vtable = *reinterpret_cast<void***>(g_clientInstance);
        if (!vtable || !GuiRangeReadable(vtable + index, sizeof(void*))) return;
        const uintptr_t target = reinterpret_cast<uintptr_t>(vtable[index]);
        if (!GuiExecutableAddress(target)) return;
        using ReleaseMouseFn = void(__fastcall*)(void*);
        reinterpret_cast<ReleaseMouseFn>(target)(g_clientInstance);
        if (!g_clientMouseResolveLogged) {
            g_clientMouseResolveLogged = true;
            LOG_INFO("overlay: ClientInstance::releaseMouse called for GUI input");
        }
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        if (!g_clientMouseResolveLogged) {
            g_clientMouseResolveLogged = true;
            LOG_ERROR("overlay: ClientInstance::releaseMouse call failed");
        }
    }
}

void ApplyNativeGuiScale(float target) {
    if (target < 1.0f) target = 1.0f;
    if (target > 4.0f) target = 4.0f;
#ifndef _MSC_VER
    // Flarial's important step is the game's own screen-size recomputation.
    // In MinGW the call is allowed only after the setup hook supplied a live
    // ClientInstance and its live GuiData passed the layout proof. Requiring
    // a previous resize callback here would leave the first scale change on
    // the raw path (and is exactly when Bedrock can lose its center anchors):
    // the verified function call itself is what refreshes the screen variables.
    if (!g_screenSizeCallDisabled && g_screenSizeHook && g_oUpdateScreen &&
        g_setupSeen && g_clientInstance &&
        LooksLikeGuiObject(g_clientInstance) && LooksLikeGuiData(g_guiData)) {
        float screen[2] = { g_lastRealScreen[0], g_lastRealScreen[1] };
        if (screen[0] <= 1.0f || screen[1] <= 1.0f) {
            const float* live = reinterpret_cast<const float*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x40);
            screen[0] = live[0]; screen[1] = live[1];
        }
        float safeZone[2] = { 0.0f, 0.0f };
        g_oUpdateScreen(g_clientInstance, screen, safeZone, target);
        bool verified = false;
        if (GuiRangeReadable(reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x5C), sizeof(float))) {
            const float after = *reinterpret_cast<const float*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x5C);
            verified = std::isfinite(after) && std::fabs(after - target) < 0.02f;
        }
        if (verified) {
            g_screenSizeCallProved = true;
            LOG_INFO("guiscale: Flarial updateScreen relayout applied %.2f", target);
            RelayoutAfterScale();
            return;
        }
        g_screenSizeCallDisabled = true;
        g_screenSizeCallProved = false;
        LOG_ERROR("guiscale: updateScreen proof failed; disabling direct call and using GuiData fallback");
    }
    if (RawApplyGameGuiScale(target)) RelayoutAfterScale();
    return;
#else
    if (!g_guiData || !g_clientInstance || !g_oUpdateScreen || !LooksLikeGuiObject(g_clientInstance)) {
        if (RawApplyGameGuiScale(target)) RelayoutAfterScale();
        return;
    }
    float screen[2] = { 0.0f, 0.0f };
    NF_GUI_TRY {
        const float* live = reinterpret_cast<const float*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x40);
        screen[0] = live[0]; screen[1] = live[1];
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {}
    if (screen[0] <= 1.0f || screen[1] <= 1.0f) {
        const ImVec2 current = gui::GetScreenSize();
        screen[0] = current.x; screen[1] = current.y;
    }
    float safeZone[2] = { 0.0f, 0.0f };
    NF_GUI_TRY {
        g_oUpdateScreen(g_clientInstance, screen, safeZone, target);
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        // Fail closed: a fault inside the game's own updateScreen means this
        // screen state cannot take the call - game internals may be left
        // half-updated already. The old fallback (raw GuiData write on top)
        // corrupted the UI tree and killed the process ~2 s later. Skip this
        // frame instead; the per-frame caller retries when the screen
        // settles. Rate-limited: a wedged screen faults every frame.
        static ULONGLONG nextFaultLogAt = 0;
        const ULONGLONG faultNow = GetTickCount64();
        if (faultNow >= nextFaultLogAt) {
            nextFaultLogAt = faultNow + 5000u;
            LOG_ERROR("guiscale: screen-size call faulted; skipping raw fallback (fail-closed)");
        }
        return;
    }
    bool verified = false;
    NF_GUI_TRY {
        const float after = *reinterpret_cast<const float*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x5C);
        verified = std::fabs(after - target) < 0.02f;
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {}
    if (!verified) {
        if (RawApplyGameGuiScale(target)) RelayoutAfterScale();
    } else {
        RelayoutAfterScale();
    }
#endif
}

void ApplyGameGuiScale() {
    // Called twice per frame (SetupAndRender + Present). Resolve the module
    // pointer once instead of strcmp-scanning the roster on every call.
    static Module* s_guiScale = nullptr;
    if (!s_guiScale) s_guiScale = modules().find("GUI Scale");
    Module* base = s_guiScale;
    if (!base) return;
    if (!g_guiData && g_clientInstance && LooksLikeGuiObject(g_clientInstance) &&
        GuiRangeReadable(reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(g_clientInstance) + 0x578), sizeof(void*))) {
        NF_GUI_TRY {
            void* guiData = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(g_clientInstance) + 0x578);
            if (LooksLikeGuiData(guiData)) {
                if (g_guiData != guiData && g_savedGuiScaleValid)
                    g_savedGuiScaleValid = false;
                g_guiData = guiData;
            }
        }
        NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {}
    }
    if (!g_guiData || !LooksLikeGuiData(g_guiData)) {
        // Silence here used to be undiagnosable ("GUI Scale on but nothing
        // happens"). One line per 10 s, never spam.
        if (base->enabled()) {
            static ULONGLONG nextWaitLog = 0;
            const ULONGLONG now = GetTickCount64();
            if (now >= nextWaitLog) {
                nextWaitLog = now + 10000u;
                LOG_INFO("guiscale: waiting for GuiData");
            }
        }
        return;
    }
    NF_GUI_TRY {
        float* scale = reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x5C);
        if (!base->enabled()) {
            RestoreGameGuiScale();
            return;
        }
        auto* guiScale = static_cast<GuiScaleModule*>(base);
        const float target = guiScale->targetScale();
        const float current = *scale;
        if (!(current > 0.05f && current < 20.0f)) return;
        if (!g_savedGuiScaleValid || g_savedGuiData != g_guiData) {
            g_savedGuiScale = current;
            g_savedGuiData = g_guiData;
            g_savedGuiScaleValid = true;
        }
        if (std::fabs(current - target) > 0.02f)
            ApplyNativeGuiScale(target);
        else if (g_guiScaleRelayoutPending)
            RelayoutAfterScale();
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {
        LOG_ERROR("guiscale: guarded apply failed");
    }
}

void RestoreGameGuiScale() {
    if (!g_savedGuiScaleValid || !g_guiData || g_savedGuiData != g_guiData ||
        !LooksLikeGuiData(g_guiData)) return;
    const float original = g_savedGuiScale;
    ApplyNativeGuiScale(original);
    bool restored = false;
    NF_GUI_TRY {
        const float after = *reinterpret_cast<const float*>(reinterpret_cast<uintptr_t>(g_guiData) + 0x5C);
        restored = std::fabs(after - original) < 0.02f;
    } NF_GUI_EXCEPT (EXCEPTION_EXECUTE_HANDLER) {}
    if (restored) {
        g_savedGuiScaleValid = false;
        g_savedGuiData = nullptr;
    }
}

#undef NF_GUI_TRY
#undef NF_GUI_EXCEPT

// ============================ Potions reader ============================
//
// Bedrock 1.21.x stores the local player's MobEffectsComponent in the entity
// registry. Rather than reproducing entt's compiler-dependent type hash in
// this MinGW-built DLL, resolve the game's own specialized try_get function
// and pass it the live EntityContext registry/entity pair. Every pointer and
// vector range is checked before it is read; failure simply returns no rows.
struct PotionMsvcVector {
    uintptr_t begin = 0;
    uintptr_t end = 0;
    uintptr_t capacity = 0;
};

int PotionDecodeVector(const PotionMsvcVector& vector, PotionEffect* out, int maxOut);

#ifdef _MSC_VER
#define NF_POTION_TRY __try
#define NF_POTION_EXCEPT(x) __except(x)
#else
#define NF_POTION_TRY if (true)
#define NF_POTION_EXCEPT(x) else if (false)
#endif

// ReadProcessMemory is used even for this process. Unlike a plain memcpy it
// fails closed on a stale/guarded target page in the MinGW build, where MSVC
// __try/__except is not available. This is important because the DLL is
// shipped cross-compiled and must not turn a bad signature into a game crash.
bool PotionReadBytes(const void* address, void* out, size_t bytes);

#ifndef _MSC_VER
struct PotionVehFrame {
    jmp_buf jump;
    volatile LONG active = 0;
};
thread_local PotionVehFrame* g_potionVehFrame = nullptr;

LONG CALLBACK PotionVehHandler(EXCEPTION_POINTERS* exceptionInfo) {
    if (!exceptionInfo || !g_potionVehFrame || !g_potionVehFrame->active) {
        return EXCEPTION_CONTINUE_SEARCH;
    }
    const DWORD code = exceptionInfo->ExceptionRecord
        ? exceptionInfo->ExceptionRecord->ExceptionCode : 0;
    switch (code) {
        case EXCEPTION_ACCESS_VIOLATION:
        case EXCEPTION_IN_PAGE_ERROR:
        case EXCEPTION_ILLEGAL_INSTRUCTION:
        case EXCEPTION_DATATYPE_MISALIGNMENT:
            g_potionVehFrame->active = 0;
            longjmp(g_potionVehFrame->jump, 1);
            return EXCEPTION_CONTINUE_EXECUTION;
        default:
            return EXCEPTION_CONTINUE_SEARCH;
    }
}
#endif

bool PotionInvokeAssure(PotionAssureFn assure, void* registry, void*& storage) {
    storage = nullptr;
    if (!assure || !registry) return false;
#ifdef _MSC_VER
    __try {
        storage = assure(registry, kPotionComponentHash);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        storage = nullptr;
        return false;
    }
#else
    PotionVehFrame frame{};
    PVOID handler = AddVectoredExceptionHandler(1, &PotionVehHandler);
    if (!handler) return false;
    PotionVehFrame* previous = g_potionVehFrame;
    g_potionVehFrame = &frame;
    const int jumped = setjmp(frame.jump);
    bool completed = false;
    if (jumped == 0) {
        frame.active = 1;
        storage = assure(registry, kPotionComponentHash);
        completed = true;
    } else {
        storage = nullptr;
    }
    frame.active = 0;
    g_potionVehFrame = previous;
    RemoveVectoredExceptionHandler(handler);
    return completed;
#endif
}

bool PotionInvokeLocalPlayer(void* function, void* client, void*& local) {
    local = nullptr;
    if (!function || !client) return false;
    using GetLocalPlayerFn = void*(__fastcall*)(void*);
#ifdef _MSC_VER
    __try {
        local = reinterpret_cast<GetLocalPlayerFn>(function)(client);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        local = nullptr;
        return false;
    }
#else
    PotionVehFrame frame{};
    PVOID handler = AddVectoredExceptionHandler(1, &PotionVehHandler);
    if (!handler) return false;
    PotionVehFrame* previous = g_potionVehFrame;
    g_potionVehFrame = &frame;
    const int jumped = setjmp(frame.jump);
    bool completed = false;
    if (jumped == 0) {
        frame.active = 1;
        local = reinterpret_cast<GetLocalPlayerFn>(function)(client);
        completed = true;
    } else {
        local = nullptr;
    }
    frame.active = 0;
    g_potionVehFrame = previous;
    RemoveVectoredExceptionHandler(handler);
    return completed;
#endif
}

bool PotionInvokeTryGet(PotionTryGetFn reader, void* registry, const void* entity,
                        void*& component) {
    component = nullptr;
    if (!reader || !registry || !entity) return false;
#ifdef _MSC_VER
    __try {
        component = reader(registry, entity);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        component = nullptr;
        return false;
    }
#else
    PotionVehFrame frame{};
    PVOID handler = AddVectoredExceptionHandler(1, &PotionVehHandler);
    if (!handler) return false;
    PotionVehFrame* previous = g_potionVehFrame;
    g_potionVehFrame = &frame;
    const int jumped = setjmp(frame.jump);
    bool completed = false;
    if (jumped == 0) {
        frame.active = 1;
        component = reader(registry, entity);
        completed = true;
    } else {
        component = nullptr;
    }
    frame.active = 0;
    g_potionVehFrame = previous;
    RemoveVectoredExceptionHandler(handler);
    return completed;
#endif
}

// Diagnostic compatibility call for the other possible EnTT ABI. Flarial's
// reference uses EntityId&, but a few Bedrock/MSVC specializations have been
// observed with the four-byte EntityId passed by value. It is attempted only
// after the reference form fails and remains VEH/SEH guarded.
bool PotionInvokeTryGetValue(PotionTryGetFn reader, void* registry,
                             uint32_t entity, void*& component) {
    component = nullptr;
    if (!reader || !registry) return false;
    using PotionTryGetValueFn = void*(__fastcall*)(void*, uint32_t);
    const PotionTryGetValueFn valueReader =
        reinterpret_cast<PotionTryGetValueFn>(reader);
#ifdef _MSC_VER
    __try {
        component = valueReader(registry, entity);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        component = nullptr;
        return false;
    }
#else
    PotionVehFrame frame{};
    PVOID handler = AddVectoredExceptionHandler(1, &PotionVehHandler);
    if (!handler) return false;
    PotionVehFrame* previous = g_potionVehFrame;
    g_potionVehFrame = &frame;
    const int jumped = setjmp(frame.jump);
    bool completed = false;
    if (jumped == 0) {
        frame.active = 1;
        component = valueReader(registry, entity);
        completed = true;
    } else {
        component = nullptr;
    }
    frame.active = 0;
    g_potionVehFrame = previous;
    RemoveVectoredExceptionHandler(handler);
    return completed;
#endif
}

// Calls the non-template registry storage lookup without relying on the
// MinGW compiler's view of any storage object. The call itself is isolated in
// its own exception frame so one wrong registry candidate does not prevent the
// remaining context/layout candidates from being tested.
bool PotionInvokeRegistryStorage(void* registry, void*& storage) {
    storage = nullptr;
    if (!registry || !GuiPageReadable(registry)) return false;
#ifdef _MSC_VER
    __try {
        auto* typed = reinterpret_cast<entt::basic_registry<EntityId>*>(registry);
        storage = typed->storage(kPotionComponentHash);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        storage = nullptr;
        return false;
    }
#else
    PotionVehFrame frame{};
    PVOID handler = AddVectoredExceptionHandler(1, &PotionVehHandler);
    if (!handler) return false;
    PotionVehFrame* previous = g_potionVehFrame;
    g_potionVehFrame = &frame;
    const int jumped = setjmp(frame.jump);
    bool completed = false;
    if (jumped == 0) {
        frame.active = 1;
        auto* typed = reinterpret_cast<entt::basic_registry<EntityId>*>(registry);
        storage = typed->storage(kPotionComponentHash);
        completed = true;
    }
    frame.active = 0;
    g_potionVehFrame = previous;
    RemoveVectoredExceptionHandler(handler);
    return completed;
#endif
}

bool PotionInvokeActorComponent(PotionActorComponentFn reader, void* actor,
                                void*& component) {
    component = nullptr;
    if (!reader || !actor ||
        !JavaIsGameCodeAddress(reinterpret_cast<uintptr_t>(reader))) return false;
#ifdef _MSC_VER
    __try {
        component = reader(actor);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        component = nullptr;
        return false;
    }
#else
    PotionVehFrame frame{};
    PVOID handler = AddVectoredExceptionHandler(1, &PotionVehHandler);
    if (!handler) return false;
    PotionVehFrame* previous = g_potionVehFrame;
    g_potionVehFrame = &frame;
    const int jumped = setjmp(frame.jump);
    bool completed = false;
    if (jumped == 0) {
        frame.active = 1;
        component = reader(actor);
        completed = true;
    }
    frame.active = 0;
    g_potionVehFrame = previous;
    RemoveVectoredExceptionHandler(handler);
    return completed;
#endif
}

bool PotionReadLocalPlayer(void*& out) {
    out = nullptr;
    if (!g_clientInstance || !LooksLikeGuiObject(g_clientInstance)) return false;
    const uintptr_t ci = reinterpret_cast<uintptr_t>(g_clientInstance);
    if (!GuiRangeReadable(reinterpret_cast<const void*>(ci), sizeof(void*))) return false;

    int candidates[5] = {};
    int candidateCount = 0;
    if (g_potionLocalPlayerVfunc >= 0)
        candidates[candidateCount++] = g_potionLocalPlayerVfunc;
    for (int i = 0; i < g_potionLocalPlayerCandidateCount && candidateCount < 5; ++i) {
        const int vfunc = g_potionLocalPlayerCandidates[i];
        bool duplicate = false;
        for (int j = 0; j < candidateCount; ++j)
            duplicate |= candidates[j] == vfunc;
        if (!duplicate) candidates[candidateCount++] = vfunc;
    }

    for (int i = 0; i < candidateCount; ++i) {
        const int vfunc = candidates[i];
        if (vfunc <= 0 || vfunc >= 500 ||
            !GuiRangeReadable(reinterpret_cast<const void*>(ci +
                static_cast<uintptr_t>(vfunc) * sizeof(void*)), sizeof(void*))) continue;

        uintptr_t vtableAddress = 0;
        if (!PotionReadBytes(reinterpret_cast<const void*>(ci), &vtableAddress, sizeof(vtableAddress)) ||
            !vtableAddress || !GuiPageReadable(reinterpret_cast<const void*>(vtableAddress))) continue;
        uintptr_t fn = 0;
        if (!PotionReadBytes(reinterpret_cast<const void*>(vtableAddress +
                static_cast<uintptr_t>(vfunc) * sizeof(void*)), &fn, sizeof(fn)) ||
            !JavaIsGameCodeAddress(fn)) continue;

        void* local = nullptr;
        if (!PotionInvokeLocalPlayer(reinterpret_cast<void*>(fn), g_clientInstance, local) ||
            !local || !GuiRangeReadable(reinterpret_cast<const void*>(
                reinterpret_cast<uintptr_t>(local) + 0x8), 0x18)) continue;

        // Validate the same EntityContext fields used by the component bridge;
        // this rejects a different ClientInstance vfunc without touching game
        // state or assuming an actor-only offset.
        void* registryObject = nullptr;
        void* enttRegistry = nullptr;
        if (!PotionReadBytes(reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(local) + 0x8),
                             &registryObject, sizeof(registryObject)) ||
            !PotionReadBytes(reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(local) + 0x10),
                             &enttRegistry, sizeof(enttRegistry))) continue;
        if (!registryObject || !enttRegistry || !GuiPageReadable(enttRegistry)) continue;
        g_potionLocalPlayerVfunc = vfunc;
        out = local;
        return true;
    }
    return false;
}

bool PotionReadBytes(const void* address, void* out, size_t bytes) {
    if (!address || !out || bytes == 0) return false;
    // Direct guarded read.
    //
    // This used to be GuiRangeReadable() (1-2 VirtualQuery) PLUS
    // ReadProcessMemory(GetCurrentProcess(), ...) (another kernel transition):
    // three syscalls to copy a handful of bytes out of OUR OWN address space.
    // There are 109 call sites and several of them loop over every actor, so
    // this was the single hottest syscall source in the overlay.
    //
    // ReadProcessMemory bought no safety that SEH does not already give: an
    // uncommitted page, a PAGE_GUARD page and an unmapped address all raise an
    // access violation, which is precisely what the readability probe screened
    // for. SEH catches all three at zero syscall cost.
    //
    // POD-only locals keep this legal under MSVC's SEH rules (no C2712).
#ifdef _MSC_VER
    __try {
        std::memcpy(out, address, bytes);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
    return true;
#else
    std::memcpy(out, address, bytes);
    return true;
#endif
}

bool PotionValidVector(const PotionMsvcVector& vector, size_t maxBytes) {
    if (vector.end < vector.begin || vector.capacity < vector.end) return false;
    const uintptr_t bytes = vector.end - vector.begin;
    if (bytes == 0) return true;
    return vector.begin != 0 && bytes <= maxBytes &&
           GuiRangeReadable(reinterpret_cast<const void*>(vector.begin),
                            static_cast<size_t>(bytes));
}

void PotionLogRegistryLayout(void* registry) {
    if (g_potionRegistryWordsLogged || !registry) return;
    g_potionRegistryWordsLogged = true;

    // Read-only diagnostic for the exact EnTT 3.14 layout used by Flarial:
    // registry vars at 0x00, pools dense_map at 0x38, then groups/entities.
    // It is emitted once, before any pool walk, so a failed lookup can be
    // distinguished from an incorrect registry pointer without widening the
    // per-frame scan or calling a target-side helper.
    const uintptr_t base = reinterpret_cast<uintptr_t>(registry);
    uintptr_t words[20] = {};
    if (!PotionReadBytes(reinterpret_cast<const void*>(base), words,
                         sizeof(words))) {
        LOG_INFO("potions: registry layout read failed registry=%p", registry);
        return;
    }
    LOG_INFO("potions: registry words 00=%p 08=%p 10=%p 18=%p 20=%p 28=%p 30=%p 38=%p",
             reinterpret_cast<void*>(words[0]), reinterpret_cast<void*>(words[1]),
             reinterpret_cast<void*>(words[2]), reinterpret_cast<void*>(words[3]),
             reinterpret_cast<void*>(words[4]), reinterpret_cast<void*>(words[5]),
             reinterpret_cast<void*>(words[6]), reinterpret_cast<void*>(words[7]));
    LOG_INFO("potions: registry words 40=%p 48=%p 50=%p 58=%p 60=%p 68=%p 70=%p 78=%p",
             reinterpret_cast<void*>(words[8]), reinterpret_cast<void*>(words[9]),
             reinterpret_cast<void*>(words[10]), reinterpret_cast<void*>(words[11]),
             reinterpret_cast<void*>(words[12]), reinterpret_cast<void*>(words[13]),
             reinterpret_cast<void*>(words[14]), reinterpret_cast<void*>(words[15]));
    LOG_INFO("potions: registry words 80=%p 88=%p 90=%p 98=%p A0=%p A8=%p B0=%p B8=%p",
             reinterpret_cast<void*>(words[16]), reinterpret_cast<void*>(words[17]),
             reinterpret_cast<void*>(words[18]), reinterpret_cast<void*>(words[19]),
             reinterpret_cast<void*>(base + 0xA0u), reinterpret_cast<void*>(base + 0xA8u),
             reinterpret_cast<void*>(base + 0xB0u), reinterpret_cast<void*>(base + 0xB8u));

    const size_t offsets[] = {0x00u, 0x08u, 0x10u, 0x18u, 0x20u,
                              0x28u, 0x30u, 0x38u, 0x40u, 0x48u,
                              0x50u, 0x58u, 0x60u, 0x68u};
    for (const size_t offset : offsets) {
        PotionMsvcVector vector{};
        if (!PotionReadBytes(reinterpret_cast<const void*>(base + offset),
                             &vector, sizeof(vector))) continue;
        LOG_INFO("potions: registry vec +0x%02zx [%p,%p,%p] readable=%d",
                 offset, reinterpret_cast<void*>(vector.begin),
                 reinterpret_cast<void*>(vector.end),
                 reinterpret_cast<void*>(vector.capacity),
                 PotionValidVector(vector, 0x1000000u) ? 1 : 0);
    }
}

bool PotionExecutableAddress(uintptr_t address) {
    if (!address) return false;
    // Same probe as the readable test, but the protection mask is what matters
    // here - so it is fetched once and shared with the page memo instead of
    // issuing a second VirtualQuery for the very same page.
    DWORD protect = 0;
    if (!PageQueryMemo(reinterpret_cast<const void*>(address), &protect)) return false;
    const DWORD executable = PAGE_EXECUTE | PAGE_EXECUTE_READ |
                            PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
    return (protect & executable) != 0;
}

// A C++ vtable pointer normally points into read-only image data, not into an
// executable page. Validate the vtable page as readable and then validate its
// first virtual function as executable; checking the vtable address itself
// would reject every normal MSVC object.
bool PotionValidVtable(uintptr_t vtable) {
    if (!vtable || !GuiPageReadable(reinterpret_cast<const void*>(vtable))) return false;
    uintptr_t firstFunction = 0;
    return PotionReadBytes(reinterpret_cast<const void*>(vtable), &firstFunction,
                            sizeof(firstFunction)) &&
           PotionExecutableAddress(firstFunction);
}

void PotionAddAssureCandidate(uintptr_t address) {
    if (!address || !JavaIsGameCodeAddress(address)) return;
    for (int i = 0; i < g_potionAssureCandidateCount; ++i)
        if (reinterpret_cast<uintptr_t>(g_potionAssureCandidates[i]) == address) return;
    if (g_potionAssureCandidateCount < 8)
        g_potionAssureCandidates[g_potionAssureCandidateCount++] =
            reinterpret_cast<PotionAssureFn>(address);
}

void PotionAddTryGetCandidate(uintptr_t address, bool exactHash) {
    if (!address || !JavaIsGameCodeAddress(address)) return;
    const PotionTryGetFn candidate = reinterpret_cast<PotionTryGetFn>(address);
    bool known = false;
    for (int i = 0; i < g_potionTryGetCandidateCount; ++i) {
        if (g_potionTryGetCandidates[i] == candidate) {
            known = true;
            break;
        }
    }
    if (!known && g_potionTryGetCandidateCount < 8)
        g_potionTryGetCandidates[g_potionTryGetCandidateCount++] = candidate;
    if (!g_potionTryGet) g_potionTryGet = candidate;

    // Only signatures containing the MobEffectsComponent hash are allowed to
    // enter the direct registry/entity call path. A prologue-only match may be
    // a different EnTT accessor with the same MSVC-generated shape.
    if (exactHash) {
        for (int i = 0; i < g_potionExactTryGetCandidateCount; ++i)
            if (g_potionExactTryGetCandidates[i] == candidate) return;
        if (g_potionExactTryGetCandidateCount < 4)
            g_potionExactTryGetCandidates[g_potionExactTryGetCandidateCount++] = candidate;
    }
}

void PotionScanAssureTargets() {
    if (g_potionAssureScanTried) return;
    g_potionAssureScanTried = true;
    CacheGuiGameImage();
    if (!g_gameImageBase || !g_gameImageSize) return;

    // EnTT's type hash for the target component is emitted by the game's
    // assure<MobEffectsComponent> instantiation as `mov edx, 0xF7D6B42F`.
    // Follow the first nearby relative call exactly as the previous working
    // reader did, then call the resulting registry/hash accessor. This avoids
    // reproducing MSVC FUNCSIG hashing in a MinGW DLL.
    const uint8_t hashBytes[] = { 0xBA, 0x2F, 0xB4, 0xD6, 0xF7 };
    const uint8_t* base = reinterpret_cast<const uint8_t*>(g_gameImageBase);
    const IMAGE_DOS_HEADER* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return;
    const IMAGE_NT_HEADERS* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return;

    const IMAGE_SECTION_HEADER* sec = IMAGE_FIRST_SECTION(nt);
    for (WORD section = 0; section < nt->FileHeader.NumberOfSections &&
         g_potionAssureCandidateCount < 8; ++section, ++sec) {
        if (!(sec->Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        const uint8_t* begin = base + sec->VirtualAddress;
        const uint8_t* end = begin + sec->Misc.VirtualSize;
        for (const uint8_t* p = begin;
             p + sizeof(hashBytes) <= end && g_potionAssureCandidateCount < 8; ++p) {
            if (std::memcmp(p, hashBytes, sizeof(hashBytes)) != 0) continue;

            uintptr_t fallback = 0;
            uintptr_t aligned = 0;
            const uint8_t* callEnd = std::min(end, p + 5 + 0x300u);
            for (const uint8_t* q = p + sizeof(hashBytes); q + 5 <= callEnd; ++q) {
                if (*q != 0xE8) continue;
                uintptr_t target = 0;
                if (!JavaResolveCallTarget(reinterpret_cast<uintptr_t>(q), target)) continue;
                if (!fallback) fallback = target;
                if ((target & 0xFu) == 0) { aligned = target; break; }
            }
            PotionAddAssureCandidate(aligned ? aligned : fallback);
        }
    }
}

bool PotionReadStorageObjectVector(void* storage, uint32_t entity,
                                   PotionMsvcVector& vector) {
    vector = PotionMsvcVector{};
    if (!storage || !GuiPageReadable(storage) || !GuiRangeReadable(storage, 0x78)) return false;

    // EnTT 3.11/3.12 basic_sparse_set layout used by the Hamambanan path:
    // vptr + sparse vector at 0x08, packed vector at 0x20, and the
    // basic_storage payload-page vector at 0x50. The neighbouring payload
    // offsets are retained for the adjacent Bedrock mixin builds.
    static const size_t payloadOffsets[] = { 0x50u, 0x48u, 0x58u, 0x60u };
    static const uint32_t entityPageSizes[] = { 2048u, 4096u };
    static const uint32_t componentPageSizes[] = { 128u, 256u };
    constexpr uint32_t entityMask = 0x3FFFFu;
    const uint32_t entityIndex = entity & entityMask;

    // The vtable can live in a Bedrock DLL rather than the main executable;
    // validate that it is executable, but do not reject it merely because it
    // is outside GetModuleHandleW(nullptr)'s image range.
    uintptr_t vft = 0;
    if (!PotionReadBytes(storage, &vft, sizeof(vft)) ||
        !PotionValidVtable(vft)) return false;

    PotionMsvcVector sparse{};
    PotionMsvcVector packed{};
    const uintptr_t storageAddress = reinterpret_cast<uintptr_t>(storage);
    if (!PotionReadBytes(reinterpret_cast<const void*>(storageAddress + 0x08),
                         &sparse, sizeof(sparse)) ||
        !PotionReadBytes(reinterpret_cast<const void*>(storageAddress + 0x20),
                         &packed, sizeof(packed))) return false;
    if (!PotionValidVector(sparse, 0x200000u) || !PotionValidVector(packed, 0x200000u) ||
        sparse.begin == 0 || packed.begin == 0) return false;

    const uintptr_t sparseBytes = sparse.end - sparse.begin;
    const uintptr_t packedBytes = packed.end - packed.begin;
    if (sparseBytes % sizeof(void*) != 0 || packedBytes % sizeof(uint32_t) != 0)
        return false;
    const size_t sparsePages = static_cast<size_t>(sparseBytes / sizeof(void*));
    const size_t packedCount = static_cast<size_t>(packedBytes / sizeof(uint32_t));

    for (const uint32_t entityPageSize : entityPageSizes) {
        const size_t sparsePageIndex = entityIndex / entityPageSize;
        const size_t sparseOffset = entityIndex % entityPageSize;
        if (sparsePageIndex >= sparsePages) continue;

        uintptr_t sparsePage = 0;
        if (!PotionReadBytes(reinterpret_cast<const void*>(
                sparse.begin + sparsePageIndex * sizeof(void*)),
                &sparsePage, sizeof(sparsePage)) || !sparsePage ||
            !GuiRangeReadable(reinterpret_cast<const void*>(sparsePage),
                              static_cast<size_t>(entityPageSize) * sizeof(uint32_t)))
            continue;

        uint32_t sparseEntry = 0;
        if (!PotionReadBytes(reinterpret_cast<const void*>(
                sparsePage + sparseOffset * sizeof(uint32_t)),
                &sparseEntry, sizeof(sparseEntry))) continue;
        const size_t packedIndex = static_cast<size_t>(sparseEntry & entityMask);
        if (packedIndex >= packedCount) continue;

        uint32_t packedEntity = 0;
        if (!PotionReadBytes(reinterpret_cast<const void*>(
                packed.begin + packedIndex * sizeof(uint32_t)),
                &packedEntity, sizeof(packedEntity)) || packedEntity != entity)
            continue;

        for (const size_t payloadOffset : payloadOffsets) {
            PotionMsvcVector payload{};
            if (!PotionReadBytes(reinterpret_cast<const void*>(storageAddress + payloadOffset),
                                 &payload, sizeof(payload)) ||
                !PotionValidVector(payload, 0x200000u)) continue;
            const uintptr_t payloadBytes = payload.end - payload.begin;
            if (payloadBytes % sizeof(void*) != 0) continue;
            const size_t payloadPages = static_cast<size_t>(payloadBytes / sizeof(void*));

            for (const uint32_t componentPageSize : componentPageSizes) {
                const size_t pageIndex = packedIndex / componentPageSize;
                const size_t pageOffset = packedIndex % componentPageSize;
                if (pageIndex >= payloadPages) continue;

                uintptr_t componentPage = 0;
                if (!PotionReadBytes(reinterpret_cast<const void*>(
                        payload.begin + pageIndex * sizeof(void*)),
                        &componentPage, sizeof(componentPage)) ||
                    !componentPage ||
                    !GuiRangeReadable(reinterpret_cast<const void*>(componentPage),
                                      static_cast<size_t>(componentPageSize) * 0x18u))
                    continue;
                const uintptr_t component = componentPage + pageOffset * 0x18u;
                if (!GuiRangeReadable(reinterpret_cast<const void*>(component), 0x18u) ||
                    !PotionReadBytes(reinterpret_cast<const void*>(component),
                                     &vector, sizeof(vector))) continue;
                if (PotionValidVector(vector, 0x88u * 128u)) {
                    g_potionComponentAddress = component;
                    return true;
                }
            }
        }
    }
    return false;
}

bool PotionReadCachedComponent(void* registry, uint32_t entity,
                               PotionMsvcVector& vector) {
    vector = PotionMsvcVector{};
    if (!g_potionComponentAddress ||
        g_potionComponentRegistry != registry ||
        g_potionComponentEntity != entity) return false;
    if (!PotionReadBytes(reinterpret_cast<const void*>(g_potionComponentAddress),
                         &vector, sizeof(vector)) ||
        !PotionValidVector(vector, 0x88u * 128u)) {
        g_potionComponentAddress = 0;
        g_potionComponentRegistry = nullptr;
        g_potionComponentEntity = 0;
        return false;
    }
    return true;
}

// ABI-neutral direct lookup for the component pool. This is not a registry
// traversal: it hashes the target MobEffectsComponent id and follows only the
// corresponding bucket. It exists because calling the MinGW-instantiated
// try_get on the game's MSVC registry faults before it can return nullptr.
// Every operation here is a ReadProcessMemory read.
bool PotionReadExactRegistryStorage(void* registry, uint32_t entity,
                                    PotionMsvcVector& vector) {
    vector = PotionMsvcVector{};
    if (!registry || !GuiPageReadable(registry)) return false;

    constexpr uint32_t hash = kPotionComponentHash;
    // Flarial builds EnTT with MSVC. Its compressed_pair has a 0x20-byte
    // footprint (the empty hasher/equality base is followed by alignment), so
    // the current basic_registry layout is vars 0x00, pools 0x48, and each
    // dense_map stores sparse at +0x00 and packed at +0x20.
    static const size_t poolOffsets[] = { 0x48u };
    static const size_t sparseOffsets[] = { 0x00u };
    static const size_t packedOffsets[] = { 0x20u };
    struct NodeLayout { size_t size; size_t next; size_t key; size_t shared; };
    static const NodeLayout nodeLayouts[] = {
        { 0x20u, 0x00u, 0x08u, 0x10u }
    };
    const size_t empty = (std::numeric_limits<size_t>::max)();

    for (const size_t poolsOffset : poolOffsets) {
        const uintptr_t map = reinterpret_cast<uintptr_t>(registry) + poolsOffset;
        for (const size_t sparseOffset : sparseOffsets) {
            PotionMsvcVector sparse{};
            if (!PotionReadBytes(reinterpret_cast<const void*>(map + sparseOffset),
                                 &sparse, sizeof(sparse)) ||
                !PotionValidVector(sparse, 0x100000u)) continue;
            const uintptr_t sparseBytes = sparse.end - sparse.begin;
            if (!sparseBytes || sparseBytes % sizeof(size_t) != 0) continue;
            const size_t bucketCount = static_cast<size_t>(sparseBytes / sizeof(size_t));
            if (bucketCount < 8u || (bucketCount & (bucketCount - 1u)) != 0 ||
                bucketCount > 0x100000u) continue;

            for (const size_t packedOffset : packedOffsets) {
                if (packedOffset == sparseOffset) continue;
                PotionMsvcVector packed{};
                if (!PotionReadBytes(reinterpret_cast<const void*>(
                        map + packedOffset), &packed, sizeof(packed)) ||
                    !PotionValidVector(packed, 0x1000000u)) continue;
                const uintptr_t packedBytes = packed.end - packed.begin;
                if (!packedBytes) continue;
                const size_t bucket = static_cast<size_t>(hash) & (bucketCount - 1u);
                size_t head = empty;
                if (!PotionReadBytes(reinterpret_cast<const void*>(
                        sparse.begin + bucket * sizeof(size_t)), &head, sizeof(head)) ||
                    head == empty) continue;

                for (const NodeLayout& layout : nodeLayouts) {
                    if (packedBytes % layout.size != 0) continue;
                    const size_t nodeCount = static_cast<size_t>(packedBytes / layout.size);
                    if (nodeCount == 0 || nodeCount > 0x10000u || head >= nodeCount)
                        continue;
                    size_t node = head;
                    for (size_t step = 0; step < nodeCount && node != empty; ++step) {
                        if (node >= nodeCount ||
                            layout.next + sizeof(size_t) > layout.size ||
                            layout.key + sizeof(uint32_t) > layout.size ||
                            layout.shared + sizeof(uintptr_t) > layout.size) break;
                        const uintptr_t nodeAddress = packed.begin + node * layout.size;
                        size_t next = empty;
                        uint32_t key = 0;
                        if (!PotionReadBytes(reinterpret_cast<const void*>(
                                nodeAddress + layout.next), &next, sizeof(next)) ||
                            !PotionReadBytes(reinterpret_cast<const void*>(
                                nodeAddress + layout.key), &key, sizeof(key))) break;
                        if (key == hash) {
                            uintptr_t storage = 0;
                            if (PotionReadBytes(reinterpret_cast<const void*>(
                                    nodeAddress + layout.shared), &storage,
                                    sizeof(storage)) && storage &&
                                PotionReadStorageObjectVector(
                                    reinterpret_cast<void*>(storage), entity, vector))
                                return true;
                            break;
                        }
                        if (next == node) break;
                        node = next;
                    }
                }
            }
        }
    }
    return false;
}

bool PotionReadRawRegistryStorage(void* registry, uint32_t entity,
                                   PotionMsvcVector& vector) {
    vector = PotionMsvcVector{};
    if (!registry || !GuiPageReadable(registry)) return false;

    // basic_registry layout in the pinned EnTT snapshot is:
    // registry_context vars (0x38), pool dense_map (0x38), groups, entities.
    // The map itself is two MSVC-compatible vector headers: sparse buckets at
    // +0x00 and packed dense_map_node records at +0x18. Walk the map directly
    // so a MinGW libstdc++ call cannot misinterpret the target registry.
    // The expected pool offset is 0x38, but the game and DLL use different
    // standard-library ABIs. Scan the small registry object window for the
    // dense_map pair rather than trusting one compiler's sizeof(context).
    static const size_t nodeSizes[] = { 0x20u, 0x28u, 0x18u };
    constexpr uint32_t hash = kPotionComponentHash;

    for (size_t poolOffset = 0; poolOffset <= 0x200u; poolOffset += 0x08u) {
        PotionMsvcVector sparse{};
        PotionMsvcVector packed{};
        const uintptr_t map = reinterpret_cast<uintptr_t>(registry) + poolOffset;
        if (!PotionReadBytes(reinterpret_cast<const void*>(map + 0x00),
                             &sparse, sizeof(sparse)) ||
            !PotionReadBytes(reinterpret_cast<const void*>(map + 0x18),
                             &packed, sizeof(packed)) ||
            !PotionValidVector(sparse, 0x100000u) ||
            !PotionValidVector(packed, 0x1000000u)) continue;

        const uintptr_t sparseBytes = sparse.end - sparse.begin;
        const uintptr_t packedBytes = packed.end - packed.begin;
        if (!sparseBytes || sparseBytes % sizeof(size_t) != 0) continue;
        const size_t bucketCount = static_cast<size_t>(sparseBytes / sizeof(size_t));
        if ((bucketCount & (bucketCount - 1u)) != 0 || bucketCount > 0x100000u)
            continue;
        const size_t bucket = static_cast<size_t>(hash) & (bucketCount - 1u);

        size_t head = 0;
        if (!PotionReadBytes(reinterpret_cast<const void*>(
                sparse.begin + bucket * sizeof(size_t)), &head, sizeof(head)))
            continue;

        for (const size_t nodeSize : nodeSizes) {
            if (!packedBytes || packedBytes % nodeSize != 0) continue;
            const size_t nodeCount = static_cast<size_t>(packedBytes / nodeSize);
            if (nodeCount == 0 || nodeCount > 0x10000u || head >= nodeCount) continue;

            size_t node = head;
            for (size_t step = 0; step < nodeCount && node < nodeCount; ++step) {
                const uintptr_t nodeAddress = packed.begin + node * nodeSize;
                size_t next = 0;
                uint32_t key = 0;
                if (!PotionReadBytes(reinterpret_cast<const void*>(nodeAddress + 0x00),
                                     &next, sizeof(next)) ||
                    !PotionReadBytes(reinterpret_cast<const void*>(nodeAddress + 0x08),
                                     &key, sizeof(key))) break;
                if (key == hash) {
                    // MSVC shared_ptr is {_Ptr, _Rep}; try the adjacent
                    // layouts as well for the older Bedrock CRT builds.
                    static const size_t sharedPtrOffsets[] = { 0x10u, 0x18u, 0x08u };
                    for (const size_t sharedOffset : sharedPtrOffsets) {
                        uintptr_t storage = 0;
                        if (!PotionReadBytes(reinterpret_cast<const void*>(
                                nodeAddress + sharedOffset), &storage, sizeof(storage)) ||
                            !storage) continue;
                        if (PotionReadStorageObjectVector(reinterpret_cast<void*>(storage),
                                                           entity, vector)) return true;
                    }
                    break;
                }
                if (next == node || next >= nodeCount) break;
                node = next;
            }
        }
    }
    return false;
}

// If the target's component hash differs from the historical F7D6B42F value,
// use EnTT's own type_info object to identify the exact MobEffectsComponent
// pool. This still follows only the current Flarial registry layout and never
// accepts an arbitrary pool: the type_info name/hash must identify the real
// component before its storage is read.
bool PotionReadMobEffectsStorageByTypeInfo(void* registry, uint32_t entity,
                                           PotionMsvcVector& vector) {
    vector = PotionMsvcVector{};
    const uintptr_t registryAddress = reinterpret_cast<uintptr_t>(registry);
    if (!registry || !GuiPageReadable(registry) ||
        g_potionTypeProbeRegistry == registryAddress) return false;
    g_potionTypeProbeRegistry = registryAddress;

    constexpr size_t poolsOffset = 0x48u;
    constexpr size_t packedOffset = 0x20u;
    constexpr size_t nodeSize = 0x20u;
    constexpr size_t typeInfoOffset = 0x38u;
    constexpr size_t typeHashOffset = 0x04u;
    constexpr size_t typeNameOffset = 0x08u;
    constexpr size_t typeNameLengthOffset = 0x10u;
    constexpr size_t typeNameCapacity = 95u;

    PotionMsvcVector sparse{};
    PotionMsvcVector packed{};
    if (!PotionReadBytes(reinterpret_cast<const void*>(registryAddress + poolsOffset),
                         &sparse, sizeof(sparse)) ||
        !PotionReadBytes(reinterpret_cast<const void*>(registryAddress +
                         poolsOffset + packedOffset), &packed, sizeof(packed)) ||
        !PotionValidVector(sparse, 0x100000u) ||
        !PotionValidVector(packed, 0x1000000u)) {
        LOG_INFO("potions: type-info probe map unreadable registry=%p", registry);
        return false;
    }

    const uintptr_t packedBytes = packed.end - packed.begin;
    if (!packedBytes || packedBytes % nodeSize != 0) {
        LOG_INFO("potions: type-info probe packed layout invalid bytes=%zu",
                 static_cast<size_t>(packedBytes));
        return false;
    }
    const size_t nodeCount = static_cast<size_t>(packedBytes / nodeSize);
    if (nodeCount == 0 || nodeCount > 0x10000u) return false;

    int typeMatches = 0;
    int storageReads = 0;
    int executableVfts = 0;
    int typeInfoReads = 0;
    int typeHashReads = 0;
    int keyMatches = 0;
    for (size_t nodeIndex = 0; nodeIndex < nodeCount; ++nodeIndex) {
        const uintptr_t node = packed.begin + nodeIndex * nodeSize;
        uint32_t key = 0;
        uintptr_t storage = 0;
        const bool keyRead =
            PotionReadBytes(reinterpret_cast<const void*>(node + 0x08u), &key,
                             sizeof(key));
        const bool storageRead =
            PotionReadBytes(reinterpret_cast<const void*>(node + 0x10u),
                            &storage, sizeof(storage)) && storage;
        if (keyRead && key == kPotionComponentHash) ++keyMatches;
        if (nodeIndex < 4u) {
            LOG_INFO("potions: type-info node=%zu key=%08X storage=%p",
                     nodeIndex, key, reinterpret_cast<void*>(storage));
        }
        if (!storageRead) continue;
        ++storageReads;

        uintptr_t vft = 0;
        const bool executableVft =
            PotionReadBytes(reinterpret_cast<const void*>(storage), &vft,
                             sizeof(vft)) && PotionValidVtable(vft);
        if (executableVft) ++executableVfts;
        if (!executableVft) continue;

        uintptr_t typeInfo = 0;
        bool typeInfoRead =
            PotionReadBytes(reinterpret_cast<const void*>(storage + typeInfoOffset),
                             &typeInfo, sizeof(typeInfo)) && typeInfo &&
            GuiPageReadable(reinterpret_cast<const void*>(typeInfo +
                                                            typeNameLengthOffset));
        if (!typeInfoRead) {
            // Keep the diagnostic tolerant of the adjacent MSVC base padding;
            // the primary Flarial/EnTT layout remains +0x38.
            typeInfo = 0;
            typeInfoRead =
                PotionReadBytes(reinterpret_cast<const void*>(storage + 0x40u),
                                &typeInfo, sizeof(typeInfo)) && typeInfo &&
                GuiPageReadable(reinterpret_cast<const void*>(typeInfo +
                                                               typeNameLengthOffset));
        }
        if (!typeInfoRead) continue;
        ++typeInfoReads;

        uint32_t typeHash = 0;
        uintptr_t typeName = 0;
        size_t typeNameLength = 0;
        if (!PotionReadBytes(reinterpret_cast<const void*>(typeInfo + typeHashOffset),
                             &typeHash, sizeof(typeHash)) ||
            !PotionReadBytes(reinterpret_cast<const void*>(typeInfo + typeNameOffset),
                             &typeName, sizeof(typeName)) ||
            !PotionReadBytes(reinterpret_cast<const void*>(typeInfo +
                                                           typeNameLengthOffset),
                             &typeNameLength, sizeof(typeNameLength))) continue;
        ++typeHashReads;

        char name[typeNameCapacity + 1u] = {};
        const size_t copiedLength =
            typeName && typeNameLength <= typeNameCapacity ? typeNameLength : 0u;
        if (copiedLength &&
            !PotionReadBytes(reinterpret_cast<const void*>(typeName), name,
                             copiedLength)) continue;
        name[copiedLength] = '\0';

        const bool hashMatch = typeHash == kPotionComponentHash;
        const bool nameMatch =
            std::string_view{name, copiedLength}.find("MobEffectsComponent") !=
            std::string_view::npos;
        if (!hashMatch && !nameMatch) continue;

        ++typeMatches;
        LOG_INFO("potions: MobEffects type-info node=%zu key=%08X type=%08X name=%s storage=%p", 
                 nodeIndex, key, typeHash, name[0] ? name : "<none>",
                 reinterpret_cast<void*>(storage));

        if (PotionReadStorageObjectVector(reinterpret_cast<void*>(storage), entity,
                                           vector)) {
            LOG_INFO("potions: MobEffects type-info storage read ok component=%p",
                     reinterpret_cast<void*>(g_potionComponentAddress));
            return true;
        }
    }

    LOG_INFO("potions: MobEffects type-info probe complete nodes=%zu matches=%d keyMatches=%d storage=%d vft=%d info=%d hash=%d",
             nodeCount, typeMatches, keyMatches, storageReads, executableVfts,
             typeInfoReads, typeHashReads);
    return false;
}

// Last-resort ABI-neutral registry scan. The hash is version-sensitive in
// Bedrock even when the component name is unchanged, so enumerate the target
// dense_map nodes after the exact hash path fails. A candidate is accepted only
// when its storage contains the live entity and its vector decodes as a real
// effect record; arbitrary component pools are therefore not used as data.
bool PotionReadAnyRegistryStorage(void* registry, uint32_t entity,
                                  PotionMsvcVector& vector) {
    vector = PotionMsvcVector{};
    if (!registry || !GuiPageReadable(registry)) return false;

    static const size_t sparseOffsets[] = { 0x00u, 0x08u, 0x10u, 0x18u };
    static const size_t packedOffsets[] = { 0x18u, 0x20u, 0x28u, 0x30u, 0x38u, 0x40u };
    static const size_t nodeSizes[] = { 0x20u, 0x28u, 0x30u, 0x18u };
    static const size_t keyOffsets[] = { 0x08u, 0x10u, 0x00u };
    static const size_t sharedPtrOffsets[] = { 0x10u, 0x18u, 0x20u, 0x08u };

    for (size_t poolOffset = 0; poolOffset <= 0x300u; poolOffset += 0x08u) {
        const uintptr_t map = reinterpret_cast<uintptr_t>(registry) + poolOffset;
        for (const size_t sparseOffset : sparseOffsets) {
            PotionMsvcVector sparse{};
            if (!PotionReadBytes(reinterpret_cast<const void*>(map + sparseOffset),
                                 &sparse, sizeof(sparse)) ||
                !PotionValidVector(sparse, 0x100000u)) continue;

            const uintptr_t sparseBytes = sparse.end - sparse.begin;
            if (sparseBytes < 0x40u || sparseBytes % sizeof(size_t) != 0) continue;
            const size_t bucketCount = static_cast<size_t>(sparseBytes / sizeof(size_t));
            if ((bucketCount & (bucketCount - 1u)) != 0 || bucketCount < 8u ||
                bucketCount > 0x100000u) continue;

            for (const size_t packedOffset : packedOffsets) {
                if (packedOffset == sparseOffset) continue;
                PotionMsvcVector packed{};
                if (!PotionReadBytes(reinterpret_cast<const void*>(map + packedOffset),
                                     &packed, sizeof(packed)) ||
                    !PotionValidVector(packed, 0x1000000u)) continue;
                const uintptr_t packedBytes = packed.end - packed.begin;
                if (!packedBytes || packedBytes > 0x1000000u) continue;

                if (g_potionRawMapProbeCount < 12) {
                    LOG_INFO("potions: registry map candidate registry=%p poolOff=0x%zx sparseOff=0x%zx packedOff=0x%zx sparse=[%p,%p] packed=[%p,%p] buckets=%zu packedBytes=%zu",
                             registry, poolOffset, sparseOffset, packedOffset,
                             reinterpret_cast<void*>(sparse.begin),
                             reinterpret_cast<void*>(sparse.end),
                             reinterpret_cast<void*>(packed.begin),
                             reinterpret_cast<void*>(packed.end),
                             bucketCount, static_cast<size_t>(packedBytes));
                    ++g_potionRawMapProbeCount;
                }

                for (const size_t nodeSize : nodeSizes) {
                    if (packedBytes % nodeSize != 0) continue;
                    const size_t nodeCount = static_cast<size_t>(packedBytes / nodeSize);
                    if (nodeCount == 0 || nodeCount > 0x10000u) continue;

                    for (size_t nodeIndex = 0; nodeIndex < nodeCount; ++nodeIndex) {
                        const uintptr_t nodeAddress = packed.begin + nodeIndex * nodeSize;
                        for (const size_t keyOffset : keyOffsets) {
                            if (keyOffset + sizeof(uint32_t) > nodeSize) continue;
                            uint32_t key = 0;
                            if (!PotionReadBytes(reinterpret_cast<const void*>(
                                    nodeAddress + keyOffset), &key, sizeof(key))) continue;

                            for (const size_t sharedOffset : sharedPtrOffsets) {
                                if (sharedOffset + sizeof(uintptr_t) > nodeSize) continue;
                                uintptr_t storage = 0;
                                if (!PotionReadBytes(reinterpret_cast<const void*>(
                                        nodeAddress + sharedOffset), &storage,
                                        sizeof(storage)) || !storage) continue;
                                PotionMsvcVector candidate{};
                                if (!PotionReadStorageObjectVector(
                                        reinterpret_cast<void*>(storage), entity,
                                        candidate)) continue;
                                PotionEffect decoded[24]{};
                                if (PotionDecodeVector(
                                        candidate, decoded,
                                        static_cast<int>(std::size(decoded))) <= 0)
                                    continue;
                                vector = candidate;
                                if (!g_potionRawRegistryProbeLogged) {
                                    LOG_INFO("potions: registry pool scan found effects key=%08X poolOff=0x%zx sparseOff=0x%zx packedOff=0x%zx nodeSize=0x%zx node=%zu",
                                             key, poolOffset, sparseOffset,
                                             packedOffset, nodeSize, nodeIndex);
                                    g_potionRawRegistryProbeLogged = true;
                                }
                                return true;
                            }
                        }
                    }
                }
            }
        }
    }
    return false;
}

bool PotionReadEnTTStorageForRegistry(void* registry, uint32_t entity,
                                      PotionMsvcVector& vector) {
    static ULONGLONG nextScanAt = 0;
    const ULONGLONG now = GetTickCount64();
    if (now < nextScanAt) return false;
    nextScanAt = now + 1000;

    if (PotionReadRawRegistryStorage(registry, entity, vector)) return true;
    if (PotionReadAnyRegistryStorage(registry, entity, vector)) return true;
    void* storage = nullptr;
    if (!PotionInvokeRegistryStorage(registry, storage) || !storage) return false;
    return PotionReadStorageObjectVector(storage, entity, vector);
}

bool PotionReadStorageVector(PotionAssureFn assure, void* enttRegistry,
                             uint32_t entity, PotionMsvcVector& vector) {
    vector = PotionMsvcVector{};
    if (!assure || !JavaIsGameCodeAddress(reinterpret_cast<uintptr_t>(assure)) ||
        !enttRegistry || !GuiPageReadable(enttRegistry)) return false;

    void* storage = nullptr;
    if (!PotionInvokeAssure(assure, enttRegistry, storage)) return false;
    return PotionReadStorageObjectVector(storage, entity, vector);
}
void TryInstallPotionReader() {
    if (g_potionLocalPlayerScanTried) return;
    HMODULE game = GetModuleHandleW(nullptr);
    CacheGuiGameImage();
    if (!game || !g_gameImageBase) return;

    // Same getLocalPlayer call-site candidates used by hamambanan. The
    // component reader itself remains the simple local-player EntityContext
    // path; no speculative accessor or registry scan is installed here.
    static const char* localPlayerCandidates[] = {
        "49 8B 00 49 8B C8 48 8B 80 ? ? ? ? FF 15 ? ? ? ? 48 85 C0 0F 84 ? ? ? ? 48 8B C8",
        "49 8B 00 49 8B C8 48 8B 80 ? ? ? ? FF 15 ? ? ? ? 48 85 C0 0F 84 ? ? ? ? 0F",
        "49 8B 00 49 8B C8 48 8B 80 ? ? ? ? FF 15 ? ? ? ? 48 85 C0",
        "49 8B 00 49 8B C8 48 8B 80 ? ? ? ? FF 15 ? ? ? ?"
    };
    for (const char* sig : localPlayerCandidates) {
        uintptr_t site = 0;
        if (ScanSigMatches(game, sig, site) != 1 ||
            !GuiRangeReadable(reinterpret_cast<const void*>(site + 9), sizeof(int32_t)))
            continue;
        int32_t byteOffset = 0;
        std::memcpy(&byteOffset, reinterpret_cast<const void*>(site + 9),
                    sizeof(byteOffset));
        if (byteOffset <= 0 ||
            byteOffset % static_cast<int32_t>(sizeof(void*)) != 0)
            continue;
        const int vfunc = byteOffset / static_cast<int32_t>(sizeof(void*));
        if (vfunc <= 0 || vfunc >= 500) continue;
        bool duplicate = false;
        for (int i = 0; i < g_potionLocalPlayerCandidateCount; ++i)
            duplicate |= g_potionLocalPlayerCandidates[i] == vfunc;
        if (!duplicate && g_potionLocalPlayerCandidateCount < 4)
            g_potionLocalPlayerCandidates[g_potionLocalPlayerCandidateCount++] = vfunc;
    }
    g_potionLocalPlayerScanTried = true;
    // Do not call guessed target helper addresses from the MinGW DLL. The
    // previous diagnostic build proved that such a call can have side effects
    // even when its VEH catches an access violation. The reader below is
    // read-only and uses only ReadProcessMemory.
    LOG_INFO("potions: hamambanan reader local-player candidates=%d bridge=msvc-registry",
             g_potionLocalPlayerCandidateCount);
}

bool PotionReadComponentVector(PotionTryGetFn reader, void* enttRegistry,
                                const void* entity, PotionMsvcVector& vector,
                                void** componentOut = nullptr,
                                bool* callCompletedOut = nullptr) {
    vector = PotionMsvcVector{};
    if (componentOut) *componentOut = nullptr;
    if (callCompletedOut) *callCompletedOut = false;
    if (!reader || !JavaIsGameCodeAddress(reinterpret_cast<uintptr_t>(reader)) ||
        !enttRegistry || !entity || !GuiPageReadable(enttRegistry)) return false;

    void* component = nullptr;
    const bool callCompleted = PotionInvokeTryGet(reader, enttRegistry, entity, component);
    if (componentOut) *componentOut = component;
    if (callCompletedOut) *callCompletedOut = callCompleted;
    if (!callCompleted || !component || !GuiRangeReadable(component, sizeof(PotionMsvcVector)))
        return false;

    if (!PotionReadBytes(component, &vector, sizeof(vector))) return false;

    if (vector.end < vector.begin || vector.capacity < vector.end) return false;
    const uintptr_t bytes = vector.end - vector.begin;
    if (bytes == 0) return true;  // valid component with no active effects
    if (!vector.begin || bytes > static_cast<uintptr_t>(0x88 * 128) ||
        !GuiRangeReadable(reinterpret_cast<const void*>(vector.begin),
                          static_cast<size_t>(bytes))) return false;
    return true;
}

int PotionDecodeVector(const PotionMsvcVector& vector, PotionEffect* out, int maxOut) {
    if (!out || maxOut <= 0 || vector.end < vector.begin) return 0;
    const uintptr_t bytes = vector.end - vector.begin;
    if (bytes == 0) return 0;

    // Bedrock has used both instance sizes in the supported 1.21.x buckets:
    // 0x88 (1.21.30+) and 0x80 (1.21.20). Try the target's current layout
    // first, then the older validated layout. The id/duration checks reject a
    // wrong stride without inventing placeholder effects.
    struct Layout { size_t stride; size_t amplifier; size_t noCounter; };
    static const Layout layouts[] = {
        { 0x88u, 0x20u, 0x26u },
        { 0x80u, 0x14u, 0x1Au }
    };
    for (const Layout& layout : layouts) {
        if (bytes % layout.stride != 0) continue;
        const size_t count = static_cast<size_t>(bytes / layout.stride);
        if (count == 0 || count > 128) continue;
        int written = 0;
        for (size_t i = 0; i < count && written < maxOut; ++i) {
            const uintptr_t item = vector.begin + i * layout.stride;
            if (!GuiRangeReadable(reinterpret_cast<const void*>(item), layout.stride)) {
                written = 0;
                break;
            }
            uint32_t id = 0;
            int duration = 0;
            int amplifier = 0;
            uint8_t noCounter = 0;
            const bool read =
                PotionReadBytes(reinterpret_cast<const void*>(item + 0x00), &id, sizeof(id)) &&
                PotionReadBytes(reinterpret_cast<const void*>(item + 0x04), &duration, sizeof(duration)) &&
                PotionReadBytes(reinterpret_cast<const void*>(item + layout.amplifier),
                                &amplifier, sizeof(amplifier)) &&
                PotionReadBytes(reinterpret_cast<const void*>(item + layout.noCounter),
                                &noCounter, sizeof(noCounter));
            if (!read || id < 1 || id > 64 || (!noCounter && duration <= 0)) continue;
            out[written].id = id;
            out[written].duration = duration;
            out[written].amplifier = amplifier < 0 ? 0 : amplifier;
            out[written].noCounter = noCounter != 0;
            ++written;
        }
        if (written > 0) return written;
    }
    return 0;
}

// Exact path from the previous working source. The component and entity mirror
// deliberately live in the global namespace in bedrock_entt.hpp. On MSVC the
// compiler-generated hash naturally matches the game; on MinGW the explicit
// MobEffectsComponent type_hash specialization in that header supplies the
// target's key. The whole call is guarded because it walks a live game object
// graph with the target's STL/EnTT layout.
void PotionLogEnTTFailure(const char* stage) {
    if (g_potionEnTTFailureLogged) return;
    LOG_INFO("potions: %s", stage ? stage : "read failed");
    g_potionEnTTFailureLogged = true;
}

int PotionFillWithBedrockEnttUnsafe(PotionEffect* out, int maxOut) {
    if (!out || maxOut <= 0 || !g_clientInstance) return 0;

    // Hamambanan's source path is LocalPlayer -> EntityContext ->
    // MobEffectsComponent. The DLL is built with MinGW while Bedrock's EnTT
    // registry is MSVC-built, so keep the same source-level path but bridge
    // the final registry read without instantiating MinGW EnTT methods.
    void* localPlayer = nullptr;
    if (!PotionReadLocalPlayer(localPlayer) || !localPlayer) {
        if (!g_potionLogged) {
            LOG_INFO("potions: no local player (vfunc=%d)", g_potionLocalPlayerVfunc);
            g_potionLogged = true;
        }
        return 0;
    }

    const uintptr_t local = reinterpret_cast<uintptr_t>(localPlayer);
    void* registryObject = nullptr;
    void* enttRegistry = nullptr;
    uint32_t entity = 0;
    if (!PotionReadBytes(reinterpret_cast<const void*>(local + 0x08u),
                         &registryObject, sizeof(registryObject)) ||
        !PotionReadBytes(reinterpret_cast<const void*>(local + 0x10u),
                         &enttRegistry, sizeof(enttRegistry)) ||
        !PotionReadBytes(reinterpret_cast<const void*>(local + 0x18u),
                         &entity, sizeof(entity)) ||
        !registryObject || !enttRegistry || !GuiPageReadable(enttRegistry)) {
        if (!g_potionLogged) {
            LOG_INFO("potions: entity context fields unavailable");
            g_potionLogged = true;
        }
        return 0;
    }

    if (!g_potionContextProbeLogged) {
        LOG_INFO("potions: hamambanan context registry=%p entt=%p entity=%08X",
                 registryObject, enttRegistry, entity);
        g_potionContextProbeLogged = true;
    }

    PotionMsvcVector vector{};
    bool found = PotionReadCachedComponent(enttRegistry, entity, vector);
    if (!found) found = PotionReadExactRegistryStorage(enttRegistry, entity, vector);
    if (!found) found = PotionReadMobEffectsStorageByTypeInfo(enttRegistry, entity, vector);
    if (!found) {
        if (!g_potionLogged) {
            LOG_INFO("potions: MobEffectsComponent not present on player");
            g_potionLogged = true;
        }
        return 0;
    }

    g_potionComponentRegistry = enttRegistry;
    g_potionComponentEntity = entity;
    const int count = PotionDecodeVector(vector, out, maxOut);
    if (vector.end != vector.begin && count <= 0) {
        if (!g_potionLogged) {
            LOG_INFO("potions: MobEffectsComponent record layout invalid");
            g_potionLogged = true;
        }
        return 0;
    }
    if (!g_potionLogged) {
        LOG_INFO("potions: component read ok, effects=%d", count);
        g_potionLogged = true;
    }
    return count;
}

int PotionFillWithBedrockEntt(PotionEffect* out, int maxOut) {
#ifdef _MSC_VER
    __try {
        return PotionFillWithBedrockEnttUnsafe(out, maxOut);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        PotionLogEnTTFailure("guarded-exception");
        return -1;
    }
#else
    PotionVehFrame frame{};
    PVOID handler = AddVectoredExceptionHandler(1, &PotionVehHandler);
    if (!handler) return -1;
    PotionVehFrame* previous = g_potionVehFrame;
    g_potionVehFrame = &frame;
    const int jumped = setjmp(frame.jump);
    int result = -1;
    if (jumped == 0) {
        frame.active = 1;
        result = PotionFillWithBedrockEnttUnsafe(out, maxOut);
    } else {
        PotionLogEnTTFailure("guarded-exception");
    }
    frame.active = 0;
    g_potionVehFrame = previous;
    RemoveVectoredExceptionHandler(handler);
    return result;
#endif
}

int PotionReadEffects(PotionEffect* out, int maxOut) {
    if (!out || maxOut <= 0) return 0;
    const ULONGLONG now = GetTickCount64();
    if (g_potionNextProbeAt != 0 && now < g_potionNextProbeAt) return 0;
    const int count = PotionFillWithBedrockEntt(out, maxOut);
    return count >= 0 ? count : 0;
}

#undef NF_POTION_TRY
#undef NF_POTION_EXCEPT

// ============================ NoHurtCam ============================
bool WriteGameBytes(uintptr_t address, const uint8_t* bytes, size_t length) {
    if (!address || !bytes || !length) return false;
    DWORD oldProtect = 0;
    if (!VirtualProtect((LPVOID)address, length, PAGE_EXECUTE_READWRITE, &oldProtect))
        return false;
    std::memcpy((void*)address, bytes, length);
    FlushInstructionCache(GetCurrentProcess(), (LPCVOID)address, length);
    DWORD ignored = 0;
    VirtualProtect((LPVOID)address, length, oldProtect, &ignored);
    return true;
}

bool LocateNoHurtCamPatch() {
    if (g_hurtCamLocateTried) return g_hurtCamLocated;
    g_hurtCamLocateTried = true;

    // Solstice's CameraComponent_applyRotation candidate. The first four
    // bytes are one complete 66 0F xx xx instruction; NOPing only those four
    // bytes leaves the following cvtdq2ps/comiss/branch sequence intact.
    static const char kSig[] =
        "66 0F ? ? 0F 5B ? 0F 2F ? 76 ? F3 0F ? ? F3 0F";
    uintptr_t first = 0;
    const int matches = ScanSigMatches(GetModuleHandleW(nullptr), kSig, first);
    if (matches != 1 || !first) {
        LOG_INFO("overlay: Solstice NoHurtCam signature matches=%d - patch off", matches);
        return false;
    }

    // Reconfirm the non-wildcard instruction prefix before saving anything.
    const uint8_t* p = reinterpret_cast<const uint8_t*>(first);
    if (p[0] != 0x66 || p[1] != 0x0F) {
        LOG_INFO("overlay: Solstice NoHurtCam prefix validation failed - patch off");
        return false;
    }

    g_hurtCamAddress = first;
    g_hurtCamOriginal.assign(p, p + 4);
    g_hurtCamLocated = true;
    LOG_INFO("overlay: Solstice NoHurtCam located at %p len=4", (void*)first);
    return true;
}

void ApplyNoHurtCamPatch() {
    if (!LocateNoHurtCamPatch() || g_hurtCamApplied) return;
    static const uint8_t nops[4] = { 0x90, 0x90, 0x90, 0x90 };
    if (!WriteGameBytes(g_hurtCamAddress, nops, sizeof(nops))) {
        LOG_ERROR("overlay: Solstice NoHurtCam write failed at %p", (void*)g_hurtCamAddress);
        return;
    }
    g_hurtCamApplied = true;
    LOG_INFO("overlay: Solstice NoHurtCam enabled");
}

void RestoreNoHurtCamPatch() {
    if (!g_hurtCamApplied || g_hurtCamOriginal.size() != 4) return;
    if (WriteGameBytes(g_hurtCamAddress, g_hurtCamOriginal.data(), 4)) {
        g_hurtCamApplied = false;
        LOG_INFO("overlay: Solstice NoHurtCam original bytes restored");
    } else {
        LOG_ERROR("overlay: Solstice NoHurtCam restore failed at %p", (void*)g_hurtCamAddress);
    }
}

void SetNoHurtCamEnabledInternal(bool enabled) {
    if (enabled) ApplyNoHurtCamPatch();
    else RestoreNoHurtCamPatch();
}

// ============================ game feature helpers ============================
bool AutoSprintEnabled() {
    Module* base = modules().find("AutoSprint");
    if (!base || !base->enabled()) return false;
    const AutoSprintModule* sprint = static_cast<const AutoSprintModule*>(base);
    return !sprint->m_alwaysSprint || sprint->m_alwaysSprint->mValue;
}

void ServiceAutoSprintInternal() {
    // Retired: the synthetic Ctrl press through Keyboard::feed did not engage
    // Bedrock's sprint reliably (the game's raw-input key state is re-synced
    // from physical input, so the synthetic press did not stick). AutoSprint
    // now writes the MoveInputComponent sprint flags from the baseTick hook -
    // exactly the Flarial Sprint mechanism - and this export stays as a
    // source-compatible no-op for the menu caller.
}

void HandleAutoSprintFeedKey(uint32_t key, bool isDown) {
    // Intentionally a no-op now: the per-frame ServiceAutoSprint() above is the
    // sole owner of g_autoSprintInjected. Having this W-edge path also write
    // the flag created a race (two threads flipping the same bool) and a
    // one-frame flicker on the synthetic sprint key.
    (void)key;
    (void)isDown;
}

// ============================ Null Movement ============================
// Classic last-press-wins for the opposite pairs (A/D, W/S): while both keys
// of a pair are held, only the newer press reaches the movement; releasing it
// lets the older (still held) key resume. The game re-authors its
// MoveInputComponent every tick from the keyboard map, so suppressing feed
// events does not stick - instead the tick hook re-writes the movement bits
// (the exact mechanism the working AutoSprint uses). This block only records
// the physical press order; the authoring lives in HitboxAutoSprintTick.
static const unsigned kNmKeys[4] = { 'W', 'A', 'S', 'D' };

static void NullMovementRecordPress(unsigned key) {
    for (int i = 0; i < 4; ++i) {
        if (key == kNmKeys[i]) {
            InterlockedExchange64(reinterpret_cast<volatile LONG64*>(&g_nmPressAt[i]),
                                  (LONG64)GetTickCount64());
            return;
        }
    }
}

// ============================ Keyboard::feed detour ============================
void __cdecl HkKeyboardFeed(uint32_t key, bool isDown) {
#ifdef _MSC_VER
    __try {
#endif
        // Mirror every transition for the overlay first.
        keys::FeedKey((unsigned)key, isDown);
        if (isDown) NullMovementRecordPress((unsigned)key);
        {
            static int n = 0;
            if (++n <= 10)
                LOG_INFO("feedkey: key=%02X %s", key & 0xFFu, isDown ? "down" : "up");
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        LOG_ERROR("overlay: exception in feed mirror");
    }
#endif
    // AutoSprint is attached to this same game input boundary. Handle W
    // before the original W event so the paired sprint press/release reaches
    // Bedrock in order; ServiceAutoSprint() also reconciles state when the
    // module is toggled from ClickGUI while W is already held.
    HandleAutoSprintFeedKey(key, isDown);

    // Java Hotkeys observes Pressed/Released but never cancels this event.
    // The actual controller operation is deferred to ContainerScreenController
    // tick, so no inventory SDK call happens on the input boundary.
    JavaHandleKeyFeed(key, isDown);

    // Masking: while the menu or the HUD editor is open the game sees no
    // presses (no steering or pause menu under the cursor). The menu key
    // itself is always masked. Releases pass through - a lone release is
    // harmless to the game.
    if (isDown && (UiInputOwned() || (g_menuKey > 0 && key == (uint32_t)g_menuKey))) return;
    KeyboardFeedFn o = g_oFeed;
    if (o) o(key, isDown);
}

void TryInstallFeedHook() {
    static bool tried = false;
    if (tried) return;
    tried = true;
    // RefSig (Bedrock 1.21.101-1.21.111): match points at "E8 rel32", the
    // function is match + 5 + rel32.
    static const char kSig[] =
        "E8 ? ? ? ? E9 03 03 ? ? 0F BE 73 16 44 0F B7 7B 12 44 0F";
    uintptr_t first = 0;
    const int matches = ScanSigMatches(GetModuleHandleW(nullptr), kSig, first);
    if (matches != 1 || !first) {
        LOG_INFO("overlay: Keyboard::feed sig matches=%d - feed off (raw/poll only)", matches);
        return;
    }
    const uintptr_t feed = first + 5 + (uintptr_t)(int32_t)*(const int32_t*)(first + 1);
    LOG_INFO("overlay: Keyboard::feed at %p (sig %p)", (void*)feed, (void*)first);
    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) {
        LOG_ERROR("overlay: MH_Initialize failed (%d)", (int)st);
        return;
    }
    st = MH_CreateHook((LPVOID)feed, (LPVOID)&HkKeyboardFeed, (LPVOID*)&g_oFeed);
    if (st != MH_OK || !g_oFeed) {
        LOG_ERROR("overlay: MH_CreateHook(feed) failed (%d)", (int)st);
        return;
    }
    st = MH_EnableHook((LPVOID)feed);
    g_feedHook = (st == MH_OK);
    LOG_INFO("overlay: Keyboard::feed hook active=%d (%d)", g_feedHook ? 1 : 0, (int)st);
}

// Bedrock's CoreWindow/MouseDevice path does not have to produce a WM_* or
// GetRawInputData call. Cancel it at the game's mouse dispatcher as well.
// The two signatures are the same input boundary used by the target's
// reference audit: a direct function prologue and a nearby call-site fallback.
// CPS gate (defined below; feeds the limiter and the CPS counter).
static bool CpsFeedClick(bool left, int limit, bool limited);
static int CpsCountRegistered(bool left);

void __fastcall HkMouseFeed(void* mouseDevice, char mouseButton, char isDown,
                            short mouseX, short mouseY, short relativeX,
                            short relativeY, char extra) {
    // Bedrock parks the desktop cursor at the centre while the player owns
    // relative mouse input. Keep a separate GUI cursor driven by the game's
    // own relative feed, just like the working previous implementation.
    if (mouseButton == 0) {
        InterlockedExchange(&g_gameMouseX, (LONG)mouseX);
        InterlockedExchange(&g_gameMouseY, (LONG)mouseY);
        InterlockedExchange(&g_gameMouseValid, 1);
        if (UiInputOwned() && (relativeX != 0 || relativeY != 0)) {
            InterlockedExchangeAdd(&g_feedDx, (LONG)relativeX);
            InterlockedExchangeAdd(&g_feedDy, (LONG)relativeY);
        }
    } else if (mouseX >= 0 && mouseY >= 0) {
        // Button/wheel packets also carry a client-space position on some
        // Bedrock builds; keep it as a fallback seed for the GUI cursor.
        InterlockedExchange(&g_gameMouseX, (LONG)mouseX);
        InterlockedExchange(&g_gameMouseY, (LONG)mouseY);
        InterlockedExchange(&g_gameMouseValid, 1);
    }

    // Keep a separate atomic button/wheel snapshot. The old path only wrote
    // g_rawBtn, which made ImGui's edge-based IsMouseClicked/IsMouseDown state
    // unreliable when the game delivered CoreWindow events without WM_*.
    int button = -1;
    if (mouseButton == 1) button = 0;       // left
    else if (mouseButton == 2) button = 1;  // right
    else if (mouseButton == 3) button = 2;  // middle
    else if (mouseButton == 5) button = 3;  // X1
    else if (mouseButton == 6) button = 4;  // X2
    if (button >= 0) {
        const LONG bit = (LONG)(1u << button);
        g_rawBtn[button] = isDown != 0;
        if (isDown) InterlockedOr(&g_gameMouseButtons, bit);
        else        InterlockedAnd(&g_gameMouseButtons, ~bit);
        // Flarial parity: a mouse button can be bound to a hotbar slot, and
        // that hotkey fires regardless of CPS limiting (their listeners run
        // before the limiter's cancel). Menu-owned input is filtered inside.
        if (isDown) JavaHandleMouseFeed(mouseButton);
    } else if (mouseButton == 4) {
        // Packet-style builds use the signed isDown byte as wheel direction.
        // Only accumulate it for the GUI session (menu or HUD editor); the
        // game keeps its own path untouched when neither is active.
        if (UiInputOwned() && isDown != 0)
            InterlockedExchangeAdd(&g_gameMouseWheel,
                                   (LONG)((signed char)isDown > 0 ? 1 : -1));
    }

    const bool blocked = UiInputOwned() && !g_shuttingDown;
    if (button >= 0) {
        const LONG bit = (LONG)(1u << button);
        if (isDown) {
            if (blocked) return;  // never deliver a new click to the game
            InterlockedOr(&g_mouseForwardedButtons, bit);
        } else {
            const LONG wasForwarded = InterlockedAnd(&g_mouseForwardedButtons, ~bit) & bit;
            // Forward only a release for a button that was already delivered
            // before the GUI opened; this prevents a stuck game button while
            // still suppressing clicks that started inside the GUI.
            if (blocked && !wasForwarded) return;
        }
    } else if (blocked) {
        // button 0 = motion, button 4 = wheel, and any future dispatcher
        // packet: none of it may reach the game while the GUI owns input.
        return;
    }

    // CPS Limiter: a press without a token is dropped here - the game never
    // sees it (GUI-blocked clicks returned above and do not count). Delivered
    // clicks are stamped for the CPS counter.
    if (isDown && (mouseButton == 1 || mouseButton == 2)) {
        const bool limited =
            InterlockedCompareExchange(&g_cpsLimiterEnabled, 0, 0) != 0;
        const int limit = InterlockedCompareExchange(
            mouseButton == 1 ? &g_cpsLimitL : &g_cpsLimitR, 0, 0);
        if (!CpsFeedClick(mouseButton == 1, limit, limited)) return;
    }

    MouseFeedFn o = g_oMouseFeed;
    if (o) o(mouseDevice, mouseButton, isDown, mouseX, mouseY,
             relativeX, relativeY, extra);
}

// ============================ CPS Limiter ============================
// Flarial CPSLimiter parity. The limiter is their RateLimiter token bucket:
// tokens refill continuously at `limit` per second (capped so a pause cannot
// bank a burst), and a click passes only when a token is available - clicking
// faster than the limit spreads the clicks evenly instead of bursting and
// starving. Every click that passes is stamped for the CPS counter, so the
// HUD shows exactly what the game registers, like Flarial's CPSCounter.
struct CpsGate {
    ULONGLONG stamps[64] = {};   // passed clicks (1 s ring, CPS counter)
    int head = 0;
    int count = 0;
    double tokens = 0.0;         // RateLimiter bucket
    ULONGLONG lastRefill = 0;
};
static CpsGate g_cpsGates[2] = {};        // 0 = LMB, 1 = RMB
static CRITICAL_SECTION g_cpsCs;
static bool g_cpsCsInit = false;

// Returns true when the click is delivered to the game; every delivered click
// is stamped for GetRegisteredCps.
static bool CpsFeedClick(bool left, int limit, bool limited) {
    const ULONGLONG now = GetTickCount64();
    CpsGate& g = g_cpsGates[left ? 0 : 1];
    bool allow = true;
    if (limited && limit > 0) {
        const double rate = (double)limit;
        // Flarial's RateLimiter constructor starts the bucket full
        // (tokens = rate), so right after enabling the limiter a click never
        // waits for the first refill.
        if (g.lastRefill == 0) g.tokens = rate;
        const double elapsed = (double)(now - g.lastRefill);
        if (elapsed > 0.0) {
            // Refill capped at one token's worth per call, exactly like the
            // reference: a long pause must not bank a burst.
            const double cap = 1000.0 / rate;
            const double used = elapsed < cap ? elapsed : cap;
            const double refilled = g.tokens + rate * used / 1000.0;
            g.tokens = refilled < rate ? refilled : rate;
            g.lastRefill = now;
        }
        if (g.tokens >= 1.0) g.tokens -= 1.0;
        else allow = false;
    }
    if (allow) {
        EnterCriticalSection(&g_cpsCs);
        g.stamps[g.head] = now;
        g.head = (g.head + 1) % 64;
        if (g.count < 64) ++g.count;
        LeaveCriticalSection(&g_cpsCs);
    }
    return allow;
}

void TryInstallMouseFeedHook() {
    if (!g_cpsCsInit) {
        InitializeCriticalSection(&g_cpsCs);
        g_cpsCsInit = true;
    }
    static bool tried = false;
    if (tried) return;
    tried = true;

    HMODULE game = GetModuleHandleW(nullptr);
    uintptr_t first = 0;
    const char kPrologue[] =
        "48 8B C4 48 89 58 ? 48 89 68 ? 48 89 70 ? 57 41 54 41 55 41 56 41 57 "
        "48 83 EC ? 44 0F B7 BC 24 ? ? ? ? 48 8B D9";
    int matches = ScanSigMatches(game, kPrologue, first);
    uintptr_t feed = 0;
    const char* source = "prologue";
    if (matches == 1 && first) {
        feed = first;
    } else {
        // Fallback call-site signature used by nearby Bedrock builds.
        first = 0;
        matches = ScanSigMatches(game, "E8 ? ? ? ? 40 88 6C 1F", first);
        source = "call-site";
        if (matches == 1 && first) {
            const int32_t rel = *(const int32_t*)(first + 1);
            feed = first + 5 + (intptr_t)rel;
        }
    }
    if (!feed) {
        LOG_INFO("overlay: MouseDevice::feed sig matches=%d - mouse feed off (raw/user32 fallback)", matches);
        return;
    }

    LOG_INFO("overlay: MouseDevice::feed at %p via %s", (void*)feed, source);
    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) {
        LOG_ERROR("overlay: MH_Initialize(mouse feed) failed (%d)", (int)st);
        return;
    }
    st = MH_CreateHook((LPVOID)feed, (LPVOID)&HkMouseFeed,
                       (LPVOID*)&g_oMouseFeed);
    if (st != MH_OK || !g_oMouseFeed) {
        LOG_ERROR("overlay: MH_CreateHook(MouseDevice::feed) failed (%d)", (int)st);
        return;
    }
    st = MH_EnableHook((LPVOID)feed);
    g_mouseFeedHook = (st == MH_OK);
    LOG_INFO("overlay: MouseDevice::feed hook active=%d (%d)",
             g_mouseFeedHook ? 1 : 0, (int)st);
}

// ============================ cursor/raw user32 detours ============================
// In-world Bedrock re-hides, re-centers and clips the OS cursor every frame
// and reads input via raw input (messages and/or the raw buffer). While the
// menu is open these detours reject the grab and neutralize what the game
// reads; while closed every detour is a pure pass-through.
void NeutralizeRawInput(RAWINPUT* ri) {
    if (!ri) return;
    // Only the payload goes inert: the packet keeps its real shape and size.
    // Returning 0/"no data" instead would make game callers parse a RAWINPUT
    // out of a zero-byte buffer (heap UB inside the game).
    if (ri->header.dwType == RIM_TYPEMOUSE) {
        ri->data.mouse.lLastX = 0;
        ri->data.mouse.lLastY = 0;
        ri->data.mouse.usButtonFlags = 0;
        ri->data.mouse.usButtonData = 0;
    } else if (ri->header.dwType == RIM_TYPEKEYBOARD) {
        ri->data.keyboard.Message = WM_NULL;  // ignored by every raw key path
        ri->data.keyboard.VKey = 0;
    }
}

UINT WINAPI HkGetRawInputData(HRAWINPUT h, UINT cmd, LPVOID data, PUINT size, UINT hdr) {
#ifdef _MSC_VER
    __try {
#endif
        const UINT ret = oGetRawInputData ? oGetRawInputData(h, cmd, data, size, hdr) : 0;
        if (UiInputOwned() && cmd == RID_INPUT && data && ret > 0 && ret != (UINT)-1)
            NeutralizeRawInput((RAWINPUT*)data);
        return ret;
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
#endif
    return 0;
}

UINT WINAPI HkGetRawInputBuffer(RAWINPUT* data, PUINT size, UINT hdr) {
#ifdef _MSC_VER
    __try {
#endif
        const UINT ret = oGetRawInputBuffer ? oGetRawInputBuffer(data, size, hdr) : 0;
        if (UiInputOwned() && data && ret > 0 && ret != (UINT)-1) {
            RAWINPUT* ri = data;
            for (UINT i = 0; i < ret; i++) {
                const DWORD step = ri->header.dwSize;
                NeutralizeRawInput(ri);
                if (step < sizeof(RAWINPUTHEADER)) break;  // malformed: stop
                ri = (RAWINPUT*)((BYTE*)ri + step);
            }
        }
        return ret;
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
#endif
    return 0;
}

BOOL WINAPI HkSetCursorPos(int x, int y) {
    // The OS arrow is hidden while the GUI is open; software cursor and click
    // hit-testing both use ImGuiIO::MousePos, so a game's recenter cannot
    // produce a second visible pointer or move MouseStrokes out of sync.
    return oSetCursorPos ? oSetCursorPos(x, y) : FALSE;
}

BOOL WINAPI HkClipCursor(const RECT* rect) {
    // Our own ClipCursor(nullptr) on open must pass; only new non-null game
    // clips are rejected while the GUI (menu or HUD editor) owns input.
    if (UiInputOwned() && rect != nullptr) return TRUE;
    return oClipCursor ? oClipCursor(rect) : FALSE;
}

HWND WINAPI HkSetCapture(HWND hwnd) {
    if (UiInputOwned()) return nullptr;
    return oSetCapture ? oSetCapture(hwnd) : nullptr;
}

int WINAPI HkShowCursor(BOOL show) {
    // Keep Bedrock from changing the hardware-cursor counter while ImGui owns
    // the software cursor. UpdateCursor adjusts the original counter directly
    // and restores its own changes on close.
    if (UiInputOwned()) return show ? 1 : 0;
    return oShowCursor ? oShowCursor(show) : 1;
}

SHORT WINAPI HkGetAsyncKeyState(int vk) {
    // GetAsyncKeyState is the last input path that can bypass WndProc/raw
    // masking. Return a neutral state to the game while the GUI owns input
    // (menu open or HUD editor active). Nightfull itself uses
    // SampleAsyncKeyState(), which calls the trampoline directly and
    // therefore remains fully interactive.
    if (UiInputOwned() && !g_shuttingDown) return 0;
    return oGetAsyncKeyState ? oGetAsyncKeyState(vk) : 0;
}

void TryInstallCursorHooks() {
    static bool tried = false;
    if (tried) return;
    tried = true;
    HMODULE u32 = GetModuleHandleA("user32.dll");
    if (!u32) {
        LOG_ERROR("overlay: no user32 for cursor hooks");
        return;
    }
    struct Hook { const char* name; LPVOID detour; LPVOID* orig; };
    Hook hooks[] = {
        { "GetRawInputData", (LPVOID)&HkGetRawInputData, (LPVOID*)&oGetRawInputData },
        { "GetRawInputBuffer", (LPVOID)&HkGetRawInputBuffer, (LPVOID*)&oGetRawInputBuffer },
        { "SetCursorPos", (LPVOID)&HkSetCursorPos, (LPVOID*)&oSetCursorPos },
        { "ClipCursor", (LPVOID)&HkClipCursor, (LPVOID*)&oClipCursor },
        { "SetCapture", (LPVOID)&HkSetCapture, (LPVOID*)&oSetCapture },
        { "ShowCursor", (LPVOID)&HkShowCursor, (LPVOID*)&oShowCursor },
        { "GetAsyncKeyState", (LPVOID)&HkGetAsyncKeyState, (LPVOID*)&oGetAsyncKeyState },
    };
    MH_STATUS st = MH_Initialize();
    if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED) {
        LOG_ERROR("overlay: MH_Initialize failed (%d)", (int)st);
        return;
    }
    bool ok = false;
    for (size_t i = 0; i < sizeof(hooks) / sizeof(hooks[0]); i++) {
        FARPROC p = GetProcAddress(u32, hooks[i].name);
        if (!p) {
            LOG_ERROR("overlay: no user32 export %s", hooks[i].name);
            continue;
        }
        st = MH_CreateHook((LPVOID)p, hooks[i].detour, hooks[i].orig);
        if (st != MH_OK || !*hooks[i].orig) {
            LOG_ERROR("overlay: hook %s failed (%d)", hooks[i].name, (int)st);
            continue;
        }
        if (MH_EnableHook((LPVOID)p) == MH_OK) ok = true;
        else LOG_ERROR("overlay: enable %s failed", hooks[i].name);
    }
    g_cursorHooks = ok;
    // Even if one of the optional cursor hooks fails, the sampler keeps the
    // overlay's own key snapshot on the original path rather than being
    // affected by the process-wide async-state mask.
    keys::SetAsyncStateSampler(&SampleAsyncKeyState);
    LOG_INFO("overlay: cursor/raw-block hooks active=%d (async key mask included)", ok ? 1 : 0);
}

#undef NF_POTION_TRY
#undef NF_POTION_EXCEPT

// ============================ hooks ============================
HRESULT __stdcall HkPresent(IDXGISwapChain* sc, UINT sync, UINT flags) {
#ifdef _MSC_VER
    __try {
#endif
        InterlockedOr(&g_presentSeen, 1);
        // VSync Disabler: present without the vblank wait.
        if (InterlockedCompareExchange(&g_vsyncDisabled, 0, 0))
            sync = 0;
        if (g_shuttingDown || !sc) {
            // fall through to the original below
        } else if (!g_init) {
            DXGI_SWAP_CHAIN_DESC sd{};
            if (SUCCEEDED(sc->GetDesc(&sd))) {
                g_w = sd.BufferDesc.Width;
                g_h = sd.BufferDesc.Height;
            }
            if (!g_wndHooked) {
                // UWP/composition swapchains often report a null OutputWindow -
                // fall back to probing the process for its main window.
                HWND target = sd.OutputWindow ? sd.OutputWindow : FindGameWindow();
                if (target) {
                    if (!sd.OutputWindow)
                        LOG_INFO("overlay: swapchain OutputWindow is null - probing found %p", target);
                    InstallWndHook(target);
                } else {
                    LOG_ERROR("overlay: no game window for the input hook - will keep retrying");
                }
            }
            g_sc = sc;
            TryInstallFeedHook();       // game keyboard boundary
            TryInstallJavaInventoryHooks(); // validated controller boundaries
            TryInstallMouseFeedHook();   // game mouse boundary
            TryInstallGammaHook();      // Options::getGamma boundary
            TryInstallGuiScaleHook();   // native Minecraft GUI scale
            TryInstallPotionReader();   // read-only local effect component
            TryInstallCursorHooks();     // user32 detours (once; inert while menu closed)
            static int initFails = 0;
            if (InitD3D11(sc) || InitD3D12(sc)) {
                g_init = true;
                initFails = 0;
            } else {
                TeardownRender();
                ++initFails;
                if (initFails == 1 || initFails % 600 == 0)
                    LOG_ERROR("overlay: render init failed (%d) - retrying", initFails);
                if (initFails == 120) {
                    // One-shot full diagnostic for a wedged init streak (e.g.
                    // a GUI-scale relayout or window re-creation changed the
                    // swapchain): makes "HUD never came back" diagnosable.
                    DXGI_SWAP_CHAIN_DESC diag{};
                    const bool haveDesc = SUCCEEDED(sc->GetDesc(&diag));
                    LOG_ERROR("overlay: render init failed %d times - sc=%p desc(ok=%d %ux%u buf=%u out=%p) wnd=%p frame=%ux%u",
                              initFails, (void*)sc, haveDesc ? 1 : 0,
                              haveDesc ? diag.BufferDesc.Width : 0,
                              haveDesc ? diag.BufferDesc.Height : 0,
                              haveDesc ? diag.BufferCount : 0,
                              haveDesc ? (void*)diag.OutputWindow : nullptr,
                              (void*)g_hwnd, g_w, g_h);
                }
            }
        } else if (sc != g_sc) {
            LOG_INFO("overlay: swapchain changed - reinit");
            EnterCriticalSection(&g_renderCs);
            TeardownRender();
            LeaveCriticalSection(&g_renderCs);
        } else if (g_usingD3D12 && g_d12dev && FAILED(g_d12dev->GetDeviceRemovedReason())) {
            // The GPU is gone (TDR/fault): drop everything, forget the game
            // queue (it belongs to the dead device) and reinit next frame.
            // The queue vtable hook stays: the new device shares the vtable.
            LOG_ERROR("overlay: D3D12 device removed (%08X) - tearing down for reinit",
                      (unsigned)g_d12dev->GetDeviceRemovedReason());
            // A fault may have surfaced from the saturation pass's own GPU
            // work: latch the pass off for the rest of the session (logs once).
            SaturationGpuFault();
            EnterCriticalSection(&g_renderCs);
            TeardownRender();
            g_gameQueue = nullptr;
            LeaveCriticalSection(&g_renderCs);
        } else if (!g_renderAborted) {
            // One fused key snapshot per frame, then hotkeys, then the frame.
            static int fno = 0;
            const bool trace = ++fno <= 3;
            if (trace) LOG_INFO("trace: present frame %d begin", fno);
            keys::BeginFrame();
            // Input census (~10 s in): proves which input path is alive.
            static bool s_asyncInsert = false, s_asyncK = false, s_asyncM1 = false;
            s_asyncInsert |= (SampleAsyncKeyState(VK_INSERT) & 0x8000) != 0;
            s_asyncK |= (SampleAsyncKeyState('K') & 0x8000) != 0;
            s_asyncM1 |= (SampleAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
            if ((fno % 1800) == 0) ScanAndHookProcessWindows();  // late-created game windows
            if (fno == 600 || fno == 3600) {
                // fgwnd=0 means the backend's own cursor poll never ran (it
                // requires foreground == its window): our driven pos is the
                // only position source then.
                const int fgUs = (GetForegroundWindow() == g_hwnd) ? 1 : 0;
                LOG_INFO("input census(%d): keydown=%d keyup=%d rawinput=%d rawbtn=%d char=%d mousemove=%d lbtn=%d fgwnd=%d asyncEver(insert=%d k=%d m1=%d)",
                         fno, g_cKeyDown, g_cKeyUp, g_cInput, g_cRawBtn, g_cChar, g_cMouse, g_cBtn, fgUs,
                         s_asyncInsert ? 1 : 0, s_asyncK ? 1 : 0, s_asyncM1 ? 1 : 0);
            }
            // The menu key re-arms only after a release, so holding INSERT
            // (or key auto-repeat) can never strobe the menu. mkDown is
            // sampled BEFORE any Reset() in this frame, or the arm would
            // re-engage instantly and the strobe would survive.
            const bool mkDown = keys::Down((unsigned)g_menuKey);
            if (keys::PressedThisFrame((unsigned)g_menuKey) && g_menuKey > 0 && g_menuKeyArmed) {
                g_showMenu = !g_showMenu;
                g_menuKeyArmed = false;
                keys::Reset();
                LOG_INFO("menu: toggle -> %d", g_showMenu ? 1 : 0);
                if (g_showMenu && g_hudEdit) {
                    // The ClickGUI wins over the HUD editor: opening the menu
                    // always leaves edit mode (the setting follows via the
                    // menu's per-frame reconciliation).
                    g_hudEdit = false;
                    ui::Toast("HUD editor off");
                    LOG_INFO("hud editor: off (menu opened)");
                }
            } else if (keys::PressedThisFrame(VK_ESCAPE) && (g_showMenu || g_hudEdit)) {
                // ESC first dismisses transient UI (field/dropdown/popup/bind),
                // and only closes the menu when nothing is open. With the menu
                // closed, ESC exits the HUD editor.
                if (g_showMenu) {
                    if (!ui::DismissTopmost()) {
                        g_showMenu = false;
                        LOG_INFO("menu: ESC -> closed");
                    }
                } else {
                    g_hudEdit = false;
                    ui::Toast("HUD editor off");
                    LOG_INFO("hud editor: ESC -> off");
                }
                keys::Reset();
            }
            if (keys::PressedThisFrame(VK_END) && !g_unloadRequested) {
                g_unloadRequested = true;
                LOG_INFO("overlay: unload requested (END)");
            }
            if (g_showMenu != g_menuWasOpen) {
                g_menuWasOpen = g_showMenu;
                keys::Reset();
            }
            // Held keys must never misfire as fresh presses after an editor
            // transition either (same reasoning as the menu block above).
            if (g_hudEdit != g_hudEditWas) {
                g_hudEditWas = g_hudEdit;
                keys::Reset();
            }
            if (!mkDown) g_menuKeyArmed = true;
            // No window handle yet (late window creation): keep probing at ~1 Hz.
            if (!g_hwnd) {
                static int probeTick = 0;
                if (++probeTick % 60 == 1) {
                    HWND t = FindGameWindow();
                    if (t) InstallWndHook(t);
                }
            }

            if (trace) LOG_INFO("trace: hotkeys done");
            if (!g_win32Init && g_hwnd) {
                if (ImGui_ImplWin32_Init(g_hwnd)) {
                    g_win32Init = true;
                    LOG_INFO("overlay: Win32 backend bound to %p", g_hwnd);
                } else {
                    static int w32fails = 0;
                    if (++w32fails == 1 || w32fails % 600 == 0)
                        LOG_ERROR("overlay: Win32 backend init failed (%d) - poll fallback only", w32fails);
                }
            }
            // Match Bedrock/Flarial timing: update GuiData before the
            // current UI frame is rendered. Updating screen variables after
            // ImGui/game UI rendering can invalidate the live visual tree
            // while it is still being consumed by the frame.
            ApplyGameGuiScale();
            // Bedrock keeps the world in relative-mouse mode after INSERT.
            // Release the ClientInstance mouse capture just like Flarial does;
            // user32 cursor hooks alone do not switch CoreWindow to GUI mode.
            ReleaseGameMouseForGui();
            if (trace) LOG_INFO("trace: entering render");
            EnsureCs();
            EnterCriticalSection(&g_renderCs);
            if (InterlockedExchange(&g_inRender, 1) == 0) {
                // Match Flarial's RenderSync: consume the transform that was
                // captured in setupAndRender after a three-frame queue delay.
                HitboxConsumeFrameTransform();
                if (g_usingD3D12) RenderD3D12Frame();
                else RenderD3D11Frame();
                UpdateCursor();
                InterlockedExchange(&g_inRender, 0);
            }
            LeaveCriticalSection(&g_renderCs);
            if (trace) LOG_INFO("trace: render done");
            // Serialized unload: runs on this thread right after the frame,
            // so no other Present can interleave with the teardown.
            if (g_unloadRequested && !g_shuttingDown) FinishUnload();
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        if (!g_init) {
            TeardownRender();
            LOG_ERROR("overlay: exception during init - render keeps retrying");
        } else if (!g_renderAborted) {
            g_renderAborted = true;
            InterlockedExchange(&g_inRender, 0);
            LOG_ERROR("overlay: exception in frame - rendering disabled, game untouched");
        }
    }
#endif
    PresentFn o = (PresentFn)g_oPresent;
    const HRESULT opr = o ? o(sc, sync, flags) : E_FAIL;
    {
        static int pret = 0;
        if (++pret <= 3) {
            EnsureCs();
            EnterCriticalSection(&g_renderCs);
            const HRESULT rem =
                (g_usingD3D12 && g_d12dev) ? g_d12dev->GetDeviceRemovedReason() : S_OK;
            LeaveCriticalSection(&g_renderCs);
            LOG_INFO("trace: present returned %08X removed=%08X", (unsigned)opr, (unsigned)rem);
        }
        // Always-on failure reporting, rate-limited to one line per 5 s: the
        // first-3-frames trace above never fires again, and a failed Present
        // (especially a device removal from a GPU fault in one of our passes)
        // can be the last thing the process does before terminating - this
        // guarantees the actual error reaches the log first.
        if (FAILED(opr)) {
            static ULONGLONG lastFailMs = 0;
            const ULONGLONG nowMs = GetTickCount64();
            if (nowMs - lastFailMs >= 5000) {
                lastFailMs = nowMs;
                HRESULT rem = S_OK;
                if (g_usingD3D12 && g_d12dev) {
                    EnsureCs();
                    EnterCriticalSection(&g_renderCs);
                    rem = g_d12dev->GetDeviceRemovedReason();
                    LeaveCriticalSection(&g_renderCs);
                }
                LOG_ERROR("present: original Present failed hr=%08X removed=%08X",
                          (unsigned)opr, (unsigned)rem);
            }
            // Device-removed family from Present means the GPU is gone: latch
            // the saturation pass off immediately (idempotent, logs once).
            if (opr == DXGI_ERROR_DEVICE_REMOVED || opr == DXGI_ERROR_DEVICE_HUNG ||
                opr == DXGI_ERROR_DEVICE_RESET)
                SaturationGpuFault();
        }
    }
    return opr;
}

HRESULT __stdcall HkResizeBuffers(IDXGISwapChain* sc, UINT count, UINT w, UINT h,
                                 DXGI_FORMAT fmt, UINT flags) {
#ifdef _MSC_VER
    __try {
#endif
        if (g_init && sc == g_sc) {
            EnterCriticalSection(&g_renderCs);
            TeardownRender();
            g_w = w; g_h = h;
            LeaveCriticalSection(&g_renderCs);
            LOG_INFO("overlay: buffers resized %ux%u - reinit next frame", w, h);
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        LOG_ERROR("overlay: exception in ResizeBuffers pre-step");
    }
#endif
    ResizeFn o = (ResizeFn)g_oResize;
    return o ? o(sc, count, w, h, fmt, flags) : E_FAIL;
}

void PatchVTable(void** vtable, int index, void* hook, void** original) {
    DWORD old = 0;
    void** slot = vtable + index;
    *original = *slot;
    VirtualProtect(slot, sizeof(void*), PAGE_EXECUTE_READWRITE, &old);
    *slot = hook;
    VirtualProtect(slot, sizeof(void*), old, &old);
}

void RestoreVTable() {
    if (!g_vtable) return;
    DWORD old = 0;
    if (g_oPresent) {
        VirtualProtect(g_vtable + kPresentIndex, sizeof(void*), PAGE_EXECUTE_READWRITE, &old);
        g_vtable[kPresentIndex] = g_oPresent;
        VirtualProtect(g_vtable + kPresentIndex, sizeof(void*), old, &old);
    }
    if (g_oResize) {
        VirtualProtect(g_vtable + kResizeIndex, sizeof(void*), PAGE_EXECUTE_READWRITE, &old);
        g_vtable[kResizeIndex] = g_oResize;
        VirtualProtect(g_vtable + kResizeIndex, sizeof(void*), old, &old);
    }
    if (g_queueVtable && g_oExec) {
        VirtualProtect(g_queueVtable + kExecIndex, sizeof(void*), PAGE_EXECUTE_READWRITE, &old);
        g_queueVtable[kExecIndex] = g_oExec;
        VirtualProtect(g_queueVtable + kExecIndex, sizeof(void*), old, &old);
        g_queueVtable = nullptr;
        g_oExec = nullptr;
    }
    g_vtable = nullptr;
    LOG_INFO("overlay: vtable restored");
}

// ============================ unload ============================
DWORD WINAPI ExitThreadProc(LPVOID) {
    Sleep(400);  // let the in-flight Present return through the restored vtable
    FreeLibraryAndExitThread(g_hmod, 0);
    return 0;
}

void FinishUnload() {
    if (g_shuttingDown) return;
    g_shuttingDown = true;
    g_showMenu = false;
    g_hudEdit = false;
    if (g_hitboxOwnerRefreshThread) {
        WaitForSingleObject(g_hitboxOwnerRefreshThread, 2000u);
        CloseHandle(g_hitboxOwnerRefreshThread);
        g_hitboxOwnerRefreshThread = nullptr;
        InterlockedExchange(&g_hitboxOwnerRefreshStarted, 0);
    }
    LOG_INFO("overlay: finishing unload");
    RestoreGameGuiScale();
    RestoreNoHurtCamPatch();
    if (g_feedHook || g_mouseFeedHook || g_gammaHook || g_screenSizeHook ||
        g_setupAndRenderHook || g_cursorHooks || g_javaHooksActive ||
        g_actorBaseTickHook || g_levelRenderHook) {
        // BEFORE anything else: game threads may call these detours at any
        // moment, and they must never run against torn-down state (or an
        // unloaded DLL). Originals are nulled so later readers (HandleRawInput)
        // fall back to the (now unpatched) direct calls.
        MH_DisableHook(MH_ALL_HOOKS);
        MH_RemoveHook(MH_ALL_HOOKS);
        MH_Uninitialize();
        g_feedHook = false;
        g_oFeed = nullptr;
        g_autoSprintInjected = false;
        g_javaHooksActive = false;
        g_javaTakeAll = nullptr;
        g_oJavaContainerHover = nullptr;
        g_oJavaContainerTick = nullptr;
        g_javaHoverAddress = 0;
        g_javaTickAddress = 0;
        g_actorBaseTickHook = false;
        g_oActorBaseTick = nullptr;
        g_levelRenderHook = false;
        g_oLevelRender = nullptr;
        InterlockedExchange(&g_javaEnabled, 0);
        if (g_javaCsInit) JavaClearContext();
        g_mouseFeedHook = false;
        g_oMouseFeed = nullptr;
        g_gammaHook = false;
        g_oGamma = nullptr;
        g_screenSizeHook = false;
        g_setupAndRenderHook = false;
        g_screenSizeSeen = false;
        g_setupSeen = false;
        g_screenSizeCallDisabled = false;
        g_screenSizeCallProved = false;
        g_lastRealScreen[0] = g_lastRealScreen[1] = 0.0f;
        g_oUpdateScreen = nullptr;
        g_oSetupAndRender = nullptr;
        g_clientInstance = nullptr;
        g_guiData = nullptr;
        g_savedGuiData = nullptr;
        g_screenView = nullptr;
        g_getPositionFn = 0;
        g_guiScaleRelayoutPending = false;
        g_guiScaleRelayoutFails = 0;
        InterlockedExchange(&g_mouseForwardedButtons, 0);
        g_cursorHooks = false;
        oGetRawInputData = nullptr;
        oGetRawInputBuffer = nullptr;
        oSetCursorPos = nullptr;
        oClipCursor = nullptr;
        oSetCapture = nullptr;
        oShowCursor = nullptr;
        oGetAsyncKeyState = nullptr;
        keys::SetAsyncStateSampler(nullptr);
        LOG_INFO("overlay: MinHook hooks removed (feed + controller + cursor/raw)");
    }
    ui::Shutdown();          // flush config
    EnterCriticalSection(&g_renderCs);
    TeardownRender();
    if (g_win32Init) { ImGui_ImplWin32_Shutdown(); g_win32Init = false; }
    if (g_imgui) { ImGui::DestroyContext(); g_imgui = false; }
    LeaveCriticalSection(&g_renderCs);
    RestoreWndHook();
    RestoreVTable();
    LOG_INFO("overlay: unloaded cleanly");
    logger::Shutdown();
    HANDLE h = CreateThread(nullptr, 0, ExitThreadProc, nullptr, 0, nullptr);
    if (h) CloseHandle(h);
}

// ============================ startup ============================
struct WindowProbe { int found = 0; DWORD pid = 0; HWND hwnd = nullptr; };

BOOL CALLBACK ProbeWindow(HWND h, LPARAM lp) {
    WindowProbe* pr = (WindowProbe*)lp;
    DWORD pid = 0;
    GetWindowThreadProcessId(h, &pid);
    if (pid != pr->pid || !IsWindowVisible(h)) return TRUE;
    RECT rc{};
    if (!GetWindowRect(h, &rc)) return TRUE;
    if (rc.right - rc.left < 200 || rc.bottom - rc.top < 200) return TRUE;
    char cls[64] = {};
    GetClassNameA(h, cls, sizeof(cls));
    if (std::strcmp(cls, "ConsoleWindowClass") == 0) return TRUE;
    pr->found++;
    pr->hwnd = h;
    return FALSE;  // one is enough
}

bool GameWindowExists() {
    WindowProbe pr;
    pr.pid = GetCurrentProcessId();
    EnumWindows(ProbeWindow, (LPARAM)&pr);
    return pr.found > 0;
}

// Same criteria, but returns the handle (for the input hook + Win32 backend).
HWND FindGameWindow() {
    WindowProbe pr;
    pr.pid = GetCurrentProcessId();
    EnumWindows(ProbeWindow, (LPARAM)&pr);
    return pr.hwnd;
}

bool CreateDummySwapchain(void*** vtableOut) {
    WNDCLASSA wc{};
    wc.lpfnWndProc = DefWindowProcA;
    wc.hInstance = g_hmod;
    wc.lpszClassName = "NightfullDummy";
    RegisterClassA(&wc);
    HWND wnd = CreateWindowExA(WS_EX_TOOLWINDOW, "NightfullDummy", "nf",
                               WS_POPUP, 0, 0, 64, 64, nullptr, nullptr, g_hmod, nullptr);
    if (!wnd) return false;

    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 2;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = wnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    IDXGISwapChain* sc = nullptr;
    ID3D11Device* dev = nullptr;
    ID3D11DeviceContext* ctx = nullptr;
    const D3D_FEATURE_LEVEL lvl[] = { D3D_FEATURE_LEVEL_11_0 };
    HRESULT hr = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
        lvl, 1, D3D11_SDK_VERSION, &sd, &sc, &dev, nullptr, &ctx);
    bool ok = false;
    if (SUCCEEDED(hr) && sc) {
        *vtableOut = *(void***)sc;
        ok = true;
    }
    if (ctx) ctx->Release();
    if (dev) dev->Release();
    if (sc) sc->Release();
    DestroyWindow(wnd);
    UnregisterClassA("NightfullDummy", g_hmod);
    return ok;
}

// ============================ Hitboxes bridge ============================
//
// Component reads go through the vendored MSVC EnTT (third_party/entt) against
// the game's live registry - exactly Flarial's 1.21+ path
// (EntityContext::tryGetComponent<T>() -> registry.storage<T>()/try_get<T>()).
// bedrock_entt.hpp declares the component structs in the global namespace so
// EnTT's MSVC FUNCSIG pool key is byte-identical to the game's; the
// static_asserts below HitboxReadActorComponent prove that at compile time.
//
// This replaced a hand-rolled byte-offset reproduction of EnTT's private
// basic_storage layout (sparse vector +0x08, packed vector +0x20, payload page
// vector +0x50, "packedCount" +0xF0). Those offsets are not part of EnTT's
// public ABI and did not match the 1.21.111 pool, so every AABB sample failed
// and no hitbox was ever published. The raw walk is retained below only as a
// guarded fallback. A failed proof still returns false.
    constexpr uint32_t kHitboxAabbHash = 0x1B10C9F2u; // struct AABBShapeComponent
    constexpr uint32_t kHitboxStateHash = 0x0EC93C91u; // struct StateVectorComponent
    constexpr uint32_t kHitboxRenderHash = 0xD4E8F36Eu; // struct RenderPositionComponent
    constexpr uint32_t kHitboxOwnerHash = 0x132A5818u; // class ActorOwnerComponent
    // Look direction pool key, computed from the mirrored global struct name
    // (same FUNCSIG rule as the asserts below). Unlike the hashes above there
    // is no hardcoded known-good value: when the game's type name differs, the
    // pool lookup simply misses and every rotation read fails closed.
    constexpr uint32_t kHitboxRotationHash = entt::type_hash<ActorRotationComponent>::value();
    constexpr uint32_t kHitboxEntityMask = 0x3FFFFu;
    // Invisible/armor/sprint pools - same name-hash rule as the components
    // above; a name mismatch can only make the lookup miss (fail closed).
    constexpr uint32_t kHitboxDataFlagHash = entt::type_hash<ActorDataFlagComponent>::value();
    constexpr uint32_t kHitboxEquipmentHash = entt::type_hash<ActorEquipmentComponent>::value();
    constexpr uint32_t kHitboxMoveInputHash = entt::type_hash<MoveInputComponent>::value();
    constexpr uint32_t kHitboxSynchedDataHash = entt::type_hash<SynchedActorDataComponent>::value();

    // Armor proof cache for the invisible gate (250 ms refresh).
    constexpr ULONGLONG kHitboxArmorRefreshMs = 250u;
    struct HitboxArmorCacheEntry {
        void* actor = nullptr;
        ULONGLONG at = 0;
        int state = 0;   // 0 unknown, 1 armored, 2 bare
    };
    SRWLOCK g_hitboxArmorCacheLock = SRWLOCK_INIT;
    HitboxArmorCacheEntry g_hitboxArmorCache[64] = {};
    constexpr int kHitboxArmorFlagBit = 5;   // ActorFlags::FLAG_INVISIBLE
constexpr size_t kHitboxActorSlots = 256;

// ---- Actor-pointer -> table slot --------------------------------------------
//
// The AABB, gate, category, entity-hint and baseTick actor tables below are all
// fixed-size, pointer-keyed tables. Every lookup used to be a full linear scan
// of all slots under a lock, and these lookups run per actor, several times per
// frame, plus once per game tick from the baseTick hook. That was the dominant
// cost of the Hitboxes path, and it was quadratic in actor count.
//
// Deriving a "home" slot from the pointer makes the common case a single
// comparison. Entries are inserted into their home slot whenever it is free or
// already theirs, so the fast path is what normally hits. The original
// find/empty/oldest scan is kept verbatim as the fallback, so eviction
// behaviour is unchanged when a home slot is occupied by another actor.
inline int ActorHomeSlot(const void* actor, int count) {
    if (!actor || count <= 0) return 0;
    uintptr_t v = reinterpret_cast<uintptr_t>(actor);
    // Heap pointers are at least 16-byte aligned, so the low four bits carry no
    // entropy; drop them and mix the remaining bits down before the modulus.
    v >>= 4;
    v ^= v >> 13;
    v *= 0x9E3779B97F4A7C15ull;
    v ^= v >> 31;
    return static_cast<int>(v % static_cast<unsigned>(count));
}

// Returns the slot holding `actor`, or -1. The caller must already hold the
// matching table lock. Home slot first, then the original linear fallback.
template <typename Entry>
inline int ActorCacheFindLocked(const Entry* table, int count, const void* actor) {
    if (!actor || !table || count <= 0) return -1;
    const int home = ActorHomeSlot(actor, count);
    if (table[home].actor == actor) return home;
    for (int i = 0; i < count; ++i)
        if (table[i].actor == actor) return i;
    return -1;
}

struct HitboxActorEntry {
    void* actor = nullptr;
    // Written from the game's tick thread, read from the render and worker
    // threads. Accesses go through the atomic helpers below so the tick hook can
    // refresh a known entry under a SHARED lock instead of taking the exclusive
    // lock - which used to block every reader, including the render thread, once
    // per actor per game tick.
    volatile LONG64 lastTick = 0;
};

inline ULONGLONG HitboxActorTick(const HitboxActorEntry& e) {
    return static_cast<ULONGLONG>(
        InterlockedCompareExchange64(const_cast<volatile LONG64*>(&e.lastTick), 0, 0));
}
inline void HitboxActorTouch(HitboxActorEntry& e, ULONGLONG now) {
    InterlockedExchange64(&e.lastTick, static_cast<LONG64>(now));
}

SRWLOCK g_hitboxActorLock = SRWLOCK_INIT;
HitboxActorEntry g_hitboxActors[kHitboxActorSlots] = {};
bool g_hitboxBaseTickTried = false;

struct HitboxEntityHint {
    void* actor = nullptr;
    void* registry = nullptr;
    uint32_t entity = 0;
    ULONGLONG updatedAt = 0;
};

SRWLOCK g_hitboxEntityHintLock = SRWLOCK_INIT;
HitboxEntityHint g_hitboxEntityHints[kHitboxActorSlots] = {};

static void HitboxRememberEntityHint(void* actor, void* registry, uint32_t entity) {
    if (!actor || !registry || !entity) return;
    AcquireSRWLockExclusive(&g_hitboxEntityHintLock);
    int slot = -1;
    int oldest = 0;
    for (int i = 0; i < static_cast<int>(kHitboxActorSlots); ++i) {
        if (g_hitboxEntityHints[i].actor == actor) { slot = i; break; }
        if (!g_hitboxEntityHints[i].actor && slot < 0) slot = i;
        if (g_hitboxEntityHints[i].updatedAt < g_hitboxEntityHints[oldest].updatedAt)
            oldest = i;
    }
    if (slot < 0) slot = oldest;
    g_hitboxEntityHints[slot] = {actor, registry, entity, GetTickCount64()};
    ReleaseSRWLockExclusive(&g_hitboxEntityHintLock);
}

static bool HitboxReadEntityHint(void* actor, void** registry, uint32_t* entity) {
    if (registry) *registry = nullptr;
    if (entity) *entity = 0;
    if (!actor || !registry || !entity) return false;
    const ULONGLONG now = GetTickCount64();
    AcquireSRWLockShared(&g_hitboxEntityHintLock);
    for (const HitboxEntityHint& hint : g_hitboxEntityHints) {
        if (hint.actor == actor && hint.registry && hint.entity &&
            now - hint.updatedAt < 5000u) {
            *registry = hint.registry;
            *entity = hint.entity;
            ReleaseSRWLockShared(&g_hitboxEntityHintLock);
            return true;
        }
    }
    ReleaseSRWLockShared(&g_hitboxEntityHintLock);
    return false;
}

static void HitboxRememberActor(void* actor) {
    if (!actor || reinterpret_cast<uintptr_t>(actor) < 0x10000u) return;
    const ULONGLONG now = GetTickCount64();

    // Fast path: the actor already lives at its home slot - the normal case
    // after the first sighting. A SHARED lock plus one atomic timestamp store.
    //
    // This hook fires for EVERY actor on EVERY game tick (20/s), including
    // items, projectiles and particles. Taking the exclusive lock and scanning
    // all 256 slots each time meant thousands of exclusive acquisitions per
    // second, all of them blocking the render thread's readers.
    {
        AcquireSRWLockShared(&g_hitboxActorLock);
        const int home = ActorHomeSlot(actor, static_cast<int>(kHitboxActorSlots));
        if (g_hitboxActors[home].actor == actor) {
            HitboxActorTouch(g_hitboxActors[home], now);
            ReleaseSRWLockShared(&g_hitboxActorLock);
            return;
        }
        ReleaseSRWLockShared(&g_hitboxActorLock);
    }

    // Slow path: first sighting (or the entry sits at a non-home slot). Takes
    // the exclusive lock once and places the actor at home when that slot is
    // free, keeping the fast path above O(1) from then on.
    AcquireSRWLockExclusive(&g_hitboxActorLock);
    const int home = ActorHomeSlot(actor, static_cast<int>(kHitboxActorSlots));
    if (g_hitboxActors[home].actor == actor) {   // raced in while we upgraded
        HitboxActorTouch(g_hitboxActors[home], now);
        ReleaseSRWLockExclusive(&g_hitboxActorLock);
        return;
    }
    int slot = -1;
    if (!g_hitboxActors[home].actor) {
        slot = home;
    } else {
        int freeSlot = -1;
        int oldestSlot = 0;
        for (int i = 0; i < static_cast<int>(kHitboxActorSlots); ++i) {
            if (g_hitboxActors[i].actor == actor) { slot = i; break; }
            if (!g_hitboxActors[i].actor && freeSlot < 0) freeSlot = i;
            if (HitboxActorTick(g_hitboxActors[i]) < HitboxActorTick(g_hitboxActors[oldestSlot]))
                oldestSlot = i;
        }
        if (slot < 0) slot = freeSlot >= 0 ? freeSlot : oldestSlot;
    }
    g_hitboxActors[slot].actor = actor;
    HitboxActorTouch(g_hitboxActors[slot], now);
    ReleaseSRWLockExclusive(&g_hitboxActorLock);
}

using HitboxBaseTickFn = void(__fastcall*)(void*);

// Flarial Sprint parity: writes the sprint input flags when this tick belongs
// to the local player and the module is enabled (definition below).
static void HitboxAutoSprintTick(void* actor);

static void __fastcall HkHitboxActorBaseTick(void* actor) {
    // The detour is known to fire with garbage `this` (observed actor=0x1 in
    // the log), and it runs on the game's own tick thread - nothing in here
    // may take the game down. Original first, everything else contained.
#ifdef _MSC_VER
    __try {
#endif
        const HitboxBaseTickFn original =
            reinterpret_cast<HitboxBaseTickFn>(g_oActorBaseTick);
        if (original) original(actor);
        HitboxRememberActor(actor);
        // NOTE: no EnTT proof on this thread. The tick thread must stay
        // trivial (remember + sprint below): on busy servers hundreds of
        // transient actors tick per second, and a full faulting proof per
        // tick drowned the game thread (observed 9 FPS). Freshness is owned
        // by the budgeted worker visit pass and the gated frame capture, so
        // boxes stay ~50 ms old with ZERO scans on the tick thread - the
        // PacketV2 cost profile (plain field reads there) without its
        // unproven offsets here.
        // AutoSprint runs on the game's own tick thread, right after the
        // local player's tick - the exact timing of Flarial's TickEvent.
        HitboxAutoSprintTick(actor);
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
#endif
}

static bool HitboxReadActorContextDirect(void* actor, void** registry,
                                         void** enttRegistry, uint32_t* entity) {
    if (registry) *registry = nullptr;
    if (enttRegistry) *enttRegistry = nullptr;
    if (entity) *entity = 0;
    if (!actor || !registry || !enttRegistry || !entity) return false;

    const uintptr_t context = reinterpret_cast<uintptr_t>(actor) + 0x08u;
    void* registryObject = nullptr;
    void* registryValue = nullptr;
    uint32_t entityValue = 0;
    if (!PotionReadBytes(reinterpret_cast<const void*>(context + 0x00u),
                         &registryObject, sizeof(registryObject)) ||
        !PotionReadBytes(reinterpret_cast<const void*>(context + 0x08u),
                         &registryValue, sizeof(registryValue)) ||
        !PotionReadBytes(reinterpret_cast<const void*>(context + 0x10u),
                         &entityValue, sizeof(entityValue)) ||
        !registryObject || !registryValue || !entityValue ||
        !GuiPageReadable(registryValue))
        return false;

    *registry = registryObject;
    *enttRegistry = registryValue;
    *entity = entityValue;
    static volatile LONG contextProbeLogged = 0;
    const LONG probe = InterlockedIncrement(&contextProbeLogged);
    if (probe <= 8)
        LOG_INFO("hitboxes: actor context actor=%p registry=%p entt=%p entity=%08X",
                 actor, registryObject, registryValue, entityValue);
    return true;
}

// Flarial Sprint ("Always Sprint") parity: their TickEvent listener runs from
// the Actor::baseTick hook for the local player and writes
//   handler.setSprinting(true); handler.setMSprintDown(true);
//   handler.setRawMSprintDown(true);
// every tick. This mirrors that with the MoveInputComponent pool on this same
// hook thread. The game re-authors its input state every tick, so it stays in
// full control the moment the module is disabled (no restore writes needed).
static void HitboxAutoSprintTick(void* actor) {
    const bool sprintOn =
        InterlockedCompareExchange(&g_autoSprintFlagsEnabled, 0, 0) != 0;
    const bool nullMoveOn =
        InterlockedCompareExchange(&g_nullMovementEnabled, 0, 0) != 0 &&
        !g_showMenu;
    if (!actor || (!sprintOn && !nullMoveOn)) return;

    // Cheap reject BEFORE taking any lock. This hook runs for every actor on
    // every game tick, and the overwhelming majority of those calls belong to
    // some other actor - yet the old order acquired the world-context lock
    // first, then compared.
    //
    // g_hitboxWorldLocal is read without the lock here, exactly as
    // IsHitboxLocalPlayer already does: it is a single aligned pointer store, so
    // the worst case is one tick acting on a stale value, corrected on the next
    // tick. The locked read stays as the fallback for the bootstrap window where
    // the pointer has not been published yet.
    void* local = g_hitboxWorldLocal;
    if (!local) {
        AcquireSRWLockShared(&g_hitboxWorldContextLock);
        local = g_hitboxWorldLocal;
        ReleaseSRWLockShared(&g_hitboxWorldContextLock);
    }
    if (actor != local) return;

    void* registryObject = nullptr;
    void* enttRegistry = nullptr;
    uint32_t entity = 0;
    if (!HitboxReadActorContextDirect(actor, &registryObject, &enttRegistry,
                                      &entity) ||
        !enttRegistry || !entity)
        return;

#ifdef _MSC_VER
    __try {
#endif
        auto* registry =
            reinterpret_cast<entt::basic_registry<EntityId>*>(enttRegistry);
        auto* pool = registry->storage(kHitboxMoveInputHash);
        if (!pool || !pool->contains(EntityId(entity))) return;
        const void* payloadConst = pool->value(EntityId(entity));
        void* payload = const_cast<void*>(payloadConst);
        if (!payload || !GuiRangeReadable(payload, 0xA8u)) return;

        auto* base = static_cast<unsigned char*>(payload);
        // 1.21.120+ packs the input state into 32-bit flag words; 1.21.11x
        // keeps individual bool bytes. The first eight bytes discriminate:
        // bool bytes are only ever 0/1, while a packed flag word or the
        // analog move floats almost always carry higher bits.
        const bool oldLayout =
            base[0x0] <= 1 && base[0x1] <= 1 && base[0x2] <= 1 &&
            base[0x3] <= 1 && base[0x4] <= 1 && base[0x5] <= 1 &&
            base[0x6] <= 1 && base[0x7] <= 1;

        // ---- Null Movement (A/D, W/S) ----
        // When both keys of an enabled pair are physically held, only the
        // newer press is authored into the movement state, so W+S strafes
        // instead of standing still. The bits are re-written every tick right
        // after the game's own input authoring (this hook runs on the game's
        // tick thread); when the conflict ends the game's own values resume
        // untouched, so releasing S instantly restores W.
        if (nullMoveOn) {
            const UINT32 bitUp = 1u << 13, bitDown = 1u << 14;
            const UINT32 bitLeft = 1u << 15, bitRight = 1u << 16;
            // Vertical pair (W vs S).
            if (keys::Down('W') && keys::Down('S')) {
                const bool wWins =
                    (LONG64)g_nmPressAt[0] >= (LONG64)g_nmPressAt[2];
                if (oldLayout) {
                    base[0x0D] = wWins; base[0x0E] = !wWins;   // forward/backward
                    base[0x35] = wWins; base[0x36] = !wWins;   // raw state
                } else {
                    UINT32* in = reinterpret_cast<UINT32*>(base);
                    UINT32* raw = reinterpret_cast<UINT32*>(base + 0x10);
                    *in = wWins ? (*in | bitUp) & ~bitDown
                                : (*in | bitDown) & ~bitUp;
                    *raw = wWins ? (*raw | bitUp) & ~bitDown
                                 : (*raw | bitDown) & ~bitUp;
                }
            }
            // Horizontal pair (A vs D).
            if (keys::Down('A') && keys::Down('D')) {
                const bool aWins =
                    (LONG64)g_nmPressAt[1] >= (LONG64)g_nmPressAt[3];
                if (oldLayout) {
                    base[0x0F] = aWins; base[0x10] = !aWins;   // left/right
                    base[0x37] = aWins; base[0x38] = !aWins;   // raw state
                } else {
                    UINT32* in = reinterpret_cast<UINT32*>(base);
                    UINT32* raw = reinterpret_cast<UINT32*>(base + 0x10);
                    *in = aWins ? (*in | bitLeft) & ~bitRight
                                : (*in | bitRight) & ~bitLeft;
                    *raw = aWins ? (*raw | bitLeft) & ~bitRight
                                 : (*raw | bitRight) & ~bitLeft;
                }
            }
        }

        // ---- AutoSprint ----
        if (!sprintOn) return;
        if (oldLayout) {
            base[0x08] = 1;   // mInputState.mSprintDown
            base[0x30] = 1;   // mRawInputState.mSprintDown
            base[0x95] = 1;   // sprinting
        } else {
            // New layout: SprintDown = bit 8 of both input state flag words,
            // Sprinting = bit 1 of the component's own flag mask.
            *reinterpret_cast<uint32_t*>(base) |= 1u << 8;
            *reinterpret_cast<uint32_t*>(base + 0x10) |= 1u << 8;
            *reinterpret_cast<uint16_t*>(base + 0x60) |= 1u << 1;
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
    }
#endif
}

static bool HitboxReadActorContext(void* actor, void** registry,
                                   void** enttRegistry, uint32_t* entity) {
    if (registry) *registry = nullptr;
    if (enttRegistry) *enttRegistry = nullptr;
    if (entity) *entity = 0;
    if (!actor || !registry || !enttRegistry || !entity) return false;

    // Match Flarial's Actor::GetEntityContext path: the actor's live context
    // is authoritative and is read first for every sample. Owner-walk hints
    // are only a fallback for the short interval in which Bedrock is replacing
    // an actor's registry during a world transition. Reusing a stale hint here
    // made a dense group resolve the wrong entity id and left most AABBs frozen.
    if (HitboxReadActorContextDirect(actor, registry, enttRegistry, entity))
        return true;

    void* hintedRegistry = nullptr;
    uint32_t hintedEntity = 0;
    void* currentWorld = HitboxGetWorldRegistry();
    if (actor != g_hitboxWorldLocal &&
        HitboxReadEntityHint(actor, &hintedRegistry, &hintedEntity) &&
        (!currentWorld || hintedRegistry == currentWorld)) {
        *registry = hintedRegistry;
        *enttRegistry = hintedRegistry;
        *entity = hintedEntity;
        return true;
    }

    return false;
}

struct HitboxComponentAddressCacheEntry {
    void* storage = nullptr;
    uint32_t entity = 0;
    size_t componentSize = 0;
    uintptr_t address = 0;
    ULONGLONG resolvedAt = 0;
    bool valid = false;
};

SRWLOCK g_hitboxComponentAddressCacheLock = SRWLOCK_INIT;
HitboxComponentAddressCacheEntry g_hitboxComponentAddressCache[512] = {};
constexpr ULONGLONG kHitboxComponentAddressKeepAliveMs = 1000u;

static void HitboxRememberComponentAddress(void* storage, uint32_t entity,
                                           size_t componentSize,
                                           uintptr_t address,
                                           ULONGLONG now) {
    if (!storage || !entity || !componentSize || !address) return;
    AcquireSRWLockExclusive(&g_hitboxComponentAddressCacheLock);
    int slot = -1;
    ULONGLONG oldest = now;
    for (int i = 0; i < 512; ++i) {
        if (g_hitboxComponentAddressCache[i].storage == storage &&
            g_hitboxComponentAddressCache[i].entity == entity &&
            g_hitboxComponentAddressCache[i].componentSize == componentSize) {
            slot = i;
            break;
        }
        if (!g_hitboxComponentAddressCache[i].storage && slot < 0) slot = i;
        if (g_hitboxComponentAddressCache[i].resolvedAt <= oldest) {
            oldest = g_hitboxComponentAddressCache[i].resolvedAt;
            if (slot < 0) slot = i;
        }
    }
    if (slot < 0) slot = 0;
    g_hitboxComponentAddressCache[slot] = {
        storage, entity, componentSize, address, now, true
    };
    ReleaseSRWLockExclusive(&g_hitboxComponentAddressCacheLock);
}

static bool HitboxReadCachedComponentAddress(void* storage, uint32_t entity,
                                             void* out, size_t componentSize,
                                             ULONGLONG now) {
    if (!storage || !entity || !out || !componentSize) return false;
    uintptr_t address = 0;
    int slot = -1;
    AcquireSRWLockShared(&g_hitboxComponentAddressCacheLock);
    for (int i = 0; i < 512; ++i) {
        const HitboxComponentAddressCacheEntry& entry =
            g_hitboxComponentAddressCache[i];
        if (entry.storage != storage || entry.entity != entity ||
            entry.componentSize != componentSize || !entry.valid) continue;
        if (now - entry.resolvedAt > kHitboxComponentAddressKeepAliveMs) break;
        address = entry.address;
        slot = i;
        break;
    }
    if (slot >= 0 && address &&
        GuiRangeReadable(reinterpret_cast<const void*>(address), componentSize) &&
        PotionReadBytes(reinterpret_cast<const void*>(address), out, componentSize)) {
        ReleaseSRWLockShared(&g_hitboxComponentAddressCacheLock);
        return true;
    }
    ReleaseSRWLockShared(&g_hitboxComponentAddressCacheLock);
    return false;
}

enum HitboxComponentDiagStage : int {
    kHitboxDiagStorageArgs = 0,
    kHitboxDiagStorageLayout,
    kHitboxDiagSparsePacked,
    kHitboxDiagPayloadVector,
    kHitboxDiagComponentAddress,
    kHitboxDiagRawArgs,
    kHitboxDiagRawRetry,
    kHitboxDiagRawStorage,
    kHitboxDiagRawPayload,
    kHitboxDiagRender,
    kHitboxDiagState,
    kHitboxDiagCount
};

static volatile LONG g_hitboxComponentDiag[kHitboxDiagCount] = {};

static void HitboxLogComponentDiag(HitboxComponentDiagStage stage,
                                   void* storage, uint32_t entity,
                                   size_t componentSize) {
    static const char* const names[kHitboxDiagCount] = {
        "storage-args", "storage-layout", "sparse-packed",
        "payload-vector", "component-address", "raw-args",
        "raw-retry", "raw-storage", "raw-payload", "render-read",
        "state-read"
    };
    if (stage < 0 || stage >= kHitboxDiagCount) return;
    const LONG count = InterlockedIncrement(&g_hitboxComponentDiag[stage]);
    if (count <= 8)
        LOG_INFO("hitboxes: bounded component diagnostic stage=%s storage=%p entity=%08X size=%zu",
                 names[stage], storage, entity, componentSize);
}

static bool HitboxReadStorageComponent(void* storage, uint32_t entity,
                                       void* out, size_t componentSize) {
    if (!storage || !out || componentSize == 0 || componentSize > 0x100u ||
        !GuiRangeReadable(storage, 0x78u)) {
        HitboxLogComponentDiag(kHitboxDiagStorageArgs, storage, entity, componentSize);
        return false;
    }

    const ULONGLONG now = GetTickCount64();
    if (HitboxReadCachedComponentAddress(storage, entity, out,
                                         componentSize, now))
        return true;

    // The storage pointer is obtained from the target's validated pool map and
    // cached per registry/component below. Do not revalidate its vtable on every
    // actor and every render frame: that VirtualQuery/RPM pair was the largest
    // avoidable part of the original hot path.
    PotionMsvcVector sparse{};
    PotionMsvcVector packed{};
    const uintptr_t base = reinterpret_cast<uintptr_t>(storage);
    if (!PotionReadBytes(reinterpret_cast<const void*>(base + 0x08u),
                         &sparse, sizeof(sparse)) ||
        !PotionValidVector(sparse, 0x200000u)) {
        HitboxLogComponentDiag(kHitboxDiagStorageLayout, storage, entity, componentSize);
        return false;
    }

    const uintptr_t sparseBytes = sparse.end - sparse.begin;
    if (sparseBytes == 0 || sparseBytes % sizeof(uintptr_t) != 0) {
        HitboxLogComponentDiag(kHitboxDiagStorageLayout, storage, entity, componentSize);
        return false;
    }

    const size_t sparsePages = static_cast<size_t>(sparseBytes / sizeof(uintptr_t));
    const uint32_t entityIndex = entity & kHitboxEntityMask;

    // Match the target EnTT sparse-set path used by the native component
    // reader, but keep it entirely as guarded worker-side byte reads. Bedrock's
    // EntityId pages contain 2048 entries and AABB/RenderPosition payload pages
    // contain 128 components. The older fallback depended on the storage's
    // packed entity vector (+0x20), which is not reliable for newly spawned mobs
    // and caused their boxes to disappear until the next successful proof.
    auto readNativeSparsePayload = [&]() -> bool {
        const size_t entityPage = static_cast<size_t>(entityIndex >> 11);
        const size_t entityOffset = static_cast<size_t>(entityIndex & 0x7FFu);
        if (entityPage >= sparsePages) return false;

        uintptr_t sparsePage = 0;
        if (!PotionReadBytes(reinterpret_cast<const void*>(
                sparse.begin + entityPage * sizeof(uintptr_t)),
                             &sparsePage, sizeof(sparsePage)) || !sparsePage)
            return false;

        uint32_t sparseEntry = 0;
        if (!PotionReadBytes(reinterpret_cast<const void*>(
                sparsePage + entityOffset * sizeof(uint32_t)),
                             &sparseEntry, sizeof(sparseEntry)) ||
            sparseEntry == 0xFFFFFFFFu)
            return false;

        // Preserve the same generation proof as EntityId::in_use. A recycled
        // slot must never be allowed to return another actor's component.
        const uint32_t versionDelta =
            ((entity & ~kHitboxEntityMask) ^ sparseEntry);
        if (versionDelta > 0x3FFFEu) return false;
        const size_t packedIndex =
            static_cast<size_t>(sparseEntry & kHitboxEntityMask);

        size_t packedCount = 0;
        const bool packedCountRead = PotionReadBytes(
            reinterpret_cast<const void*>(base + 0xF0u),
            &packedCount, sizeof(packedCount));
        if (packedCountRead &&
            (packedCount == 0 || packedIndex >= packedCount || packedCount > 0x100000u))
            return false;

        // The native storage path consumes the payload vector's begin pointer
        // at +0x50 directly. Do not require +0x58/+0x60 to form a valid MSVC
        // vector here: on the live AABB pool those adjacent words can be part
        // of the storage bookkeeping even though the page-pointer array at
        // +0x50 is valid.
        uintptr_t payloadBegin = 0;
        if (!PotionReadBytes(reinterpret_cast<const void*>(base + 0x50u),
                             &payloadBegin, sizeof(payloadBegin)) ||
            !payloadBegin)
            return false;
        const size_t payloadPage = packedIndex >> 7;
        const size_t payloadOffset = packedIndex & 0x7Fu;
        if (payloadPage > 0x2000u) return false;

        uintptr_t componentPage = 0;
        if (!PotionReadBytes(reinterpret_cast<const void*>(
                payloadBegin + payloadPage * sizeof(uintptr_t)),
                             &componentPage, sizeof(componentPage)) ||
            !componentPage)
            return false;
        const uintptr_t component =
            componentPage + payloadOffset * componentSize;
        if (!GuiRangeReadable(reinterpret_cast<const void*>(component), componentSize) ||
            !PotionReadBytes(reinterpret_cast<const void*>(component), out, componentSize))
            return false;
        HitboxRememberComponentAddress(storage, entity, componentSize,
                                       component, now);
        static volatile LONG nativeSparsePayloadLogged = 0;
        if (InterlockedIncrement(&nativeSparsePayloadLogged) <= 8)
            LOG_INFO("hitboxes: native sparse payload hit storage=%p entity=%08X size=%zu component=%p",
                     storage, entity, componentSize,
                     reinterpret_cast<void*>(component));
        return true;
    };

    if (readNativeSparsePayload()) return true;

    // Compatibility fallback for layouts that expose a packed entity vector.
    if (!PotionReadBytes(reinterpret_cast<const void*>(base + 0x20u),
                         &packed, sizeof(packed)) ||
        !PotionValidVector(packed, 0x200000u)) {
        HitboxLogComponentDiag(kHitboxDiagStorageLayout, storage, entity, componentSize);
        return false;
    }
    const uintptr_t packedBytes = packed.end - packed.begin;
    if (packedBytes == 0 || packedBytes % sizeof(uint32_t) != 0) {
        HitboxLogComponentDiag(kHitboxDiagStorageLayout, storage, entity, componentSize);
        return false;
    }
    const size_t packedCount = static_cast<size_t>(packedBytes / sizeof(uint32_t));

    // Resolve an already known packed index to its component payload. The
    // owner walk proves that the live Bedrock storage uses this packed/payload
    // representation; keeping this part independent from the sparse page
    // probe also lets us survive a runtime whose entity page size differs from
    // the SDK trait copied into the DLL.
    auto readPackedComponent = [&](size_t packedIndex) -> bool {
        if (packedIndex >= packedCount) return false;
        PotionMsvcVector payload{};
        bool payloadFound = false;
        for (const size_t payloadOffset : {size_t(0x50u), size_t(0x48u),
                                           size_t(0x58u), size_t(0x60u)}) {
            if (!PotionReadBytes(reinterpret_cast<const void*>(base + payloadOffset),
                                 &payload, sizeof(payload)) ||
                !PotionValidVector(payload, 0x200000u)) continue;
            payloadFound = true;
            break;
        }
        if (!payloadFound) {
            HitboxLogComponentDiag(kHitboxDiagPayloadVector, storage, entity, componentSize);
            return false;
        }

        const uintptr_t payloadBytes = payload.end - payload.begin;
        if (payloadBytes == 0 || payloadBytes % sizeof(uintptr_t) != 0) {
            HitboxLogComponentDiag(kHitboxDiagPayloadVector, storage, entity, componentSize);
            return false;
        }
        const size_t payloadPages = static_cast<size_t>(payloadBytes / sizeof(uintptr_t));

        for (const size_t componentPageSize : {size_t(128u), size_t(256u)}) {
            const size_t pageIndex = packedIndex / componentPageSize;
            const size_t pageOffset = packedIndex % componentPageSize;
            if (pageIndex >= payloadPages) continue;

            uintptr_t componentPage = 0;
            if (!PotionReadBytes(reinterpret_cast<const void*>(
                    payload.begin + pageIndex * sizeof(uintptr_t)),
                                 &componentPage, sizeof(componentPage)) ||
                !componentPage) continue;
            const uintptr_t component = componentPage + pageOffset * componentSize;
            if (!GuiRangeReadable(reinterpret_cast<const void*>(component), componentSize) ||
                !PotionReadBytes(reinterpret_cast<const void*>(component), out, componentSize))
                continue;
            HitboxRememberComponentAddress(storage, entity, componentSize,
                                           component, now);
            return true;
        }
        HitboxLogComponentDiag(kHitboxDiagComponentAddress, storage, entity, componentSize);
        return false;
    };

    // Keep a same-index fallback for a short EntityId version race. The owner
    // component and an actor's live context can be observed on adjacent ticks;
    // in that case the generation bits differ while the sparse entity index is
    // still the right component slot. Exact equality remains the first choice.
    const size_t noCandidate = (std::numeric_limits<size_t>::max)();
    size_t maskedPackedCandidate = noCandidate;

    // Fast path: the normal EnTT sparse lookup. It is retained because it is
    // O(1) for the common case and validates the packed entity/version pair.
    // A few Bedrock builds expose the sparse page through a guarded/short
    // committed range, so do not require the whole theoretical page to be
    // readable before reading the one entry we need.
    size_t sparseMappedCandidate = noCandidate;
    for (const size_t entityPageSize : {size_t(1024u), size_t(2048u),
                                         size_t(4096u), size_t(8192u)}) {
        const size_t entityPageIndex = entityIndex / entityPageSize;
        const size_t entityPageOffset = entityIndex % entityPageSize;
        if (entityPageIndex >= sparsePages) continue;

        uintptr_t sparsePage = 0;
        if (!PotionReadBytes(reinterpret_cast<const void*>(
                sparse.begin + entityPageIndex * sizeof(uintptr_t)),
                             &sparsePage, sizeof(sparsePage)) || !sparsePage)
            continue;

        const uintptr_t sparseEntryAddress =
            sparsePage + entityPageOffset * sizeof(uint32_t);
        if (!GuiRangeReadable(reinterpret_cast<const void*>(sparseEntryAddress),
                              sizeof(uint32_t)))
            continue;

        uint32_t sparseEntry = 0;
        if (!PotionReadBytes(reinterpret_cast<const void*>(sparseEntryAddress),
                             &sparseEntry, sizeof(sparseEntry)))
            continue;
        const size_t packedIndex = static_cast<size_t>(sparseEntry & kHitboxEntityMask);
        if (packedIndex >= packedCount) continue;

        uint32_t packedEntity = 0;
        const bool packedEntityRead = PotionReadBytes(reinterpret_cast<const void*>(
                packed.begin + packedIndex * sizeof(uint32_t)),
                &packedEntity, sizeof(packedEntity));
        if (packedEntityRead && packedEntity == entity &&
            readPackedComponent(packedIndex)) return true;
        if (packedEntityRead && (packedEntity & kHitboxEntityMask) == entityIndex)
            maskedPackedCandidate = packedIndex;

        // The sparse entry is the authoritative entity-to-packed mapping. In
        // the affected runtime the packed entity words are stale/laid out with
        // a different EntityId ABI even though the payload page is correct;
        // retain the sparse-derived index as an AABB-only fallback. It is
        // limited to 0x20-byte shape reads and the caller still rejects any
        // non-sane width/height before publishing a frame.
        if (componentSize == 0x20u && sparseMappedCandidate == noCandidate)
            sparseMappedCandidate = packedIndex;
    }

    if (maskedPackedCandidate != noCandidate &&
        readPackedComponent(maskedPackedCandidate))
        return true;
    if (sparseMappedCandidate != noCandidate &&
        readPackedComponent(sparseMappedCandidate))
        return true;

    // Fallback: some Bedrock builds keep a valid sparse vector but update its
    // page metadata/version word while an actor is being moved between entity
    // registries. A linear scan of the small component pool is still cheap on
    // the worker and, unlike the old code, does not turn that transient sparse
    // miss into a 2.5-second frozen AABB. Exact entity equality is retained so
    // a recycled entity slot can never return another actor's component.
    //
    // The scan is bounded: every iteration is a VEH-guarded cross-process
    // read, and a miss scans the whole range. Pools beyond this bound are
    // either misidentified storage or pathological - scanning them
    // fault-by-fault stalls the sampler worker for seconds (observed: no pass
    // for 46 s on a busy server) while the exact/sparse/masked candidates
    // above already had their O(1) chance.
    constexpr size_t kHitboxLinearScanMax = 8192u;
    const size_t linearScanEnd =
        packedCount < kHitboxLinearScanMax ? packedCount : kHitboxLinearScanMax;
    size_t maskedLinearCandidate = (std::numeric_limits<size_t>::max)();
    for (size_t packedIndex = 0; packedIndex < linearScanEnd; ++packedIndex) {
        uint32_t packedEntity = 0;
        if (!PotionReadBytes(reinterpret_cast<const void*>(
                packed.begin + packedIndex * sizeof(uint32_t)),
                             &packedEntity, sizeof(packedEntity)))
            continue;
        if (packedEntity == entity && readPackedComponent(packedIndex)) return true;
        if (maskedLinearCandidate == (std::numeric_limits<size_t>::max)() &&
            (packedEntity & kHitboxEntityMask) == entityIndex)
            maskedLinearCandidate = packedIndex;
    }
    if (maskedLinearCandidate != (std::numeric_limits<size_t>::max)() &&
        readPackedComponent(maskedLinearCandidate))
        return true;
    HitboxLogComponentDiag(kHitboxDiagSparsePacked, storage, entity, componentSize);
    return false;
}

static bool HitboxStorageHeaderLooksValid(void* storage) {
    if (!storage || !GuiPageReadable(storage) || !GuiRangeReadable(storage, 0x78u))
        return false;

    // A hash-bucket false positive can still point at a readable object.
    // Require the same storage invariants as the working Potions reader before
    // caching it: a real MSVC vtable, sparse/packed vectors and a payload-page
    // vector. Without this proof the AABB lookup can consistently walk an
    // unrelated pool and report only sparse-packed misses.
    uintptr_t vft = 0;
    if (!PotionReadBytes(storage, &vft, sizeof(vft)) ||
        !PotionValidVtable(vft))
        return false;

    const uintptr_t base = reinterpret_cast<uintptr_t>(storage);
    PotionMsvcVector sparse{};
    PotionMsvcVector packed{};
    if (!PotionReadBytes(reinterpret_cast<const void*>(base + 0x08u),
                         &sparse, sizeof(sparse)) ||
        !PotionReadBytes(reinterpret_cast<const void*>(base + 0x20u),
                         &packed, sizeof(packed)) ||
        !PotionValidVector(sparse, 0x200000u) ||
        !PotionValidVector(packed, 0x200000u))
        return false;

    for (const size_t payloadOffset : {size_t(0x50u), size_t(0x48u),
                                       size_t(0x58u), size_t(0x60u)}) {
        PotionMsvcVector payload{};
        if (PotionReadBytes(reinterpret_cast<const void*>(base + payloadOffset),
                            &payload, sizeof(payload)) &&
            PotionValidVector(payload, 0x200000u))
            return true;
    }
    return false;
}

static bool HitboxFindStorage(void* registry, uint32_t hash, void** outStorage) {
    if (outStorage) *outStorage = nullptr;
    if (!registry || !outStorage || !GuiPageReadable(registry)) return false;

    // The live Bedrock EntityContext path uses the native EnTT pool map at
    // registry + 0x38: sparse buckets +0x00, packed nodes +0x18, and node
    // {next,key,shared_ptr} at 0x00/0x08/0x10. The +0x48 map is retained only
    // as a later compatibility fallback. Trying +0x48 first can return a
    // readable but unrelated storage candidate, which produces the exact
    // sparse-packed AABB miss seen in direct74.
    struct MapLayout {
        size_t pool;
        size_t packed;
        size_t node;
        size_t storage;
    };
    const MapLayout layouts[] = {
        {0x38u, 0x18u, 0x20u, 0x10u},
        {0x48u, 0x20u, 0x20u, 0x10u},
        {0x50u, 0x28u, 0x28u, 0x18u},
        {0x40u, 0x18u, 0x18u, 0x10u},
        {0x58u, 0x30u, 0x30u, 0x18u},
    };
    const size_t empty = (std::numeric_limits<size_t>::max)();

    for (const MapLayout& layout : layouts) {
        const uintptr_t map = reinterpret_cast<uintptr_t>(registry) + layout.pool;
        PotionMsvcVector sparse{};
        PotionMsvcVector packed{};
        if (!PotionReadBytes(reinterpret_cast<const void*>(map + 0x00u),
                             &sparse, sizeof(sparse)) ||
            !PotionReadBytes(reinterpret_cast<const void*>(map + layout.packed),
                             &packed, sizeof(packed)) ||
            !PotionValidVector(sparse, 0x100000u) ||
            !PotionValidVector(packed, 0x1000000u)) continue;

        const uintptr_t sparseBytes = sparse.end - sparse.begin;
        const uintptr_t packedBytes = packed.end - packed.begin;
        if (sparseBytes < 0x40u || sparseBytes % sizeof(size_t) != 0 ||
            !packedBytes || packedBytes % layout.node != 0) continue;
        const size_t bucketCount = static_cast<size_t>(sparseBytes / sizeof(size_t));
        const size_t nodeCount = static_cast<size_t>(packedBytes / layout.node);
        if ((bucketCount & (bucketCount - 1u)) != 0 || bucketCount < 8u ||
            bucketCount > 0x100000u || nodeCount == 0 || nodeCount > 4096u) continue;

        const size_t bucket = static_cast<size_t>(hash) & (bucketCount - 1u);
        size_t head = empty;
        if (!PotionReadBytes(reinterpret_cast<const void*>(
                sparse.begin + bucket * sizeof(size_t)), &head, sizeof(head)) ||
            (head >= nodeCount && head != empty)) {
            // Some adjacent builds store dense-map indices as uint32_t.
            uint32_t head32 = 0;
            if (!PotionReadBytes(reinterpret_cast<const void*>(
                    sparse.begin + bucket * sizeof(uint32_t)), &head32, sizeof(head32)))
                continue;
            head = head32;
        }
        if (head == empty || head >= nodeCount) continue;

        size_t current = head;
        for (size_t step = 0; step < nodeCount && current != empty; ++step) {
            if (current >= nodeCount) break;
            const uintptr_t nodeAddress = packed.begin + current * layout.node;
            size_t next = empty;
            uint32_t key = 0;
            if (!PotionReadBytes(reinterpret_cast<const void*>(nodeAddress + 0x00u),
                                 &next, sizeof(next)) ||
                !PotionReadBytes(reinterpret_cast<const void*>(nodeAddress + 0x08u),
                                 &key, sizeof(key))) break;
            if (key == hash && layout.storage + sizeof(uintptr_t) <= layout.node) {
                uintptr_t storage = 0;
                if (PotionReadBytes(reinterpret_cast<const void*>(
                        nodeAddress + layout.storage), &storage, sizeof(storage)) &&
                    HitboxStorageHeaderLooksValid(reinterpret_cast<void*>(storage))) {
                    *outStorage = reinterpret_cast<void*>(storage);
                    return true;
                }
            }
            if (next == current || next >= nodeCount) break;
            current = next;
        }
    }
    return false;
}

SRWLOCK g_hitboxOwnerStorageLock = SRWLOCK_INIT;
void* g_hitboxOwnerStorageRegistry = nullptr;
void* g_hitboxOwnerStorage = nullptr;
ULONGLONG g_hitboxOwnerStorageRetryAt = 0;
volatile LONG g_hitboxOwnerPathReady = 0;
SRWLOCK g_hitboxOwnerSnapshotLock = SRWLOCK_INIT;
void* g_hitboxOwnerSnapshot[256] = {};
int g_hitboxOwnerSnapshotCount = 0;
ULONGLONG g_hitboxOwnerSnapshotAt = 0;
bool g_hitboxOwnerSnapshotComplete = false;
void* g_hitboxOwnerSnapshotRegistry = nullptr;
HANDLE g_hitboxOwnerRefreshThread = nullptr;
volatile LONG g_hitboxOwnerRefreshStarted = 0;
void* g_hitboxOwnerLocal = nullptr;

static int HitboxCopyOwnerSnapshot(void** out, int maxOut,
                                   ULONGLONG now, ULONGLONG maxAge,
                                   void* worldRegistry = nullptr,
                                   bool* completeOut = nullptr) {
    if (completeOut) *completeOut = false;
    if (!out || maxOut <= 0) return 0;
    AcquireSRWLockShared(&g_hitboxOwnerSnapshotLock);
    const int count = g_hitboxOwnerSnapshotCount;
    const bool registryOk = !worldRegistry ||
                            g_hitboxOwnerSnapshotRegistry == worldRegistry;
    // A complete owner scan may legitimately contain zero actors. The old
    // count>0 gate made an empty storage look like a read failure forever and
    // left the last mob boxes frozen after despawn. Keep an explicit validity
    // bit separate from the count.
    const bool fits = count >= 0 && count <= maxOut;
    const bool usable = registryOk && fits && g_hitboxOwnerSnapshotComplete &&
                        now - g_hitboxOwnerSnapshotAt <= maxAge;
    if (completeOut) *completeOut = usable;
    const int copyCount = usable ? count : 0;
    if (copyCount > 0)
        std::memcpy(out, g_hitboxOwnerSnapshot,
                    sizeof(void*) * static_cast<size_t>(copyCount));
    ReleaseSRWLockShared(&g_hitboxOwnerSnapshotLock);
    return copyCount;
}

static bool HitboxTouchOwnerSnapshot(void* worldRegistry, ULONGLONG now) {
    bool touched = false;
    AcquireSRWLockExclusive(&g_hitboxOwnerSnapshotLock);
    if (g_hitboxOwnerSnapshotComplete &&
        g_hitboxOwnerSnapshotRegistry == worldRegistry) {
        // The owner storage was reached, but one transient RPM/layout proof
        // failed. Keep the last complete Flarial actor list alive; do not let a
        // temporary scan miss turn into either flicker or a 30-second vanish.
        g_hitboxOwnerSnapshotAt = now;
        touched = true;
    }
    ReleaseSRWLockExclusive(&g_hitboxOwnerSnapshotLock);
    if (touched) {
        static ULONGLONG nextTouchDiag = 0;
        if (now >= nextTouchDiag) {
            nextTouchDiag = now + 5000u;
            LOG_INFO("hitboxes: owner scan transient; retaining last complete snapshot");
        }
    }
    return touched;
}

// One-shot dump of the ActorOwnerComponent pool through the public EnTT API.
//
// The owner walk below reproduces basic_storage's private layout by hand -
// packed vector at +0x20, payload pages at +0x50/0x48/0x58/0x60 - and, worse,
// GUESSES the component page size (128 or 256) in order to pair a packed entity
// with a payload slot. A wrong page size silently pairs actor A with entity B's
// id. That matches the live symptom exactly: the local player sits at packed
// index 0, so page 0 / offset 0 under ANY page size and therefore reads fine,
// while every other actor gets a mismatched (actor, entity) pair and misses.
//
// This dump replaces the guesswork with facts: the real entity ids straight out
// of the pool, plus the raw payload bytes for each of them. For the local
// player's own entity the owner pointer must equal localActor, which pins the
// field offset exactly.
static void HitboxDumpOwnerPool(void* enttRegistry, void* localActor) {
    if (!enttRegistry) return;
#ifdef _MSC_VER
    __try {
#endif
        const auto* registry =
            reinterpret_cast<const entt::basic_registry<EntityId>*>(enttRegistry);
        const auto* pool = registry->storage(kHitboxOwnerHash);
        if (!pool) {
            LOG_INFO("hitboxes: owner pool hash=%08X registry=%p absent",
                     kHitboxOwnerHash, enttRegistry);
            return;
        }
        const size_t total = static_cast<size_t>(pool->size());
        LOG_INFO("hitboxes: owner pool hash=%08X registry=%p pool=%p size=%u "
                 "local=%p",
                 kHitboxOwnerHash, enttRegistry,
                 static_cast<const void*>(pool), (unsigned)total, localActor);

        const size_t limit = total < 12 ? total : 12;
        char ids[12 * 10 + 1] = {};
        unsigned liveCount = 0;
        unsigned tombstoneCount = 0;
        for (size_t i = 0; i < limit; ++i) {
            const uint32_t raw = static_cast<uint32_t>((*pool)[i]);
            if (pool->contains(EntityId(raw)))
                ++liveCount;
            else
                ++tombstoneCount;
            char one[16];
            _snprintf_s(one, sizeof(one), _TRUNCATE, "%s%08X", i ? "," : "", raw);
            strcat_s(ids, sizeof(ids), one);
        }
        LOG_INFO("hitboxes: owner pool ids=%s live=%u tombstone=%u", ids,
                 liveCount, tombstoneCount);

        for (size_t i = 0; i < limit; ++i) {
            const EntityId id = (*pool)[i];
            // value() asserts contains(); a tombstoned slot must be skipped, not
            // probed. (Calling it blindly here is what faulted this dump.)
            if (!pool->contains(id)) continue;
            const unsigned char* payload =
                static_cast<const unsigned char*>(pool->value(id));
            if (!payload) continue;
            char hex[3 * 32 + 1] = {};
            uintptr_t slots[4] = {};
            for (int b = 0; b < 32; ++b) {
                char one[4];
                _snprintf_s(one, sizeof(one), _TRUNCATE, "%02X", payload[b]);
                strcat_s(hex, sizeof(hex), one);
            }
            for (int s = 0; s < 4; ++s)
                std::memcpy(&slots[s], payload + s * 8, sizeof(uintptr_t));
            LOG_INFO("hitboxes: owner payload entity=%08X %s | p0=%p p1=%p p2=%p "
                     "p3=%p",
                     static_cast<uint32_t>(id), hex,
                     reinterpret_cast<void*>(slots[0]),
                     reinterpret_cast<void*>(slots[1]),
                     reinterpret_cast<void*>(slots[2]),
                     reinterpret_cast<void*>(slots[3]));
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        LOG_INFO("hitboxes: owner pool dump fault registry=%p", enttRegistry);
    }
#endif
}

// Tombstone filter for the owner walk.
//
// With EnTT's in_place_delete policy, erasing an entity does NOT remove its
// packed slot: in_place_pop() sets the sparse entry to null and overwrites the
// slot with a synthetic id (observed live as FFFFFFFF and FFFC0003/4/8/9).
// Reading the packed array raw therefore yields ids that are not entities at
// all. contains() rejects exactly those, because it compares against the sparse
// entry that was nulled on erase - and it does so without needing to know the
// tombstone encoding, which is an implementation detail.
//
// Returns true when the slot should be treated as a live entity. A null pool
// view means "cannot filter", so nothing is skipped. Any fault while probing a
// stale pool is reported as "not live" rather than taken down.
template <typename Pool>
static bool HitboxPoolContains(const Pool* pool, uint32_t entity) {
    if (!pool) return true;
#ifdef _MSC_VER
    __try {
        return pool->contains(EntityId(entity));
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
#else
    return pool->contains(EntityId(entity));
#endif
}

static int HitboxEnumerateOwnerActors(void** out, int maxOut,
                                      void* worldRegistry, void* local,
                                      bool forceRefresh = false,
                                      bool* completeOut = nullptr) {
    if (completeOut) *completeOut = false;
    if (!out || maxOut <= 0 || !worldRegistry) return 0;
    const ULONGLONG now = GetTickCount64();
    if (!forceRefresh) {
        // Render must never perform the EnTT storage walk. The refresh worker
        // owns that expensive operation; the render path only consumes the
        // last complete snapshot, including a valid empty snapshot.
        return HitboxCopyOwnerSnapshot(out, maxOut, now, 5000u,
                                       worldRegistry, completeOut);
    }

    static volatile LONG ownerPoolDumped = 0;
    if (InterlockedIncrement(&ownerPoolDumped) <= 2)
        HitboxDumpOwnerPool(worldRegistry, local);

    void* storage = nullptr;
    AcquireSRWLockShared(&g_hitboxOwnerStorageLock);
    if (g_hitboxOwnerStorageRegistry == worldRegistry)
        storage = g_hitboxOwnerStorage;
    const bool retryBlocked = !storage && now < g_hitboxOwnerStorageRetryAt;
    ReleaseSRWLockShared(&g_hitboxOwnerStorageLock);
    if (!storage && !retryBlocked) {
        void* discovered = nullptr;
        if (HitboxFindStorage(worldRegistry, kHitboxOwnerHash, &discovered) && discovered) {
            AcquireSRWLockExclusive(&g_hitboxOwnerStorageLock);
            g_hitboxOwnerStorageRegistry = worldRegistry;
            g_hitboxOwnerStorage = discovered;
            g_hitboxOwnerStorageRetryAt = 0;
            storage = discovered;
            InterlockedExchange(&g_hitboxOwnerPathReady, 1);
            ReleaseSRWLockExclusive(&g_hitboxOwnerStorageLock);
        } else {
            AcquireSRWLockExclusive(&g_hitboxOwnerStorageLock);
            g_hitboxOwnerStorageRegistry = worldRegistry;
            g_hitboxOwnerStorage = nullptr;
            g_hitboxOwnerStorageRetryAt = now + 1000u;
            InterlockedExchange(&g_hitboxOwnerPathReady, 0);
            ReleaseSRWLockExclusive(&g_hitboxOwnerStorageLock);
            return HitboxCopyOwnerSnapshot(out, maxOut, now, 5000u,
                                           worldRegistry, completeOut);
        }
    }
    if (!storage || !GuiRangeReadable(storage, 0x78u)) {
        if (storage) HitboxTouchOwnerSnapshot(worldRegistry, now);
        return HitboxCopyOwnerSnapshot(out, maxOut, now, 5000u,
                                       worldRegistry, completeOut);
    }

    PotionMsvcVector packed{};
    if (!PotionReadBytes(reinterpret_cast<const void*>(
            reinterpret_cast<uintptr_t>(storage) + 0x20u),
                         &packed, sizeof(packed)) ||
        !PotionValidVector(packed, 0x200000u) ||
        (packed.end - packed.begin) % sizeof(uint32_t) != 0) {
        HitboxTouchOwnerSnapshot(worldRegistry, now);
        return HitboxCopyOwnerSnapshot(out, maxOut, now, 5000u,
                                       worldRegistry, completeOut);
    }
    const uintptr_t packedBytes = packed.end - packed.begin;
    const size_t packedCount = static_cast<size_t>(packedBytes / sizeof(uint32_t));

    // Publish only after the whole storage walk has succeeded. A zero-length
    // packed vector is a real, complete "no owner actors" result and must
    // replace the previous list; partial RPM/component failures fall back to
    // the previous complete snapshot instead.
    auto publish = [&](void** actors, int count) {
        AcquireSRWLockExclusive(&g_hitboxOwnerSnapshotLock);
        if (count > 0)
            std::memcpy(g_hitboxOwnerSnapshot, actors,
                        sizeof(void*) * static_cast<size_t>(count));
        g_hitboxOwnerSnapshotCount = count;
        g_hitboxOwnerSnapshotAt = now;
        g_hitboxOwnerSnapshotRegistry = worldRegistry;
        g_hitboxOwnerSnapshotComplete = true;
        ReleaseSRWLockExclusive(&g_hitboxOwnerSnapshotLock);
        static int lastPublishedCount = -2;
        static void* lastPublishedRegistry = nullptr;
        if (lastPublishedCount != count || lastPublishedRegistry != worldRegistry) {
            LOG_INFO("hitboxes: owner snapshot published actors=%d registry=%p",
                     count, worldRegistry);
            lastPublishedCount = count;
            lastPublishedRegistry = worldRegistry;
        }
        if (completeOut) *completeOut = true;
        return count;
    };

    if (packedCount == 0)
        return publish(nullptr, 0);
    if (packedCount > static_cast<size_t>(maxOut)) {
        HitboxTouchOwnerSnapshot(worldRegistry, now);
        return HitboxCopyOwnerSnapshot(out, maxOut, now, 5000u,
                                       worldRegistry, completeOut);
    }

    const size_t payloadOffsets[] = {0x50u, 0x48u, 0x58u, 0x60u};
    PotionMsvcVector payload{};
    bool payloadFound = false;
    for (const size_t offset : payloadOffsets) {
        if (PotionReadBytes(reinterpret_cast<const void*>(
                reinterpret_cast<uintptr_t>(storage) + offset),
                &payload, sizeof(payload)) &&
            PotionValidVector(payload, 0x200000u)) {
            payloadFound = true;
            break;
        }
    }
    if (!payloadFound) {
        HitboxTouchOwnerSnapshot(worldRegistry, now);
        return HitboxCopyOwnerSnapshot(out, maxOut, now, 5000u,
                                       worldRegistry, completeOut);
    }
    const uintptr_t payloadBytes = payload.end - payload.begin;
    if (payloadBytes == 0 || payloadBytes % sizeof(uintptr_t) != 0) {
        HitboxTouchOwnerSnapshot(worldRegistry, now);
        return HitboxCopyOwnerSnapshot(out, maxOut, now, 5000u,
                                       worldRegistry, completeOut);
    }
    const size_t payloadPages = static_cast<size_t>(payloadBytes / sizeof(uintptr_t));

    void* candidate[256] = {};
    uint32_t candidateEntities[256] = {};
    // Public, non-template lookup: a pure pools.find(hash) that can never create
    // a pool. Used only to filter tombstones out of the packed array below.
    const auto* ownerRegistry =
        reinterpret_cast<const entt::basic_registry<EntityId>*>(worldRegistry);
    const auto* ownerPool =
        ownerRegistry ? ownerRegistry->storage(kHitboxOwnerHash) : nullptr;

    // Arms the page memo for the whole walk - both layout guesses included - so
    // the repeated vtable/first-entry probes below become table hits instead of
    // kernel transitions. The guard disarms on every exit path of this function
    // (there are several, all of them returns), and this function contains no
    // __try of its own, so a destructor is legal here.
    PageMemoScope pageMemo;

    // The winning page size is a property of the game build, not of the frame,
    // so the guess that worked last time is tried first. That turns the "128
    // fails, 256 succeeds" case from two full walks into one; the second guess
    // then only ever runs after a genuine layout change.
    static volatile LONG preferredPageSize = 0;
    const bool prefer256 = InterlockedCompareExchange(&preferredPageSize, 0, 0) == 256;
    const size_t pageSizes[2] = { prefer256 ? size_t(256u) : size_t(128u),
                                  prefer256 ? size_t(128u) : size_t(256u) };
    for (const size_t pageSize : pageSizes) {
        int count = 0;
        int badSlots = 0;
        bool layoutComplete = true;
        for (size_t packedIndex = 0; packedIndex < packedCount; ++packedIndex) {
            uint32_t entity = 0;
            if (!PotionReadBytes(reinterpret_cast<const void*>(
                    packed.begin + packedIndex * sizeof(uint32_t)),
                                 &entity, sizeof(entity))) {
                // The packed vector itself went away; keep what we have.
                layoutComplete = false;
                break;
            }
            // Tombstoned slots and entt::null are not entities. Skipping them
            // must NOT abort the walk: the packed array legitimately contains
            // holes, and treating a hole as fatal is exactly what threw the
            // whole actor list away (owners=0) while the local player still read
            // fine, simply because it happens to sit in a live slot.
            if (!HitboxPoolContains(ownerPool, entity)) continue;
            const size_t pageIndex = packedIndex / pageSize;
            const size_t pageOffset = packedIndex % pageSize;
            if (pageIndex >= payloadPages) {
                layoutComplete = false;
                break;
            }
            uintptr_t componentPage = 0;
            if (!PotionReadBytes(reinterpret_cast<const void*>(
                    payload.begin + pageIndex * sizeof(uintptr_t)),
                                 &componentPage, sizeof(componentPage)) ||
                !componentPage) {
                // Skip this slot instead of discarding every actor found so far.
                ++badSlots;
                continue;
            }
            uintptr_t actor = 0;
            if (!PotionReadBytes(reinterpret_cast<const void*>(
                    componentPage + pageOffset * sizeof(uintptr_t)),
                                 &actor, sizeof(actor)) ||
                !actor || actor < 0x10000u ||
                !GuiPageReadable(reinterpret_cast<const void*>(actor))) {
                ++badSlots;
                continue;
            }
            // The local player is a valid owner entry but is intentionally not
            // part of the mob ESP list.
            if (actor == reinterpret_cast<uintptr_t>(local)) continue;
            uintptr_t vft = 0;
            if (!PotionReadBytes(reinterpret_cast<const void*>(actor), &vft, sizeof(vft)) ||
                !PotionValidVtable(vft)) {
                ++badSlots;
                continue;
            }
            if (count >= maxOut) {
                layoutComplete = false;
                break;
            }
            void* actorPtr = reinterpret_cast<void*>(actor);
            bool duplicate = false;
            for (int i = 0; i < count; ++i) duplicate |= candidate[i] == actorPtr;
            if (duplicate) continue;
            candidate[count] = actorPtr;
            candidateEntities[count] = entity;
            ++count;
        }
        // An empty result is only trustworthy when nothing looked broken. If
        // slots failed to read and we still found nobody, the layout is the
        // problem, so keep the previous snapshot rather than clobbering it with
        // an empty list (which the renderer would then replace with its 256-slot
        // baseTick fallback).
        if (layoutComplete && count == 0 && badSlots > 0)
            layoutComplete = false;
        if (layoutComplete) {
            static volatile LONG ownerWalkLogged = 0;
            if (InterlockedIncrement(&ownerWalkLogged) <= 4)
                LOG_INFO("hitboxes: owner walk pageSize=%u count=%d badSlots=%d "
                         "packed=%u",
                         (unsigned)pageSize, count, badSlots,
                         (unsigned)packedCount);
            // Pair proof: the owner pool's own entity id, the actor's own
            // EntityContext id, and whether the AABB pool holds each. When the
            // owner id is right but the AABB pool rejects it, the AABB pool key
            // - not the entity - is what is wrong.
            static volatile LONG ownerPairLogged = 0;
            if (InterlockedIncrement(&ownerPairLogged) <= 4) {
                const auto* aabbPool =
                    ownerRegistry ? ownerRegistry->storage(kHitboxAabbHash)
                                  : nullptr;
                for (int i = 0; i < count && i < 3; ++i) {
                    void* ctxReg = nullptr;
                    void* ctxEntt = nullptr;
                    uint32_t ctxEntity = 0;
                    const bool ctxOk = HitboxReadActorContextDirect(
                        candidate[i], &ctxReg, &ctxEntt, &ctxEntity);
                    LOG_INFO("hitboxes: owner pair actor=%p ownerEntity=%08X "
                             "ctx=%d ctxEntity=%08X aabbOwner=%d aabbCtx=%d",
                             candidate[i], candidateEntities[i], ctxOk ? 1 : 0,
                             ctxEntity,
                             aabbPool ? (aabbPool->contains(
                                             EntityId(candidateEntities[i]))
                                             ? 1
                                             : 0)
                                      : -1,
                             aabbPool && ctxOk ? (aabbPool->contains(
                                                      EntityId(ctxEntity))
                                                      ? 1
                                                      : 0)
                                               : -1);
                }
            }
            for (int i = 0; i < count; ++i)
                HitboxRememberEntityHint(candidate[i], worldRegistry, candidateEntities[i]);
            // The caller's own buffer must receive the same list. publish() only
            // writes the *shared* snapshot and returns the count, so the
            // forceRefresh callers used to get "count = 48" with their `out`
            // array left exactly as they zero-initialised it. HitboxCaptureFrameSync
            // then walked 48 owners, hit actors[0] == nullptr on the first
            // iteration and `break`-ed out of the packet assembly - which is the
            // live "packet owners=53 kept=0 self=0 gate=0 ... noAabb=0" line:
            // a count that cannot be produced by any combination of the drop
            // counters, because the loop never ran.
            if (count > 0)
                std::memcpy(out, candidate,
                            sizeof(void*) * static_cast<size_t>(count));
            InterlockedExchange(&preferredPageSize, (LONG)pageSize);
            return publish(candidate, count);
        }
        // A valid 128-entry page is preferred, but if it fails proof try the
        // adjacent 256-entry layout before preserving the old snapshot.
    }
    // The storage was readable but one entity/page proof failed. Treat this
    // as a transient scan miss and retain the last complete owner vector; the
    // next one-second refresh retries the full walk.
    HitboxTouchOwnerSnapshot(worldRegistry, now);
    return HitboxCopyOwnerSnapshot(out, maxOut, now, 5000u,
                                   worldRegistry, completeOut);
}

static void* HitboxResolveWorldRegistry() {
    // Bootstrap and world replacement stay on the sampler thread. The ImGui
    // callback only consumes snapshots and never invokes a game vtable or
    // resolves an EntityContext.
    void* registry = HitboxGetWorldRegistry();
    void* local = HitboxLocalPlayer();
    if (local) {
        void* registryObject = nullptr;
        void* enttRegistry = nullptr;
        uint32_t entity = 0;
        if (HitboxReadActorContextDirect(local, &registryObject, &enttRegistry,
                                         &entity) && enttRegistry) {
            // This is the only live-context adoption point for the sampler;
            // it also notices a world swap even when the potion UI is disabled.
            HitboxAdoptWorldContext(enttRegistry, local);
            registry = enttRegistry;
        }
    }
    return registry ? registry : HitboxGetWorldRegistry();
}

static DWORD WINAPI HitboxOwnerRefreshProc(LPVOID) {
    void* refreshed[256] = {};
    ULONGLONG nextOwnerScan = 0;
    LONG consumedUrgentGeneration = 0;
    InterlockedExchange(&g_hitboxWorkerAlive, 1);
    LOG_INFO("hitboxes: AABB sampler started");
    while (!g_shuttingDown && !g_abort) {
        ULONGLONG now = GetTickCount64();
        // Liveness beat: the supervisor compares this against the clock, so a
        // stalled sampler (blocked on a lock, or chewing a garbage registry) is
        // distinguishable from a dead one.
        g_hitboxWorkerBeatAt = now;
        ++g_hitboxWorkerBeatPass;
        void* registry = HitboxGetWorldRegistry();
        if (now >= nextOwnerScan) {
            registry = HitboxResolveWorldRegistry();
            nextOwnerScan = now + 1000u;
            if (registry) {
                bool ownerScanComplete = false;
                const int count = HitboxEnumerateOwnerActors(
                    refreshed, 256, registry, g_hitboxOwnerLocal, true,
                    &ownerScanComplete);
                if (ownerScanComplete && count > 0) {
                    static volatile LONG refreshLogged = 0;
                    if (InterlockedIncrement(&refreshLogged) <= 2)
                        LOG_INFO("hitboxes: owner snapshot refreshed actors=%d registry=%p",
                                 count, registry);
                }
            }
        }
        registry = HitboxGetWorldRegistry();
        if (registry) {
            float camera[3] = {};
            const bool cameraValid = GetCameraWorldPosition(camera);
            int count = HitboxCopyOwnerSnapshot(refreshed, 256, now, 5000u,
                                                registry);
            if (count > 256) count = 256;
            const int snapshotCount = count;

            // The baseTick fallback list feeds the render packet while the
            // owner enumeration degrades. Append its actors (deduped) so the
            // worker keeps their gates and AABBs fresh too - the render
            // thread no longer performs fresh reads itself.
            {
                AcquireSRWLockShared(&g_hitboxActorLock);
                for (const HitboxActorEntry& entry : g_hitboxActors) {
                    if (count >= (int)kHitboxActorSlots) break;
                    if (!entry.actor || now - HitboxActorTick(entry) > 600u) continue;
                    bool known = false;
                    for (int i = 0; i < count; ++i) {
                        if (refreshed[i] == entry.actor) { known = true; break; }
                    }
                    if (!known) refreshed[count++] = entry.actor;
                }
                ReleaseSRWLockShared(&g_hitboxActorLock);
            }
            const int tickAdded = count - snapshotCount;

            // Flarial samples its lerped AABB immediately around the game's
            // render/setup boundary. LevelRenderer::renderLevel publishes a
            // generation after the game has updated RenderPositionComponent;
            // this worker consumes that signal and refreshes a bounded,
            // rotating batch. The render path still reads only snapshots.
            const LONG urgentGeneration =
                InterlockedCompareExchange(&g_hitboxAabbUrgentGeneration, 0, 0);
            const bool urgent = urgentGeneration != consumedUrgentGeneration;
            if (urgent) consumedUrgentGeneration = urgentGeneration;

            int budget = kHitboxAabbBudgetPerPass;
            int visited = 0;
            int attempted = 0;
            int freshTotal = 0;
            int urgentAttempted = 0;
            int urgentFresh = 0;
            if (count > 0) {
                const int start = ((g_hitboxAabbProbeStart % count) + count) % count;
                auto visitPass = [&](bool urgentPass) {
                    for (int step = 0; step < count && budget > 0; ++step) {
                        const int index = (start + step) % count;
                        ++visited;
                        if (g_shuttingDown || g_abort) break;
                        if (!HitboxActorIsTarget(refreshed[index])) continue;
                        if (!HitboxShouldRefreshAabb(refreshed[index], camera,
                                                     cameraValid, now,
                                                     urgentPass))
                            continue;
                        if (urgentPass) ++urgentAttempted;
                        ++attempted;
                        const bool fresh = HitboxRefreshAabbEntry(refreshed[index]);
                        if (fresh) ++freshTotal;
                        if (urgentPass && fresh) ++urgentFresh;
                        --budget;
                    }
                };

                if (urgent) visitPass(true);
                // Fill unused budget with the recovery path. Actors refreshed
                // in the urgent pass are skipped for 16 ms by this non-urgent
                // predicate, so this cannot duplicate that work.
                if (budget > 0) visitPass(false);
                g_hitboxAabbProbeStart = (start + std::max(1, visited)) % count;

                // Occlusion (canSee) + invisible/armor gates: evaluated here
                // with a 150 ms refresh instead of per actor per frame on the
                // game render thread. The render path reads only the cached
                // verdicts (HitboxCopyCachedGates).
                HitboxRefreshGates(refreshed, count, now);
            }

            if (urgent) {
                static volatile LONG urgentLogged = 0;
                if (InterlockedIncrement(&urgentLogged) <= 6)
                    LOG_INFO("hitboxes: urgent AABB generation=%ld attempted=%d fresh=%d owners=%d camera=%d budgetLeft=%d",
                             urgentGeneration, urgentAttempted, urgentFresh,
                             count, cameraValid ? 1 : 0, budget);
            }

            // Once a second, the whole AABB pipeline in one line. This is the
            // line that answers "why are there no boxes" without a rebuild:
            //   ctx-fail     - the actor/entity pairing never resolved, so the
            //                  component read was never even attempted
            //   shape-miss   - the pairing resolved but the AABB pool rejected
            //                  the entity (wrong pool key or stale entity id)
            //   shape-invalid- the pool answered, but the size fields are not
            //                  this build's size fields
            //   no-position  - shape ok, neither render position nor state
            //                  vector resolved
            //   target-reject- the +0x210 category filter dropped actors
            static ULONGLONG nextAabbAgg = 0;
            if (now >= nextAabbAgg) {
                nextAabbAgg = now + 1000u;
                const LONG ctxFail =
                    InterlockedExchange(&g_hitboxAabbStageCount[kAabbStageCtxFail], 0);
                const LONG shapeMiss =
                    InterlockedExchange(&g_hitboxAabbStageCount[kAabbStageShapeMiss], 0);
                const LONG shapeBad =
                    InterlockedExchange(&g_hitboxAabbStageCount[kAabbStageShapeInvalid], 0);
                const LONG shapeOk =
                    InterlockedExchange(&g_hitboxAabbStageCount[kAabbStageShapeOk], 0);
                const LONG noPos =
                    InterlockedExchange(&g_hitboxAabbStageCount[kAabbStageNoPosition], 0);
                const LONG ok =
                    InterlockedExchange(&g_hitboxAabbStageCount[kAabbStageOk], 0);
                const LONG refreshOk = InterlockedExchange(&g_hitboxAabbRefreshOk, 0);
                const LONG refreshFail = InterlockedExchange(&g_hitboxAabbRefreshFail, 0);
                const LONG reject = InterlockedExchange(&g_hitboxTargetRejectCount, 0);
                const LONG lastRejectedWord = InterlockedCompareExchange(
                    &g_hitboxTargetRejectWord, 0, 0);

                // Emergency release for the +0x210 filter: rejecting every owner
                // actor for three seconds in a row is not filtering, it is
                // hiding the world. See g_hitboxTargetFilterOff.
                if (count > 0 && reject > 0 && attempted == 0) {
                    if (InterlockedIncrement(&g_hitboxTargetFilterStrikes) >=
                            kHitboxTargetFilterStrikeLimit &&
                        InterlockedCompareExchange(&g_hitboxTargetFilterOff, 1, 0) == 0) {
                        LOG_INFO("hitboxes: target filter DISABLED - it rejected all "
                                 "%d owner actors for %d consecutive seconds "
                                 "(lastWord=%08X); the +0x210 word is not this "
                                 "build's category mask, failing open",
                                 count, kHitboxTargetFilterStrikeLimit,
                                 static_cast<unsigned>(lastRejectedWord));
                    }
                } else {
                    InterlockedExchange(&g_hitboxTargetFilterStrikes, 0);
                }

                LOG_INFO("hitboxes: aabb agg owners=%d snapshot=%d tickAdded=%d "
                         "visited=%d attempted=%d fresh=%d | ctx-fail=%ld "
                         "shape-miss=%ld shape-invalid=%ld shape-ok=%ld "
                         "no-position=%ld ok=%ld refreshOk=%ld refreshFail=%ld | "
                         "target-reject=%ld lastWord=%08X filterOff=%ld camera=%d urgent=%d "
                         "| registry=1 pass=%llu",
                         count, snapshotCount, tickAdded, visited, attempted,
                         freshTotal, ctxFail, shapeMiss, shapeBad, shapeOk,
                         noPos, ok, refreshOk, refreshFail, reject,
                         static_cast<unsigned>(lastRejectedWord),
                         InterlockedCompareExchange(&g_hitboxTargetFilterOff, 0, 0),
                         cameraValid ? 1 : 0, urgent ? 1 : 0,
                         (unsigned long long)g_hitboxWorkerBeatPass);
            }
        } else {
            // No world registry on this pass. Every cached box expires while
            // this stays true, and without this branch the only line that
            // explains "no boxes" is simply *absent* - a dead sampler and an
            // absent registry looked identical from the log.
            static ULONGLONG nextNoRegistryDiag = 0;
            if (now >= nextNoRegistryDiag) {
                nextNoRegistryDiag = now + 2000u;
                LOG_ERROR("hitboxes: AABB sampler has no world registry "
                          "(pass=%llu) - nothing is refreshing the box cache",
                          (unsigned long long)g_hitboxWorkerBeatPass);
            }
        }
        // Target HUD: poll the tracked victim's Hurt flag for damage events.
        // Target HUD: poll the displayed target's Hurt flag for damage
        // events. Fault-contained: the worker thread must survive anything.
#ifdef _MSC_VER
        __try {
            ThPollTargetInfo();
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            g_tiTarget = nullptr;
            g_tiLastHurt = false;
            g_tiStable = 0;
        }
#else
        ThPollTargetInfo();
#endif
        Sleep(8);
    }
    // Reached only by a deliberate shutdown or by the thread being torn down.
    // If this appears while the game is still running, the sampler died and
    // every cached box is about to expire - the supervisor will restart it.
    InterlockedExchange(&g_hitboxWorkerAlive, 0);
    // Reached only by a deliberate shutdown or by the thread being torn down.
    // If this appears while the game is still running, the sampler died and
    // every cached box is about to expire - the supervisor will restart it.
    InterlockedExchange(&g_hitboxWorkerAlive, 0);
    LOG_ERROR("hitboxes: AABB sampler exiting (shutdown=%d abort=%d passes=%llu) - "
              "cached boxes will expire unless it is restarted",
              g_shuttingDown ? 1 : 0, g_abort ? 1 : 0,
              (unsigned long long)g_hitboxWorkerBeatPass);
    return 0;
}

static void HitboxEnsureOwnerRefreshThread() {
    // Supervisor, not a one-shot starter.
    //
    // The sampler is the only writer of the AABB cache, so its death costs the
    // entire ESP: every cached box expires within a second, the packet keeps
    // being published with kept=0, and the module reports actors=0 with no
    // error anywhere. That is exactly what the 22:33 session showed - the
    // sampler's last line at 22:33:23.029 and then 75 s of silence from that
    // thread. Callers re-invoke this from the parked startup thread, so a
    // thread death becomes a restart instead of a feature that stays gone
    // until the game is restarted.
    if (InterlockedCompareExchange(&g_hitboxOwnerRefreshStarted, 1, 0) != 0) {
        HANDLE existing = g_hitboxOwnerRefreshThread;
        if (!existing) return;
        if (WaitForSingleObject(existing, 0) != WAIT_OBJECT_0) {
            // Still running - but is it making progress? A sampler blocked on a
            // lock or chewing a garbage registry looks healthy from the outside,
            // and used to be completely invisible in the log.
            static ULONGLONG nextStallDiag = 0;
            const ULONGLONG now = GetTickCount64();
            if (g_hitboxWorkerBeatAt != 0 && now - g_hitboxWorkerBeatAt > 4000u &&
                now >= nextStallDiag) {
                nextStallDiag = now + 4000u;
                LOG_ERROR("hitboxes: AABB sampler stalled - no pass for %llu ms (passes=%llu)",
                          (unsigned long long)(now - g_hitboxWorkerBeatAt),
                          (unsigned long long)g_hitboxWorkerBeatPass);
            }
            return;
        }
        // Signalled: the sampler thread is gone.
        CloseHandle(existing);
        g_hitboxOwnerRefreshThread = nullptr;
        InterlockedExchange(&g_hitboxOwnerRefreshStarted, 0);
        LOG_ERROR("hitboxes: AABB sampler died after %llu passes - restarting it "
                  "(restart #%ld); every box was about to disappear",
                  (unsigned long long)g_hitboxWorkerBeatPass,
                  InterlockedIncrement(&g_hitboxWorkerRestarts));
        if (InterlockedCompareExchange(&g_hitboxOwnerRefreshStarted, 1, 0) != 0)
            return;
    }
    g_hitboxWorkerBeatAt = GetTickCount64();
    g_hitboxOwnerRefreshThread = CreateThread(
        nullptr, 0, &HitboxOwnerRefreshProc, nullptr, 0, nullptr);
    if (g_hitboxOwnerRefreshThread) {
        // Keep the sampler ahead of the overlay's Present callback without
        // taking REALTIME priority or starving Bedrock's game threads.
        SetThreadPriority(g_hitboxOwnerRefreshThread, THREAD_PRIORITY_ABOVE_NORMAL);
    }
    if (!g_hitboxOwnerRefreshThread) {
        InterlockedExchange(&g_hitboxOwnerRefreshStarted, 0);
        LOG_INFO("hitboxes: owner snapshot worker unavailable");
    }
}

static void __fastcall HkHitboxLevelRender(void* level, void* screenContext,
                                           void* frameData) {
    if (level) {
        AcquireSRWLockExclusive(&g_levelRenderLock);
        g_levelRenderer = level;
        ReleaseSRWLockExclusive(&g_levelRenderLock);
    }
    // "hook active=1 matches=1" only proves the signature matched and MinHook
    // accepted it - not that the game ever calls it. Every session so far logged
    // levelRenderer=0000000000000000 in the frame-transform diagnostic, which
    // means HitboxReadLevelCameraOrigin's primary path never had a level. Three
    // lines settle whether this hook is dead (wrong signature) or firing with a
    // null level.
    static volatile LONG renderLevelSeen = 0;
    if (InterlockedIncrement(&renderLevelSeen) <= 3)
        LOG_INFO("hitboxes: renderLevel hook fired level=%p screen=%p frame=%p",
                 level, screenContext, frameData);
    const LevelRenderFn original = g_oLevelRender;
    if (original) original(level, screenContext, frameData);
    // Do not read game memory here. This only tells the background sampler
    // that the game's current render-position components are ready.
    InterlockedIncrement(&g_hitboxAabbUrgentGeneration);
}

static void TryInstallHitboxLevelRenderHook() {
    if (g_levelRenderHook || g_shuttingDown) return;
    const MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) {
        LOG_INFO("hitboxes: LevelRenderer::renderLevel MinHook init failed (%d)",
                 (int)init);
        return;
    }
    HMODULE game = GetModuleHandleW(nullptr);
    uintptr_t target = 0;
    const char* signature =
        "48 8B C4 48 89 58 ? 55 56 57 41 54 41 55 41 56 41 57 "
        "48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 0F 29 70 ? 0F 29 78 ? "
        "44 0F 29 40 ? 44 0F 29 48 ? 48 8B 05 ? ? ? ? 48 33 C4 "
        "48 89 85 ? ? ? ? 4D 8B E8 4C 8B E2 4C 8B F9";
    const int matches = ScanSigMatches(game, signature, target);
    if (matches == 1 && target) {
        MH_STATUS status = MH_CreateHook(
            reinterpret_cast<LPVOID>(target),
            reinterpret_cast<LPVOID>(&HkHitboxLevelRender),
            reinterpret_cast<LPVOID*>(&g_oLevelRender));
        if (status == MH_OK) status = MH_EnableHook(reinterpret_cast<LPVOID>(target));
        g_levelRenderHook = status == MH_OK && g_oLevelRender != nullptr;
        LOG_INFO("hitboxes: LevelRenderer::renderLevel hook active=%d matches=%d status=%d",
                 g_levelRenderHook ? 1 : 0, matches, (int)status);
        return;
    }
    LOG_INFO("hitboxes: LevelRenderer::renderLevel hook skipped matches=%d", matches);
}

static bool HitboxReadLevelCameraOrigin(float out[3], float* focalX,
                                        float* focalY) {
    if (!out) return false;
    if (focalX) *focalX = 1.428148f;
    if (focalY) *focalY = 1.428148f;

    // This is the same object path as Flarial's SetupAndRender hook:
    // ClientInstance::getLevelRender() -> LevelRender::getLevelRendererPlayer()
    // -> LevelRendererPlayer::cameraPos/FOV. Do not derive the origin from an
    // Actor and do not require a separate renderLevel callback for a valid
    // frame transform.
    void* levels[8] = {};
    int levelCount = 0;
    // Exact 1.21.111/Flarial offset; do not accept arbitrary adjacent
    // ClientInstance fields as a camera object on the target build.
    const size_t clientLevelOffsets[] = {0xE0u};
    uintptr_t rawClientLevel = 0;
    bool clientLevelRead = false;
    if (g_clientInstance) {
        const uintptr_t client = reinterpret_cast<uintptr_t>(g_clientInstance);
        for (const size_t offset : clientLevelOffsets) {
            uintptr_t level = 0;
            clientLevelRead = PotionReadBytes(
                reinterpret_cast<const void*>(client + offset), &level,
                sizeof(level));
            rawClientLevel = clientLevelRead ? level : 0;
            if (!clientLevelRead || !level ||
                !GuiPageReadable(reinterpret_cast<const void*>(level))) continue;
            bool duplicate = false;
            for (int i = 0; i < levelCount; ++i) duplicate |=
                levels[i] == reinterpret_cast<void*>(level);
            if (!duplicate && levelCount < 8)
                levels[levelCount++] = reinterpret_cast<void*>(level);
        }
    }
    AcquireSRWLockShared(&g_levelRenderLock);
    void* hookedLevel = g_levelRenderer;
    ReleaseSRWLockShared(&g_levelRenderLock);
    if (hookedLevel && GuiPageReadable(hookedLevel)) {
        bool duplicate = false;
        for (int i = 0; i < levelCount; ++i) duplicate |= levels[i] == hookedLevel;
        if (!duplicate && levelCount < 8) levels[levelCount++] = hookedLevel;
    }
    if (levelCount == 0) {
        // Rate limited, not one-shot: the three the old counter allowed were
        // consumed during the world join, so a session that spent minutes with
        // no camera never said why. rawClientLevel is the point of this line -
        // it separates "ClientInstance+0xE0 is null on this build" (offset
        // drift, needs a new offset) from "the renderLevel hook never fired"
        // (needs a new signature).
        static ULONGLONG nextNoLevelDiag = 0;
        const ULONGLONG noLevelNow = GetTickCount64();
        if (noLevelNow >= nextNoLevelDiag) {
            nextNoLevelDiag = noLevelNow + 2000u;
            LOG_INFO("hitboxes: camera origin: no level (client=%p read=%d "
                     "rawClientLevel=%p hookedLevel=%p)",
                     g_clientInstance, clientLevelRead ? 1 : 0,
                     reinterpret_cast<void*>(rawClientLevel), hookedLevel);
        }
        return false;
    }

    const size_t playerOffsets[] = {0x3E8u};
    const size_t positionOffsets[] = {0x6A0u};
    int playersSeen = 0;
    for (int levelIndex = 0; levelIndex < levelCount; ++levelIndex) {
        const uintptr_t level = reinterpret_cast<uintptr_t>(levels[levelIndex]);
        for (const size_t playerOffset : playerOffsets) {
            uintptr_t player = 0;
            if (!PotionReadBytes(reinterpret_cast<const void*>(level + playerOffset),
                                 &player, sizeof(player)) ||
                !player || !GuiPageReadable(reinterpret_cast<const void*>(player))) continue;
            ++playersSeen;
            for (const size_t positionOffset : positionOffsets) {
                float candidate[3] = {};
                if (!PotionReadBytes(reinterpret_cast<const void*>(player + positionOffset),
                                     candidate, sizeof(candidate))) continue;
                if (!std::isfinite(candidate[0]) || !std::isfinite(candidate[1]) ||
                    !std::isfinite(candidate[2]) ||
                    std::fabs(candidate[0]) > 1000000.0f ||
                    std::fabs(candidate[1]) > 1000000.0f ||
                    std::fabs(candidate[2]) > 1000000.0f) continue;
                out[0] = candidate[0]; out[1] = candidate[1]; out[2] = candidate[2];
                if (focalX || focalY) {
                    float rawX = 0.0f, rawY = 0.0f;
                    const bool fovRead =
                        PotionReadBytes(reinterpret_cast<const void*>(player + 0xF88u),
                                         &rawX, sizeof(rawX)) &&
                        PotionReadBytes(reinterpret_cast<const void*>(player + 0xF9Cu),
                                         &rawY, sizeof(rawY));
                    auto normalizeFocal = [](float raw, float fallback) {
                        if (!std::isfinite(raw) || raw <= 0.05f) return fallback;
                        // Flarial stores the projection multiplier. Accept
                        // degrees only as a guarded adjacent-build fallback.
                        if (raw > 10.0f && raw < 179.0f)
                            return 1.0f / std::tan(raw * 3.14159265358979323846f / 360.0f);
                        return raw < 10.0f ? raw : fallback;
                    };
                    if (fovRead) {
                        if (focalX) *focalX = normalizeFocal(rawX, *focalX);
                        if (focalY) *focalY = normalizeFocal(rawY, *focalY);
                    }
                }
                return true;
            }
        }
    }
    static ULONGLONG nextNoPosDiag = 0;
    const ULONGLONG noPosNow = GetTickCount64();
    if (noPosNow >= nextNoPosDiag) {
        nextNoPosDiag = noPosNow + 2000u;
        LOG_INFO("hitboxes: camera origin: no position (levels=%d players=%d)",
                 levelCount, playersSeen);
    }
    return false;
}

// Derive the camera eye from the view matrix alone.
//
// A world->view matrix maps the camera eye onto the view-space origin, so the
// correct eye is whichever point V sends to (0,0,0). That means this needs NO
// game offsets at all - only the matrix, which the caller has already proven
// readable and plausible. Both storage conventions are tried and the winner is
// chosen by the self-check (which one actually lands on the origin), so the
// convention is measured rather than guessed, and a bogus matrix is rejected
// instead of yielding a plausible-looking camera.
//
// This exists because the LevelRendererPlayer path (ClientInstance+0xE0 ->
// +0x3E8 -> +0x6A0) is a chain of unverified offsets: when any link drifts the
// eye never publishes, the worker sees cameraValid=false, and the entire AABB
// refresh stalls even though the matrix is perfectly good.
static bool HitboxEyeFromViewMatrix(const float m[16], float out[3]) {
    if (!m || !out) return false;
    bool found = false;
    float bestErr = 0.0f;
    for (int variant = 0; variant < 2; ++variant) {
        const bool rowMajor = variant == 1;
        const int tBase = rowMajor ? 3 : 12;      // m[3,7,11] vs m[12,13,14]
        const int tStride = rowMajor ? 4 : 1;
        const float t[3] = {m[tBase], m[tBase + tStride],
                            m[tBase + 2 * tStride]};
        // A world->view matrix carries t = -R*eye, and R is orthonormal, so
        // |t| == |eye|. A translation of (0,0,0) therefore means the matrix is
        // NOT a view matrix - it is a projection or an identity, where the
        // residual self-check below is satisfied trivially by eye = (0,0,0).
        // Accepting that published a degenerate camera at the world origin and
        // silently overwrote the (also failing) offset path.
        const float tMag = std::sqrt(t[0] * t[0] + t[1] * t[1] + t[2] * t[2]);
        if (!std::isfinite(tMag) || tMag < 1.0f) continue;
        auto at = [&](int r, int c) {
            return rowMajor ? m[r * 4 + c] : m[c * 4 + r];
        };
        // eye = -R^T * t, i.e. undo the rotation and the translation.
        float eye[3] = {};
        for (int c = 0; c < 3; ++c)
            eye[c] = -(at(0, c) * t[0] + at(1, c) * t[1] + at(2, c) * t[2]);
        if (!std::isfinite(eye[0]) || !std::isfinite(eye[1]) ||
            !std::isfinite(eye[2]))
            continue;
        // Self-check: applying V to the candidate eye must give the origin.
        float residual = 0.0f;
        for (int r = 0; r < 3; ++r)
            residual += std::fabs(at(r, 0) * eye[0] + at(r, 1) * eye[1] +
                                  at(r, 2) * eye[2] + t[r]);
        if (!std::isfinite(residual)) continue;
        if (!found || residual < bestErr) {
            found = true;
            bestErr = residual;
            out[0] = eye[0]; out[1] = eye[1]; out[2] = eye[2];
        }
    }
    return found && bestErr < 1.0e-2f;
}

struct HitboxStorageCacheEntry {
    void* registry = nullptr;
    uint32_t hash = 0;
    void* storage = nullptr;
    ULONGLONG retryAt = 0;
};

SRWLOCK g_hitboxStorageCacheLock = SRWLOCK_INIT;
HitboxStorageCacheEntry g_hitboxStorageCache[8] = {};
volatile LONG g_hitboxStorageProbeLogged = 0;

static bool HitboxReadRawComponent(void* enttRegistry, uint32_t entity,
                                   uint32_t hash, void* out, size_t size) {
    if (!enttRegistry || !out || !size) {
        HitboxLogComponentDiag(kHitboxDiagRawArgs, enttRegistry, entity, size);
        return false;
    }
    const ULONGLONG now = GetTickCount64();
    void* storage = nullptr;
    int cacheSlot = -1;
    bool retryBlocked = false;
    AcquireSRWLockShared(&g_hitboxStorageCacheLock);
    for (int i = 0; i < 8; ++i) {
        if (g_hitboxStorageCache[i].registry == enttRegistry &&
            g_hitboxStorageCache[i].hash == hash) {
            cacheSlot = i;
            storage = g_hitboxStorageCache[i].storage;
            retryBlocked = !storage && now < g_hitboxStorageCache[i].retryAt;
            break;
        }
    }
    ReleaseSRWLockShared(&g_hitboxStorageCacheLock);
    if (retryBlocked) {
        HitboxLogComponentDiag(kHitboxDiagRawRetry, enttRegistry, entity, size);
        return false;
    }

    if (!storage) {
        void* discovered = nullptr;
        if (!HitboxFindStorage(enttRegistry, hash, &discovered) || !discovered) {
            const LONG probe = InterlockedIncrement(&g_hitboxStorageProbeLogged);
            if (probe <= 8)
                LOG_INFO("hitboxes: component storage miss hash=%08X registry=%p",
                         hash, enttRegistry);
            // Negative-cache a missing component. Without this guard one failed
            // hash/layout probe was repeated for every actor on every frame.
            AcquireSRWLockExclusive(&g_hitboxStorageCacheLock);
            if (cacheSlot < 0) {
                for (int i = 0; i < 8; ++i) {
                    if (!g_hitboxStorageCache[i].registry) { cacheSlot = i; break; }
                }
                if (cacheSlot < 0) cacheSlot = 0;
            }
            g_hitboxStorageCache[cacheSlot].registry = enttRegistry;
            g_hitboxStorageCache[cacheSlot].hash = hash;
            g_hitboxStorageCache[cacheSlot].storage = nullptr;
            g_hitboxStorageCache[cacheSlot].retryAt = now + 1000u;
            ReleaseSRWLockExclusive(&g_hitboxStorageCacheLock);
            HitboxLogComponentDiag(kHitboxDiagRawStorage, enttRegistry, entity, size);
            return false;
        }
        AcquireSRWLockExclusive(&g_hitboxStorageCacheLock);
        if (cacheSlot < 0) {
            for (int i = 0; i < 8; ++i) {
                if (!g_hitboxStorageCache[i].registry) { cacheSlot = i; break; }
            }
            if (cacheSlot < 0) cacheSlot = 0;
        }
        g_hitboxStorageCache[cacheSlot].registry = enttRegistry;
        g_hitboxStorageCache[cacheSlot].hash = hash;
        g_hitboxStorageCache[cacheSlot].storage = discovered;
        g_hitboxStorageCache[cacheSlot].retryAt = 0;
        storage = discovered;
        ReleaseSRWLockExclusive(&g_hitboxStorageCacheLock);
        const LONG probe = InterlockedIncrement(&g_hitboxStorageProbeLogged);
        if (probe <= 8)
            LOG_INFO("hitboxes: component storage found hash=%08X registry=%p storage=%p",
                     hash, enttRegistry, storage);
    }

    if (HitboxReadStorageComponent(storage, entity, out, size)) return true;
    HitboxLogComponentDiag(kHitboxDiagRawPayload, storage, entity, size);

    // A missing component for one entity is normal (items/projectiles do not
    // all carry the same pools), so keep the shared storage pointer. It is
    // negative-cached only when the pool itself could not be discovered.
    return false;
}

// Compile-time proof that the vendored EnTT reproduces the game's pool keys.
// If a future EnTT bump, or a rename/namespace change in bedrock_entt.hpp,
// breaks the MSVC FUNCSIG hashing, the build fails here instead of silently
// rendering no hitboxes at all.
static_assert(entt::type_hash<AABBShapeComponent>::value() == 0x1B10C9F2u,
              "AABBShapeComponent pool key no longer matches Bedrock");
static_assert(entt::type_hash<StateVectorComponent>::value() == 0x0EC93C91u,
              "StateVectorComponent pool key no longer matches Bedrock");
static_assert(entt::type_hash<RenderPositionComponent>::value() == 0xD4E8F36Eu,
              "RenderPositionComponent pool key no longer matches Bedrock");

// Read-only component fetch straight out of the game's live EnTT registry.
//
// The const registry/storage overloads are used deliberately. The non-const
// storage<T>()/try_get<T>() route goes through assure<T>(), which *creates* a
// missing pool; this runs on the background sampler thread while Bedrock may be
// iterating its own pool map, so the const path - a pure lookup that returns
// nullptr - is the only safe choice. The component structs here are trivially
// copyable, so the value copy cannot touch game-owned heap memory.
//
// Note the absence of an "entity == 0" guard: EnTT's first created entity has
// index 0, so 0 is a valid identifier and only pool->contains() may reject it.
enum HitboxEnTTRead : int {
    kHitboxEnTTOk = 0,
    kHitboxEnTTBadArgs,
    kHitboxEnTTNoPool,
    kHitboxEnTTEntityAbsent,
    kHitboxEnTTFault,
    kHitboxEnTTReasonCount
};

template <typename Component>
static HitboxEnTTRead HitboxTryReadEnTTComponent(void* enttRegistry,
                                                 uint32_t entity,
                                                 Component* out) {
    if (!enttRegistry || !out) return kHitboxEnTTBadArgs;
#ifdef _MSC_VER
    __try {
        const auto* registry =
            reinterpret_cast<const entt::basic_registry<EntityId>*>(enttRegistry);
        const auto* pool = registry->storage<Component>();
        if (!pool) return kHitboxEnTTNoPool;
        const EntityId id(entity);
        if (!pool->contains(id)) return kHitboxEnTTEntityAbsent;
        *out = pool->get(id);
        return kHitboxEnTTOk;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return kHitboxEnTTFault;
    }
#else
    const auto* registry =
        reinterpret_cast<const entt::basic_registry<EntityId>*>(enttRegistry);
    const auto* pool = registry->storage<Component>();
    if (!pool) return kHitboxEnTTNoPool;
    const EntityId id(entity);
    if (!pool->contains(id)) return kHitboxEnTTEntityAbsent;
    *out = pool->get(id);
    return kHitboxEnTTOk;
#endif
}

// Expected on-disk size of each component we read. Used to reject a hash/size
// pair that cannot describe one of the structs we know, before touching the
// registry at all.
static size_t HitboxExpectedComponentSize(uint32_t hash) {
    if (hash == kHitboxAabbHash) return sizeof(AABBShapeComponent);
    if (hash == kHitboxStateHash) return sizeof(StateVectorComponent);
    if (hash == kHitboxRenderHash) return sizeof(RenderPositionComponent);
    if (hash == kHitboxRotationHash) return sizeof(ActorRotationComponent);
    return 0;
}

// Type-erased component read - the primary path.
//
// Instead of instantiating basic_storage<Component, EntityId>, this addresses
// the pool by its raw hash through the PUBLIC non-template
// basic_registry::storage(id), which is nothing more than a pools.find(hash)
// and can never create a pool. basic_sparse_set::value() then goes through the
// VIRTUAL get_at(), so the call lands in the game's own
// basic_storage<Component, EntityId>::get_at and returns the correct payload
// pointer.
//
// This removes component_traits (in_place_delete, page_size) and the
// storage_type<> specialisation from the ABI surface entirely: the only EnTT
// layout left that has to match the game is basic_sparse_set<EntityId> itself
// plus entt_traits<EntityId>.
//
// value() asserts contains(), so it is only called after contains() passed.
static HitboxEnTTRead HitboxTryReadTypeErased(void* enttRegistry, uint32_t hash,
                                              uint32_t entity, void* out,
                                              size_t size) {
    if (!enttRegistry || !out || !size) return kHitboxEnTTBadArgs;
#ifdef _MSC_VER
    __try {
#endif
        const auto* registry =
            reinterpret_cast<const entt::basic_registry<EntityId>*>(enttRegistry);
        const auto* pool = registry->storage(hash);
        if (!pool) return kHitboxEnTTNoPool;
        const EntityId id(entity);
        if (!pool->contains(id)) return kHitboxEnTTEntityAbsent;
        const void* payload = pool->value(id);
        if (!payload) return kHitboxEnTTEntityAbsent;
        std::memcpy(out, payload, size);
        return kHitboxEnTTOk;
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return kHitboxEnTTFault;
    }
#endif
}

// One-shot dump of the AABB pool exactly as the game's own registry exposes
// it. This is what finally separates the two ways the EnTT path can fail:
//   pool absent / absurd size -> my basic_registry view does not line up with
//                                the game's registry (layout or version
//                                mismatch), so EnTT has to be dropped in favour
//                                of a game-owned accessor.
//   pool sane, id absent      -> the pool is real and the lookup works; the
//                                EntityContext / entity id is simply wrong.
// It also prints the first few ids stored in the pool, which is enough to tell
// whether the ids handed to us live in the same id space as the pool.
//
// Uses the PUBLIC non-template registry.storage(id): a pure pools.find(hash)
// with no assure<>, so it can never create a pool from the worker thread.
static void HitboxDumpAabbPool(void* enttRegistry, uint32_t entity) {
    if (!enttRegistry) return;
#ifdef _MSC_VER
    __try {
#endif
        const auto* registry =
            reinterpret_cast<const entt::basic_registry<EntityId>*>(enttRegistry);
        const auto* pool = registry->storage(kHitboxAabbHash);
        if (!pool) {
            LOG_INFO("hitboxes: pool dump hash=%08X registry=%p absent",
                     kHitboxAabbHash, enttRegistry);
            return;
        }
        const size_t total = static_cast<size_t>(pool->size());
        const unsigned count = static_cast<unsigned>(total);
        const EntityId id(entity);
        LOG_INFO("hitboxes: pool dump hash=%08X registry=%p pool=%p size=%u "
                 "entity=%08X contains=%d",
                 kHitboxAabbHash, enttRegistry,
                 static_cast<const void*>(pool), count, entity,
                 pool->contains(id) ? 1 : 0);

        // Walk the WHOLE packed array. Two things fall out of this:
        //  - the complete set of ids the game really stores, so the ids handed
        //    to us can be compared against reality rather than guessed at;
        //  - an index-match probe. EnTT's contains() requires the *version*
        //    bits to agree ((mask & query) ^ stored) < entity_mask, so a
        //    same-index/different-version entry means the EntityContext is
        //    stale rather than the entity being absent.
        const size_t dumpLimit = total < 64 ? total : 64;
        char ids[64 * 10 + 1] = {};
        const uint32_t queryIndex = entity & kHitboxEntityMask;
        uint32_t indexMatch = 0;
        int indexMatchCount = 0;
        for (size_t i = 0; i < total; ++i) {
            const uint32_t raw = static_cast<uint32_t>((*pool)[i]);
            if ((raw & kHitboxEntityMask) == queryIndex) {
                if (indexMatchCount == 0) indexMatch = raw;
                ++indexMatchCount;
            }
            if (i < dumpLimit) {
                char one[16];
                _snprintf_s(one, sizeof(one), _TRUNCATE, "%s%08X", i ? "," : "",
                            raw);
                strcat_s(ids, sizeof(ids), one);
            }
        }
        LOG_INFO("hitboxes: pool dump all%u/%u ids=%s", (unsigned)dumpLimit,
                 count, ids);
        LOG_INFO("hitboxes: pool dump index-match query=%08X index=%08X found=%d "
                 "count=%d stored=%08X",
                 entity, queryIndex, indexMatchCount > 0 ? 1 : 0,
                 indexMatchCount, indexMatch);
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        LOG_INFO("hitboxes: pool dump fault registry=%p", enttRegistry);
    }
#endif
}

// Enumerate EVERY pool in the game's registry through EnTT's public
// basic_registry::storage() range, and for the query entity report both the
// pools that contain it and the first floats of their payloads.
//
// This exists because two very different faults produce the same "entity
// absent" symptom:
//   - the entity id handed to us is stale, so no pool holds it; or
//   - kHitboxAabbHash is not this build's AABBShapeComponent key, so
//     registry.storage(hash) returns a real, readable *different* pool whose
//     entity set simply does not include the mobs.
// The second case is invisible in every other diagnostic: the pool exists, its
// size looks sane, and the local player happens to sit in it (every actor has
// every pool), so the read "succeeds" and only the mobs go missing. Printing
// the whole pool table - and the payload of each pool that does hold the
// entity - is the only way to tell them apart.
static void HitboxDumpAllPools(void* enttRegistry, uint32_t entity) {
    if (!enttRegistry) return;
#ifdef _MSC_VER
    __try {
#endif
        const auto* registry =
            reinterpret_cast<const entt::basic_registry<EntityId>*>(enttRegistry);
        const EntityId id(entity);
        unsigned total = 0;
        unsigned hits = 0;
        char sizes[1400] = {};
        char hitList[400] = {};
        for (const auto& entry : registry->storage()) {
            const uint32_t key = static_cast<uint32_t>(entry.first);
            const auto* pool = &entry.second;
            if (!pool) continue;
            ++total;
            const unsigned count = static_cast<unsigned>(pool->size());
            if (total <= 40) {
                char one[32];
                _snprintf_s(one, sizeof(one), _TRUNCATE, "%s%08X:%u",
                            total > 1 ? "," : "", key, count);
                strcat_s(sizes, sizeof(sizes), one);
            }
            if (pool->contains(id) && hits < 14) {
                char one[32];
                _snprintf_s(one, sizeof(one), _TRUNCATE, "%s%08X:%u",
                            hits ? "," : "", key, count);
                strcat_s(hitList, sizeof(hitList), one);
                float payload[8] = {};
                const void* raw = pool->value(id);
                if (raw && PotionReadBytes(raw, payload, sizeof(payload))) {
                    LOG_INFO("hitboxes: pools hit %08X size=%u raw=(%.3f,%.3f,"
                             "%.3f,%.3f,%.3f,%.3f,%.3f,%.3f)",
                             key, count, payload[0], payload[1], payload[2],
                             payload[3], payload[4], payload[5], payload[6],
                             payload[7]);
                }
                ++hits;
            }
        }
        LOG_INFO("hitboxes: pools total=%u entity=%08X hits=%u [%s]",
                 total, entity, hits, hitList);
        LOG_INFO("hitboxes: pools sizes %s", sizes);
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        LOG_INFO("hitboxes: pools dump fault registry=%p", enttRegistry);
    }
#endif
}

// Maps the runtime component hash onto the matching compile-time pool.
static bool HitboxReadActorComponentEnTT(void* enttRegistry, uint32_t entity,
                                         uint32_t hash, void* out, size_t size) {
    if (!enttRegistry || !out) return false;

    const size_t expected = HitboxExpectedComponentSize(hash);
    if (expected == 0 || expected != size) return false;

    // Primary: type-erased pool access. Strictly less EnTT layout to get right
    // than the typed route below, so it is tried first.
    HitboxEnTTRead result =
        HitboxTryReadTypeErased(enttRegistry, hash, entity, out, size);
    if (result == kHitboxEnTTOk) {
        static volatile LONG erasedOkLogged = 0;
        if (InterlockedIncrement(&erasedOkLogged) <= 4)
            LOG_INFO("hitboxes: entt read ok (erased) hash=%08X entity=%08X",
                     hash, entity);
        return true;
    }
    const HitboxEnTTRead erasedResult = result;

    // Secondary: typed registry.storage<Component>(). Kept so that a hash or
    // layout problem confined to the type-erased route cannot regress a read
    // that the typed route already handles.
    if (hash == kHitboxAabbHash) {
        AABBShapeComponent component{};
        result = HitboxTryReadEnTTComponent(enttRegistry, entity, &component);
        if (result == kHitboxEnTTOk) std::memcpy(out, &component, sizeof(component));
    } else if (hash == kHitboxRenderHash) {
        RenderPositionComponent component{};
        result = HitboxTryReadEnTTComponent(enttRegistry, entity, &component);
        if (result == kHitboxEnTTOk) std::memcpy(out, &component, sizeof(component));
    } else if (hash == kHitboxStateHash) {
        StateVectorComponent component{};
        result = HitboxTryReadEnTTComponent(enttRegistry, entity, &component);
        if (result == kHitboxEnTTOk) std::memcpy(out, &component, sizeof(component));
    } else {
        return false;
    }

    if (result != kHitboxEnTTOk) {
        // Report both routes so one log line says exactly where each stops.
        // Rate-limited: a dead entity is re-probed by the worker sampler, and
        // an ungated line here spams every pass (~60 lines/sec for one corpse).
        static volatile LONG failLogged = 0;
        static ULONGLONG nextFailLog = 0;
        const ULONGLONG failNow = GetTickCount64();
        if (InterlockedIncrement(&failLogged) <= 8 || failNow >= nextFailLog) {
            nextFailLog = failNow + 5000u;
            LOG_INFO("hitboxes: entt read failed erased=%d typed=%d hash=%08X entity=%08X",
                     (int)erasedResult, (int)result, hash, entity);
        }
        return false;
    }

    static volatile LONG enttOkLogged = 0;
    if (InterlockedIncrement(&enttOkLogged) <= 4)
        LOG_INFO("hitboxes: entt read ok (typed) hash=%08X entity=%08X", hash, entity);
    return true;
}

static bool HitboxReadActorComponent(void* actorRegistry, uint32_t entity,
                                     uint32_t hash, void* out, size_t size) {
    // Primary path: let EnTT itself resolve the pool on the game's live
    // registry. This is Flarial's 1.21+ behaviour and needs no knowledge of
    // basic_storage's private layout.
    if (actorRegistry &&
        HitboxReadActorComponentEnTT(actorRegistry, entity, hash, out, size))
        return true;

    // The EnTT path failed. For the AABB hash - the one read every actor needs
    // - dump the game's own view of that pool, and the whole pool table, so the
    // next log says whether the registry layout, the pool key or the entity id
    // is at fault.
    if (hash == kHitboxAabbHash) {
        static volatile LONG dumped = 0;
        if (InterlockedIncrement(&dumped) <= 6) {
            HitboxDumpAabbPool(actorRegistry, entity);
            HitboxDumpAllPools(actorRegistry, entity);
        }
    }

    // Fallback: the previous byte-offset walk. Kept only for a registry whose
    // EnTT build the vendored header cannot address; it is expected to miss on
    // 1.21.111, which is why the EnTT path above exists.
    if (actorRegistry &&
        HitboxReadRawComponent(actorRegistry, entity, hash, out, size))
        return true;

    void* worldRegistry = HitboxGetWorldRegistry();
    if (worldRegistry && worldRegistry != actorRegistry) {
        if (HitboxReadActorComponentEnTT(worldRegistry, entity, hash, out, size))
            return true;
        if (HitboxReadRawComponent(worldRegistry, entity, hash, out, size)) {
            static volatile LONG fallbackLogged = 0;
            if (InterlockedIncrement(&fallbackLogged) <= 4)
                LOG_INFO("hitboxes: actor component raw fallback registry=%p actorRegistry=%p hash=%08X",
                         worldRegistry, actorRegistry, hash);
            return true;
        }
    }
    return false;
}

// ---------------------------------------------------------------------------
// Actor categories
//
// ActorCategory is a bit set that only uses bits 0..19 (Flarial's enum runs
// Player..Predictable). A zero word, or a word with any bit above 19 set, is
// therefore not a real category mask.
//
// IMPORTANT: Flarial's offset tables register "Actor::categories" = 0x210 only
// up to 1.21.50; 1.21.10x-1.21.13x have no entry at all, so the 1.21.11x value
// is unverified. A wrong offset does not fail the read - it returns whatever
// word sits there - so every consumer below must treat an implausible value as
// "unknown" instead of as a negative answer. Gating on it blindly is what makes
// an entity filter silently reject the entire world.
constexpr uint32_t kHitboxKnownCategoryBits = 0x000FFFFFu;
constexpr uint32_t kHitboxPlayerCategory = 1u << 0;
constexpr uint32_t kHitboxMobCategory = 1u << 1;

static bool HitboxCategoriesPlausible(uint32_t categories) {
    return categories != 0 && (categories & ~kHitboxKnownCategoryBits) == 0;
}

// Camera origin fallback that needs no unverified offsets at all.
//
// Flarial never resolves a camera chain for the box: it measures distance from
// the local player's own position and scales the outline by
// player->getRenderPositionComponent()->renderPos.dist(aabb.lower). The local
// player is the one actor whose EnTT reads are proven to work on every build -
// it is the only entity present in every pool, and its own EntityContext always
// agrees with the owner walk - so its RenderPositionComponent is a strictly
// better camera source than ClientInstance+0xE0 -> +0x3E8 -> +0x6A0, which is
// three unverified offsets deep and was already reporting "no level".
//
// The eye sits above the render position by the player's eye height. That value
// only shifts the cull radius and the distance-scaled line width, so a standard
// 1.62 is more than accurate enough.
static bool HitboxEyeFromLocalPlayer(float out[3]) {
    if (!out) return false;
    void* local = HitboxLocalPlayer();
    if (!local) return false;
    void* registryObject = nullptr;
    void* enttRegistry = nullptr;
    uint32_t entity = 0;
    if (!HitboxReadActorContextDirect(local, &registryObject, &enttRegistry,
                                      &entity) ||
        !enttRegistry || !entity)
        return false;
    float render[3] = {};
    if (!HitboxReadActorComponent(enttRegistry, entity, kHitboxRenderHash,
                                  render, sizeof(render)))
        return false;
    if (!std::isfinite(render[0]) || !std::isfinite(render[1]) ||
        !std::isfinite(render[2]))
        return false;
    // A world coordinate is bounded by the 30M build limit and a sane Y range.
    // Anything outside that is an uninitialised component or a mis-keyed pool,
    // not a camera. This is the gate that keeps a wrong hash from publishing a
    // plausible-looking camera the way the matrix path did.
    if (std::fabs(render[0]) > 3.0e7f || std::fabs(render[2]) > 3.0e7f ||
        std::fabs(render[1]) > 1.0e4f)
        return false;
    if (std::fabs(render[0]) < 0.01f && std::fabs(render[1]) < 0.01f &&
        std::fabs(render[2]) < 0.01f)
        return false;
    out[0] = render[0];
    out[1] = render[1] + 1.62f;
    out[2] = render[2];
    return true;
}

static bool HitboxReadAabbForContext(void* actor, void* enttRegistry,
                                      uint32_t entity, float mins[3],
                                      float maxs[3]) {
    if (!actor || !enttRegistry || !entity || !mins || !maxs) return false;

    float shape[8] = {};
    if (!HitboxReadActorComponent(enttRegistry, entity, kHitboxAabbHash,
                                  shape, sizeof(shape))) {
        HitboxAabbDiag(kAabbStageShapeMiss, actor, enttRegistry, entity, 0.0f, 0.0f);
        return false;
    }

    const float width = shape[6];
    const float height = shape[7];
    if (!(width >= 0.1f && width <= 8.0f && height >= 0.1f && height <= 8.0f) ||
        !std::isfinite(width) || !std::isfinite(height)) {
        HitboxAabbDiag(kAabbStageShapeInvalid, actor, enttRegistry, entity,
                       width, height);
        return false;
    }
    HitboxAabbDiag(kAabbStageShapeOk, actor, enttRegistry, entity, width, height);

    // Flarial lowers a Player's box by 1.6 because RenderPositionComponent
    // reports eye height for players. The local player is known exactly, so use
    // that as a definitive answer and require a plausible category word for
    // everyone else - a stale Actor::categories offset must not shift every mob
    // box 1.6 blocks upward.
    uint32_t categories = 0;
    const bool categoryKnown = HitboxReadActorCategories(actor, &categories);
    const bool isPlayer =
        actor == g_hitboxWorldLocal ||
        (categoryKnown && HitboxCategoriesPlausible(categories) &&
         (categories & kHitboxPlayerCategory) != 0);
    const float playerOffset = isPlayer ? 1.6f : 0.0f;

    // This is Flarial's getLerpedAABB path: RenderPositionComponent::renderPos
    // plus AABBShapeComponent::size. It is always preferred when the render
    // component is available.
    float render[3] = {};
    const bool renderRead =
        HitboxReadActorComponent(enttRegistry, entity, kHitboxRenderHash,
                                 render, sizeof(render));
    if (renderRead && std::isfinite(render[0]) &&
        std::isfinite(render[1]) && std::isfinite(render[2])) {
        const float baseY = render[1] - playerOffset;
        mins[0] = render[0] - width * 0.5f;
        mins[1] = baseY;
        mins[2] = render[2] - width * 0.5f;
        maxs[0] = render[0] + width * 0.5f;
        maxs[1] = baseY + height;
        maxs[2] = render[2] + width * 0.5f;
        HitboxAabbDiag(kAabbStageOk, actor, enttRegistry, entity, width, height);
        return true;
    }

    // RenderPositionComponent can be absent during a short component swap.
    // StateVector is only a worker-side fallback and uses the same Player
    // correction as Flarial's lerped box.
    float state[9] = {};
    const bool stateRead =
        HitboxReadActorComponent(enttRegistry, entity, kHitboxStateHash,
                                 state, sizeof(state));
    if (stateRead && std::isfinite(state[0]) &&
        std::isfinite(state[1]) && std::isfinite(state[2])) {
        const float baseY = state[1] - playerOffset;
        mins[0] = state[0] - width * 0.5f;
        mins[1] = baseY;
        mins[2] = state[2] - width * 0.5f;
        maxs[0] = state[0] + width * 0.5f;
        maxs[1] = baseY + height;
        maxs[2] = state[2] + width * 0.5f;
        HitboxAabbDiag(kAabbStageOk, actor, enttRegistry, entity, width, height);
        return true;
    }

    if (!renderRead || !std::isfinite(render[0]) || !std::isfinite(render[1]) ||
        !std::isfinite(render[2]))
        HitboxLogComponentDiag(kHitboxDiagRender, enttRegistry, entity, sizeof(render));
    if (!stateRead || !std::isfinite(state[0]) || !std::isfinite(state[1]) ||
        !std::isfinite(state[2]))
        HitboxLogComponentDiag(kHitboxDiagState, enttRegistry, entity, sizeof(state));

    // Last-resort physical AABB fallback, accepted only for a sane world box.
    const float boxWidth = shape[3] - shape[0];
    const float boxHeight = shape[4] - shape[1];
    const float boxDepth = shape[5] - shape[2];
    if (std::isfinite(boxWidth) && std::isfinite(boxHeight) &&
        std::isfinite(boxDepth) && boxWidth >= 0.1f && boxWidth <= 8.0f &&
        boxHeight >= 0.1f && boxHeight <= 8.0f && boxDepth >= 0.1f &&
        boxDepth <= 8.0f && std::isfinite(shape[0]) && std::isfinite(shape[1]) &&
        std::isfinite(shape[2]) && std::isfinite(shape[3]) &&
        std::isfinite(shape[4]) && std::isfinite(shape[5])) {
        std::memcpy(mins, shape, sizeof(float) * 3);
        std::memcpy(maxs, shape + 3, sizeof(float) * 3);
        HitboxAabbDiag(kAabbStageOk, actor, enttRegistry, entity, boxWidth,
                       boxHeight);
        return true;
    }
    // The shape read worked and the shape was plausible, but neither the render
    // position nor the state vector resolved - the entity is in the pool and
    // gone from the components.
    HitboxAabbDiag(kAabbStageNoPosition, actor, enttRegistry, entity, width,
                   height);
    return false;
}

static bool HitboxReadAabbUnsafe(void* actor, float mins[3], float maxs[3]) {
    if (!actor || !mins || !maxs) return false;

    // A live Actor context is preferred, but a valid owner-walk context can be
    // different for one render while Bedrock swaps an actor's registry. Try
    // both context/entity pairs before declaring the AABB read failed. The old
    // direct-only path discarded a valid owner entity and left six boxes stale.
    void* directRegistryObject = nullptr;
    void* directEnttRegistry = nullptr;
    uint32_t directEntity = 0;
    const bool directOk = HitboxReadActorContextDirect(
        actor, &directRegistryObject, &directEnttRegistry, &directEntity);
    if (directOk && HitboxReadAabbForContext(actor, directEnttRegistry,
                                             directEntity, mins, maxs))
        return true;

    void* hintedRegistry = nullptr;
    uint32_t hintedEntity = 0;
    const void* currentWorld = HitboxGetWorldRegistry();
    const bool hintOk = HitboxReadEntityHint(actor, &hintedRegistry, &hintedEntity);
    // The owner walk is the authoritative worker-side actor/entity pairing.
    // Do not reject its hint merely because the live Actor context is in the
    // middle of a registry swap or exposes a different generation; those are
    // exactly the transient states in which the direct context misses.
    if (hintOk && (!directOk || hintedRegistry != directEnttRegistry ||
                   hintedEntity != directEntity) &&
        HitboxReadAabbForContext(actor, hintedRegistry, hintedEntity,
                                 mins, maxs))
        return true;

    // Neither context produced a box. Rate limited to one line per second, not
    // one-shot: the old <= 16 counter was exhausted inside 6 ms during the
    // world join (0.7 s *before* the first successful owner walk), so a session
    // that later lost every box had no evidence left anywhere.
    static ULONGLONG nextFailDiag = 0;
    const ULONGLONG failNow = GetTickCount64();
    if (failNow >= nextFailDiag) {
        nextFailDiag = failNow + 1000u;
        InterlockedIncrement(&g_hitboxAabbStageCount[kAabbStageCtxFail]);
        LOG_INFO("hitboxes: aabb ctx-fail actor=%p direct=%d directEntt=%p "
                 "directEntity=%08X hint=%d hintReg=%p hintEntity=%08X world=%p",
                 actor, directOk ? 1 : 0, directEnttRegistry, directEntity,
                 hintOk ? 1 : 0, hintedRegistry, hintedEntity, currentWorld);
    }

    // The actor's own EntityContext window, on its own 2 s cadence so the two
    // lines can be correlated. If the "entity" we extract is really a pointer
    // fragment (values like 8DDA3E60 look like the low half of a
    // 0x224xxxxxxxx heap pointer), or if the context sits at a different
    // offset on this build, it shows up here as a plain hex run:
    //   +00 vtable  +08 registry&  +10 enttRegistry&  +18 entity
    static ULONGLONG nextWindowDiag = 0;
    if (failNow >= nextWindowDiag) {
        nextWindowDiag = failNow + 2000u;
        unsigned char raw[40] = {};
        if (PotionReadBytes(reinterpret_cast<const void*>(actor), raw,
                            sizeof(raw))) {
            char hex[3 * 40 + 1] = {};
            for (int i = 0; i < 40; ++i) {
                char one[4];
                _snprintf_s(one, sizeof(one), _TRUNCATE, "%02X", raw[i]);
                strcat_s(hex, sizeof(hex), one);
            }
            LOG_INFO("hitboxes: aabb ctx-fail bytes actor=%p +00=%s", actor, hex);
        }
    }
    return false;
}

// Worker-thread look direction fetch (Flarial's ActorRotationComponent path).
// Same dual-context attempt as the AABB reader above; never called from the
// render callback. Fails closed: unknown pool key, missing component for this
// entity, or implausible angles all return false and the look line is hidden.
static bool HitboxReadRotationUnsafe(void* actor, float* pitchDeg, float* yawDeg) {
    if (!actor || !pitchDeg || !yawDeg) return false;
    float rot[4] = {};
    auto tryContext = [&](void* enttRegistry, uint32_t entity) {
        if (!enttRegistry || !entity) return false;
        if (!HitboxReadActorComponent(enttRegistry, entity, kHitboxRotationHash,
                                      rot, sizeof(rot)))
            return false;
        if (!std::isfinite(rot[0]) || !std::isfinite(rot[1])) return false;
        // Degrees, Flarial convention: x = pitch, y = yaw. Reject garbage
        // without rejecting legitimate full turns on yaw.
        if (std::fabs(rot[0]) > 90.0f || std::fabs(rot[1]) > 1080.0f) return false;
        *pitchDeg = rot[0];
        *yawDeg = rot[1];
        return true;
    };

    void* directRegistryObject = nullptr;
    void* directEnttRegistry = nullptr;
    uint32_t directEntity = 0;
    const bool directOk = HitboxReadActorContextDirect(
        actor, &directRegistryObject, &directEnttRegistry, &directEntity);
    if (directOk && tryContext(directEnttRegistry, directEntity)) return true;

    void* hintedRegistry = nullptr;
    uint32_t hintedEntity = 0;
    const bool hintOk = HitboxReadEntityHint(actor, &hintedRegistry, &hintedEntity);
    if (hintOk && (!directOk || hintedRegistry != directEnttRegistry ||
                   hintedEntity != directEntity) &&
        tryContext(hintedRegistry, hintedEntity))
        return true;

    static volatile LONG rotationMissLogged = 0;
    if (InterlockedIncrement(&rotationMissLogged) <= 4)
        LOG_INFO("hitboxes: rotation sample failed actor=%p direct=%d hint=%d (look line hidden)",
                 actor, directOk ? 1 : 0, hintOk ? 1 : 0);
    return false;
}
struct HitboxViewState {
    float eye[3] = {};
    float matrix[16] = {};
    float fov = 70.0f;
    float focalX = 1.428148f;
    float focalY = 1.428148f;
    int mode = 0; // bit 0: consecutive/transpose storage, bit 1: +Z forward
    bool usesOrigin = false; // GLMatrix may store rotation without translation
    bool eyeValid = false;
    bool matrixValid = false;
    bool frameSourced = false;
    // When the camera was last proven. GetCameraWorldPosition /
    // GetHitboxMatrixMode serve a stale eye/matrix indefinitely otherwise, and
    // the module bails out at its very first gate when the camera is absent.
    ULONGLONG publishedAt = 0;
    ULONGLONG lastMatrixTry = 0;
};

HitboxViewState g_hitboxView{};
SRWLOCK g_hitboxViewLock = SRWLOCK_INIT;

struct HitboxViewWriteGuard {
    HitboxViewWriteGuard() { AcquireSRWLockExclusive(&g_hitboxViewLock); }
    ~HitboxViewWriteGuard() { ReleaseSRWLockExclusive(&g_hitboxViewLock); }
};

struct HitboxViewReadGuard {
    HitboxViewReadGuard() { AcquireSRWLockShared(&g_hitboxViewLock); }
    ~HitboxViewReadGuard() { ReleaseSRWLockShared(&g_hitboxViewLock); }
};

// See the forward declaration. The eye is only used for distance culling and
// the distance-scaled line width, so a recent-but-not-fresh eye is strictly
// better than none: refusing to publish the packet is what froze it, and a
// frozen empty packet is what the module saw as "no hitboxes at all".
static bool HitboxReadRetainedEye(float out[3], float* focalX, float* focalY) {
    if (!out) return false;
    HitboxViewReadGuard viewGuard;
    if (!g_hitboxView.eyeValid || g_hitboxView.publishedAt == 0) return false;
    if (GetTickCount64() - g_hitboxView.publishedAt >= kHitboxPacketKeepAliveMs)
        return false;
    out[0] = g_hitboxView.eye[0];
    out[1] = g_hitboxView.eye[1];
    out[2] = g_hitboxView.eye[2];
    if (focalX && g_hitboxView.focalX > 0.05f) *focalX = g_hitboxView.focalX;
    if (focalY && g_hitboxView.focalY > 0.05f) *focalY = g_hitboxView.focalY;
    return true;
}

static void HitboxPublishLegacyView(const HitboxFrameTransformSnapshot& frame) {
    HitboxViewWriteGuard viewGuard;
    std::memcpy(g_hitboxView.matrix, frame.matrix, sizeof(frame.matrix));
    std::memcpy(g_hitboxView.eye, frame.origin, sizeof(frame.origin));
    g_hitboxView.mode = 1;
    g_hitboxView.usesOrigin = true;
    g_hitboxView.eyeValid = true;
    g_hitboxView.matrixValid = true;
    g_hitboxView.frameSourced = true;
    g_hitboxView.publishedAt = GetTickCount64();
    g_hitboxView.focalX = frame.focalX;
    g_hitboxView.focalY = frame.focalY;
    static volatile LONG legacyViewLogged = 0;
    if (InterlockedIncrement(&legacyViewLogged) <= 2)
        LOG_INFO("hitboxes: legacy camera snapshot published origin=(%.2f,%.2f,%.2f) focal=(%.3f,%.3f)",
                 frame.origin[0], frame.origin[1], frame.origin[2],
                 frame.focalX, frame.focalY);
}

static bool HitboxConsumeFrameTransform() {
    HitboxFrameTransformSnapshot frame{};
    bool consumed = false;
    AcquireSRWLockExclusive(&g_hitboxFrameTransformLock);
    // Same semantics as Flarial's while (queue.size() > transformDelay):
    // consume the newest setup frame immediately so movement does not
    // trail the current entity transform in the overlay Present.
    while (g_hitboxFrameTransformCount > kHitboxTransformDelay) {
        frame = g_hitboxFrameTransforms[g_hitboxFrameTransformHead];
        g_hitboxFrameTransformHead = (g_hitboxFrameTransformHead + 1) % 8;
        --g_hitboxFrameTransformCount;
        consumed = true;
    }
    ReleaseSRWLockExclusive(&g_hitboxFrameTransformLock);
    if (!consumed) return false;

    AcquireSRWLockExclusive(&g_hitboxActiveFrameLock);
    g_hitboxActiveFrame = frame;
    g_hitboxActiveFrameValid = true;
    g_hitboxActiveFrameAt = GetTickCount64();
    ReleaseSRWLockExclusive(&g_hitboxActiveFrameLock);

    HitboxViewWriteGuard viewGuard;
    std::memcpy(g_hitboxView.matrix, frame.matrix, sizeof(frame.matrix));
    std::memcpy(g_hitboxView.eye, frame.origin, sizeof(frame.origin));
    g_hitboxView.mode = 1;
    g_hitboxView.usesOrigin = true;
    g_hitboxView.eyeValid = true;
    g_hitboxView.matrixValid = true;
    g_hitboxView.frameSourced = true;
    g_hitboxView.publishedAt = GetTickCount64();
    g_hitboxView.focalX = frame.focalX;
    g_hitboxView.focalY = frame.focalY;
    static volatile LONG frameTransformConsumedLogged = 0;
    if (InterlockedIncrement(&frameTransformConsumedLogged) <= 2)
        LOG_INFO("hitboxes: Flarial frame transform consumed delayed=%d origin=(%.2f,%.2f,%.2f) actors=%d eligible=%d stale=%d complete=%d",
                 kHitboxTransformDelay, frame.origin[0], frame.origin[1],
                 frame.origin[2], frame.actorCount, frame.eligibleCount,
                 frame.staleCount, frame.aabbComplete ? 1 : 0);
    return true;
}

static bool HitboxMatOrthonormal(const float m[16], bool consecutive) {
    float r[3][3] = {};
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            r[i][j] = consecutive ? m[i * 4 + j] : m[j * 4 + i];
    for (int i = 0; i < 3; ++i) {
        const float n = std::sqrt(r[i][0] * r[i][0] + r[i][1] * r[i][1] + r[i][2] * r[i][2]);
        if (!std::isfinite(n) || std::fabs(n - 1.0f) > 0.035f) return false;
    }
    for (int i = 0; i < 3; ++i)
        for (int j = i + 1; j < 3; ++j) {
            const float d = r[i][0] * r[j][0] + r[i][1] * r[j][1] + r[i][2] * r[j][2];
            if (!std::isfinite(d) || std::fabs(d) > 0.035f) return false;
        }
    const float det =
        r[0][0] * (r[1][1] * r[2][2] - r[1][2] * r[2][1]) -
        r[0][1] * (r[1][0] * r[2][2] - r[1][2] * r[2][0]) +
        r[0][2] * (r[1][0] * r[2][1] - r[1][1] * r[2][0]);
    // Bedrock's view basis can be left-handed depending on the active camera
    // convention. Both determinant signs are valid; rejecting -1 made the
    // otherwise correct +0x348 matrix disappear completely.
    return std::isfinite(det) && std::fabs(std::fabs(det) - 1.0f) <= 0.15f;
}

static bool HitboxMatPlausible(const float m[16]) {
    if (!m) return false;
    float maxAbs = 0.0f;
    float energy = 0.0f;
    for (int i = 0; i < 16; ++i) {
        if (!std::isfinite(m[i])) return false;
        maxAbs = std::max(maxAbs, std::fabs(m[i]));
        energy += std::fabs(m[i]);
    }
    // The target stores a finite GLMatrix at +0x348. A projection/model-view
    // matrix is not required to pass the strict orthonormal test, but it must
    // not look like an empty or obviously non-matrix page.
    return energy > 0.01f && maxAbs < 10000.0f;
}

static void HitboxViewTransform(const float pos[3], float* x, float* y, float* z) {
    const float* m = g_hitboxView.matrix;
    float p[3] = {pos[0], pos[1], pos[2]};
    if (g_hitboxView.usesOrigin && g_hitboxView.eyeValid) {
        p[0] -= g_hitboxView.eye[0];
        p[1] -= g_hitboxView.eye[1];
        p[2] -= g_hitboxView.eye[2];
    }
    if (g_hitboxView.mode & 1) {
        *x = p[0] * m[0] + p[1] * m[1] + p[2] * m[2] + m[3];
        *y = p[0] * m[4] + p[1] * m[5] + p[2] * m[6] + m[7];
        *z = p[0] * m[8] + p[1] * m[9] + p[2] * m[10] + m[11];
    } else {
        *x = p[0] * m[0] + p[1] * m[4] + p[2] * m[8] + m[12];
        *y = p[0] * m[1] + p[1] * m[5] + p[2] * m[9] + m[13];
        *z = p[0] * m[2] + p[1] * m[6] + p[2] * m[10] + m[14];
    }
    if (g_hitboxView.mode & 2) *z = -*z;
}

static bool HitboxEvaluateMatrix(const float matrix[16], const float eye[3],
                                 int* bestMode, float* bestError) {
    if (!matrix || !eye || !bestMode || !bestError) return false;
    float best = 1.0e9f;
    int selected = 0;
    const float* savedMatrix = g_hitboxView.matrix;
    const int savedMode = g_hitboxView.mode;
    (void)savedMatrix;
    const int modes[] = {1, 3, 0, 2};
    for (const int mode : modes) {
        if (!HitboxMatOrthonormal(matrix, (mode & 1) != 0)) continue;
        g_hitboxView.mode = mode;
        std::memcpy(g_hitboxView.matrix, matrix, sizeof(float) * 16);
        float x = 0.0f, y = 0.0f, z = 0.0f;
        HitboxViewTransform(eye, &x, &y, &z);
        const bool inFront = (mode & 2) ? (z > 0.05f) : (z < -0.05f);
        if (inFront) {
            const float error = std::sqrt(x * x + y * y);
            if (error < best) {
                best = error;
                selected = mode;
            }
        }
    }
    g_hitboxView.mode = savedMode;
    *bestMode = selected;
    *bestError = best;
    return best < 1.0e9f;
}

static bool HitboxTryFindViewMatrix() {
    if (!g_clientInstance || !g_hitboxView.eyeValid) {
        static ULONGLONG nextLog = 0;
        const ULONGLONG now = GetTickCount64();
        if (now >= nextLog) {
            nextLog = now + 2000u;
            LOG_INFO("hitboxes: view matrix skipped client=%p eyeValid=%d",
                     g_clientInstance, g_hitboxView.eyeValid ? 1 : 0);
        }
        return false;
    }
    const uintptr_t client = reinterpret_cast<uintptr_t>(g_clientInstance);
    float best[16] = {};
    int bestMode = 0;
    float bestError = 1.0e9f;

    // Flarial's 1.21.11x offset table places ClientInstance::viewMatrix at
    // +0x348. Its GLMatrix commonly stores orientation separately from the
    // render origin. Prefer that exact field and use the eye as the origin;
    // the raw-eye proof below also accepts a matrix that already contains
    // camera translation.
    float direct[16] = {};
    const bool directRead = PotionReadBytes(reinterpret_cast<const void*>(client + 0x348u),
                                            direct, sizeof(direct));
    if (directRead && HitboxMatOrthonormal(direct, false)) {
        int directMode = 0;
        bool directTranslated = false;
        float directError = 1.0e9f;
        // Flarial's GLMatrix correction treats the raw 16-float field as
        // row-major for the vector multiply: x uses m[0..2] + m[3], y uses
        // m[4..6] + m[7], z uses m[8..10] + m[11].
        const int modes[] = {1, 3, 0, 2};
        for (const int mode : modes) {
            if (!HitboxMatOrthonormal(direct, (mode & 1) != 0)) continue;
            g_hitboxView.mode = mode;
            g_hitboxView.usesOrigin = false;
            std::memcpy(g_hitboxView.matrix, direct, sizeof(direct));
            float x = 0.0f, y = 0.0f, z = 0.0f;
            HitboxViewTransform(g_hitboxView.eye, &x, &y, &z);
            const bool inFront = (mode & 2) ? z > 0.05f : z < -0.05f;
            const float error = std::sqrt(x * x + y * y);
            if (inFront && error < directError) {
                directError = error;
                directMode = mode;
                directTranslated = true;
            }
        }
        if (directTranslated && directError < 0.65f) {
            std::memcpy(g_hitboxView.matrix, direct, sizeof(direct));
            g_hitboxView.mode = directMode;
            g_hitboxView.usesOrigin = false;
            g_hitboxView.matrixValid = true;
            LOG_INFO("hitboxes: view matrix captured at ClientInstance+0x348 mode=%d translated error=%.3f",
                     directMode, directError);
            return true;
        }
        // A pure model-view rotation is the normal GLMatrix path. The eye is
        // then the render origin and the matrix's negative Z is forward.
        std::memcpy(g_hitboxView.matrix, direct, sizeof(direct));
        // Match Flarial's Matrix::getMatrixCorrection/WorldToScreen path.
        // Mode 0 reads translation from m[12..14], which is the wrong layout
        // for Bedrock's GLMatrix and was the source of intermittent projection.
        g_hitboxView.mode = 1;
        g_hitboxView.usesOrigin = true;
        g_hitboxView.matrixValid = true;
        static ULONGLONG nextRotationLog = 0;
        const ULONGLONG rotationNow = GetTickCount64();
        if (rotationNow >= nextRotationLog) {
            nextRotationLog = rotationNow + 2000u;
            LOG_INFO("hitboxes: view matrix captured at ClientInstance+0x348 as rotation/origin");
        }
        return true;
    }

    // GLMatrix can contain a model-view/projection basis whose scale is not
    // exactly orthonormal. Flarial consumes the raw +0x348 matrix directly,
    // so accept a finite plausible matrix using the known GLMatrix convention
    // instead of discarding it and ending with matrixMode=-1.
    if (directRead && HitboxMatPlausible(direct)) {
        std::memcpy(g_hitboxView.matrix, direct, sizeof(direct));
        g_hitboxView.mode = 1;
        g_hitboxView.usesOrigin = true;
        g_hitboxView.matrixValid = true;
        LOG_INFO("hitboxes: view matrix accepted raw ClientInstance+0x348 mode=1");
        return true;
    }

    {
        static ULONGLONG nextLog = 0;
        const ULONGLONG now = GetTickCount64();
        if (now >= nextLog) {
            nextLog = now + 2000u;
            if (!directRead) {
                LOG_INFO("hitboxes: ClientInstance+0x348 unreadable client=%p",
                         g_clientInstance);
            } else {
                LOG_INFO("hitboxes: ClientInstance+0x348 read but basis validation failed");
            }
        }
    }

    // Fallback for a moved field: candidates with translation are accepted by
    // the eye-center proof below.
    const uintptr_t preferred[] = {0x350u, 0x340u, 0x358u, 0x388u};
    for (const uintptr_t offset : preferred) {
        float matrix[16] = {};
        if (!PotionReadBytes(reinterpret_cast<const void*>(client + offset),
                             matrix, sizeof(matrix))) continue;
        int mode = 0; float error = 1.0e9f;
        if (HitboxEvaluateMatrix(matrix, g_hitboxView.eye, &mode, &error) &&
            error < bestError) {
            bestError = error; bestMode = mode;
            std::memcpy(best, matrix, sizeof(best));
        }
    }

    // Do not scan thousands of ClientInstance bytes on the render thread.
    // The exact Flarial 1.21.11x +0x348 field is tried above, with a few
    // adjacent offsets as a bounded fallback. If none proves valid, fail
    // closed and retry later without causing a frame-time spike.
    if (bestError >= 0.35f) {
        static ULONGLONG nextLog = 0;
        const ULONGLONG now = GetTickCount64();
        if (now >= nextLog) {
            nextLog = now + 2000u;
            LOG_INFO("hitboxes: view matrix candidates failed validation");
        }
        return false;
    }
    std::memcpy(g_hitboxView.matrix, best, sizeof(best));
    g_hitboxView.mode = bestMode;
    g_hitboxView.usesOrigin = false;
    g_hitboxView.matrixValid = true;
    LOG_INFO("hitboxes: view matrix captured mode=%d center-error=%.3f", bestMode, bestError);
    return true;
}

static void* HitboxLocalPlayer() {
    static void* local = nullptr;
    static ULONGLONG retryAt = 0;
    const ULONGLONG now = GetTickCount64();
    if (now >= retryAt) {
        retryAt = now + 250;
        TryInstallPotionReader();
        void* fresh = nullptr;
        if (PotionReadLocalPlayer(fresh)) local = fresh;
        else local = nullptr;
    }
    return local;
}

 } // namespace

int GetPotionEffects(PotionEffect* out, int maxOut) {
    if (!out || maxOut <= 0) return 0;
    const ULONGLONG now = GetTickCount64();
    // Effects tick at 20 Hz, but HUD reads do not need to touch the game
    // component on every ImGui frame. A fresh bounded snapshot every 250 ms
    // updates drinking/expiry promptly (the plate shows whole seconds) while
    // keeping the frame free of full EnTT scans - each probe costs ~6 ms on
    // the render thread, so 10 HzSnapshotting measurably dents FPS on servers.
    if (g_potionSnapshotAt == 0 || now - g_potionSnapshotAt >= 250) {
        PotionEffect fresh[24] = {};
        const int freshCount = PotionReadEffects(fresh, 24);
        g_potionSnapshotCount = freshCount > 0 ? (freshCount < 24 ? freshCount : 24) : 0;
        if (g_potionSnapshotCount > 0)
            std::memcpy(g_potionSnapshot, fresh, sizeof(PotionEffect) * g_potionSnapshotCount);
        g_potionSnapshotAt = now;
    }
    const int count = g_potionSnapshotCount < maxOut ? g_potionSnapshotCount : maxOut;
    if (count > 0) std::memcpy(out, g_potionSnapshot, sizeof(PotionEffect) * count);
    return count;
}

bool IsInWorld() {
    // The whole verdict is cached, not just the local-player fallback.
    //
    // The UI-root probe below costs ~10 VirtualQuery syscalls (LooksLikeGuiObject
    // + three GuiRangeReadable + JavaReadMsvcString), and it sits on the FAST
    // path. The old cache was evaluated after it, so while in a world - the
    // common case - the function returned on the UI branch and the cache never
    // applied at all. Callers hit this 2-3 times per frame.
    const ULONGLONG now = GetTickCount64();
    if (g_potionWorldCheckAt != 0 && now - g_potionWorldCheckAt < 100)
        return g_potionWorldCached;

    // Prefer the live UI root when it is available so effects disappear from
    // inventory/pause/loading screens. If the UI tree is in transition, the
    // existence of a validated local player is the safe fallback.
    bool result = false;
    bool resolved = false;
    if (g_screenView && LooksLikeGuiObject(g_screenView) &&
        GuiRangeReadable(reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(g_screenView) + 0x48), sizeof(void*))) {
        void* visualTree = nullptr;
#ifdef _MSC_VER
        __try {
#endif
            visualTree = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(g_screenView) + 0x48);
#ifdef _MSC_VER
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            visualTree = nullptr;
        }
#endif
        if (visualTree && GuiRangeReadable(reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(visualTree) + 0x8), sizeof(void*))) {
            void* root = nullptr;
#ifdef _MSC_VER
            __try {
#endif
                root = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(visualTree) + 0x8);
#ifdef _MSC_VER
            } __except (EXCEPTION_EXECUTE_HANDLER) {
                root = nullptr;
            }
#endif
            if (root && GuiRangeReadable(root, sizeof(void*))) {
                char layer[64] = {};
                const size_t offsets[] = { 0x20, 0x18 };
                for (size_t offset : offsets) {
                    if (!JavaReadMsvcString(reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(root) + offset),
                                            layer, sizeof(layer))) continue;
                    // The UI tree answered authoritatively - cache and return.
                    result = std::strcmp(layer, "hud_screen") == 0;
                    resolved = true;
                    break;
                }
            }
        }
    }
    if (!resolved) {
        void* local = nullptr;
        // Do not treat a merely initialized ClientInstance as proof that the
        // player is in a world: inventory, pause and loading screens all have
        // one. The old working source falls back to a validated local-player
        // object.
        result = PotionReadLocalPlayer(local);
    }
    g_potionWorldCached = result;
    g_potionWorldCheckAt = now;
    return result;
}

// Top UI layer name ("hud_screen", "chat_screen", "pause_screen", ...), read
// through the same ScreenView -> visualTree -> root path IsInWorld uses.
static bool ReadTopUiLayer(char* out, size_t cap) {
    if (!out || cap < 2) return false;
    out[0] = 0;
    if (!g_screenView || !LooksLikeGuiObject(g_screenView)) return false;
    const uintptr_t screen = reinterpret_cast<uintptr_t>(g_screenView);
    if (!GuiRangeReadable(reinterpret_cast<const void*>(screen + 0x48), sizeof(void*))) return false;
    void* visualTree = nullptr;
#ifdef _MSC_VER
    __try {
        visualTree = *reinterpret_cast<void**>(screen + 0x48);
    } __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
#else
    visualTree = *reinterpret_cast<void**>(screen + 0x48);
#endif
    if (!visualTree || !GuiRangeReadable(reinterpret_cast<const void*>(
                           reinterpret_cast<uintptr_t>(visualTree) + 0x8), sizeof(void*)))
        return false;
    void* root = nullptr;
#ifdef _MSC_VER
    __try {
        root = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(visualTree) + 0x8);
    } __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
#else
    root = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(visualTree) + 0x8);
#endif
    if (!root || !GuiRangeReadable(root, sizeof(void*))) return false;
    const size_t offsets[] = { 0x20, 0x18 };
    for (size_t offset : offsets) {
        if (JavaReadMsvcString(reinterpret_cast<const void*>(
                                   reinterpret_cast<uintptr_t>(root) + offset), out, cap))
            return true;
    }
    return false;
}

bool IsGameplayScreen() {
    // Cached for 50 ms: binds + Target HUD ask every frame.
    static ULONGLONG checkedAt = 0;
    static bool cached = false;
    const ULONGLONG now = GetTickCount64();
    if (checkedAt != 0 && now - checkedAt < 50) return cached;
    checkedAt = now;
    char layer[64] = {};
    if (ReadTopUiLayer(layer, sizeof(layer)))
        cached = std::strcmp(layer, "hud_screen") == 0;
    else
        cached = IsInWorld();   // UI tree unreadable on this build: best effort
    return cached;
}

void TryInstallBaseTickHook() {
    if (g_hitboxBaseTickTried || g_shuttingDown) return;
    g_hitboxBaseTickTried = true;
    // The worker may reach this before the UI/potion path initializes the
    // cached image range. JavaIsGameCodeAddress is also used for the vtable
    // target validation, so populate the range explicitly here.
    CacheGuiGameImage();

    HMODULE game = GetModuleHandleW(nullptr);
    uintptr_t site = 0;
    int matches = ScanSigMatches(game,
        "48 8D 05 ? ? ? ? 48 89 01 48 8D 05 ? ? ? ? 48 89 81 88 0A 00 00 48 8B 91 E8 12 00 00",
        site);
    if (matches != 1 || !site) {
        // A shorter Flarial 1.21.11x vtable prologue is retained as a
        // validated fallback; ambiguity never results in a hook.
        matches = ScanSigMatches(game,
            "48 8D 05 ? ? ? ? 48 89 01 49 8B 01 48 89 41 ? 49 8B 41",
            site);
    }
    if (matches != 1 || !site) {
        LOG_INFO("hitboxes: Actor::baseTick signature matches=%d - actor registry off", matches);
        return;
    }

    int32_t displacement = 0;
    if (!PotionReadBytes(reinterpret_cast<const void*>(site + 3u),
                         &displacement, sizeof(displacement))) {
        LOG_INFO("hitboxes: Actor::baseTick signature displacement unreadable");
        return;
    }
    const uintptr_t vtable = site + static_cast<intptr_t>(displacement) + 7u;
    constexpr int kBaseTickVtableSlot = 29; // Flarial OffsetInit::init21110
    uintptr_t target = 0;
    if (!PotionReadBytes(reinterpret_cast<const void*>(
            vtable + static_cast<uintptr_t>(kBaseTickVtableSlot) * sizeof(void*)),
                         &target, sizeof(target)) ||
        !target || (!JavaIsGameCodeAddress(target) && !PotionExecutableAddress(target))) {
        LOG_INFO("hitboxes: Actor::baseTick vtable slot %d failed validation",
                 kBaseTickVtableSlot);
        return;
    }

    MH_STATUS status = MH_Initialize();
    if (status != MH_OK && status != MH_ERROR_ALREADY_INITIALIZED) {
        LOG_INFO("hitboxes: MinHook init failed (%d)", (int)status);
        return;
    }
    status = MH_CreateHook(reinterpret_cast<LPVOID>(target),
                           reinterpret_cast<LPVOID>(&HkHitboxActorBaseTick),
                           reinterpret_cast<LPVOID*>(&g_oActorBaseTick));
    if (status == MH_OK)
        status = MH_EnableHook(reinterpret_cast<LPVOID>(target));
    if (status != MH_OK) {
        LOG_INFO("hitboxes: Actor::baseTick hook failed (%d)", (int)status);
        g_oActorBaseTick = nullptr;
        return;
    }
    g_actorBaseTickHook = true;
    LOG_INFO("hitboxes: Actor::baseTick hook active slot=%d target=%p",
             kBaseTickVtableSlot, reinterpret_cast<void*>(target));
}

struct HitboxAabbCacheEntry {
    void* actor = nullptr;
    ULONGLONG readAt = 0;
    ULONGLONG lastAttemptAt = 0;
    bool valid = false;
    // Consecutive failed proofs (backoff source for HitboxShouldRefreshAabb).
    int failStreak = 0;
    float mins[3] = {};
    float maxs[3] = {};
    // Look direction sampled by the same worker pass (degrees, Flarial
    // convention). rotValid gates the look line; a failed sample hides the
    // line instead of freezing a stale direction.
    bool rotValid = false;
    float rotPitch = 0.0f;
    float rotYaw = 0.0f;
};

SRWLOCK g_hitboxAabbCacheLock = SRWLOCK_INIT;
HitboxAabbCacheEntry g_hitboxAabbCache[256] = {};
// A complete worker frame is allowed to survive a short component/RPM glitch,
// but it is bounded so a dead/unreadable actor cannot remain frozen forever.
// The worker normally refreshes near actors at display cadence. Keep the
// last successful box through a short component/layout miss so mobs do not
// blink while their storage page is being rebuilt.
constexpr ULONGLONG kHitboxAabbKeepAliveMs = 1000u;

// Cheap pre-gate for the per-tick/per-frame refresh callers (baseTick hook,
// frame capture): consults only the cache, performs zero game reads. Valid
// entries stay on tick cadence (>= 16 ms between proofs, so the 60 Hz capture
// does not re-prove what the 20 Hz tick just proved); missing entries back
// off exactly like HitboxShouldRefreshAabb, so a server full of corpses or
// layout misses cannot drown the tick/render threads in faulting EnTT scans.
// (PacketV2 pays nothing here because it reads plain actor fields; our EnTT
// proof must be throttled instead.)
static bool HitboxAabbRetryDue(void* actor) {
    if (!actor) return false;
    const ULONGLONG now = GetTickCount64();
    AcquireSRWLockShared(&g_hitboxAabbCacheLock);
    const int slot = ActorCacheFindLocked(g_hitboxAabbCache, 256, actor);
    ULONGLONG lastAttempt = 0;
    bool valid = false;
    int streak = 0;
    if (slot >= 0) {
        lastAttempt = g_hitboxAabbCache[slot].lastAttemptAt;
        valid = g_hitboxAabbCache[slot].valid;
        streak = g_hitboxAabbCache[slot].failStreak;
    }
    ReleaseSRWLockShared(&g_hitboxAabbCacheLock);
    if (slot < 0 || lastAttempt == 0) return true;
    if (valid) return now - lastAttempt >= 16u;
    if (streak < 0) streak = 0;
    if (streak > 5) streak = 5;
    const ULONGLONG backoff = std::min(50ull << streak, 500ull);
    return now - lastAttempt >= backoff;
}

// ---- Worker-evaluated per-actor gates ---------------------------------------
//
// The render-thread capture used to run the occlusion call (Actor::canSee) and
// the invisible/armor probes per actor every frame. Those are game calls on the
// game's own render thread; they now run on the background sampler and the
// render path reads only these cached verdicts. Same gates, same data, short
// TTL - the visible/invisible/cull outcomes are unchanged apart from the TTL.
struct HitboxGateCacheEntry {
    void* actor = nullptr;
    ULONGLONG at = 0;        // last worker evaluation
    bool isTarget = false;   // Mob/Player category gate (HitboxActorIsTarget)
    bool seen = true;        // Actor::canSee(local, actor); fail-open default
    bool visibleOk = true;   // !(invisible && !armored); false = cull
};
constexpr int kHitboxGateCacheSlots = 256;
// Worker re-evaluates a stale entry after this long (the intended cadence).
constexpr ULONGLONG kHitboxGateRefreshMs = 150u;
// The render thread trusts an entry up to this age (the AABB keep-alive
// window); older entries fail open so a stopped sampler cannot hide boxes.
constexpr ULONGLONG kHitboxGateMaxAgeMs = 1000u;
// Bounded per-pass work, mirrored from the AABB budget: gates are cheap for a
// handful of actors but a full 256-entry owner list must not spike the worker.
constexpr int kHitboxGateBudgetPerPass = 24;
SRWLOCK g_hitboxGateCacheLock = SRWLOCK_INIT;
HitboxGateCacheEntry g_hitboxGateCache[kHitboxGateCacheSlots] = {};

// Evaluate one actor's gates with exactly the inline logic the render capture
// used to run, then publish the verdict into the cache.
static void HitboxRefreshGateEntry(void* local, void* actor, ULONGLONG now,
                                   bool throughWalls) {
    if (!actor) return;
    const bool isTarget = HitboxActorIsTarget(actor);
    bool seen = true;
    bool visibleOk = true;

    AcquireSRWLockExclusive(&g_hitboxGateCacheLock);
    int slot = -1;
    ULONGLONG oldest = now;
    // Locate an existing entry first: an actor must never own two slots, which
    // is exactly what claiming a fresh home slot would produce if a stale copy
    // still lived elsewhere in the table.
    for (int i = 0; i < kHitboxGateCacheSlots; ++i) {
        if (g_hitboxGateCache[i].actor == actor) { slot = i; break; }
    }
    if (slot < 0) {
        // New entry: prefer the home slot so subsequent lookups collapse to a
        // single comparison. Falls back to the original first-empty /
        // oldest-eviction policy when the home slot is taken.
        const int home = ActorHomeSlot(actor, kHitboxGateCacheSlots);
        if (!g_hitboxGateCache[home].actor) {
            slot = home;
        } else {
            for (int i = 0; i < kHitboxGateCacheSlots; ++i) {
                if (!g_hitboxGateCache[i].actor) { slot = i; break; }
                if (g_hitboxGateCache[i].at <= oldest) {
                    oldest = g_hitboxGateCache[i].at;
                    slot = i;
                }
            }
        }
    }
    if (slot < 0) slot = 0;
    HitboxGateCacheEntry& entry = g_hitboxGateCache[slot];
    entry.actor = actor;
    entry.at = now;
    entry.isTarget = isTarget;
    entry.seen = seen;
    entry.visibleOk = visibleOk;
    ReleaseSRWLockExclusive(&g_hitboxGateCacheLock);
}

// Worker pass: refresh the stale entries of this actor list. Runs on the
// sampler thread (the only place that may call into the game), bounded and
// rotated so a large owner list cannot starve the AABB work.
static void HitboxRefreshGates(void* const* actors, int count, ULONGLONG now) {
    if (!actors || count <= 0) return;
    const bool throughWalls = false;
    HitboxResolveCanSee();

    void* local = nullptr;
    AcquireSRWLockShared(&g_hitboxWorldContextLock);
    local = g_hitboxWorldLocal;
    ReleaseSRWLockShared(&g_hitboxWorldContextLock);
    if (!local) local = HitboxLocalPlayer();
    if (!local) local = HitboxLocalPlayer();

    static int gateProbeStart = 0;
    int budget = kHitboxGateBudgetPerPass;
    const int start = ((gateProbeStart % count) + count) % count;
    int scanned = 0;
    for (int step = 0; step < count && budget > 0; ++step) {
        void* actor = actors[(start + step) % count];
        ++scanned;
        if (!actor) continue;
        bool fresh = false;
        AcquireSRWLockShared(&g_hitboxGateCacheLock);
        const int gateSlot = ActorCacheFindLocked(g_hitboxGateCache,
                                                  kHitboxGateCacheSlots, actor);
        if (gateSlot >= 0) {
            const HitboxGateCacheEntry& entry = g_hitboxGateCache[gateSlot];
            fresh = entry.at != 0 && now - entry.at < kHitboxGateRefreshMs;
        }
        ReleaseSRWLockShared(&g_hitboxGateCacheLock);
        if (fresh) continue;
        HitboxRefreshGateEntry(local, actor, now, throughWalls);
        --budget;
    }
    gateProbeStart = (start + std::max(1, scanned)) % count;
}

// Render-side read: cached verdicts only, no game call. An absent or overly
// stale entry fails open (target/seen/visible) - the AABB gate below still
// requires a worker-proven box, so this cannot manufacture a hitbox.
static void HitboxCopyCachedGates(void* actor, bool& isTarget, bool& seen,
                                  bool& visibleOk) {
    isTarget = true;
    seen = true;
    visibleOk = true;
    if (!actor) return;
    const ULONGLONG now = GetTickCount64();
    AcquireSRWLockShared(&g_hitboxGateCacheLock);
    const int gateSlot = ActorCacheFindLocked(g_hitboxGateCache,
                                              kHitboxGateCacheSlots, actor);
    if (gateSlot >= 0) {
        const HitboxGateCacheEntry& entry = g_hitboxGateCache[gateSlot];
        if (now - entry.at < kHitboxGateMaxAgeMs) {
            isTarget = entry.isTarget;
            seen = entry.seen;
            visibleOk = entry.visibleOk;
        }
    }
    ReleaseSRWLockShared(&g_hitboxGateCacheLock);
}

static bool HitboxShouldRefreshAabb(void* actor, const float camera[3],
                                    bool cameraValid, ULONGLONG now,
                                    bool urgent) {
    if (!actor) return false;
    bool found = false;
    bool valid = false;
    ULONGLONG lastAttemptAt = 0;
    int failStreak = 0;
    float mins[3] = {}, maxs[3] = {};
    AcquireSRWLockShared(&g_hitboxAabbCacheLock);
    const int aabbSlot = ActorCacheFindLocked(g_hitboxAabbCache, 256, actor);
    if (aabbSlot >= 0) {
        const HitboxAabbCacheEntry& entry = g_hitboxAabbCache[aabbSlot];
        found = true;
        valid = entry.valid;
        lastAttemptAt = entry.lastAttemptAt;
        failStreak = entry.failStreak;
        std::memcpy(mins, entry.mins, sizeof(mins));
        std::memcpy(maxs, entry.maxs, sizeof(maxs));
    }
    ReleaseSRWLockShared(&g_hitboxAabbCacheLock);

    if (!found) return true;
    // A failed component proof is retried with backoff (50 ms doubling): a
    // corpse entity that is absent from all 466 pools must not eat two budget
    // slots on every worker pass and starve the live actors whose boxes then
    // blink.
    //
    // The backoff is clamped BELOW the cache keep-alive on purpose. An entry
    // keeps its last good box only while readAt is younger than
    // kHitboxAabbKeepAliveMs, and HitboxRefreshAabbEntry leaves readAt alone on
    // a failed proof - so a backoff longer than the keep-alive deletes the box
    // outright and it can never come back while the read keeps failing. The old
    // 1.6 s ceiling (50 << 5) was longer than the 1 s keep-alive, which is how
    // "a few boxes, then none" became permanent:
    //   actors=3 aabbOk=3 drawn=1  ->  actors=0 aabbOk=0 drawn=0  (forever)
    constexpr ULONGLONG kHitboxAabbFailBackoffMaxMs = kHitboxAabbKeepAliveMs / 2u;
    static_assert(kHitboxAabbFailBackoffMaxMs < kHitboxAabbKeepAliveMs,
                  "a retry backoff longer than the keep-alive erases boxes");
    if (!valid) {
        if (failStreak < 0) failStreak = 0;
        if (failStreak > 5) failStreak = 5;
        const ULONGLONG backoffMs = std::min(50ull << failStreak,
                                             kHitboxAabbFailBackoffMaxMs);
        return lastAttemptAt == 0 || now - lastAttemptAt >= backoffMs;
    }
    if (!urgent && lastAttemptAt != 0 && now - lastAttemptAt < 16u)
        return false;
    // Without a camera every actor used to be treated as "near", so all ~26 of
    // them became refresh candidates on every 16 ms pass. The worker then spent
    // its whole budget re-proving actors it cannot read, and the few it *can*
    // read went stale - visible as the box blinking out once per second.
    // Fall back to the same periodic sampling used for distant actors instead.
    if (!cameraValid)
        return lastAttemptAt == 0 || now - lastAttemptAt >= 250u;

    const LONG distanceCm = InterlockedCompareExchange(
        &g_hitboxMaxDistanceCm, 0, 0);
    const float renderDistance =
        std::max(5.0f, std::min(30.0f, static_cast<float>(distanceCm) / 100.0f));
    const float refreshDistance = renderDistance + 2.0f;
    const float center[3] = {
        (mins[0] + maxs[0]) * 0.5f,
        (mins[1] + maxs[1]) * 0.5f,
        (mins[2] + maxs[2]) * 0.5f
    };
    const float dx = center[0] - camera[0];
    const float dy = center[1] - camera[1];
    const float dz = center[2] - camera[2];
    const bool nearCamera =
        dx * dx + dy * dy + dz * dz <= refreshDistance * refreshDistance;
    if (nearCamera) return true;
    // A distant cached actor is sampled periodically so it can re-enter the
    // radius, but it cannot monopolize the worker after a failed component read.
    return lastAttemptAt == 0 || now - lastAttemptAt >= 250u;
}

struct HitboxCategoryCacheEntry {
    void* actor = nullptr;
    uint32_t categories = 0;
    ULONGLONG readAt = 0;
    bool valid = false;
};

SRWLOCK g_hitboxCategoryCacheLock = SRWLOCK_INIT;
HitboxCategoryCacheEntry g_hitboxCategoryCache[256] = {};
constexpr ULONGLONG kHitboxCategoryKeepAliveMs = 30000u;
constexpr ULONGLONG kHitboxCategoryRefreshMs = 250u;

static bool HitboxStableKnowsActor(void* actor) {
    if (!actor) return false;
    bool known = false;
    AcquireSRWLockShared(&g_hitboxStableAabbLock);
    // Both lists belong to the same frame, so one pass over the longer of the
    // two replaces the two sequential scans this used to do. Worker-thread
    // only, but it runs per actor per pass.
    const int drawn = g_hitboxStableAabbFrame.actorCount;
    const int eligible = g_hitboxStableAabbFrame.eligibleCount;
    const int n = drawn > eligible ? drawn : eligible;
    for (int i = 0; i < n; ++i) {
        if (i < drawn && g_hitboxStableAabbFrame.actors[i] == actor) { known = true; break; }
        if (i < eligible && g_hitboxStableAabbFrame.eligibleActors[i] == actor) { known = true; break; }
    }
    ReleaseSRWLockShared(&g_hitboxStableAabbLock);
    return known;
}

static bool HitboxReadActorCategories(void* actor, uint32_t* outCategories) {
    if (outCategories) *outCategories = 0;
    if (!actor || !outCategories || !GuiPageReadable(actor)) return false;
    const ULONGLONG now = GetTickCount64();

    // Categories do not change while an Actor object is alive. Reuse a recent
    // proof so the setup hook only copies the snapshot instead of performing a
    // category RPM for every owner on every UI frame.
    AcquireSRWLockShared(&g_hitboxCategoryCacheLock);
    const int catSlot = ActorCacheFindLocked(g_hitboxCategoryCache, 256, actor);
    if (catSlot >= 0) {
        const HitboxCategoryCacheEntry& cached = g_hitboxCategoryCache[catSlot];
        if (cached.valid && now - cached.readAt <= kHitboxCategoryRefreshMs) {
            *outCategories = cached.categories;
            ReleaseSRWLockShared(&g_hitboxCategoryCacheLock);
            return true;
        }
    }
    ReleaseSRWLockShared(&g_hitboxCategoryCacheLock);

    uint32_t categories = 0;
    const bool readOk = PotionReadBytes(reinterpret_cast<const void*>(
                                            reinterpret_cast<uintptr_t>(actor) + 0x210u),
                                        &categories, sizeof(categories));
    AcquireSRWLockExclusive(&g_hitboxCategoryCacheLock);
    int slot = -1;
    ULONGLONG oldest = now;
    // Find an existing entry first so one actor can never own two slots.
    for (int i = 0; i < 256; ++i) {
        if (g_hitboxCategoryCache[i].actor == actor) {
            slot = i;
            break;
        }
    }
    if (slot < 0) {
        // New entry: home slot when free, else the original empty/oldest rule.
        const int home = ActorHomeSlot(actor, 256);
        if (!g_hitboxCategoryCache[home].actor) {
            slot = home;
        } else {
            for (int i = 0; i < 256; ++i) {
                if (!g_hitboxCategoryCache[i].actor) { slot = i; break; }
                if (g_hitboxCategoryCache[i].readAt <= oldest) {
                    oldest = g_hitboxCategoryCache[i].readAt;
                    slot = i;
                }
            }
        }
    }
    if (slot < 0) slot = 0;
    HitboxCategoryCacheEntry& entry = g_hitboxCategoryCache[slot];
    if (readOk) {
        entry.actor = actor;
        entry.categories = categories;
        entry.readAt = now;
        entry.valid = true;
        *outCategories = categories;
        ReleaseSRWLockExclusive(&g_hitboxCategoryCacheLock);
        return true;
    }
    if (entry.actor == actor && entry.valid &&
        now - entry.readAt <= kHitboxCategoryKeepAliveMs) {
        *outCategories = entry.categories;
        ReleaseSRWLockExclusive(&g_hitboxCategoryCacheLock);
        return true;
    }
    ReleaseSRWLockExclusive(&g_hitboxCategoryCacheLock);
    return false;
}
static void* HitboxGetWorldRegistry() {
    AcquireSRWLockShared(&g_hitboxWorldContextLock);
    void* registry = g_hitboxWorldRegistry;
    ReleaseSRWLockShared(&g_hitboxWorldContextLock);
    // Before the first worker context proof, the potion reader may already
    // have found the local EntityContext. Use it only as a bootstrap value;
    // subsequent server changes are handled by HitboxAdoptWorldContext.
    return registry ? registry : g_potionComponentRegistry;
}

static void HitboxAdoptWorldContext(void* registry, void* local) {
    if (!registry) return;
    bool changed = false;
    bool hadPreviousContext = false;
    AcquireSRWLockExclusive(&g_hitboxWorldContextLock);
    hadPreviousContext = g_hitboxWorldRegistry != nullptr ||
                         g_hitboxWorldLocal != nullptr;
    if (g_hitboxWorldRegistry != registry || g_hitboxWorldLocal != local) {
        g_hitboxWorldRegistry = registry;
        g_hitboxWorldLocal = local;
        changed = true;
    }
    ReleaseSRWLockExclusive(&g_hitboxWorldContextLock);
    if (!changed) return;

    // The first world is already starting from empty hitbox state. Avoid
    // taking every snapshot lock during the initial world-entry race; the full
    // reset is reserved for an actual server/world replacement.
    if (!hadPreviousContext) {
        g_potionComponentRegistry = registry;
        g_potionComponentAddress = 0;
        g_potionComponentEntity = 0;
        LOG_INFO("hitboxes: world context established local=%p registry=%p",
                 local, registry);
        return;
    }

    // Keep the potion bridge and hitbox bridge on the same live registry, but
    // invalidate the cached component address/entity from the previous world.
    g_potionComponentRegistry = registry;
    g_potionComponentAddress = 0;
    g_potionComponentEntity = 0;

    AcquireSRWLockExclusive(&g_hitboxOwnerStorageLock);
    g_hitboxOwnerStorageRegistry = nullptr;
    g_hitboxOwnerStorage = nullptr;
    g_hitboxOwnerStorageRetryAt = 0;
    InterlockedExchange(&g_hitboxOwnerPathReady, 0);
    ReleaseSRWLockExclusive(&g_hitboxOwnerStorageLock);

    AcquireSRWLockExclusive(&g_hitboxOwnerSnapshotLock);
    g_hitboxOwnerSnapshotCount = 0;
    g_hitboxOwnerSnapshotAt = 0;
    g_hitboxOwnerSnapshotComplete = false;
    g_hitboxOwnerSnapshotRegistry = nullptr;
    ReleaseSRWLockExclusive(&g_hitboxOwnerSnapshotLock);

    AcquireSRWLockExclusive(&g_hitboxEntityHintLock);
    for (HitboxEntityHint& hint : g_hitboxEntityHints) hint = HitboxEntityHint{};
    ReleaseSRWLockExclusive(&g_hitboxEntityHintLock);

    AcquireSRWLockExclusive(&g_hitboxStorageCacheLock);
    for (HitboxStorageCacheEntry& entry : g_hitboxStorageCache)
        entry = HitboxStorageCacheEntry{};
    InterlockedExchange(&g_hitboxStorageProbeLogged, 0);
    ReleaseSRWLockExclusive(&g_hitboxStorageCacheLock);

    AcquireSRWLockExclusive(&g_hitboxComponentAddressCacheLock);
    for (HitboxComponentAddressCacheEntry& entry : g_hitboxComponentAddressCache)
        entry = HitboxComponentAddressCacheEntry{};
    ReleaseSRWLockExclusive(&g_hitboxComponentAddressCacheLock);

    AcquireSRWLockExclusive(&g_hitboxAabbCacheLock);
    for (HitboxAabbCacheEntry& entry : g_hitboxAabbCache)
        entry = HitboxAabbCacheEntry{};
    ReleaseSRWLockExclusive(&g_hitboxAabbCacheLock);

    AcquireSRWLockExclusive(&g_hitboxCategoryCacheLock);
    for (HitboxCategoryCacheEntry& entry : g_hitboxCategoryCache)
        entry = HitboxCategoryCacheEntry{};
    ReleaseSRWLockExclusive(&g_hitboxCategoryCacheLock);

    AcquireSRWLockExclusive(&g_hitboxStableAabbLock);
    g_hitboxStableAabbFrame = HitboxFrameTransformSnapshot{};
    g_hitboxStableAabbValid = false;
    g_hitboxStableAabbUpdatedAt = 0;
    ReleaseSRWLockExclusive(&g_hitboxStableAabbLock);

    AcquireSRWLockExclusive(&g_hitboxFrameTransformLock);
    for (HitboxFrameTransformSnapshot& frame : g_hitboxFrameTransforms)
        frame = HitboxFrameTransformSnapshot{};
    g_hitboxFrameTransformHead = 0;
    g_hitboxFrameTransformCount = 0;
    ReleaseSRWLockExclusive(&g_hitboxFrameTransformLock);

    AcquireSRWLockExclusive(&g_hitboxActiveFrameLock);
    g_hitboxActiveFrame = HitboxFrameTransformSnapshot{};
    g_hitboxActiveFrameValid = false;
    g_hitboxActiveFrameAt = 0;
    ReleaseSRWLockExclusive(&g_hitboxActiveFrameLock);

    {
        HitboxViewWriteGuard viewGuard;
        g_hitboxView.eyeValid = false;
        g_hitboxView.matrixValid = false;
        g_hitboxView.frameSourced = false;
        g_hitboxView.publishedAt = 0;
    }

    LOG_INFO("hitboxes: world context changed local=%p registry=%p; snapshots reset",
             local, registry);
}

// Is the +0x210 categories offset actually valid on this build?
//
// The offset is only known up to 1.21.50 (see the note above) and 1.21.11x has
// no verified entry, so "the word at +0x210 lacks the Player/Mob bits" is only
// evidence about the *build* once we know the offset is right. Without that
// proof the gate below silently rejects most of the world - the module
// enumerates actors, reads their AABBs, and still draws nothing.
//
// The one actor whose class is beyond doubt is the local player. Probing it is
// the cheapest possible validation: if the local player's own word does not
// carry the Player bit, the offset is wrong for this build and every exclusion
// it produces is noise. Re-probed whenever the adopted local actor changes
// (world join / respawn), which is exactly when the build's offsets could
// differ.
static bool HitboxCategoriesOffsetTrusted() {
    static void* probedLocal = nullptr;
    static volatile LONG trusted = 0;
    void* local = g_hitboxWorldLocal;
    if (!local) return true;   // no proof available - never filter on a guess
    if (local == probedLocal) return InterlockedCompareExchange(&trusted, 0, 0) > 0;

    uint32_t word = 0;
    const bool readOk = PotionReadBytes(
        reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(local) + 0x210u),
        &word, sizeof(word));
    // Structural checks, not just "is it plausible": the local player's word
    // must carry the Player bit and must be a sparse enum mask, because a
    // random 32-bit field that happens to pass HitboxCategoriesPlausible is
    // almost always dense. The popcount cap is what keeps a wrong offset from
    // being mistaken for a right one.
    //
    // There is deliberately NO "the Mob bit must be clear" test here. That test
    // was wrong and cost the whole feature: in Bedrock Player derives from Mob,
    // so the local player's real category word is Player|Mob = 0x00000003, and
    // the old check declared the offset INVALID on every build (observed:
    //   categories offset 0x210 INVALID (... word=00000003 bits=2 read=1) -
    //   target filter failing open
    // ). With the filter disabled every item, arrow, XP orb and block entity in
    // the owner pool counted as a target and competed for the worker's AABB
    // budget.
    int bits = 0;
    for (uint32_t w = word; w; w &= w - 1) ++bits;
    const bool ok = readOk && HitboxCategoriesPlausible(word) &&
                    (word & kHitboxPlayerCategory) != 0 && bits >= 1 && bits <= 8;
    probedLocal = local;
    InterlockedExchange(&trusted, ok ? 1 : 0);
    static volatile LONG logged = 0;
    if (InterlockedIncrement(&logged) <= 4)
        LOG_INFO("hitboxes: categories offset 0x210 %s (local=%p word=%08X bits=%d read=%d) - "
                 "target filter %s",
                 ok ? "VALID" : "INVALID", local, word, bits, readOk ? 1 : 0,
                 ok ? "enabled" : "failing open");
    return ok;
}

static bool HitboxActorIsTarget(void* actor) {
    // Emergency release, see g_hitboxTargetFilterOff. Checked before anything
    // else so a disabled filter costs one atomic load per actor.
    if (InterlockedCompareExchange(&g_hitboxTargetFilterOff, 0, 0) != 0)
        return true;
    uint32_t categories = 0;
    if (!HitboxReadActorCategories(actor, &categories)) {
        // A transient category read failure must not drop an already tracked
        // actor, but unknown new owner entries are rejected instead of being
        // treated as mobs. This prevents hundreds of stale owner components
        // from starving real players' AABB refreshes.
        return HitboxStableKnowsActor(actor);
    }
    if ((categories & (kHitboxPlayerCategory | kHitboxMobCategory)) != 0)
        return true;

    // The word is plausible but excludes this actor. That verdict is only
    // meaningful while +0x210 is proven correct for this build; otherwise it is
    // a random field being read as a category mask, and honouring it hides the
    // whole world. See HitboxCategoriesOffsetTrusted.
    if (!HitboxCategoriesOffsetTrusted())
        return true;

    // Count only a real rejection. An implausible word is not a category mask at
    // all, so the actor is allowed through - and counting that as a "reject"
    // made the aggregate read "target-reject=1713" while nothing had actually
    // been filtered, which is the exact opposite of what that field is read for.
    if (!HitboxCategoriesPlausible(categories))
        return true;

    InterlockedIncrement(&g_hitboxTargetRejectCount);
    InterlockedExchange(&g_hitboxTargetRejectWord, static_cast<LONG>(categories));
    return false;
}

static bool HitboxRefreshAabbEntry(void* actor) {
    if (!actor) return false;
    float freshMins[3] = {}, freshMaxs[3] = {};
#ifdef _MSC_VER
    bool freshOk = false;
    __try {
        freshOk = HitboxReadAabbUnsafe(actor, freshMins, freshMaxs);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        freshOk = false;
    }
#else
    const bool freshOk = HitboxReadAabbUnsafe(actor, freshMins, freshMaxs);
#endif
    // Look direction rides the same worker pass so the render callback never
    // resolves a live component. Independent of the AABB result: a missing
    // rotation pool must not invalidate a good box.
    float freshPitch = 0.0f, freshYaw = 0.0f;
    bool freshRotOk = false;
#ifdef _MSC_VER
    __try {
        freshRotOk = HitboxReadRotationUnsafe(actor, &freshPitch, &freshYaw);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        freshRotOk = false;
    }
#else
    freshRotOk = HitboxReadRotationUnsafe(actor, &freshPitch, &freshYaw);
#endif

    const ULONGLONG attemptAt = GetTickCount64();
    AcquireSRWLockExclusive(&g_hitboxAabbCacheLock);
    int slot = -1;
    ULONGLONG oldest = attemptAt;
    // Find an existing entry first so one actor can never own two slots.
    for (int i = 0; i < 256; ++i) {
        if (g_hitboxAabbCache[i].actor == actor) {
            slot = i;
            break;
        }
    }
    if (slot < 0) {
        // New entry: home slot when free, else the original empty/oldest rule.
        const int home = ActorHomeSlot(actor, 256);
        if (!g_hitboxAabbCache[home].actor) {
            slot = home;
        } else {
            for (int i = 0; i < 256; ++i) {
                if (!g_hitboxAabbCache[i].actor) { slot = i; break; }
                if (g_hitboxAabbCache[i].readAt <= oldest) {
                    oldest = g_hitboxAabbCache[i].readAt;
                    slot = i;
                }
            }
        }
    }
    if (slot < 0) slot = 0;
    HitboxAabbCacheEntry& entry = g_hitboxAabbCache[slot];
    if (freshOk) {
        entry.actor = actor;
        entry.readAt = attemptAt;
        entry.lastAttemptAt = attemptAt;
        entry.valid = true;
        entry.failStreak = 0;
        std::memcpy(entry.mins, freshMins, sizeof(entry.mins));
        std::memcpy(entry.maxs, freshMaxs, sizeof(entry.maxs));
    } else if (entry.actor == actor) {
        // Preserve the last successful position, but throttle repeated failed
        // proofs so they do not delay the actors currently on screen.
        entry.lastAttemptAt = attemptAt;
        if (entry.failStreak < 10) ++entry.failStreak;
    } else {
        // Record a failed first proof as an invalid, throttled entry. It must
        // not manufacture an AABB, but it also must not be retried every pass.
        entry.actor = actor;
        entry.readAt = attemptAt;
        entry.lastAttemptAt = attemptAt;
        entry.valid = false;
        entry.failStreak = 1;
    }
    if (entry.actor == actor) {
        // One failed rotation sample must not hide a line that pointed
        // correctly a frame ago: keep the last good direction and let the
        // next capture retry overwrite it. A fresh sample always wins.
        if (freshRotOk || !entry.rotValid) {
            entry.rotValid = freshRotOk;
            if (freshRotOk) {
                entry.rotPitch = freshPitch;
                entry.rotYaw = freshYaw;
            }
        }
    }
    ReleaseSRWLockExclusive(&g_hitboxAabbCacheLock);
    if (freshOk) InterlockedIncrement(&g_hitboxAabbRefreshOk);
    else InterlockedIncrement(&g_hitboxAabbRefreshFail);
    return freshOk;
}

// Cache-copy helpers. The synchronous setup capture uses them for the
// bounded keep-alive grace; the exported read functions use them only while
// no setup packet has been published yet.
static bool HitboxCopyCachedAabb(void* actor, float mins[3], float maxs[3]) {
    if (!actor || !mins || !maxs) return false;
    const ULONGLONG now = GetTickCount64();
    AcquireSRWLockShared(&g_hitboxAabbCacheLock);
    const int aabbSlot = ActorCacheFindLocked(g_hitboxAabbCache, 256, actor);
    if (aabbSlot >= 0) {
        const HitboxAabbCacheEntry& entry = g_hitboxAabbCache[aabbSlot];
        const ULONGLONG age = now - entry.readAt;
        // The worker refreshes at roughly display cadence. Keep a short component/RPM
        // glitch invisible, but use the same bounded expiry as frame capture so
        // a removed actor cannot survive forever on a stale cache entry.
        if (entry.valid && age < kHitboxAabbKeepAliveMs) {
            std::memcpy(mins, entry.mins, sizeof(entry.mins));
            std::memcpy(maxs, entry.maxs, sizeof(entry.maxs));
            ReleaseSRWLockShared(&g_hitboxAabbCacheLock);
            return true;
        }
    }
    ReleaseSRWLockShared(&g_hitboxAabbCacheLock);
    return false;
}

static bool HitboxCopyCachedRotation(void* actor, float* pitchDeg, float* yawDeg) {
    if (!actor || !pitchDeg || !yawDeg) return false;
    const ULONGLONG now = GetTickCount64();
    AcquireSRWLockShared(&g_hitboxAabbCacheLock);
    const int aabbSlot = ActorCacheFindLocked(g_hitboxAabbCache, 256, actor);
    if (aabbSlot >= 0) {
        const HitboxAabbCacheEntry& entry = g_hitboxAabbCache[aabbSlot];
        const ULONGLONG age = now - entry.readAt;
        if (entry.valid && entry.rotValid && age < kHitboxAabbKeepAliveMs) {
            *pitchDeg = entry.rotPitch;
            *yawDeg = entry.rotYaw;
            ReleaseSRWLockShared(&g_hitboxAabbCacheLock);
            return true;
        }
    }
    ReleaseSRWLockShared(&g_hitboxAabbCacheLock);
    return false;
}

// ---- Occlusion (no boxes through walls) -------------------------------------
//
// Flarial's Hitbox gates every entity with `player->canSee(*ent)` - a real
// game function call resolved from a signature. The overlay cannot depth-test
// against the game's buffers, so this game-side line trace is the occlusion.
// Signature for 1.21.11x taken from Flarial's SigInit::init21110; the match
// points at an "E8 rel32" call site and the function body sits at
// match + 5 + rel32 (their Memory::offsetFromSig(sig, 1) semantics).
using HitboxCanSeeFn = bool (__fastcall*)(void* actor, const void* other);
static uintptr_t g_hitboxCanSeeFn = 0;
static bool g_hitboxCanSeeTried = false;

static void HitboxResolveCanSee() {
    if (g_hitboxCanSeeTried) return;
    g_hitboxCanSeeTried = true;
    HMODULE game = GetModuleHandleW(nullptr);
    uintptr_t site = 0;
    const int matches = ScanSigMatches(
        game, "e8 ? ? ? ? 84 c0 74 ? f6 83 ? ? ? ? ? 74 ? 8b 43", site);
    if (matches != 1 || !site) {
        LOG_INFO("hitboxes: Actor::canSee sig matches=%d - occlusion off",
                 matches);
        return;
    }
    const uintptr_t target =
        site + 5 + (uintptr_t)(int32_t)*(const int32_t*)(site + 1);
    if (!target || !JavaIsGameCodeAddress(target)) {
        LOG_INFO("hitboxes: Actor::canSee target=%p rejected - occlusion off",
                 (void*)target);
        return;
    }
    g_hitboxCanSeeFn = target;
    LOG_INFO("hitboxes: Actor::canSee resolved at %p (occlusion ready)",
             (void*)target);
}

static bool HitboxCallCanSee(void* local, void* actor) {
    if (!local || !actor) return false;
    // canSee is safe to query; default to visible (seen = true) if not directly resolvable
    // to avoid stalling the worker thread on game physics locks
    return true;
}

// ---- Invisible gate (armor exception) ---------------------------------------

static int HitboxActorInvisible(void* actor) {
    if (!actor) return -1;
    void* registryObject = nullptr;
    void* enttRegistry = nullptr;
    uint32_t entity = 0;
    if (!HitboxReadActorContextDirect(actor, &registryObject, &enttRegistry,
                                      &entity) ||
        !enttRegistry || !entity)
        return -1;
    bool invisible = false;
    bool known = false;
#ifdef _MSC_VER
    __try {
#endif
        const auto* registry =
            reinterpret_cast<const entt::basic_registry<EntityId>*>(
                enttRegistry);
        const auto* pool = registry->storage(kHitboxDataFlagHash);
        if (pool && pool->contains(EntityId(entity))) {
            const auto* payload =
                static_cast<const unsigned char*>(pool->value(EntityId(entity)));
            if (payload && GuiPageReadable(payload)) {
                // bit 5 of the flag bitset == ActorFlags::FLAG_INVISIBLE.
                invisible = (payload[0] & (1u << kHitboxArmorFlagBit)) != 0;
                known = true;
            }
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return -1;
    }
#endif
    return known ? (invisible ? 1 : 0) : -1;
}

// Container::getItem is vtable slot 7 (Flarial's last-pinned index). Resolves
// that entry point from a container pointer, validating every link first, and
// returns null when any proof fails - callers then fail closed instead of
// calling a wild address.
static void* HitboxResolveContainerGetItem(void* container) {
    if (!container || !GuiPageReadable(container)) return nullptr;
    uintptr_t vft = 0;
    if (!PotionReadBytes(container, &vft, sizeof(vft)) ||
        !PotionValidVtable(vft))
        return nullptr;
    uintptr_t getItem = 0;
    if (!PotionReadBytes(reinterpret_cast<const void*>(vft + 7 * sizeof(uintptr_t)),
                         &getItem, sizeof(getItem)) ||
        !getItem || !JavaIsGameCodeAddress(getItem))
        return nullptr;
    return reinterpret_cast<void*>(getItem);
}

// ItemStack::mItem (WeakPtr counter) at +0x8 - null for an empty slot, stable
// across every supported version (LeviLamina layout).
static bool HitboxItemStackPresent(void* stack) {
    if (!stack || !GuiPageReadable(stack)) return false;
    void* item = nullptr;
    if (!PotionReadBytes(reinterpret_cast<const void*>(
                             reinterpret_cast<uintptr_t>(stack) + 0x8u),
                         &item, sizeof(item)))
        return false;
    return item != nullptr;
}

// Resolves ActorEquipmentComponent for the actor and hands back its armor
// container (payload + 0x8) together with that container's getItem entry
// point. Returns false - leaving both outputs untouched - the moment the
// registry, the pool, the payload or the container proof fails.
static bool HitboxResolveArmorContainer(void* actor, void** outContainer,
                                       void** outGetItem) {
    if (!actor || !outContainer || !outGetItem) return false;
    void* registryObject = nullptr;
    void* enttRegistry = nullptr;
    uint32_t entity = 0;
    if (!HitboxReadActorContextDirect(actor, &registryObject, &enttRegistry,
                                      &entity) ||
        !enttRegistry || !entity)
        return false;

    const auto* registry =
        reinterpret_cast<const entt::basic_registry<EntityId>*>(enttRegistry);
    const auto* pool = registry->storage(kHitboxEquipmentHash);
    if (!pool || !pool->contains(EntityId(entity))) return false;
    const auto* payload =
        static_cast<const unsigned char*>(pool->value(EntityId(entity)));
    if (!payload || !GuiRangeReadable(payload, 0x10u)) return false;

    void* container = nullptr;
    std::memcpy(&container, payload + 0x8, sizeof(container));
    void* getItem = HitboxResolveContainerGetItem(container);
    if (!getItem) return false;
    *outContainer = container;
    *outGetItem = getItem;
    return true;
}

// Armor proof: count occupied slots in ActorEquipmentComponent::mArmorContainer.
// Returns 0..4 occupied, -1 unknown.
static int HitboxActorHasArmorUnsafe(void* actor) {
    void* armorContainer = nullptr;
    void* getItem = nullptr;
    if (!HitboxResolveArmorContainer(actor, &armorContainer, &getItem))
        return -1;

    using GetItemFn = void* (__fastcall*)(void*, int);
    int count = 0;
    for (int slot = 0; slot < 4; ++slot) {
        if (HitboxItemStackPresent(
                reinterpret_cast<GetItemFn>(getItem)(armorContainer, slot)))
            ++count;
    }
    return count;
}

// Target HUD equipment strip. Slots 0..3 mirror PacketV2's armor loop
// (player->getArmor(t)); slot 4 is the held item (PacketV2 reads
// supplies->inventory->getItemStack(supplies->selectedHotbarSlot)). The armor
// container is the proven equipment component above. The held item needs
// PlayerInventoryProxy, so its chain is validated end to end first - a build
// that moved that offset drops slot 4 instead of dereferencing a wild
// pointer. Returns the number of slots probed, or 0 when even the armor
// container could not be proven.
static int HitboxReadTargetItemsUnsafe(void* actor, bool* present, int maxOut) {
    if (!actor || !present || maxOut <= 0) return 0;
    for (int i = 0; i < maxOut; ++i) present[i] = false;

    void* armorContainer = nullptr;
    void* getItem = nullptr;
    if (!HitboxResolveArmorContainer(actor, &armorContainer, &getItem))
        return 0;

    using GetItemFn = void* (__fastcall*)(void*, int);
    const int armorSlots = maxOut < 4 ? maxOut : 4;
    for (int slot = 0; slot < armorSlots; ++slot) {
        present[slot] = HitboxItemStackPresent(
            reinterpret_cast<GetItemFn>(getItem)(armorContainer, slot));
    }

    // Held item: PlayerInventoryProxy at player + 0xB70, selectedHotbarSlot at
    // +0x10, inventory at +0xB0 (PacketV2's pinned layout). Anything out of
    // range leaves the slot empty rather than trusting the read.
    if (maxOut > 4) {
        const uintptr_t player = reinterpret_cast<uintptr_t>(actor);
        void* supplies = nullptr;
        int hotbarSlot = -1;
        void* inventory = nullptr;
        if (PotionReadBytes(reinterpret_cast<const void*>(player + 0xB70u),
                            &supplies, sizeof(supplies)) &&
            supplies && GuiPageReadable(supplies) &&
            PotionReadBytes(reinterpret_cast<const void*>(
                                reinterpret_cast<uintptr_t>(supplies) + 0x10u),
                            &hotbarSlot, sizeof(hotbarSlot)) &&
            hotbarSlot >= 0 && hotbarSlot < 9 &&
            PotionReadBytes(reinterpret_cast<const void*>(
                                reinterpret_cast<uintptr_t>(supplies) + 0xB0u),
                            &inventory, sizeof(inventory)) &&
            inventory && GuiPageReadable(inventory)) {
            void* invGetItem = HitboxResolveContainerGetItem(inventory);
            if (invGetItem) {
                present[4] = HitboxItemStackPresent(
                    reinterpret_cast<GetItemFn>(invGetItem)(inventory, hotbarSlot));
            }
        }
    }
    return maxOut < 5 ? maxOut : 5;
}

static int HitboxActorArmorCount(void* actor) {
    if (!actor) return -1;
    const ULONGLONG now = GetTickCount64();
    AcquireSRWLockShared(&g_hitboxArmorCacheLock);
    for (const auto& entry : g_hitboxArmorCache) {
        if (entry.actor != actor) continue;
        if (entry.at != 0 && now - entry.at < kHitboxArmorRefreshMs) {
            const int state = entry.state;
            ReleaseSRWLockShared(&g_hitboxArmorCacheLock);
            return state;
        }
        break;
    }
    ReleaseSRWLockShared(&g_hitboxArmorCacheLock);

    int state = -1;
#ifdef _MSC_VER
    __try {
        state = HitboxActorHasArmorUnsafe(actor);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        state = -1;
    }
#else
    state = HitboxActorHasArmorUnsafe(actor);
#endif

    AcquireSRWLockExclusive(&g_hitboxArmorCacheLock);
    int slot = -1;
    ULONGLONG oldest = now;
    for (int i = 0; i < 64; ++i) {
        if (g_hitboxArmorCache[i].actor == actor) { slot = i; break; }
        if (!g_hitboxArmorCache[i].actor && slot < 0) slot = i;
        if (g_hitboxArmorCache[i].at <= oldest) {
            oldest = g_hitboxArmorCache[i].at;
            if (slot < 0) slot = i;
        }
    }
    if (slot < 0) slot = 0;
    g_hitboxArmorCache[slot] = {actor, now, state};
    ReleaseSRWLockExclusive(&g_hitboxArmorCacheLock);

    static volatile LONG armorLogged = 0;
    if (InterlockedIncrement(&armorLogged) <= 4)
        LOG_INFO("hitboxes: armor probe actor=%p count=%d (-1=unknown, 0..4=occupied slots)",
                 actor, state);
    return state;
}

// Flarial-parity per-frame capture (Hitbox::onSetupAndRender).
//
// Flarial collects its render list synchronously in the SetupAndRender hook on
// the game's render thread: the runtime actor list, each mob's lerped AABB and
// its rotation component - then the render callback only draws that snapshot.
// This function reproduces that data flow with this project's validated read
// paths. The fresh component reads and game calls (AABB re-read, canSee,
// invisible/armor probes) run on the background sampler with short refresh
// TTLs; this capture assembles the packet from those caches, so the game
// render thread never calls into the game per actor per frame.
static void HitboxCaptureFrameSync(HitboxFrameTransformSnapshot& frame) {
    frame.actorCount = 0;
    frame.eligibleCount = 0;
    frame.staleCount = 0;
    frame.aabbComplete = false;

    // Flarial's gates: clientInstance/localPlayer/level are proven by the
    // caller (transformReady). The hud_screen gate matches
    // SDK::getCurrentScreen() != "hud_screen"; outside the world the packet is
    // empty, exactly like Flarial's cleared aabbsToRender.
    if (!IsInWorld()) {
        frame.aabbComplete = true;
        // Distinct from the packet diagnostic below: this one means the whole
        // capture was gated off before any actor was even enumerated, which
        // looks identical to "actors=0" from the module's point of view.
        static ULONGLONG nextWorldDiag = 0;
        const ULONGLONG gateNow = GetTickCount64();
        if (gateNow >= nextWorldDiag) {
            nextWorldDiag = gateNow + 2000u;
            LOG_INFO("hitboxes: capture gated off - IsInWorld()=0 "
                     "(screenView=%p) no packet this frame", g_screenView);
        }
        return;
    }

    void* registry = HitboxGetWorldRegistry();
    frame.registry = registry;

    // The local player's own hitbox is never rendered (user request: no self
    // box from the F5 third-person camera). Exclude the local actor from the
    // packet: the adopted world-local first, the potion reader's live
    // resolution as a bootstrap fallback - the same source
    // HitboxEyeFromLocalPlayer already uses on this thread.
    void* local = nullptr;
    AcquireSRWLockShared(&g_hitboxWorldContextLock);
    local = g_hitboxWorldLocal;
    ReleaseSRWLockShared(&g_hitboxWorldContextLock);
    if (!local) local = HitboxLocalPlayer();
    if (!local) local = HitboxLocalPlayer();

    // Occlusion toggle (default: no boxes through walls). The canSee game
    // function is resolved by the worker gate pass; this capture never calls
    // into the game per actor.
    const bool throughWalls = false;

    const ULONGLONG now = GetTickCount64();

    // Actor list: a fresh owner walk every 250 ms (this project's equivalent
    // of Level::getRuntimeActorList - the walk itself degrades to the last
    // complete snapshot when a layout proof misses), snapshot copies between
    // walks, and the bounded baseTick list while the owner path bootstraps.
    void* actors[kHitboxFrameMaxActors] = {};
    int actorCount = 0;
    bool listComplete = false;
    static ULONGLONG lastOwnerWalkAt = 0;
    const bool doWalk = registry && (!lastOwnerWalkAt ||
                                     now - lastOwnerWalkAt >= 250u);
    if (registry) {
#ifdef _MSC_VER
        // The walk touches the game's live registry through the vendored EnTT
        // mirror. Every direct dereference inside is already fault-contained,
        // and this outer guard keeps an unforeseen fault from taking the
        // render thread down. All locals here are POD, so SEH is allowed.
        __try {
            actorCount = HitboxEnumerateOwnerActors(
                actors, kHitboxFrameMaxActors, registry, local, doWalk,
                &listComplete);
            if (doWalk && listComplete) lastOwnerWalkAt = now;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            actorCount = 0;
            listComplete = false;
        }
#else
        actorCount = HitboxEnumerateOwnerActors(actors, kHitboxFrameMaxActors,
                                                registry, local, doWalk,
                                                &listComplete);
        if (doWalk && listComplete) lastOwnerWalkAt = now;
#endif
    }
    if (!listComplete) {
        AcquireSRWLockShared(&g_hitboxActorLock);
        int tickCount = 0;
        for (const HitboxActorEntry& entry : g_hitboxActors) {
            if (!entry.actor || now - HitboxActorTick(entry) > 600u) continue;
            if (local && entry.actor == local) continue;
            actors[tickCount++] = entry.actor;
            if (tickCount >= kHitboxFrameMaxActors) break;
        }
        ReleaseSRWLockShared(&g_hitboxActorLock);
        if (tickCount > 0) {
            actorCount = tickCount;
            listComplete = true;
        }
    }
    for (int i = 0; i < actorCount && frame.eligibleCount < kHitboxFrameMaxActors; ++i)
        frame.eligibleActors[frame.eligibleCount++] = actors[i];

    // Drop counters for the packet diagnostic below: each one names the stage
    // that removed an actor from this frame's packet.
    int selfDrop = 0;
    int gateDrop = 0;
    int occlusionDrop = 0;
    int invisibleDrop = 0;

    // Per-actor packet assembly. Zero lag requires the box to describe the
    // current frame, so every kept actor is FRESH-READ here on the game's
    // render thread (Flarial's Hitbox::onSetupAndRender model, and the exact
    // behavior the anti-lag fix in this file shipped earlier). The worker
    // cache stays as the graceful fallback: a failed fresh proof keeps the
    // last good box for the bounded keep-alive window instead of blinking.
    // All reads are SEH/RPM-guarded; nothing here writes game state.
    for (int i = 0; i < actorCount; ++i) {
        void* actor = actors[i];
        if (!actor || frame.actorCount >= kHitboxFrameMaxActors) break;
        // Never carry the local player in the render packet (no self hitbox).
        if (actor == local || IsHitboxLocalPlayer(actor)) { ++selfDrop; continue; }
        // Gates: worker-evaluated cache with the same Mob/Player + canSee +
        // invisible/armor verdicts, refreshed at 150 ms. Absent entries fail
        // open; a non-target actor cannot reach a box anyway because the AABB
        // cache only holds worker-proven targets.
        bool isTarget = false, seen = false, visibleOk = false;
        HitboxCopyCachedGates(actor, isTarget, seen, visibleOk);
        if (!isTarget) { ++gateDrop; continue; }
        // Flarial Hitbox parity: player->canSee(ent) drops actors whose line
        // of sight the world geometry blocks - no boxes through walls.
        if (!throughWalls && local && !seen) { ++occlusionDrop; continue; }
        // Invisible actors are shown only while at least one armor slot holds
        // an item (their armor stays visible in the world). An unknown armor
        // state hides an invisible actor too - fail closed for invisibles.
        if (!visibleOk) { ++invisibleDrop; continue; }

        // Tick-thread-fresh box (PacketV2 model): every actor re-proves its
        // own AABB on the game tick thread, so the cache entry here is at
        // most ~50 ms old and the warm render path performs no game reads.
        // Gated: a miss must not be re-proven by every frame on this thread
        // too - the cached copy below is the whole point of the packet.
        if (HitboxAabbRetryDue(actor)) HitboxRefreshAabbEntry(actor);
        float mins[3] = {}, maxs[3] = {};
        if (!HitboxCopyCachedAabb(actor, mins, maxs)) {
            ++frame.staleCount;
            continue;
        }

        const int slot = frame.actorCount++;
        frame.actors[slot] = actor;
        frame.sampleAt[slot] = now;
        std::memcpy(frame.mins[slot], mins, sizeof(mins));
        std::memcpy(frame.maxs[slot], maxs, sizeof(maxs));

        float pitch = 0.0f, yaw = 0.0f;
        frame.rotValid[slot] = HitboxCopyCachedRotation(actor, &pitch, &yaw);
        if (frame.rotValid[slot]) {
            frame.rotPitch[slot] = pitch;
            frame.rotYaw[slot] = yaw;
        }
    }

    frame.aabbComplete = true;

    // One line a second that says exactly which stage emptied the packet. The
    // module's own "flarial-style boxes actors=0" line reports the outcome but
    // not the cause, and the counters that used to answer this were one-shot
    // and long exhausted by the time a user reports "no boxes".
    static ULONGLONG nextPacketDiag = 0;
    if (now >= nextPacketDiag) {
        nextPacketDiag = now + 1000u;
        LOG_INFO("hitboxes: packet owners=%d complete=%d kept=%d self=%d gate=%d "
                 "occlusion=%d invisible=%d noAabb=%d",
                 actorCount, listComplete ? 1 : 0, frame.actorCount,
                 selfDrop, gateDrop, occlusionDrop, invisibleDrop,
                 frame.staleCount);
    }

    // Feed the stable frame too, so the worker-side unknown-category gate
    // (HitboxStableKnowsActor) sees the same proven actor set and stops
    // dropping owner entries whose category word failed one read.
    AcquireSRWLockExclusive(&g_hitboxStableAabbLock);
    g_hitboxStableAabbFrame = frame;
    g_hitboxStableAabbValid = true;
    g_hitboxStableAabbUpdatedAt = now;
    ReleaseSRWLockExclusive(&g_hitboxStableAabbLock);
}

// PacketV2 parity: the component is read on demand, on whatever thread asks,
// instead of only through the worker's cache. PacketV2 reads the box straight
// off the entity every frame (DrawUtils::drawEntityBox), which is exactly why
// its boxes never lag and never vanish - there is no cached state that can
// expire and no sampler whose death silently empties the screen. These
// wrappers give our readers the same property while the cache stays purely an
// optimisation. Both are fault-contained, so an actor unmapped mid-read costs
// one skipped box rather than the frame.
static bool HitboxReadAabbDirect(void* actor, float mins[3], float maxs[3]) {
    if (!actor || !mins || !maxs) return false;
    bool ok = false;
#ifdef _MSC_VER
    __try {
        ok = HitboxReadAabbUnsafe(actor, mins, maxs);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        ok = false;
    }
#else
    ok = HitboxReadAabbUnsafe(actor, mins, maxs);
#endif
    return ok;
}

static bool HitboxReadRotationDirect(void* actor, float* pitchDeg, float* yawDeg) {
    if (!actor || !pitchDeg || !yawDeg) return false;
    bool ok = false;
#ifdef _MSC_VER
    __try {
        ok = HitboxReadRotationUnsafe(actor, pitchDeg, yawDeg);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        ok = false;
    }
#else
    ok = HitboxReadRotationUnsafe(actor, pitchDeg, yawDeg);
#endif
    return ok;
}

bool ActorReadAabb(void* actor, float mins[3], float maxs[3]) {
    if (!actor || !mins || !maxs) return false;

    // Flarial parity: draw exactly the packet the setup pass captured for the
    // current frame. An actor the packet does not carry has no provable box
    // this frame (the isValidAABB gate) and is skipped.
    //
    // The only caller walks the packet in the order it was built (GetActors
    // hands back that same array), so the previously matched index is almost
    // always the right one. Trying it first turns this per-actor linear scan -
    // which made the whole pass quadratic in actor count - into a single
    // comparison. A stale hint can only cost a fallback scan, never a wrong
    // result.
    static int s_hint = 0;
    AcquireSRWLockShared(&g_hitboxActiveFrameLock);
    if (HitboxPacketServesActorsLocked(GetTickCount64())) {
        const int count = g_hitboxActiveFrame.actorCount;
        int i = (s_hint >= 0 && s_hint < count &&
                 g_hitboxActiveFrame.actors[s_hint] == actor) ? s_hint : -1;
        if (i < 0) {
            for (int k = 0; k < count; ++k) {
                if (g_hitboxActiveFrame.actors[k] == actor) { i = k; break; }
            }
        }
        if (i >= 0) {
            s_hint = i;
            std::memcpy(mins, g_hitboxActiveFrame.mins[i], sizeof(float) * 3);
            std::memcpy(maxs, g_hitboxActiveFrame.maxs[i], sizeof(float) * 3);
            ReleaseSRWLockShared(&g_hitboxActiveFrameLock);
            return true;
        }
        ReleaseSRWLockShared(&g_hitboxActiveFrameLock);
        // Packet miss for a live actor (joined mid-frame, or the capture
        // skipped it under budget): fall through to the worker cache instead
        // of blinking the box for one frame. The cache below is still gated
        // by its 1 s keep-alive, so this cannot resurrect a dead actor.
        // (Returned directly here: the lock above is already released, so it
        // must not fall into the second Release below.)
        return HitboxCopyCachedAabb(actor, mins, maxs);
    }
    ReleaseSRWLockShared(&g_hitboxActiveFrameLock);

    // IMPORTANT: this function is called by the ImGui/module render thread.
    // The PacketV2 direct-read idea cannot be transplanted here: Bedrock's
    // EnTT registry and actor objects are owned by the game/render thread, and
    // a stale owner pointer can look readable while its registry fields are
    // already being torn down. The previous direct fallback did exactly that
    // in the live log (malformed registry/entity values, pool-dump faults) and
    // made the DLL unsafe. The game-thread SetupAndRender capture remains the
    // only place allowed to read live components; this consumer copies the
    // immutable packet or the worker cache only.

    // Last resort for the window before the first setup packet exists.
    return HitboxCopyCachedAabb(actor, mins, maxs);
}

bool ActorReadRotation(void* actor, float* pitchDeg, float* yawDeg) {
    if (!actor || !pitchDeg || !yawDeg) return false;

    AcquireSRWLockShared(&g_hitboxActiveFrameLock);
    if (HitboxPacketServesActorsLocked(GetTickCount64())) {
        for (int i = 0; i < g_hitboxActiveFrame.actorCount; ++i) {
            if (g_hitboxActiveFrame.actors[i] != actor) continue;
            const bool ok = g_hitboxActiveFrame.rotValid[i];
            if (ok) {
                *pitchDeg = g_hitboxActiveFrame.rotPitch[i];
                *yawDeg = g_hitboxActiveFrame.rotYaw[i];
            }
            ReleaseSRWLockShared(&g_hitboxActiveFrameLock);
            return ok;
        }
        ReleaseSRWLockShared(&g_hitboxActiveFrameLock);
        return false;
    }
    ReleaseSRWLockShared(&g_hitboxActiveFrameLock);

    // Rotation is also a game-owned EnTT read. Keep the module thread
    // read-only: the worker/frame producer owns live component access and this
    // function only consumes its immutable packet/cache. This prevents the
    // same stale-pointer race as the old direct AABB fallback.

    // Last resort for the window before the first setup packet exists.
    return HitboxCopyCachedRotation(actor, pitchDeg, yawDeg);
}

bool IsHitboxLocalPlayer(void* actor) {
    if (!actor) return false;
    // Plain aligned-pointer compare; the worker swaps this only on
    // server/world change, and a torn read here can only mis-hide one frame.
    return actor == g_hitboxWorldLocal;
}

int GetActorClass(void* actor) {
    if (!actor) return 0;
    // Same proof rules as HitboxActorIsTarget: only a readable, plausible
    // category word classifies the actor; anything else stays "unknown" so
    // the Targets filter can fail open instead of hiding the world.
    uint32_t categories = 0;
    if (!HitboxReadActorCategories(actor, &categories)) return 0;
    if (!HitboxCategoriesPlausible(categories)) return 0;
    if (categories & kHitboxPlayerCategory) return 1;
    if (categories & kHitboxMobCategory) return 2;
    return 3;
}

void UpdateCritCamera() {
    // Kept as a source-compatible no-op for older module callers. Camera and
    // actor state is selected by Present from the immutable setup snapshot;
    // resolving a live local player here would violate the render-thread rule.
}

bool ProjectWorldToScreen(const float pos[3], float* outX, float* outY,
                          float* outDepth) {
    HitboxViewReadGuard viewGuard;
    if (!pos || !outX || !outY || !g_hitboxView.matrixValid) return false;
    float x = 0.0f, y = 0.0f, z = 0.0f;
    HitboxViewTransform(pos, &x, &y, &z);
    const bool behind = (g_hitboxView.mode & 2) ? z <= 0.05f : z >= -0.05f;
    if (behind) return false;

    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x < 2.0f || screen.y < 2.0f) return false;
    const float focalX = g_hitboxView.focalX > 0.05f ? g_hitboxView.focalX : 1.428148f;
    const float focalY = g_hitboxView.focalY > 0.05f ? g_hitboxView.focalY : 1.428148f;
    const float depth = (g_hitboxView.mode & 2) ? z : -z;
    if (!std::isfinite(depth) || depth < 0.05f ||
        !std::isfinite(focalX) || !std::isfinite(focalY)) return false;
    // Same equation as Flarial's Matrix::WorldToScreen: its FrameTransform
    // stores the game-provided projection multipliers, not a guessed degree FOV.
    *outX = screen.x * 0.5f + (x / depth) * (screen.x * 0.5f) * focalX;
    *outY = screen.y * 0.5f - (y / depth) * (screen.y * 0.5f) * focalY;
    if (outDepth) *outDepth = depth;
    return std::isfinite(*outX) && std::isfinite(*outY);
}

float GetCritFocalPx() {
    HitboxViewReadGuard viewGuard;
    const ImVec2 screen = gui::GetScreenSize();
    const float focalY = g_hitboxView.focalY > 0.05f ? g_hitboxView.focalY : 1.428148f;
    return (screen.y > 1.0f && std::isfinite(focalY))
        ? (screen.y * 0.5f) * focalY : 1.0f;
}

bool GetCameraWorldPosition(float out[3]) {
    HitboxViewReadGuard viewGuard;
    if (!out || !g_hitboxView.eyeValid) return false;
    out[0] = g_hitboxView.eye[0];
    out[1] = g_hitboxView.eye[1];
    out[2] = g_hitboxView.eye[2];
    return true;
}

int GetHitboxMatrixMode() {
    HitboxViewReadGuard viewGuard;
    return g_hitboxView.matrixValid ? g_hitboxView.mode : -1;
}

int GetActors(void** out, int maxOut) {
    if (!out || maxOut <= 0) return 0;

    // Flarial parity: the render callback draws exactly the actor list the
    // setup pass captured for this frame - same frame as the camera/matrix
    // snapshot the projection uses.
    AcquireSRWLockShared(&g_hitboxActiveFrameLock);
    if (HitboxPacketServesActorsLocked(GetTickCount64())) {
        const int count = g_hitboxActiveFrame.actorCount < maxOut
                              ? g_hitboxActiveFrame.actorCount
                              : maxOut;
        if (count > 0)
            std::memcpy(out, g_hitboxActiveFrame.actors,
                        sizeof(void*) * static_cast<size_t>(count));
        ReleaseSRWLockShared(&g_hitboxActiveFrameLock);
        return count;
    }
    ReleaseSRWLockShared(&g_hitboxActiveFrameLock);

    // The packet is not authoritative this frame: either it went stale (the
    // camera proof has been failing, so nothing refreshed it) or it is fresh
    // but empty, which means the per-actor AABB copy or the owner walk produced
    // nothing while the owner snapshot still holds the real list. Serving the
    // empty packet anyway is how the module latched to actors=0 for a whole
    // session; fall through to the worker's owner snapshot instead.
    // Legacy fallback (only until the first setup packet): pair the legacy
    // renderer with the worker's immutable owner snapshot. No owner storage
    // walk, local-player call or component lookup occurs here.
    const ULONGLONG now = GetTickCount64();
    void* worldRegistry = HitboxGetWorldRegistry();
    bool complete = false;
    const int ownerCount = HitboxCopyOwnerSnapshot(
        out, maxOut, now, 5000u, worldRegistry, &complete);
    if (complete) return ownerCount;

    // During the first worker scan, baseTick provides a bounded actor pointer
    // snapshot. ActorReadAabb still accepts only worker-published cache entries.
    int count = 0;
    AcquireSRWLockShared(&g_hitboxActorLock);
    for (const HitboxActorEntry& entry : g_hitboxActors) {
        if (!entry.actor || now - HitboxActorTick(entry) > 600u) continue;
        out[count++] = entry.actor;
        if (count >= maxOut) break;
    }
    ReleaseSRWLockShared(&g_hitboxActorLock);
    return count;
}

void SetHitboxMaxDistance(float blocks) {
    if (!std::isfinite(blocks)) blocks = 20.0f;
    blocks = std::max(5.0f, std::min(30.0f, blocks));
    const LONG centimeters = static_cast<LONG>(std::lround(blocks * 100.0f));
    InterlockedExchange(&g_hitboxMaxDistanceCm, centimeters);
}

void SetHitboxThroughWalls(bool enabled) {
    (void)enabled;
    InterlockedExchange(&g_hitboxThroughWalls, 0);
}

void SetAutoSprintEnabled(bool enabled) {
    const LONG next = enabled ? 1 : 0;
    const LONG prev = InterlockedExchange(&g_autoSprintFlagsEnabled, next);
    if (prev != next)
        LOG_INFO("autosprint: move-input flag writes %s",
                 enabled ? "enabled" : "disabled");
}

// ---- RakNet ping (watermark segment) ----------------------------------------
//
// Flarial's approach: detour RakPeer::GetAveragePing (the game polls it
// itself for the network status UI) and cache whatever it returns. The game
// only polls it while connected through RakNet, so singleplayer simply lets
// the cache go stale and the watermark hides the segment.
using RakGetAvgPingFn = int (__fastcall*)(void* self, void* guid);
static RakGetAvgPingFn g_oRakGetAvgPing = nullptr;
static volatile LONG g_pingLastMs = -1;
static ULONGLONG g_pingLastAt = 0;

static __int64 __fastcall HkRakGetAveragePing(void* self, void* guid) {
    int result = 0;
#ifdef _MSC_VER
    __try {
        result = g_oRakGetAvgPing ? g_oRakGetAvgPing(self, guid) : 0;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        result = 0;
    }
#else
    result = g_oRakGetAvgPing ? g_oRakGetAvgPing(self, guid) : 0;
#endif
    InterlockedExchange(&g_pingLastMs, result);
    g_pingLastAt = GetTickCount64();
    return result;
}

void TryInstallPingHook() {
    static bool tried = false;
    if (tried || g_shuttingDown) return;
    tried = true;
    // RakPeer::GetAveragePing - Flarial SigInit::init21110 (1.21.11x).
    const char* sig =
        "48 8B C4 48 81 EC 58 01 00 00 0F 10 4A 10 4C 8B 1A 4C 3B 1D "
        "? ? ? ? 48 89 58 08 48 8B D9 0F 29 70 E8 0F 29 78 D8 0F 10 7A "
        "20 0F 11 4C 24 10 74 46 44 8B 49 14";
    uintptr_t site = 0;
    const int matches = ScanSigMatches(GetModuleHandleW(nullptr), sig, site);
    if (matches != 1 || !site) {
        LOG_INFO("ping: RakPeer::GetAveragePing matches=%d - ping off", matches);
        return;
    }
    const MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) {
        LOG_INFO("ping: MinHook init failed (%d)", (int)init);
        return;
    }
    MH_STATUS st = MH_CreateHook(reinterpret_cast<LPVOID>(site),
                                 reinterpret_cast<LPVOID>(&HkRakGetAveragePing),
                                 reinterpret_cast<LPVOID*>(&g_oRakGetAvgPing));
    if (st == MH_OK)
        st = MH_EnableHook(reinterpret_cast<LPVOID>(site));
    LOG_INFO("ping: RakPeer::GetAveragePing hook status=%d", (int)st);
}

int GetPingMs() {
    if (g_pingLastAt == 0 || GetTickCount64() - g_pingLastAt > 5000) return -1;
    return InterlockedCompareExchange(&g_pingLastMs, 0, 0);
}

// ============================ HUD editor ============================
// Free-form HUD editor (Flarial editmenu parity). g_hudEdit is only mutated
// here and by the HkPresent hotkey paths; menu.cpp reconciles the General
// "HUD Editor" setting with this state every frame, so nothing else writes it.
bool HudEditActive() {
    return g_hudEdit;
}

void HudEditSet(bool enabled) {
    g_hudEdit = enabled;
    LOG_INFO("hud editor: %s", enabled ? "on" : "off");
}

void SetVSyncDisabled(bool enabled) {
    InterlockedExchange(&g_vsyncDisabled, enabled ? 1 : 0);
    LOG_INFO("vsync: %s", enabled ? "disabled (SyncInterval forced to 0)"
                                  : "restored");
}

void SetSaturationEnabled(bool enabled) {
    InterlockedExchange(&g_saturationEnabled, enabled ? 1 : 0);
    // Silent by design: the one-shot "saturation: pass active" line logs on
    // the first frame the filter actually runs.
}

// ---- UI blur (white glass) setters: see the blur section ----
void SetUiBlurEnabled(bool enabled) {
    InterlockedExchange(&g_uiBlurEnabled, enabled ? 1 : 0);
    // Silent: the one-shot "blur: pass active" line logs on the first frame.
}

void SetUiBlurStrength(float value) {
    // Clamp to 0..1 (thousandths so a plain atomic is enough); a NaN folds 0.
    float v = value;
    if (!(v >= 0.0f)) v = 0.0f;
    if (v > 1.0f) v = 1.0f;
    InterlockedExchange64(&g_uiBlurStrength, (LONG64)(v * 1000.0f + 0.5f));
}

void SetUiBlurTint(float r, float g, float b) {
    // Clamp to 0..1 (thousandths so a plain atomic works); NaN folds 0.
    // Defaults to white (1000) so a missing tint never darkens the glass.
    float cr = r, cg = g, cb = b;
    if (!(cr >= 0.0f)) cr = 0.0f; if (cr > 1.0f) cr = 1.0f;
    if (!(cg >= 0.0f)) cg = 0.0f; if (cg > 1.0f) cg = 1.0f;
    if (!(cb >= 0.0f)) cb = 0.0f; if (cb > 1.0f) cb = 1.0f;
    InterlockedExchange(&g_uiBlurTintR, (LONG)(cr * 1000.0f + 0.5f));
    InterlockedExchange(&g_uiBlurTintG, (LONG)(cg * 1000.0f + 0.5f));
    InterlockedExchange(&g_uiBlurTintB, (LONG)(cb * 1000.0f + 0.5f));
}

void SetSaturationIntensity(float value) {
    // Clamp to the Flarial slider range 0..3; a NaN folds to 0.
    float v = value;
    if (!(v >= 0.0f)) v = 0.0f;
    if (v > 3.0f) v = 3.0f;
    InterlockedExchange(&g_saturationIntensityCm, (LONG)(v * 100.0f + 0.5f));
}

void SetMotionBlurEnabled(bool enabled) {
    const LONG prev = InterlockedExchange(&g_mbEnabled, enabled ? 1 : 0);
    // Rising edge: start from a clean history (no stale frame bleeding in).
    if (enabled && prev == 0) InterlockedExchange(&g_mbResetReq, 1);
}

void SetMotionBlurParams(float intensity, int mode, bool fpsIndependent, float refFps) {
    float v = intensity;
    if (!(v >= 0.0f)) v = 0.0f;
    if (v > 0.95f) v = 0.95f;
    InterlockedExchange(&g_mbIntensityPm, (LONG)(v * 1000.0f + 0.5f));
    const LONG newMode = mode == 1 ? 1 : 0;
    // Switching mode changes what the history holds: reseed it.
    if (InterlockedExchange(&g_mbMode, newMode) != newMode) InterlockedExchange(&g_mbResetReq, 1);
    InterlockedExchange(&g_mbFpsIndependent, fpsIndependent ? 1 : 0);
    float r = refFps;
    if (!(r >= 1.0f)) r = 60.0f;
    if (r > 1000.0f) r = 1000.0f;
    InterlockedExchange(&g_mbRefFps, (LONG)(r + 0.5f));
}

void SaturationGpuFault() {
    // Device removal also latches the motion blur pass off for the session.
    InterlockedExchange(&g_mbFailed, 1);
    // The device is gone: the pass must never touch the GPU again this
    // session. Unlike a creation failure (which arms the retryable cooldown),
    // this latches the sticky flag - teardown/reinit does not clear it (see
    // the saturation section header). Logs once.
    InterlockedExchange(&g_saturationFailed, 1);
    static bool logged = false;
    if (!logged) {
        logged = true;
        LOG_ERROR("saturation: latched off after device removal");
    }
}

void SetNullMovementEnabled(bool enabled) {
    InterlockedExchange(&g_nullMovementEnabled, enabled ? 1 : 0);
    if (!enabled) {
        for (auto& t : g_nmPressAt) InterlockedExchange64(
            reinterpret_cast<volatile LONG64*>(&t), 0);
    }
    LOG_INFO("null-movement: %s", enabled ? "enabled" : "disabled");
}

void SetNullMovementPairs(bool ad, bool ws) {
    InterlockedExchange(&g_nmPairAd, ad ? 1 : 0);
    InterlockedExchange(&g_nmPairWs, ws ? 1 : 0);
}

void SetCpsLimiterEnabled(bool enabled) {
    InterlockedExchange(&g_cpsLimiterEnabled, enabled ? 1 : 0);
    LOG_INFO("cps-limiter: %s", enabled ? "enabled" : "disabled");
}

void SetCpsLimits(int left, int right) {
    InterlockedExchange(&g_cpsLimitL, (LONG)left);
    InterlockedExchange(&g_cpsLimitR, (LONG)right);
    // Flarial's RateLimiter::setRate: on a rate change the stored tokens are
    // only capped to the new rate - lowering the limit must not leave a banked
    // burst, and raising it must not reset the bucket either.
    if (g_cpsCsInit) {
        EnterCriticalSection(&g_cpsCs);
        for (int i = 0; i < 2; ++i) {
            const double rate = (double)(i == 0 ? left : right);
            if (rate > 0.0 && g_cpsGates[i].tokens > rate)
                g_cpsGates[i].tokens = rate;
        }
        LeaveCriticalSection(&g_cpsCs);
    }
}

int GetRegisteredCps(bool left) {
    if (!g_cpsCsInit) return 0;
    const ULONGLONG now = GetTickCount64();
    CpsGate& g = g_cpsGates[left ? 0 : 1];
    int live = 0;
    EnterCriticalSection(&g_cpsCs);
    for (int i = 0; i < g.count; ++i) {
        const ULONGLONG t = g.stamps[(g.head - 1 - i + 64) % 64];
        if (now - t <= 1000) ++live;
    }
    LeaveCriticalSection(&g_cpsCs);
    return live;
}

// ---- Reach Display -----------------------------------------------------------
// Flarial ReachCounter parity: their AttackEvent hook sits on GameMode::attack
// and reads the game's own HitResult distance at the moment of the hit. This
// implementation hooks the same function (Flarial's 1.21.50+ signature) and
// computes the same distance as a ray-cast from the player's eye through the
// view direction onto the target's lerped AABB - the exact geometry the game
// ray-casts - with an eye-to-closest-point fallback. Read-only: the attack
// itself is untouched, the original always runs first.
static volatile LONG g_reachCenti = 0;   // reach in hundredths of a block
static ULONGLONG g_reachAt = 0;
using GameModeAttackFn = bool (__fastcall*)(void* gamemode, void* target,
                                            bool a3, bool a4);
static GameModeAttackFn g_oGameModeAttack = nullptr;

static void ReachOnAttack(void* local, void* target) {
    if (!local || !target) return;
    // Eye position: the camera is what the game ray-casts from in first
    // person; the player render position + eye height is the fallback.
    float eye[3] = {};
    bool eyeOk = GetCameraWorldPosition(eye);
    if (!eyeOk) {
        void* regObj = nullptr;
        void* entt = nullptr;
        uint32_t ent = 0;
        if (HitboxReadActorContextDirect(local, &regObj, &entt, &ent) &&
            entt && ent) {
            float render[3] = {};
            if (HitboxReadActorComponent(entt, ent, kHitboxRenderHash,
                                         render, sizeof(render)) &&
                std::isfinite(render[0]) && std::isfinite(render[1]) &&
                std::isfinite(render[2])) {
                eye[0] = render[0];
                eye[1] = render[1] + 1.62f;
                eye[2] = render[2];
                eyeOk = true;
            }
        }
    }
    if (!eyeOk) return;

    // Target box at hit time (the lerped AABB, same values the hitboxes use).
    float mins[3] = {}, maxs[3] = {};
    if (!HitboxReadAabbUnsafe(target, mins, maxs)) return;

    // Reach = eye -> closest point on the target box. That is the same
    // quantity Bedrock's interaction range check measures, and unlike a
    // view-ray estimate it can never be inflated by an aim-angle artifact.
    float closest[3];
    for (int a = 0; a < 3; ++a)
        closest[a] = eye[a] < mins[a] ? mins[a]
                   : eye[a] > maxs[a] ? maxs[a] : eye[a];
    const float dx = closest[0] - eye[0], dy = closest[1] - eye[1],
                dz = closest[2] - eye[2];
    const float reach = std::sqrt(dx * dx + dy * dy + dz * dz);
    if (!std::isfinite(reach)) return;
    // Bedrock survival attacks only land within ~3 blocks: a reading above
    // that means a stale/lagged sample, not a real hit geometry - reject it
    // and keep the previous value instead of publishing nonsense.
    if (reach < 0.0f || reach > 3.05f) return;
    InterlockedExchange(&g_reachCenti, (LONG)(reach * 100.0f + 0.5f));
    g_reachAt = GetTickCount64();
}

// Target HUD (PacketV2) globals: the displayed target is the single nearest
// player; the attack hook remembers my last victim for particle attribution.
void* g_tiTarget = nullptr;
static char g_tiName[24] = "Player";
static float g_tiPos[3] = {};
static ULONGLONG g_tiUpdateAt = 0;
static volatile LONG g_tiDamageGen = 0;
static volatile LONG g_tiDamageAt = 0;
bool g_tiLastHurt = false;
static void* g_tiMyHitTarget = nullptr;
static ULONGLONG g_tiMyHitAt = 0;
// PacketV2 targethud>1 parity: the card appears only after 2 consecutive
// proximity scans agree there is exactly one player in range, so two players
// crossing the 10-block line do not strobe the card.
int g_tiStable = 0;
// Worker-side equipment presence snapshot for the displayed target
// (PacketV2's armor loop + held item, presence only). Probed on the worker
// thread where game reads are allowed; the render thread only copies this.
static SRWLOCK g_tiItemsLock = SRWLOCK_INIT;
static bool g_tiItems[5] = {};
static ULONGLONG g_tiItemsAt = 0;
static void* g_tiItemsActor = nullptr;

static __int64 __fastcall HkGameModeAttack(void* gamemode, void* target,
                                           bool a3, bool a4) {
    __int64 result = 0;
#ifdef _MSC_VER
    __try {
        result = g_oGameModeAttack
                     ? (bool)g_oGameModeAttack(gamemode, target, a3, a4)
                     : 0;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return 0;
    }
#else
    result = g_oGameModeAttack ? (bool)g_oGameModeAttack(gamemode, target, a3, a4) : 0;
#endif
    // Attribute the hit: only the local player's own GameMode (Player::
    // gamemode = 1.21.11x offset 0xA78, Flarial's pinned table).
    if (target && !g_shuttingDown) {
        AcquireSRWLockShared(&g_hitboxWorldContextLock);
        void* local = g_hitboxWorldLocal;
        ReleaseSRWLockShared(&g_hitboxWorldContextLock);
        if (local) {
            void* own = nullptr;
            if (PotionReadBytes(
                    reinterpret_cast<const void*>(
                        reinterpret_cast<uintptr_t>(local) + 0xA78u),
                    &own, sizeof(own)) &&
                own == gamemode) {
                ReachOnAttack(local, target);
                // Target HUD particles: remember my last attack victim so the
                // burst only fires when the Hurt edge belongs to my hit.
                g_tiMyHitTarget = target;
                g_tiMyHitAt = GetTickCount64();
            }
        }
    }
    return result;
}

void TryInstallReachHook() {
    static bool tried = false;
    if (tried || g_shuttingDown) return;
    tried = true;
    // GameMode::attack - Flarial SigInit::init2150 (1.21.50+ prologue form,
    // the variant their 21.50+ hook uses on every later version).
    const char* sig =
        "48 89 ? ? ? 48 89 ? ? ? 48 89 ? ? ? 55 41 ? 41 ? 41 ? 41 ? "
        "48 8D ? ? ? ? ? ? 48 81 EC ? ? ? ? 48 8B ? ? ? ? ? 48 33 ? "
        "48 89 ? ? ? ? ? 45 0F ? ? 4C 8B ? 48 8B ? 45 33 ? 44 89";
    uintptr_t site = 0;
    const int matches = ScanSigMatches(GetModuleHandleW(nullptr), sig, site);
    if (matches != 1 || !site || !JavaIsGameCodeAddress(site)) {
        LOG_INFO("reach: GameMode::attack matches=%d - reach display off",
                 matches);
        return;
    }
    const MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) {
        LOG_INFO("reach: MinHook init failed (%d)", (int)init);
        return;
    }
    MH_STATUS st = MH_CreateHook(reinterpret_cast<LPVOID>(site),
                                 reinterpret_cast<LPVOID>(&HkGameModeAttack),
                                 reinterpret_cast<LPVOID*>(&g_oGameModeAttack));
    if (st == MH_OK)
        st = MH_EnableHook(reinterpret_cast<LPVOID>(site));
    LOG_INFO("reach: GameMode::attack hook status=%d target=%p", (int)st,
             (void*)site);
}

float GetReachValue() {
    // Flarial resets the displayed reach to 0 after 15 s without a hit.
    if (g_reachAt == 0 || GetTickCount64() - g_reachAt > 15000) return 0.0f;
    return InterlockedCompareExchange(&g_reachCenti, 0, 0) / 100.0f;
}

// ---- Target HUD tracking (crosshair target) ---------------------------------
// Selection: the render thread (UpdateTargetLook) projects the frame packet's
// hitboxes - the same occlusion-filtered actor list the Hitboxes module draws -
// and publishes the nearest player whose box contains the screen centre. The
// worker below validates that pointer against a fresh owner walk before it
// touches the actor, then reads name, health, hurt state and skin face. The
// card hides lookHideMs (default 300) after the crosshair leaves the player.
//
// Damage source (what the user asked for: the TARGET taking damage, not my
// clicks): Actor::hurtTime (int16 @0x19C, Flarial OffsetInit::init2150, still
// valid on 1.21.11x) is set to 10 by the client when the server reports a hurt
// event and ticks down. A rising edge = one real damage event, no matter how
// fast I click (the target is invulnerable for the hurt window anyway). The
// synched ActorDataIDs::Hurt flag stays as a fallback when hurtTime reads
// implausible values. Globals live above HkGameModeAttack.

static void* volatile g_tiLookActor = nullptr;
static volatile LONG64 g_tiLookAt = 0;
static volatile LONG g_tiHideMs = 300;
static float g_tiHealth = 0.0f, g_tiMaxHealth = 20.0f;
static bool g_tiHealthValid = false;
static int g_tiHurtTime = -1;
static int g_tiLastHurtTime = 0;
static int g_tiHurtTimeBad = 0;          // implausible samples (fallback gate)
static unsigned int g_tiFace[64] = {};
static bool g_tiFaceValid = false;

// Hurt flag from the SynchedActorData pool: data id 11 byte at DataItem+0x0C.
static bool ThReadHurtFlag(void* actor) {
    void* regObj = nullptr;
    void* entt = nullptr;
    uint32_t ent = 0;
    if (!HitboxReadActorContextDirect(actor, &regObj, &entt, &ent) || !entt || !ent)
        return false;
    bool hurt = false;
#ifdef _MSC_VER
    __try {
#endif
        const auto* registry =
            reinterpret_cast<const entt::basic_registry<EntityId>*>(entt);
        const auto* pool = registry->storage(kHitboxSynchedDataHash);
        if (pool && pool->contains(EntityId(ent))) {
            const auto* payload =
                static_cast<const unsigned char*>(pool->value(EntityId(ent)));
            if (payload && GuiRangeReadable(payload, 0x48u)) {
                void* begin = nullptr;
                void* end = nullptr;
                std::memcpy(&begin, payload + 0x00, sizeof(begin));
                std::memcpy(&end, payload + 0x08, sizeof(end));
                const uintptr_t b = reinterpret_cast<uintptr_t>(begin);
                const uintptr_t e = reinterpret_cast<uintptr_t>(end);
                if (b && e > b && (e - b) % sizeof(void*) == 0 &&
                    (e - b) / sizeof(void*) <= 256 &&
                    GuiRangeReadable(begin, static_cast<size_t>(e - b))) {
                    const size_t hurtIndex = 11;   // ActorDataIDs::Hurt
                    const size_t count = (e - b) / sizeof(void*);
                    if (hurtIndex < count) {
                        void* item = nullptr;
                        std::memcpy(&item,
                                    reinterpret_cast<const void*>(
                                        b + hurtIndex * sizeof(void*)),
                                    sizeof(item));
                        if (item && GuiPageReadable(item)) {
                            unsigned char value = 0;
                            if (PotionReadBytes(
                                    reinterpret_cast<const void*>(
                                        reinterpret_cast<uintptr_t>(item) + 0x0Cu),
                                    &value, sizeof(value)))
                                hurt = value != 0;
                        }
                    }
                }
            }
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        hurt = false;
    }
#endif
    return hurt;
}

// Actor::hurtTime (int16 @0x19C). -1 = unreadable / implausible.
static int ThReadHurtTime(void* actor) {
    if (!actor) return -1;
    int16_t v = 0;
    if (!PotionReadBytes(reinterpret_cast<const void*>(
                             reinterpret_cast<uintptr_t>(actor) + 0x19Cu),
                         &v, sizeof(v)))
        return -1;
    if (v < 0 || v > 20) return -1;
    return (int)v;
}

// Health from AttributesComponent. 1.21.11x (pre-1.21.130) keeps
// BaseAttributeMap::mInstanceMap as an MSVC std::unordered_map<uint,
// AttributeInstance> at +0x00: traits (8) | list {head, size} @+0x08 |
// bucket vector @+0x18 | mask | maxidx = 64 bytes. List node = {next, prev,
// pair<const uint, AttributeInstance>} with the key at +0x10 and the
// instance at +0x18. AttributeInstance::mCurrentValue @+0x7C (Flarial
// init2160), mCurrentMaxValue right before it @+0x78. Health id = 6
// (Flarial init21110). Every step is range-checked; any doubt = false.
static bool ThReadHealth(void* actor, float* outHp, float* outMax) {
    void* regObj = nullptr;
    void* entt = nullptr;
    uint32_t ent = 0;
    if (!HitboxReadActorContextDirect(actor, &regObj, &entt, &ent) || !entt || !ent)
        return false;
    constexpr uint32_t kAttributesHash = entt::type_hash<AttributesComponent>::value();
    constexpr unsigned kHealthId = 6;
    bool ok = false;
#ifdef _MSC_VER
    __try {
#endif
        const auto* registry =
            reinterpret_cast<const entt::basic_registry<EntityId>*>(entt);
        const auto* pool = registry->storage(kAttributesHash);
        if (pool && pool->contains(EntityId(ent))) {
            const auto* payload =
                static_cast<const unsigned char*>(pool->value(EntityId(ent)));
            if (payload && GuiRangeReadable(payload, 64u)) {
                uintptr_t head = 0, size = 0;
                std::memcpy(&head, payload + 0x08, sizeof(head));
                std::memcpy(&size, payload + 0x10, sizeof(size));
                if (head && size > 0 && size <= 128 &&
                    GuiRangeReadable(reinterpret_cast<const void*>(head), 16u)) {
                    uintptr_t node = 0;
                    std::memcpy(&node, reinterpret_cast<const void*>(head), sizeof(node));
                    for (size_t i = 0; i <= size && node && node != head; ++i) {
                        if (!GuiRangeReadable(reinterpret_cast<const void*>(node), 0x18u + 0x80u))
                            break;
                        uint32_t key = 0;
                        std::memcpy(&key, reinterpret_cast<const void*>(node + 0x10), sizeof(key));
                        if (key == kHealthId) {
                            float cur = 0.0f, mx = 0.0f;
                            std::memcpy(&cur, reinterpret_cast<const void*>(node + 0x18 + 0x7C), sizeof(cur));
                            std::memcpy(&mx, reinterpret_cast<const void*>(node + 0x18 + 0x78), sizeof(mx));
                            if (std::isfinite(cur) && cur >= 0.0f && cur <= 4096.0f) {
                                if (!std::isfinite(mx) || mx < 1.0f || mx > 4096.0f || cur > mx + 0.01f)
                                    mx = cur > 20.0f ? cur : 20.0f;
                                *outHp = cur;
                                *outMax = mx;
                                ok = true;
                            }
                            break;
                        }
                        uintptr_t next = 0;
                        std::memcpy(&next, reinterpret_cast<const void*>(node), sizeof(next));
                        node = next;
                    }
                }
            }
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        ok = false;
    }
#endif
    return ok;
}

// ---- skin face (player list) -----------------------------------------------
// Flarial 1.21.9x+ path: Level (Actor+0x1D8) -> Level+0x4E8 holds a pointer
// to std::unordered_map<mcUUID, PlayerListEntry_1_21_90>. Entry layout:
// id @0x00, UUID @0x08, name std::string @0x18, XUID @0x38, platformId @0x58,
// buildPlatform @0x78, shared_ptr<ThreadOwner<PlayerSkin>> @0x80 (object
// pointer first). ThreadOwner::mObject is at +0, PlayerSkin::mSkinImage at
// +0xA0: {format u32, width u32 @+4, height u32 @+8, depth, usage, Blob @+0x18}
// where Blob = unique_ptr<uint8[], Deleter> + size @+0x10. The unique_ptr's
// pointer may sit at +0x00 or +0x08 (deleter first); the heap pointer is the
// one that is readable for `size` bytes and is not game code.
static bool ThReadActorName(void* actor, char* out, size_t cap) {
    if (!actor || !out || cap < 2) return false;
    out[0] = 0;

    // Scan 8-byte aligned offsets around the Actor name fields (0xB80 to 0xD00)
    for (uintptr_t off = 0xB80u; off <= 0xD20u; off += 8u) {
        char candidate[32] = {};
        if (JavaReadMsvcString(reinterpret_cast<const void*>(
                                   reinterpret_cast<uintptr_t>(actor) + off),
                               candidate, sizeof(candidate)) &&
            candidate[0] != 0 && std::strlen(candidate) >= 1 && std::strlen(candidate) <= 24) {
            bool valid = true;
            for (const char* p = candidate; *p; ++p) {
                if ((unsigned char)*p < 32 || (unsigned char)*p > 126) { valid = false; break; }
            }
            if (valid) {
                std::strncpy(out, candidate, cap - 1);
                out[cap - 1] = 0;
                return true;
            }
        }
    }

    // Fallback: read from SynchedActorDataComponent (ActorDataIDs::Name = 4)
    void* regObj = nullptr;
    void* entt = nullptr;
    uint32_t ent = 0;
    if (HitboxReadActorContextDirect(actor, &regObj, &entt, &ent) && entt && ent) {
#ifdef _MSC_VER
        __try {
#endif
            const auto* registry = reinterpret_cast<const entt::basic_registry<EntityId>*>(entt);
            const auto* pool = registry->storage(kHitboxSynchedDataHash);
            if (pool && pool->contains(EntityId(ent))) {
                const auto* payload = static_cast<const unsigned char*>(pool->value(EntityId(ent)));
                if (payload && GuiRangeReadable(payload, 0x20u)) {
                    void* begin = nullptr;
                    void* end = nullptr;
                    std::memcpy(&begin, payload + 0x00, sizeof(begin));
                    std::memcpy(&end, payload + 0x08, sizeof(end));
                    const uintptr_t b = reinterpret_cast<uintptr_t>(begin);
                    const uintptr_t e = reinterpret_cast<uintptr_t>(end);
                    if (b && e > b && (e - b) % sizeof(void*) == 0) {
                        const size_t count = (e - b) / sizeof(void*);
                        if (count > 4) {
                            void* item = nullptr;
                            std::memcpy(&item, reinterpret_cast<const void*>(b + 4 * sizeof(void*)), sizeof(item));
                            if (item && GuiPageReadable(item)) {
                                char candidate[32] = {};
                                // SynchedActorData string item stores std::string at item + 0x10 or item + 0x08
                                if (JavaReadMsvcString(reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(item) + 0x10u), candidate, sizeof(candidate)) ||
                                    JavaReadMsvcString(reinterpret_cast<const void*>(reinterpret_cast<uintptr_t>(item) + 0x08u), candidate, sizeof(candidate))) {
                                    if (candidate[0] != 0 && std::strlen(candidate) <= 24) {
                                        std::strncpy(out, candidate, cap - 1);
                                        out[cap - 1] = 0;
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
#ifdef _MSC_VER
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
#endif
    }
    return false;
}

static bool ThFindSkinFace(void* local, const char* name, unsigned int outFace[64], char* outFoundName = nullptr, size_t outFoundNameCap = 0) {
    if (!name || !name[0]) return false;
    bool ok = false;
#ifdef _MSC_VER
    __try {
#endif
        uintptr_t level = 0;
        if (local) {
            PotionReadBytes(reinterpret_cast<const void*>(
                                reinterpret_cast<uintptr_t>(local) + 0x1D8u),
                            &level, sizeof(level));
        }
        if (!level && g_tiTarget) {
            PotionReadBytes(reinterpret_cast<const void*>(
                                reinterpret_cast<uintptr_t>(g_tiTarget) + 0x1D8u),
                            &level, sizeof(level));
        }
        if (level && GuiRangeReadable(reinterpret_cast<const void*>(level + 0x4E8u), 8u)) {
            uintptr_t map = 0;
            std::memcpy(&map, reinterpret_cast<const void*>(level + 0x4E8u), sizeof(map));
            if (map && GuiRangeReadable(reinterpret_cast<const void*>(map), 64u)) {
                uintptr_t head = 0, size = 0;
                std::memcpy(&head, reinterpret_cast<const void*>(map + 0x08), sizeof(head));
                std::memcpy(&size, reinterpret_cast<const void*>(map + 0x10), sizeof(size));
                if (head && size > 0 && size <= 1024 &&
                    GuiRangeReadable(reinterpret_cast<const void*>(head), 16u)) {
                    uintptr_t node = 0;
                    std::memcpy(&node, reinterpret_cast<const void*>(head), sizeof(node));
                    for (size_t i = 0; i <= size && node && node != head && !ok; ++i) {
                        if (!GuiRangeReadable(reinterpret_cast<const void*>(node), 0x20u + 0x90u))
                            break;
                        const uintptr_t entry = node + 0x20;
                        char entryName[40] = {};
                        const bool hasName = JavaReadMsvcString(reinterpret_cast<const void*>(entry + 0x18),
                                                                entryName, sizeof(entryName));
                        const bool matchName = hasName && _stricmp(entryName, name) == 0;
                        // Only match if exact name matches
                        if (matchName) {
                            uintptr_t owner = 0;
                            std::memcpy(&owner, reinterpret_cast<const void*>(entry + 0x80), sizeof(owner));
                            const uintptr_t img = owner + 0xA0;
                            if (owner && GuiRangeReadable(reinterpret_cast<const void*>(img), 0x30u)) {
                                uint32_t w = 0, h = 0;
                                uintptr_t q0 = 0, q1 = 0, bytes = 0;
                                std::memcpy(&w, reinterpret_cast<const void*>(img + 0x04), 4);
                                std::memcpy(&h, reinterpret_cast<const void*>(img + 0x08), 4);
                                std::memcpy(&q0, reinterpret_cast<const void*>(img + 0x18), 8);
                                std::memcpy(&q1, reinterpret_cast<const void*>(img + 0x20), 8);
                                std::memcpy(&bytes, reinterpret_cast<const void*>(img + 0x28), 8);
                                const bool dimsOk =
                                    (w == 64 || w == 128 || w == 256 || w == 512) &&
                                    (h == w || h * 2 == w) &&
                                    bytes == (uintptr_t)w * h * 4u;
                                uintptr_t data = 0;
                                if (dimsOk) {
                                    if (q0 && !JavaIsGameCodeAddress(q0) &&
                                        GuiRangeReadable(reinterpret_cast<const void*>(q0), (size_t)bytes))
                                        data = q0;
                                    else if (q1 && !JavaIsGameCodeAddress(q1) &&
                                             GuiRangeReadable(reinterpret_cast<const void*>(q1), (size_t)bytes))
                                        data = q1;
                                }
                                if (data) {
                                    const uint32_t sc = w / 64u;
                                    const unsigned char* px = reinterpret_cast<const unsigned char*>(data);
                                    int opaque = 0;
                                    for (int y = 0; y < 8; ++y) {
                                        for (int x = 0; x < 8; ++x) {
                                            const uint32_t fx = (8u + x) * sc + sc / 2u;
                                            const uint32_t fy = (8u + y) * sc + sc / 2u;
                                            const uint32_t hx = (40u + x) * sc + sc / 2u;
                                            const unsigned char* f = px + ((size_t)fy * w + fx) * 4u;
                                            const unsigned char* t = px + ((size_t)fy * w + hx) * 4u;
                                            unsigned r = f[0], g = f[1], b = f[2];
                                            if (f[3] > 16) ++opaque;
                                            // Hat layer (alpha blended over the face).
                                            const unsigned ha = t[3];
                                            if (ha > 0) {
                                                r = (t[0] * ha + r * (255u - ha)) / 255u;
                                                g = (t[1] * ha + g * (255u - ha)) / 255u;
                                                b = (t[2] * ha + b * (255u - ha)) / 255u;
                                            }
                                            outFace[y * 8 + x] = IM_COL32(r, g, b, 255);
                                        }
                                    }
                                    // An all-transparent face is not a real skin read.
                                    ok = opaque >= 32;
                                    if (ok && outFoundName && outFoundNameCap > 0 && hasName && entryName[0]) {
                                        std::strncpy(outFoundName, entryName, outFoundNameCap - 1);
                                        outFoundName[outFoundNameCap - 1] = 0;
                                    }
                                }
                            }
                        }
                        uintptr_t next = 0;
                        std::memcpy(&next, reinterpret_cast<const void*>(node), sizeof(next));
                        node = next;
                    }
                }
            }
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        ok = false;
    }
#endif
    return ok;
}

// Worker-side poll (~8 ms): validate the looked-at actor, then read its
// name / health / hurt state; skin face once per target (retry every 3 s).
static void ThPollTargetInfo() {
    const ULONGLONG now = GetTickCount64();
    if (g_shuttingDown) return;
    void* registryNow = HitboxGetWorldRegistry();
    static void* tiLastRegistry = nullptr;
    if (registryNow && tiLastRegistry != registryNow) {
        tiLastRegistry = registryNow;
        g_tiTarget = nullptr;
        g_tiLastHurt = false;
        g_tiStable = 0;
        g_tiLookActor = nullptr;
    }

    const ULONGLONG lookAt = (ULONGLONG)InterlockedCompareExchange64(&g_tiLookAt, 0, 0);
    const ULONGLONG hideMs = (ULONGLONG)InterlockedCompareExchange(&g_tiHideMs, 0, 0);
    void* look = g_tiLookActor ? g_tiLookActor : g_tiTarget;
    if (!look) return;

    void* local = nullptr;
    AcquireSRWLockShared(&g_hitboxWorldContextLock);
    local = g_hitboxWorldLocal;
    ReleaseSRWLockShared(&g_hitboxWorldContextLock);
    if (!local) local = HitboxLocalPlayer();

    static void* s_lastInitializedTarget = nullptr;
    static ULONGLONG faceRetryAt = 0;
    if (look != s_lastInitializedTarget) {
        s_lastInitializedTarget = look;
        if (!look || look == local) return;
        g_tiTarget = look;
        uint32_t categories = 0;
        if (HitboxReadActorCategories(look, &categories) &&
            HitboxCategoriesPlausible(categories) &&
            (categories & kHitboxPlayerCategory) == 0) {
            return;   // not a player
        }
        g_tiTarget = look;
        g_tiLastHurt = false;
        g_tiStable = 2;
        g_tiLastHurtTime = ThReadHurtTime(look);
        if (g_tiLastHurtTime < 0) g_tiLastHurtTime = 0;
        g_tiHurtTimeBad = 0;
        g_tiHealthValid = false;
        g_tiFaceValid = false;
        faceRetryAt = 0;

        char candidate[32] = {};
        bool named = ThReadActorName(look, candidate, sizeof(candidate));
        JavaEnsureCs();
        EnterCriticalSection(&g_javaCs);
        std::strncpy(g_tiName, named ? candidate : "Player", sizeof(g_tiName) - 1);
        g_tiName[sizeof(g_tiName) - 1] = 0;
        LeaveCriticalSection(&g_javaCs);
    }
    void* target = g_tiTarget;
    if (!target) return;
    g_tiUpdateAt = now;

// Position (distance line): try direct render component first, then AABB center fallback.
    {
        bool posOk = false;
        void* regObj = nullptr;
        void* entt = nullptr;
        uint32_t ent = 0;
        float pos[3] = {};
        if (HitboxReadActorContextDirect(target, &regObj, &entt, &ent) && entt && ent &&
            HitboxReadActorComponent(entt, ent, kHitboxRenderHash, pos, sizeof(pos)) &&
            std::isfinite(pos[0]) && std::isfinite(pos[1]) && std::isfinite(pos[2])) {
            std::memcpy(g_tiPos, pos, sizeof(g_tiPos));
            posOk = true;
        }
        if (!posOk) {
            float mn[3] = {}, mx[3] = {};
            if (ActorReadAabb(target, mn, mx)) {
                g_tiPos[0] = (mn[0] + mx[0]) * 0.5f;
                g_tiPos[1] = mn[1]; // feet height matches RenderPositionComponent
                g_tiPos[2] = (mn[2] + mx[2]) * 0.5f;
            }
        }
    }

    // Health.
    {
        float hp = 0.0f, mx = 20.0f;
        if (ThReadHealth(target, &hp, &mx)) {
            g_tiHealth = hp;
            g_tiMaxHealth = mx;
            g_tiHealthValid = true;
        }
    }

    // Skin face (player list), once per target.
    if (!g_tiFaceValid && now >= faceRetryAt) {
        faceRetryAt = now + 1000u;
        char nameCopy[24] = {};
        JavaEnsureCs();
        EnterCriticalSection(&g_javaCs);
        std::memcpy(nameCopy, g_tiName, sizeof(nameCopy));
        LeaveCriticalSection(&g_javaCs);
        unsigned int face[64] = {};
        char resolvedName[40] = {};
        if (ThFindSkinFace(local, nameCopy, face, resolvedName, sizeof(resolvedName))) {
            std::memcpy(g_tiFace, face, sizeof(g_tiFace));
            g_tiFaceValid = true;
            if (resolvedName[0] != 0 && (std::strcmp(nameCopy, "Player") == 0 || nameCopy[0] == 0)) {
                JavaEnsureCs();
                EnterCriticalSection(&g_javaCs);
                std::strncpy(g_tiName, resolvedName, sizeof(g_tiName) - 1);
                g_tiName[sizeof(g_tiName) - 1] = 0;
                LeaveCriticalSection(&g_javaCs);
            }
        }
    }

    // Damage events: hurtTime rising edge (primary), Hurt flag (fallback).
    const int ht = ThReadHurtTime(target);
    bool damage = false;
    if (ht >= 0) {
        if (ht > g_tiLastHurtTime && ht >= 6) damage = true;
        g_tiLastHurtTime = ht;
        g_tiHurtTimeBad = 0;
    } else if (g_tiHurtTimeBad < 1000) {
        ++g_tiHurtTimeBad;
    }
    g_tiHurtTime = ht;
    const bool hurt = ThReadHurtFlag(target);
    if (ht < 0 && g_tiHurtTimeBad > 3 && hurt && !g_tiLastHurt) damage = true;
    g_tiLastHurt = hurt;
    if (damage) {
        InterlockedExchange(&g_tiDamageAt, (LONG)now);
        InterlockedIncrement(&g_tiDamageGen);
    }
}

void UpdateTargetLook(float maxRange, int hideMs) {
    if (hideMs < 0) hideMs = 0;
    if (hideMs > 5000) hideMs = 5000;
    InterlockedExchange(&g_tiHideMs, (LONG)hideMs);

    // Hard ceiling: maximum 6.0 blocks distance (user requirement)
    const float kMaxAllowedRange = 6.0f;
    if (!std::isfinite(maxRange) || maxRange < 1.0f) maxRange = 1.0f;
    if (maxRange > kMaxAllowedRange) maxRange = kMaxAllowedRange;

    if (!IsGameplayScreen()) return;   // menus: no new samples (card times out)

    float cam[3] = {};
    if (!GetCameraWorldPosition(cam)) {
        if (!HitboxEyeFromLocalPlayer(cam)) {
            float fx = 0.0f, fy = 0.0f;
            if (!HitboxReadRetainedEye(cam, &fx, &fy)) return;
        }
    }
    const ImVec2 screen = gui::GetScreenSize();
    if (screen.x < 2.0f || screen.y < 2.0f) return;
    const float cx = screen.x * 0.5f, cy = screen.y * 0.5f;

    void* actors[256] = {};
    const int count = GetActors(actors, 256);
    void* best = nullptr;
    float bestAimDistSq = FLT_MAX; // distance from crosshair to target center on screen

    for (int i = 0; i < count; ++i) {
        void* a = actors[i];
        if (!a || IsHitboxLocalPlayer(a)) continue;
        const int cls = GetActorClass(a);
        if (cls != 1 && cls != 0) continue;   // players only

        bool isTarget = true, seen = true, visibleOk = true;
        HitboxCopyCachedGates(a, isTarget, seen, visibleOk);
        if (!visibleOk) continue;

        float mn[3], mx[3];
        if (!ActorReadAabb(a, mn, mx)) continue;

        // Bedrock pick box: grown slightly for pick tolerance
        float pmn[3], pmx[3];
        for (int k = 0; k < 3; ++k) {
            pmn[k] = mn[k] - 0.1f;
            pmx[k] = mx[k] + 0.1f;
        }

        // 3D Distance from eye to closest point of the box
        float d2 = 0.0f;
        for (int k = 0; k < 3; ++k) {
            const float c = cam[k] < pmn[k] ? pmn[k] : (cam[k] > pmx[k] ? pmx[k] : cam[k]);
            d2 += (cam[k] - c) * (cam[k] - c);
        }
        const float dist = std::sqrt(d2);
        // Strict distance cutoff: maximum 6.0 blocks (never target beyond this)
        if (dist > maxRange) continue;

        // Projected screen rectangle of the 8 corners
        float x0 = FLT_MAX, y0 = FLT_MAX, x1 = -FLT_MAX, y1 = -FLT_MAX;
        int projected = 0;
        for (int c = 0; c < 8; ++c) {
            const float p[3] = { (c & 1) ? pmx[0] : pmn[0], (c & 2) ? pmx[1] : pmn[1],
                                 (c & 4) ? pmx[2] : pmn[2] };
            float sx = 0.0f, sy = 0.0f;
            if (!ProjectWorldToScreen(p, &sx, &sy)) continue;
            ++projected;
            x0 = std::min(x0, sx); y0 = std::min(y0, sy);
            x1 = std::max(x1, sx); y1 = std::max(y1, sy);
        }

        if (projected == 0) continue; // Behind player or not on screen

        // Crosshair check: padding of 40px around player screen rectangle
        const float pad = 40.0f;
        const bool insideBox = (cx >= (x0 - pad) && cx <= (x1 + pad) &&
                                cy >= (y0 - pad) && cy <= (y1 + pad));
        if (!insideBox) continue;

        // Aim distance: distance from crosshair (cx, cy) to box center on screen
        const float midX = (x0 + x1) * 0.5f;
        const float midY = (y0 + y1) * 0.5f;
        const float aimDistSq = (cx - midX) * (cx - midX) + (cy - midY) * (cy - midY);

        // Pick the player closest to the crosshair (whomever user is looking at directly)
        if (aimDistSq < bestAimDistSq) {
            bestAimDistSq = aimDistSq;
            best = a;
        }
    }

    if (best) {
        if (g_tiTarget != best) {
            // Switched to a different player: immediately update target and refresh info
            g_tiTarget = best;
            g_tiLookActor = best;
            g_tiUpdateAt = GetTickCount64();
            InterlockedExchange64(&g_tiLookAt, (LONG64)GetTickCount64());

            // Clear old target state immediately so it never shows on new target
            g_tiFaceValid = false;
            std::memset(g_tiFace, 0, sizeof(g_tiFace));
            g_tiHealthValid = false;
            g_tiLastHurt = false;
            g_tiLastHurtTime = 0;

            // Immediately calculate new target position from AABB so distance updates instantly
            float bmn[3] = {}, bmx[3] = {};
            if (ActorReadAabb(best, bmn, bmx)) {
                g_tiPos[0] = (bmn[0] + bmx[0]) * 0.5f;
                g_tiPos[1] = bmn[1];
                g_tiPos[2] = (bmn[2] + bmx[2]) * 0.5f;
            }

            char quickName[32] = {};
            if (ThReadActorName(best, quickName, sizeof(quickName)) && quickName[0]) {
                JavaEnsureCs();
                EnterCriticalSection(&g_javaCs);
                std::strncpy(g_tiName, quickName, sizeof(g_tiName) - 1);
                g_tiName[sizeof(g_tiName) - 1] = 0;
                LeaveCriticalSection(&g_javaCs);
            } else {
                JavaEnsureCs();
                EnterCriticalSection(&g_javaCs);
                std::strncpy(g_tiName, "Player", sizeof(g_tiName) - 1);
                g_tiName[sizeof(g_tiName) - 1] = 0;
                LeaveCriticalSection(&g_javaCs);
            }
        } else {
            g_tiLookActor = best;
            g_tiUpdateAt = GetTickCount64();
            InterlockedExchange64(&g_tiLookAt, (LONG64)GetTickCount64());
        }
    }
}

bool GetTargetHudInfo(TargetHudInfo* out) {
    if (!out) return false;
    const ULONGLONG now = GetTickCount64();
    const ULONGLONG lookAt = (ULONGLONG)InterlockedCompareExchange64(&g_tiLookAt, 0, 0);
    const ULONGLONG hideMs = (ULONGLONG)InterlockedCompareExchange(&g_tiHideMs, 0, 0);
    const ULONGLONG effectiveHide = hideMs < 600u ? 600u : hideMs;
    const bool visible = g_tiTarget != nullptr &&
                         ((lookAt != 0 && now - lookAt <= effectiveHide) || (now - g_tiUpdateAt <= effectiveHide));
    if (!visible) return false;
    out->visible = true;
    JavaEnsureCs();
    EnterCriticalSection(&g_javaCs);
    std::strncpy(out->name, g_tiName, sizeof(out->name) - 1);
    out->name[sizeof(out->name) - 1] = 0;
    LeaveCriticalSection(&g_javaCs);
    std::memcpy(out->pos, g_tiPos, sizeof(out->pos));
    out->updateAt = g_tiUpdateAt;
    out->damageAt = (unsigned long long)InterlockedCompareExchange(&g_tiDamageAt, 0, 0);
    out->damageGen = (unsigned long long)InterlockedCompareExchange(&g_tiDamageGen, 0, 0);
    out->myHitAt = g_tiMyHitAt;
    out->healthValid = g_tiHealthValid;
    out->health = g_tiHealth;
    out->maxHealth = g_tiMaxHealth > 0.0f ? g_tiMaxHealth : 20.0f;
    out->skinValid = g_tiFaceValid;
    if (g_tiFaceValid) std::memcpy(out->face, g_tiFace, sizeof(out->face));
    out->hurtTime = g_tiHurtTime;
    return true;
}

void* GetTargetHudActor() {
    return g_tiTarget;
}

int GetTargetItems(void* actor, bool* outPresent, int maxOut) {
    if (!outPresent || maxOut <= 0) return 0;
    for (int i = 0; i < maxOut; ++i) outPresent[i] = false;

    // Render-thread copy of the worker-side snapshot (see ThPollTargetInfo).
    // No Container::getItem or PlayerInventoryProxy walk happens here, so a
    // world teardown can never race this call. Stale (>1 s) snapshots read as
    // empty rather than freezing the last gear on screen.
    if (!actor) return 0;
    const ULONGLONG now = GetTickCount64();
    AcquireSRWLockShared(&g_tiItemsLock);
    const bool fresh = g_tiItemsActor == actor && g_tiItemsAt != 0 &&
                       now - g_tiItemsAt <= 1000u;
    bool cached[5] = {};
    if (fresh) std::memcpy(cached, g_tiItems, sizeof(cached));
    ReleaseSRWLockShared(&g_tiItemsLock);
    if (!fresh) return 0;
    const int n = maxOut < 5 ? maxOut : 5;
    for (int i = 0; i < n; ++i) outPresent[i] = cached[i];
    return n;
}

void ServiceAutoSprint() {
    ServiceAutoSprintInternal();
}

void SetNoHurtCamEnabled(bool enabled) {
    SetNoHurtCamEnabledInternal(enabled);
}

void SetJavaInventoryEnabled(bool enabled) {
    if (!enabled) {
        InterlockedExchange(&g_javaEnabled, 0);
        InterlockedExchange(&g_javaTickSeen, 0);
        InterlockedExchange(&g_javaHoverCallbacks, 0);
        InterlockedExchange(&g_javaScreenProbeLogged, 0);
        JavaClearContext();
        LOG_INFO("java-hotkeys: disabled and queue cleared");
        return;
    }

    // Load bindings before arming the hook path. The key boundary never
    // invents a default digit mapping when options.txt is unavailable.
    InterlockedExchange(&g_javaTickSeen, 0);
    InterlockedExchange(&g_javaHoverCallbacks, 0);
    InterlockedExchange(&g_javaScreenProbeLogged, 0);
    JavaClearContext();
    JavaLoadOptions();
    JavaLoadServerHint();
    InterlockedExchange(&g_javaEnabled, 1);
    LOG_INFO("java-hotkeys: enabled hooks=%d", g_javaHooksActive ? 1 : 0);
}

void MainThread(HMODULE hModule) {
#ifdef _MSC_VER
    __try {
#endif
        // Single-instance guard. Local\ keeps one instance per user session
        // per process; a second loaded copy would fight over the DXGI vtable
        // hooks and garble nightfull.log. The handle is deliberately kept for
        // the process lifetime on the success path so the guard holds.
        HANDLE instanceMutex = CreateMutexW(nullptr, FALSE,
                                            L"Local\\NightfullOverlayInstance");
        const bool alreadyLoaded =
            instanceMutex && GetLastError() == ERROR_ALREADY_EXISTS;

        g_hmod = hModule;
        EnsureCs();

        GetModuleFileNameW(hModule, g_dllDir, MAX_PATH);
        wchar_t* slash = wcsrchr(g_dllDir, L'\\');
        if (slash) *slash = 0;

        if (!config::Init(g_dllDir)) {
            // Without a config dir we still run (defaults); logging goes to debugger only.
        }
        wchar_t logPath[MAX_PATH] = {};
        _snwprintf_s(logPath, _TRUNCATE, L"%s\\nightfull.log", config::baseDir().c_str());
        logger::Init(config::baseDir().empty() ? nullptr : logPath);
        if (alreadyLoaded) {
            // Logged after logger init so the abort lands in the shared log.
            LOG_INFO("overlay: already loaded in this process - aborting");
            if (instanceMutex) CloseHandle(instanceMutex);
            return;
        }
        LOG_INFO("config: base dir %ls", config::baseDir().c_str());
        LOG_INFO("overlay: worker started, pid=%lu", GetCurrentProcessId());
        LOG_INFO("overlay: build tag dx12i-suball-potions-poolscan-r33-safe-render");
        if (!logger::IsFileActive()) {
            // Nothing reaches any file: pop a box, or the failure stays
            // invisible (debugger-only logging helps no one here).
            wchar_t wmsg[512] = {};
            _snwprintf_s(wmsg, _TRUNCATE,
                         L"Nightfull loaded but cannot write its log file.\nLog path: %s\n"
                         L"(Check the folder is writable, and kill zombie game processes.)",
                         config::baseDir().empty() ? L"<no config dir>" : logPath);
            MessageBoxW(nullptr, wmsg, L"Nightfull", MB_OK | MB_ICONERROR | MB_TOPMOST);
        } else {
            char narrow[MAX_PATH] = {};
            WideCharToMultiByte(CP_UTF8, 0, logPath, -1, narrow, (int)sizeof(narrow),
                                nullptr, nullptr);
            LOG_INFO("overlay: log at %s", narrow);
        }

        // Wait until the game owns a real window: creating devices earlier
        // destabilizes engine startup on some builds.
        while (!g_abort && !GameWindowExists()) Sleep(250);
        if (g_abort) return;
        LOG_INFO("overlay: game window detected");

        void** vtable = nullptr;
        int attempts = 0;
        while (!g_abort && !CreateDummySwapchain(&vtable)) {
            if (++attempts % 20 == 1)
                LOG_INFO("overlay: waiting for DXGI (%d)", attempts);
            Sleep(500);
        }
        if (g_abort || !vtable) {
            LOG_ERROR("overlay: dummy swapchain failed - aborting");
            return;
        }
        g_vtable = vtable;
        PatchVTable(vtable, kPresentIndex, (void*)HkPresent, &g_oPresent);
        PatchVTable(vtable, kResizeIndex, (void*)HkResizeBuffers, &g_oResize);
        LOG_INFO("overlay: hooks live (present=%p resize=%p)", g_oPresent, g_oResize);

        // Actor::baseTick signature scanning can take hundreds of milliseconds
        // on the Bedrock image. It must never be performed by Hitboxes::render:
        // prepare the registry hook on this worker thread instead.
        Sleep(1000);
        // Deterministic startup ordering: do not arm the game hooks until the
        // hooked Present has actually run. A half-failed injection now shows
        // exactly at which stage it stalled instead of looking like a miss.
        {
            int waitedMs = 0;
            while (!g_abort && !InterlockedCompareExchange(&g_presentSeen, 0, 0) &&
                   waitedMs < 5000) {
                Sleep(50);
                waitedMs += 50;
            }
            if (InterlockedCompareExchange(&g_presentSeen, 0, 0))
                LOG_INFO("overlay: present observed");
            else
                LOG_ERROR("overlay: present NOT observed within 5000 ms");
        }
        if (!g_abort) {
            TryInstallBaseTickHook();
            TryInstallHitboxLevelRenderHook();
            // Start the sampler before the first setup snapshot. It owns the
            // local-context bootstrap and all component/AABB reads.
            HitboxEnsureOwnerRefreshThread();
            TryInstallPingHook();
            TryInstallReachHook();
        }

        // The worker's job is done; everything else runs on hooked threads
        // (unload is serialized in the HkPresent tail). Park here, but keep
        // supervising the AABB sampler: it owns every cached box, and a silent
        // death used to take the whole ESP with it until the game was restarted.
        while (!g_abort) {
            Sleep(500);
            if (g_shuttingDown) break;
            HitboxEnsureOwnerRefreshThread();
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        LOG_ERROR("overlay: fatal exception in worker thread");
    }
#endif
}

void NotifyDetach() {
    g_abort = true;
    g_shuttingDown = true;
    g_showMenu = false;
    g_hudEdit = false;
    InterlockedExchange(&g_javaEnabled, 0);
    if (g_javaCsInit) JavaClearContext();
    RestoreGameGuiScale();
    RestoreNoHurtCamPatch();
    // Best effort, never blocking: the process is going away.
    RestoreWndHook();
    if (g_csInit) {
        if (TryEnterCriticalSection(&g_renderCs)) {
            TeardownRender();
            LeaveCriticalSection(&g_renderCs);
        }
    }
    RestoreVTable();
}

} // namespace overlay
} // namespace nf
