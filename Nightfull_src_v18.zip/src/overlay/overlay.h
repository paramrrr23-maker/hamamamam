// overlay.h - the engine facade: lifecycle + shared menu state.
//
// The overlay owns: DXGI Present/ResizeBuffers interception (direct vtable
// patch, no MinHook), D3D11 primary + D3D12 (own command queue) rendering,
// the WndProc input subclass, cursor arbitration and clean unload.
// Game integration is deliberately limited to validated, exact game input/UI
// boundaries. Gameplay memory is never written directly; the optional
// Java-like inventory path calls only controller UI actions after its
// signature, focus, screen and controller checks pass.

#pragma once

#include <Windows.h>

namespace nf {
namespace overlay {

// Menu visibility (written by the hotkey path, read by menu + HUD gating).
extern bool g_showMenu;
// ClickGUI toggle key (default INSERT; editable from the menu quick settings).
extern int g_menuKey;
// Free-form HUD editor (Flarial editmenu parity): while true (and the
// ClickGUI is closed) every draggable HUD element draws its edit box and the
// input-ownership gates treat the session like an open menu. Written by
// HudEditSet / the hotkey path, read by menu + HUD gating.
extern bool g_hudEdit;
// HUD editor state + toggles (logs; the editor's own drag state lives in the
// HUD modules). HudEditActive() is the read-side used by menu + HUD code.
bool HudEditActive();
void HudEditSet(bool enabled);

// Render-thread mouse snapshot owned by the GUI input path. These are updated
// immediately before ImGui::NewFrame so the custom draw-list UI can use the
// same button edges even when in-world Bedrock does not emit legacy WM_* mouse
// messages. Indexes match ImGui buttons: 0=LMB, 1=RMB, 2=MMB, 3/4=X buttons.
extern bool g_guiMouseDown[5];
extern bool g_guiMousePressed[5];
extern bool g_guiMouseReleased[5];
// Wheel delta captured by the custom in-world input bridge for the current
// frame. The native ClickGUI reads this directly instead of relying only on
// ImGui's backend wheel field, which can be consumed before custom painting.
extern float g_guiMouseWheel;
extern float g_guiMouseWheelH;

// Worker thread body (spawned from DllMain, never on the loader lock).
void MainThread(HMODULE hModule);

// Best-effort teardown on process detach (never blocks).
void NotifyDetach();

// The gameplay modules use the existing hook layer rather than carrying a
// second input/render implementation. These calls are no-ops until the
// corresponding exact, unique game signature is found.
void ServiceAutoSprint();
void SetNoHurtCamEnabled(bool enabled);

// Java-like inventory hotkeys. The hooks are installed once by the existing
// game integration path; this only changes the module's live enabled state
// and clears its controller-bound queue on disable.
void SetJavaInventoryEnabled(bool enabled);

// Read-only local-player effect snapshot for the Potions HUD. The reader uses
// a uniquely resolved Bedrock component accessor and returns zero when the
// current game build cannot be proven safe; it never writes game memory.
struct PotionEffect {
    unsigned int id = 0;
    int duration = 0;
    int amplifier = 0;
    bool noCounter = false;
};
int GetPotionEffects(PotionEffect* out, int maxOut);
bool IsInWorld();

// Read-only world/entity bridge used by the Hitboxes module. All functions
// fail closed when the current Bedrock layout/signatures cannot be proven.
// Actor pointers are short-lived registry entries; callers must not retain
// them between frames.
void UpdateCritCamera();
void TryInstallBaseTickHook();
bool ProjectWorldToScreen(const float pos[3], float* outX, float* outY,
                         float* outDepth = nullptr);
float GetCritFocalPx();
bool GetCameraWorldPosition(float out[3]);
int GetHitboxMatrixMode();
int GetActors(void** out, int maxOut);
// Live Hitboxes render radius, shared with the background AABB scheduler so
// distant owner entries do not starve nearby actors' position refreshes.
void SetHitboxMaxDistance(float blocks);
bool ActorReadAabb(void* actor, float mins[3], float maxs[3]);
// Look direction cache (worker thread reads ActorRotationComponent, render
// thread only consumes the cache). Pitch/yaw in degrees, Flarial convention
// (x = pitch, y = yaw). False when the pool cannot be proven for this build
// or the entry has no fresh sample - callers must hide the look line then.
bool ActorReadRotation(void* actor, float* pitchDeg, float* yawDeg);
// True when the actor is the worker's current local player (for Show self).
bool IsHitboxLocalPlayer(void* actor);
// Coarse actor class for the Hitboxes "Targets" filter. 0 = unknown (the
// category word was unreadable or implausible), 1 = player, 2 = mob,
// 3 = other entity. Callers must treat 0 as "cannot tell" and fail open.
int GetActorClass(void* actor);
// Hitboxes occlusion: false (default) hides boxes behind walls through the
// game's own canSee raycast; true restores through-wall boxes.
void SetHitboxThroughWalls(bool enabled);
// Flarial Sprint parity ("Always Sprint"): while enabled, the local player's
// MoveInputComponent sprint flags are set on every game tick from the
// Actor::baseTick hook. Disabled = no writes, vanilla input rules.
void SetAutoSprintEnabled(bool enabled);
// Latest RakNet average ping in ms, or -1 when stale/absent (singleplayer).
int GetPingMs();
// MinHook detour on RakPeer::GetAveragePing feeding GetPingMs (1.21.11x sig).
void TryInstallPingHook();

// True only while the plain in-game HUD is the top screen (no chat, pause,
// inventory or any other game screen). Module keybinds are gated on this.
bool IsGameplayScreen();
// VSync Disabler: forces SyncInterval=0 on every hooked DXGI Present call.
void SetVSyncDisabled(bool enabled);
// Saturation (Flarial HueChanger parity): a full-screen saturation filter on
// the GAME frame in the backbuffer, applied before the ImGui overlay draws,
// so the HUD/ClickGUI is never saturated. Intensity is clamped to 0.0..3.0
// (D2D1 Saturation semantics: 0 = grayscale, 1 = unchanged, >1 = oversat).
void SetSaturationEnabled(bool enabled);
void SetSaturationIntensity(float value);
// GPU-fault latch for the pass: called when the D3D12 device is removed
// (GetDeviceRemovedReason fails, or Present itself returns a device-removed
// family HRESULT). Latches the sticky fail-closed flag - the pass stays off
// for the rest of the session across teardown and reinit - and logs once.
// Creation failures are NOT sticky: they arm a 5 s cooldown instead, so a
// device that was not ready on the first enable recovers by itself. Safe to
// call from any thread.
void SaturationGpuFault();
// Motion Blur: frame-accumulation blur on the GAME frame (after Saturation,
// before the UI blur and ImGui). Enabled toggles the pass; a 0->1 edge drops
// the history so the first blurred frame starts clean. Intensity 0..0.95,
// mode 0 = Blend (accumulated trail), 1 = Ghost (previous frame only).
// fpsIndependent rescales the per-frame factor to refFps so the trail length
// does not change with the frame rate. Device removal latches it off
// together with Saturation (SaturationGpuFault).
void SetMotionBlurEnabled(bool enabled);
void SetMotionBlurParams(float intensity, int mode, bool fpsIndependent, float refFps);
// UI blur (white glass backdrop for the ClickGUI): SetUiBlurEnabled mirrors
// the General "UI Blur" setting; SetUiBlurStrength is pushed per frame from
// ui::Frame with the menu open animation (1.0 in the HUD editor), so the
// glass fades in/out with the menu. The pass itself runs in the overlay
// before ImGui draws, only while a non-zero strength is armed - zero cost
// while the GUI is closed.
void SetUiBlurEnabled(bool enabled);
void SetUiBlurStrength(float value);
void SetUiBlurTint(float r, float g, float b);   // theme-accent glass tint
// Null Movement: on the Keyboard::feed boundary, the last pressed of each
// enabled opposite pair (A/D, W/S) wins; the other key is suppressed until
// the winner is released (then re-pressed if still physically held).
void SetNullMovementEnabled(bool enabled);
void SetNullMovementPairs(bool ad, bool ws);
// CPS Limiter: presses above the per-second limit never reach the game
// through the hooked mouse feed (Flarial CPSLimiter parity).
void SetCpsLimiterEnabled(bool enabled);
void SetCpsLimits(int left, int right);
// Clicks actually delivered to the game in the last second (post-limiter),
// for the CPS counter HUD. left=false reads the RMB gate.
int GetRegisteredCps(bool left);
// Last hit reach in blocks (Flarial ReachCounter behavior: 0.00 until the
// first landed attack, value updates per hit, resets to 0 after 15 s idle).
float GetReachValue();

// Target HUD snapshot. Selection = the player under the crosshair (render
// thread projects the frame packet's hitboxes, UpdateTargetLook); the card
// stays while looked at and hides lookHideMs after the crosshair leaves.
// damageGen advances when the TARGET receives damage (Actor::hurtTime rising
// edge - the same source Flarial's HurtColor uses - with the synched Hurt
// flag as fallback), never on my own clicks. Health comes from the
// AttributesComponent (Health id 6 on 1.21.11x); healthValid=false when the
// layout could not be proven. face[] is the 8x8 skin face with the hat layer
// composited (IM_COL32 order), valid only when skinValid.
struct TargetHudInfo {
    bool visible;
    char name[24];
    float pos[3];
    unsigned long long updateAt;
    unsigned long long damageAt;
    unsigned long long damageGen;
    unsigned long long myHitAt;
    bool healthValid;
    float health;
    float maxHealth;
    bool skinValid;
    unsigned int face[64];
    int hurtTime;          // 0..10 live hurt ticks (red tint), -1 unknown
};
// Render thread, once per frame while the Target HUD is enabled: picks the
// player whose hitbox is under the crosshair within maxRange blocks.
void UpdateTargetLook(float maxRange, int hideMs);
bool GetTargetHudInfo(TargetHudInfo* out);
// Actor behind the current Target HUD snapshot, or null. Short-lived: only
// meaningful while GetTargetHudInfo reports visible.
void* GetTargetHudActor();
// Target HUD equipment strip (PacketV2 TargetHUD parity: its armor loop plus
// the held item). outPresent[0..3] are the armor slots, outPresent[4] is the
// held item; a slot is true only when it holds an item. The armor path is the
// proven ActorEquipmentComponent -> mArmorContainer -> Container::getItem
// (vtable slot 7) chain the Hitboxes armor probe already uses; the held item
// goes through PlayerInventoryProxy and is skipped - not guessed - when that
// layout cannot be validated on the live build. Returns the number of slots
// actually probed (0 when even the equipment component is unavailable).
// Never writes game memory, and the whole probe is fault-contained.
int GetTargetItems(void* actor, bool* outPresent, int maxOut);
// PacketV2 idea: per-actor AABB cache refresh on the game tick thread; armed
// by the Hitboxes module so disabled hitboxes cost nothing.
void SetHitboxTickRefresh(bool enabled);

} // namespace overlay
} // namespace nf
