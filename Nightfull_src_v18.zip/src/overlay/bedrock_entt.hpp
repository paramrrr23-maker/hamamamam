// bedrock_entt.hpp - Bedrock entity-component access, replicating Flarial's
// SDK (EntityContext.hpp + MobEffectsComponent.hpp) on top of the pinned
// vanilla entt (skypjack/entt @ 303801c, vendored in third_party/entt).
//
// CRITICAL: the component structs below live in the GLOBAL namespace with
// the exact names the game uses ("MobEffectsComponent", "MobEffectInstance",
// "EntityId", ...). entt keys component pools by a compile-time hash of the
// MSVC FUNCSIG of the type_hash<T> instantiation, which embeds the type name
// as written - so our instantiation hashes to the SAME pool key as the
// game's own component access code. Do not rename or wrap in a namespace.
//
// NOTE: ASCII only in this file. Effect display names live in the HUD module.

#pragma once

#include <cstdint>
#include <string>
#include <type_traits>
#include <vector>

#include <entt/entt.hpp>

class EntityId;

// ---- EntityId (Bedrock packs ids with 0x3FFFF entity / 0x3FFF version) ----
struct EntityIdTraits {
    using value_type = EntityId;  // fwd-declared below

    using entity_type  = std::uint32_t;
    using version_type = std::uint16_t;

    static constexpr entity_type entity_mask  = 0x3FFFF;
    static constexpr entity_type version_mask = 0x3FFF;
};

template <>
class entt::entt_traits<EntityId>
    : public entt::basic_entt_traits<EntityIdTraits> {
public:
    static constexpr entity_type page_size = 2048;
};

class EntityId : public entt::entt_traits<EntityId> {
public:
    entity_type mRawId{};

    constexpr EntityId() = default;
    template <typename T, typename = std::enable_if_t<std::is_integral<T>::value>>
    constexpr EntityId(T rawId) : mRawId(static_cast<entity_type>(rawId)) {}

    [[nodiscard]] constexpr bool isNull() const { return *this == entt::null; }
    [[nodiscard]] constexpr operator entity_type() const { return mRawId; }
    constexpr bool operator==(const EntityId& other) const { return mRawId == other.mRawId; }
};

struct IEntityComponent {};

// Component traits for Bedrock entities (in-place delete, 128-page), same as
// Flarial's EntityContext.hpp.
template <typename Type>
struct entt::component_traits<Type, std::enable_if_t<std::is_base_of_v<IEntityComponent, Type>>> {
    using type = Type;
    static constexpr bool in_place_delete = true;
    static constexpr std::size_t page_size = 128 * !std::is_empty_v<Type>;
};

template <typename Type>
struct entt::storage_type<Type, EntityId> {
    using type = entt::basic_storage<Type, EntityId>;
};

// ---- MobEffectsComponent (global names matching the game's own) -----------
// The vector element type is irrelevant for the pool key (only the class
// name is hashed); the real instances are read through the 1.21.30 layout.
struct MobEffectInstance {};

struct MobEffectsComponent : IEntityComponent {
    std::vector<MobEffectInstance> effects;
};

// World-space components used by the read-only entity ESP path. These names
// intentionally match Flarial's global component names so EnTT type hashes
// resolve the same Bedrock pools on the validated 1.21.11x layout.
struct AABBShapeComponent : IEntityComponent {
    float aabbLower[3];
    float aabbUpper[3];
    float sizeX;
    float sizeY;
};
static_assert(sizeof(AABBShapeComponent) == 0x20);

struct StateVectorComponent : IEntityComponent {
    float Pos[3];
    float PrevPos[3];
    float velocity[3];
};
static_assert(sizeof(StateVectorComponent) == 0x24);

struct RenderPositionComponent : IEntityComponent {
    float renderPos[3];
};
static_assert(sizeof(RenderPositionComponent) == 0x0C);

// Actor look direction (Flarial's ActorRotationComponent.hpp, verbatim).
// Same global-name rule as above: the EnTT pool key is hashed from the type
// name, so this must stay a global "struct ActorRotationComponent".
struct ActorRotationComponent : IEntityComponent {
    float rot[2];      // x = pitch, y = yaw, degrees
    float rotPrev[2];
};
static_assert(sizeof(ActorRotationComponent) == 0x10);

// Synched actor flags (Flarial's ActorDataFlagComponent.hpp, verbatim size).
// Bit 5 == ActorFlags::FLAG_INVISIBLE. Only the raw bytes are consumed, so
// the std::bitset word layout does not matter for bit indexes below 32.
struct ActorDataFlagComponent : IEntityComponent {
    unsigned char flags[16];
};
static_assert(sizeof(ActorDataFlagComponent) == 0x10);

// Equipment (Flarial's ActorEquipmentComponent.hpp): two container pointers.
// mArmorContainer holds the four armor slots.
struct ActorEquipmentComponent : IEntityComponent {
    void* mOffhandContainer;   // +0x0
    void* mArmorContainer;     // +0x8
};
static_assert(sizeof(ActorEquipmentComponent) == 0x10);

// Player movement input (pool key only). The game's own type name is
// "MoveInputComponent" in every version, but the FIELD LAYOUT differs:
// 1.21.11x stores individual bool bytes (mSprintDown at state+0x8, state size
// 0x28, sprinting bool at +0x95), 1.21.120+ packs 32-bit flag words
// (SprintDown = bit 8 at +0x0/+0x10, Sprinting = bit 1 of the uint16 at
// +0x60). The writer probes which layout is live instead of committing to
// one, so this body is intentionally opaque.
struct MoveInputComponent : IEntityComponent {
    unsigned char storage[0xA8];
};

// Synched actor data (Flarial's SynchedActorDataComponent.hpp, size 0x48).
// +0x00 holds the std::vector<DataItem*> array; per-item values sit at
// +0x0C inside each DataItem2<T>. Data id 11 ("Hurt") flips on while the
// entity is playing its hurt reaction - the server-driven "took damage"
// signal used by the Target HUD particles.
struct SynchedActorDataComponent : IEntityComponent {
    unsigned char storage[0x48];
};
static_assert(sizeof(SynchedActorDataComponent) == 0x48);

// AttributesComponent (Flarial SDK): BaseAttributeMap, 88 bytes. Pre-1.21.130
// the map is std::unordered_map<uint, AttributeInstance> at +0x00 (64 bytes)
// followed by the dirty vector. Only the pool key (global struct name) and
// the size matter here; the map is walked by hand in overlay.cpp.
struct AttributesComponent : IEntityComponent {
    alignas(8) unsigned char storage[88];
};
static_assert(sizeof(AttributesComponent) == 88);

// ---- Typed view over the effect vector (1.21.30+ instance layout) ---------
struct MobEffectInstanceData1_21_30 {
    std::uint32_t id;            // MobEffect::EffectType
    int duration;                // in ticks (20 == 1 s)
    float unknown;
    int durationEasy;
    int durationNormal;
    int durationHard;
    char pad_0018[0x8];
    int amplifier;
    bool displayOnScreenTextureAnimation;
    bool ambient;
    bool noCounter;
    bool effectVisible;
    char pad_0028[0x60];
};
static_assert(sizeof(MobEffectInstanceData1_21_30) == 0x88);

// ---- EntityContext (lives at Actor + 0x8, verbatim layout) ----------------
namespace V1_20_50 {

class EntityRegistry : public std::enable_shared_from_this<EntityRegistry> {
public:
    std::string name;
    entt::basic_registry<EntityId> ownedRegistry;
    std::uint32_t id;
};

struct EntityContext {
    EntityRegistry& registry;
    entt::basic_registry<EntityId>& enttRegistry;
    EntityId entity;

    [[nodiscard]] bool isValid() const { return enttRegistry.valid(entity); }

    template <typename T>
    [[nodiscard]] T* tryGetComponent() {
        if (!isValid()) return nullptr;
        return enttRegistry.try_get<T>(entity);
    }
};
static_assert(sizeof(EntityContext) == 0x18);

} // namespace V1_20_50
