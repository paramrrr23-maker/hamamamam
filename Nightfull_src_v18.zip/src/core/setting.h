// setting.h - typed module settings (header-only).
//
// Every setting owns its storage, a display name/description, an optional
// keybind (bool settings can be bound) and a visibility predicate that the
// menu evaluates every frame. The config system serializes settings by
// (module name, setting name), so names are stable API: never rename them.

#pragma once

#include <cmath>
#include <functional>
#include <string>
#include <vector>

#include "imgui.h"

namespace nf {

enum class SettingType { Bool, Number, Enum, Color, String };

class Setting {
public:
    Setting(std::string name, std::string desc, SettingType type)
        : mName(std::move(name)), mDescription(std::move(desc)), mType(type) {}
    virtual ~Setting() = default;

    Setting(const Setting&) = delete;
    Setting& operator=(const Setting&) = delete;

    std::string mName;
    std::string mDescription;
    SettingType mType;
    int mKey = 0;                                        // 0 = unbound
    std::function<bool()> mIsVisible = [] { return true; };
};

class BoolSetting : public Setting {
public:
    BoolSetting(const std::string& n, const std::string& d, bool v)
        : Setting(n, d, SettingType::Bool), mValue(v) {}
    bool mValue;
    float mAnim = 0.0f;                                  // menu toggle glide
};

class NumberSetting : public Setting {
public:
    NumberSetting(const std::string& n, const std::string& d, float v,
                  float mn, float mx, float step)
        : Setting(n, d, SettingType::Number), mValue(v),
          mMin(mn), mMax(mx), mStep(step > 0.0f ? step : 0.01f) {}
    void setValue(float v) {
        if (v < mMin) v = mMin;
        if (v > mMax) v = mMax;
        mValue = mMin + std::round((v - mMin) / mStep) * mStep;   // snap-to-step
        if (mValue < mMin) mValue = mMin;
        if (mValue > mMax) mValue = mMax;
    }
    float mValue, mMin, mMax, mStep;
};

class EnumSetting : public Setting {
public:
    EnumSetting(const std::string& n, const std::string& d, int v,
                std::vector<std::string> values)
        : Setting(n, d, SettingType::Enum), mValues(std::move(values)) { setValue(v); }
    void setValue(int v) {
        const int n = (int)mValues.size();
        mValue = (n > 0) ? ((v % n) + n) % n : 0;                 // wrapping
    }
    const std::string& current() const {
        static const std::string kEmpty;
        return (mValue >= 0 && mValue < (int)mValues.size()) ? mValues[mValue] : kEmpty;
    }
    int mValue = 0;
    std::vector<std::string> mValues;
};

class ColorSetting : public Setting {
public:
    ColorSetting(const std::string& n, const std::string& d,
                 float r, float g, float b, float a = 1.0f)
        : Setting(n, d, SettingType::Color) { mValue[0] = r; mValue[1] = g; mValue[2] = b; mValue[3] = a; }
    ColorSetting(const std::string& n, const std::string& d, unsigned int argb)
        : Setting(n, d, SettingType::Color) {
        mValue[0] = ((argb >> 16) & 0xFF) / 255.0f;
        mValue[1] = ((argb >> 8) & 0xFF) / 255.0f;
        mValue[2] = (argb & 0xFF) / 255.0f;
        mValue[3] = ((argb >> 24) & 0xFF) / 255.0f;
    }
    ImColor getAsImColor() const { return ImColor(mValue[0], mValue[1], mValue[2], mValue[3]); }
    float mValue[4] = { 1, 1, 1, 1 };
};

class StringSetting : public Setting {
public:
    StringSetting(const std::string& n, const std::string& d,
                  std::string v, size_t maxLen)
        : Setting(n, d, SettingType::String), mValue(std::move(v)), mMaxLength(maxLen) {}
    std::string mValue;
    size_t mMaxLength;
};

} // namespace nf
