// module_guard.cpp - crash- and hang-contained module callback invoker.

#include "core/module_guard.h"

#include <Windows.h>
#include <cstring>

#include "core/module.h"
#include "utils/logger.h"

namespace nf {

const char* g_activeModule = nullptr;
const char* g_activePhase = nullptr;

// Auto-disable watchdog thresholds. The old 100 ms single-shot threshold
// killed legitimately slow first-enables (Potions' first registry read,
// Keybinds' plate warm-up, TargetHud's first 24-burst allocation): the module
// was silently switched OFF, the user re-toggled it, the second attempt ran
// warm and survived - the "needs OFF->ON twice" symptom. Now:
//   * kSlowMs     - a callback above this is logged (rate-limited) but never
//                   auto-disables on its own.
//   * kDisableMs  - the hard watchdog ceiling. Only a callback that is BOTH
//                   above kSlowMs on the previous call of the same
//                   (module, phase) AND above kDisableMs now is disabled: a
//                   repeated offense, not a warm-up hiccup.
//   * kLogPeriodMs - one slow line per module+phase per 5 s.
static constexpr double kSlowMs = 100.0;
static constexpr double kDisableMs = 1000.0;
static constexpr ULONGLONG kLogPeriodMs = 5000;

// Per-(module, phase) watchdog state. Module pointers are stable for the
// session (the registry owns the roster); a fixed slot pool keeps this
// allocation-free (the guard may run on the hot render path).
struct SlowTrack {
    const Module* mod = nullptr;
    unsigned phase = 0;
    bool slowLast = false;          // the previous call exceeded kSlowMs
    ULONGLONG nextLogAt = 0;        // rate limit for the slow/auto-disable lines
};

static SlowTrack g_slowTrack[16] = {};
static int g_slowTrackHead = 0;

// Performance-counter frequency: a process-lifetime constant, so it is read
// once instead of on every callback (20+ guard calls per frame across the
// roster). Kept as a namespace-scope pair rather than a function-local static
// because a dynamically initialised static would require the magic-static
// guard, and MSVC then refuses to compile the __try in ModulePhaseGuard::run
// at all (C2712).
LARGE_INTEGER g_qpcFreq{};
bool g_qpcFreqReady = false;

static SlowTrack* FindSlowTrack(const Module* m, unsigned phase) {
    for (SlowTrack& t : g_slowTrack)
        if (t.mod == m && t.phase == phase) return &t;
    SlowTrack& slot = g_slowTrack[g_slowTrackHead];
    g_slowTrackHead = (g_slowTrackHead + 1) % 16;
    slot.mod = m;
    slot.phase = phase;
    slot.slowLast = false;
    slot.nextLogAt = 0;
    return &slot;
}

const char* ModulePhaseGuard::phaseName(Phase phase) {
    switch (phase) {
        case Phase::Enable:  return "enable";
        case Phase::Disable: return "disable";
        case Phase::Tick:    return "tick";
        case Phase::Render:  return "render";
        default:             return "?";
    }
}

void ModulePhaseGuard::run(Module* m, Phase phase) {
    if (!m) return;
    const char* pname = phaseName(phase);
    g_activeModule = m->name();
    g_activePhase = pname;

    // Read the timer frequency once, not on every callback.
    if (!g_qpcFreqReady) {
        QueryPerformanceFrequency(&g_qpcFreq);
        g_qpcFreqReady = true;
    }
    LARGE_INTEGER t0{}, t1{};
    QueryPerformanceCounter(&t0);

#ifdef _MSC_VER
    __try {
#endif
        switch (phase) {
            case Phase::Enable:  m->onEnable();  break;
            case Phase::Disable: m->onDisable(); break;
            case Phase::Tick:    m->onTick();    break;
            case Phase::Render:  m->onRender();  break;
        }
#ifdef _MSC_VER
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        LOG_ERROR("guard: fault in %s::%s - module auto-disabled", m->name(), pname);
        m->setEnabled(false);
        g_activeModule = nullptr;
        g_activePhase = nullptr;
        return;
    }
#endif

    QueryPerformanceCounter(&t1);
    if (g_qpcFreq.QuadPart > 0) {
        const double ms = (double)(t1.QuadPart - t0.QuadPart) * 1000.0 / (double)g_qpcFreq.QuadPart;
        const ULONGLONG now = GetTickCount64();
        SlowTrack* track = FindSlowTrack(m, static_cast<unsigned>(phase));

        if (ms > kSlowMs) {
            // Repeated offense: the SAME (module, phase) was already above the
            // slow threshold on its previous call. A one-off warm-up hitch
            // only logs now; a callback that stays slow call after call and
            // also breaches the hard ceiling is genuinely wedged.
            const bool repeated = track->slowLast;
            track->slowLast = true;
            const bool mayLog = now >= track->nextLogAt;
            if (mayLog) track->nextLogAt = now + kLogPeriodMs;

            // Hitboxes has a bounded, cache-filling first pass. Do not turn a
            // transient warm-up hitch into a permanent feature disable; the
            // actor/AABB reader fails closed on subsequent frames. Other
            // modules retain the watchdog behaviour above.
            if (std::strcmp(m->name(), "Hitboxes") == 0) {
                if (mayLog)
                    LOG_ERROR("guard: %s::%s took %.1f ms - kept enabled (warm-up)",
                              m->name(), pname, ms);
            } else if (repeated && ms > kDisableMs) {
                if (mayLog)
                    LOG_ERROR("guard: %s::%s took %.1f ms (slow twice in a row) - module auto-disabled",
                              m->name(), pname, ms);
                m->setEnabled(false);
            } else if (mayLog) {
                // A single slow phase is informative, not fatal: the next call
                // is usually warm.
                LOG_ERROR("guard: %s::%s took %.1f ms - kept enabled (single slow phase)",
                          m->name(), pname, ms);
            }
        } else {
            track->slowLast = false;
            if (ms > 5.0) {
                // Rate-limited for EVERY module, not only Hitboxes. An
                // unthrottled "slow" line writes to disk (logger::Write uses an
                // unbuffered WriteFile) on every frame of a persistently slow
                // callback - which makes the very slowness it reports worse.
                if (now >= track->nextLogAt) {
                    track->nextLogAt = now + 1000u;
                    LOG_INFO("guard: %s::%s slow (%.1f ms)", m->name(), pname, ms);
                }
            }
        }
    }
    g_activeModule = nullptr;
    g_activePhase = nullptr;
}

} // namespace nf
