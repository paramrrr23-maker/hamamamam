// module.h - the Module base class.
//
// A module is: identity (category/name/description) + enabled state +
// optional keybind + an ordered list of settings + lifecycle callbacks.
// Creating a feature = subclassing Module, declaring settings in the ctor
// with addSetting<T>(), overriding onTick/onRender, and adding one line to
// the registry (src/modules/registry.cpp). Nothing else is required: the
// menu, the config and the HUD lists pick the module up automatically.

#pragma once

#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "core/setting.h"

namespace nf {

class Module {
public:
    Module(const char* category, const char* name, const char* description)
        : mCategory(category ? category : ""), mName(name ? name : ""),
          mDescription(description ? description : "") {}
    virtual ~Module() = default;

    Module(const Module&) = delete;
    Module& operator=(const Module&) = delete;

    // -- identity / state ---------------------------------------------------
    const char* category() const { return mCategory.c_str(); }
    const char* name() const { return mName.c_str(); }
    const char* description() const { return mDescription.c_str(); }
    bool enabled() const { return mEnabled; }
    void setEnabled(bool v) { mEnabled = v; }
    void toggle() { mEnabled = !mEnabled; }
    int key() const { return mKey; }
    void setKey(int vk) { mKey = vk; }

    // -- settings ------------------------------------------------------------
    template <typename T, typename... Args>
    T* addSetting(Args&&... args) {
        auto s = std::make_unique<T>(std::forward<Args>(args)...);
        T* ptr = s.get();
        mSettings.push_back(std::move(s));
        return ptr;
    }
    const std::vector<std::unique_ptr<Setting>>& settings() const { return mSettings; }
    Setting* findSetting(const char* settingName) const {
        for (const auto& s : mSettings)
            if (s->mName == settingName) return s.get();
        return nullptr;
    }

    // -- menu / list behaviour ------------------------------------------------
    // hiddenFromLists: client-config modules (menu, theme) and always-on HUD
    // chrome (watermark, arraylist) set this so the Arraylist, Keybinds HUD
    // and "Active modules" panel skip them. Explicit flag, never name-matching.
    bool hiddenFromLists = false;
    // Per-module menu animation state (owned by the module, driven by the menu).
    float cardAnim = 0.0f;    // settings reveal 0..1 (unused by inline cards, kept for styles)
    float toggleAnim = 0.0f;  // toggle glide 0..1
    bool uiExpanded = false;  // inline settings unfolded under the card/row
    float uiExpandT = 0.0f;   // unfold amount 0..1 (spring-animated)
    float uiExpandVel = 0.0f; // unfold spring velocity
    float hoverLift = 0.0f;   // hover bounce spring position
    float hoverLiftVel = 0.0f;// hover bounce spring velocity

    // -- lifecycle (all invoked through ModulePhaseGuard) ---------------------
    virtual void onEnable() {}
    virtual void onDisable() {}
    virtual void onTick() {}    // per-frame logic (cheap; may run while menu open)
    virtual void onRender() {}  // per-frame drawing (ImGui draw lists)

protected:
    std::string mCategory, mName, mDescription;
    bool mEnabled = false;
    int mKey = 0;
    std::vector<std::unique_ptr<Setting>> mSettings;
};

} // namespace nf
