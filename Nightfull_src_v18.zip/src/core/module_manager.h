// module_manager.h - singleton owner of the module roster.

#pragma once

#include <memory>
#include <vector>

namespace nf {

class Module;

class ModuleManager {
public:
    static ModuleManager& instance();

    void add(std::unique_ptr<Module> m) { mModules.push_back(std::move(m)); }
    const std::vector<std::unique_ptr<Module>>& modules() const { return mModules; }

    Module* find(const char* name) const;
    bool toggle(const char* name);   // find + toggle; false when missing

private:
    ModuleManager() = default;
    std::vector<std::unique_ptr<Module>> mModules;
};

inline ModuleManager& modules() { return ModuleManager::instance(); }

} // namespace nf
