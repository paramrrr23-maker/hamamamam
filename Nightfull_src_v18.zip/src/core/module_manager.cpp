// module_manager.cpp - singleton owner of the module roster.

#include "core/module_manager.h"

#include <cstring>

#include "core/module.h"

namespace nf {

ModuleManager& ModuleManager::instance() {
    static ModuleManager inst;
    return inst;
}

Module* ModuleManager::find(const char* name) const {
    if (!name) return nullptr;
    for (const auto& m : mModules)
        if (std::strcmp(m->name(), name) == 0) return m.get();
    return nullptr;
}

bool ModuleManager::toggle(const char* name) {
    Module* m = find(name);
    if (!m) return false;
    m->toggle();
    return true;
}

} // namespace nf
