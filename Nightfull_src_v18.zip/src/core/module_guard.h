// module_guard.h - crash- and hang-contained module callback invoker.
//
// Every module callback (enable/disable/tick/render) runs through
// ModulePhaseGuard::run(). A faulting module is caught by SEH, logged and
// auto-disabled instead of killing the game. A slow callback (>100 ms) is
// logged (rate-limited to one line per module+phase per 5 s) but a SINGLE
// slow call never disables the module - that killed legitimate warm-up
// first-enables and forced a re-toggle to work. Auto-disable now requires a
// repeated offense: the same (module, phase) was slow on its previous call
// AND exceeds the 1000 ms hard ceiling this call. Hitboxes keeps its
// bounded warm-up pass enabled regardless. A callback between 5 and 100 ms
// logs an info line. g_activeModule/g_activePhase expose the in-flight
// callback for debuggers and watchdogs.

#pragma once

namespace nf {

class Module;

class ModulePhaseGuard {
public:
    enum class Phase { Enable, Disable, Tick, Render };

    static void run(Module* m, Phase phase);
    static const char* phaseName(Phase phase);
};

// In-flight callback markers (watchdog/debugger visibility).
extern const char* g_activeModule;
extern const char* g_activePhase;

} // namespace nf
